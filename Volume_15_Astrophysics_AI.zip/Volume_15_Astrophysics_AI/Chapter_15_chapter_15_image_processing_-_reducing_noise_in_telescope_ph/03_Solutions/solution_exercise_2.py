
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
from skimage import filters, util
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim

# --- Simulation Data ---
# Ground Truth (Clean image)
size = 100
X, Y = np.meshgrid(np.linspace(-1, 1, size), np.linspace(-1, 1, size))
ground_truth = np.exp(-(X**2 + Y**2) / 0.1)
ground_truth = (ground_truth - ground_truth.min()) / (ground_truth.max() - ground_truth.min())

# Create Noisy Input
noisy_input = ground_truth + np.random.normal(0, 0.05, ground_truth.shape)
noisy_input = util.random_noise(noisy_input, mode='s&p', amount=0.01)
noisy_input = np.clip(noisy_input, 0, 1)

# Image A: Gaussian result (High blurring)
image_a = filters.gaussian(noisy_input, sigma=1.5) 

# Image B: Optimized Median result (Better edge preservation)
image_b = filters.median(noisy_input, np.ones((3, 3)))

# Ensure all images are clipped to [0, 1] for metrics calculation
ground_truth = np.clip(ground_truth, 0, 1)
image_a = np.clip(image_a, 0, 1)
image_b = np.clip(image_b, 0, 1)
# -----------------------

# 1. Calculate PSNR scores (data_range=1.0 for normalized floats)
psnr_a = psnr(ground_truth, image_a, data_range=1.0)
psnr_b = psnr(ground_truth, image_b, data_range=1.0)

# 2. Calculate SSIM scores (data_range=1.0)
ssim_a = ssim(ground_truth, image_a, data_range=1.0)
ssim_b = ssim(ground_truth, image_b, data_range=1.0)

print(f"--- Quantitative Denoising Comparison ---")
print(f"PSNR (Image A - Gaussian): {psnr_a:.2f} dB")
print(f"PSNR (Image B - Median): {psnr_b:.2f} dB")
print(f"SSIM (Image A - Gaussian): {ssim_a:.4f}")
print(f"SSIM (Image B - Median): {ssim_b:.4f}")
print("-----------------------------------------")

# 3. Result Interpretation (Based on typical filter performance)
if ssim_b > ssim_a:
    superior_image = "Image B (Median)"
else:
    superior_image = "Image A (Gaussian)"
print(f"Conclusion: {superior_image} provided the superior result based on SSIM.")

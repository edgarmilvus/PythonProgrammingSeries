
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from skimage import filters, util
from skimage.morphology import disk 

# --- Simulation of Noisy Astronomical Image (M31) ---
# Create a simulated galaxy structure
size = 256
X, Y = np.meshgrid(np.linspace(-1, 1, size), np.linspace(-1, 1, size))
raw_image_data = np.exp(-(X**2 + Y**2) / 0.1) + 0.5 * np.exp(-(X**2 + Y**2) / 0.5)
raw_image_data = (raw_image_data - raw_image_data.min()) / (raw_image_data.max() - raw_image_data.min())

# Add Gaussian Noise (Readout Noise)
gaussian_noise = np.random.normal(0, 0.05, raw_image_data.shape)
noisy_image = raw_image_data + gaussian_noise

# Add Impulse Noise (Hot Pixels/Cosmic Rays)
noisy_image = util.random_noise(noisy_image, mode='s&p', amount=0.005)
noisy_image = np.clip(noisy_image, 0.0, 1.0)
# ----------------------------------------------------

def apply_gaussian(image, sigma):
    """Apply Gaussian filter."""
    return filters.gaussian(image, sigma=sigma, preserve_range=False)

def apply_median(image, kernel_size):
    """Apply Median filter using a square kernel equivalent."""
    return filters.median(image, disk(kernel_size // 2))

# 2. Gaussian Filtering
sigma_g = 1.5
gaussian_filtered = apply_gaussian(noisy_image, sigma_g)

# 3. Median Filtering
kernel_m = 3
median_filtered = apply_median(noisy_image, kernel_m)

# 4. Visual Comparison (Cropping for detail)
crop_slice = slice(100, 180)
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
titles = ["Original Noisy (Cropped)", f"Gaussian Filter (σ={sigma_g})", f"Median Filter ({kernel_m}x{kernel_m})"]
images = [noisy_image[crop_slice, crop_slice], 
          gaussian_filtered[crop_slice, crop_slice], 
          median_filtered[crop_slice, crop_slice]]

for ax, img, title in zip(axes, images, titles):
    ax.imshow(img, cmap='gray')
    ax.set_title(title)
    ax.axis('off')
# plt.show() # Display visualization

# 5. Observation Documentation:
# The Median filter is significantly better at removing the sharp, bright hot pixels 
# (impulse noise) without causing excessive blurring of the underlying structure. The 
# Gaussian filter successfully reduces the general background Gaussian noise but smears 
# the hot pixels into small halos and noticeably blurs the edges of the simulated galaxy core. 
# Since the image contains both Gaussian and Impulse noise, the Median filter provides 
# superior impulse noise suppression, which is crucial for mitigating cosmic ray strikes.

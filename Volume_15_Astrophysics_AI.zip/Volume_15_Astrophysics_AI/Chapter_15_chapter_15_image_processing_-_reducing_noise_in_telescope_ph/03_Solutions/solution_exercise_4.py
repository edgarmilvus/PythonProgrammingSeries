
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from skimage.restoration import denoise_bilateral
import numpy as np
import matplotlib.pyplot as plt

# --- Simulation of Jupiter Image (High Contrast Edges) ---
size = 150
Y, X = np.ogrid[0:size, 0:size]
center = size / 2
jupiter_image = np.zeros((size, size))
jupiter_image[Y < center - 10] = 0.3
jupiter_image[Y > center + 10] = 0.7
jupiter_image[(Y >= center - 10) & (Y <= center + 10)] = 0.5
spot_center = (center + 20, center + 20)
spot_radius = 15
spot_mask = ((X - spot_center[1])**2 + (Y - spot_center[0])**2) < spot_radius**2
jupiter_image[spot_mask] = 0.9
jupiter_image_noisy = jupiter_image + np.random.normal(0, 0.04, jupiter_image.shape)
jupiter_image_noisy = np.clip(jupiter_image_noisy, 0, 1)
# ----------------------------------------------------------

def apply_bilateral_filter(image, sigma_s, sigma_r):
    """Applies the Bilateral filter."""
    return denoise_bilateral(image, sigma_spatial=sigma_s, sigma_range=sigma_r, multichannel=False)

# 1. Baseline Implementation
sigma_spatial_base = 5
sigma_range_base = 0.1
baseline_denoised = apply_bilateral_filter(jupiter_image_noisy, sigma_spatial_base, sigma_range_base)

# 2. Parameter Modification Tests (Conceptual scenarios)
# Goal 1: High smoothing, low range tolerance (blurring likely)
denoised_g1 = apply_bilateral_filter(jupiter_image_noisy, sigma_s=10, sigma_r=0.05) 
# Goal 2: Low smoothing, high range tolerance (high edge preservation)
denoised_g2 = apply_bilateral_filter(jupiter_image_noisy, sigma_s=3, sigma_r=0.2) 

# 3. Optimal Tuning: Moderate spatial smoothing, high range tolerance for edge preservation
sigma_spatial_optimal = 5
sigma_range_optimal = 0.15
optimal_denoised = apply_bilateral_filter(jupiter_image_noisy, sigma_spatial_optimal, sigma_range_optimal)

# Visualization setup
fig, axes = plt.subplots(1, 3, figsize=(18, 6))
axes[0].imshow(jupiter_image_noisy, cmap='gray'); axes[0].set_title('Original Noisy')
axes[1].imshow(baseline_denoised, cmap='gray'); axes[1].set_title(f'Baseline (s={sigma_spatial_base}, r={sigma_range_base})')
axes[2].imshow(optimal_denoised, cmap='gray'); axes[2].set_title(f'Optimal (s={sigma_spatial_optimal}, r={sigma_range_optimal})')
for ax in axes: ax.axis('off')
# plt.show()

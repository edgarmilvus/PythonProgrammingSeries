
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
from skimage.filters import gaussian
import numpy as np

# --- Simulation of Star Field Image ---
size = 200
star_field_image = np.zeros((size, size))

# Add point sources (stars)
np.random.seed(42)
for _ in range(30):
    x, y = np.random.randint(10, size - 10, 2)
    star_field_image[x, y] = np.random.uniform(0.5, 1.0) # Varying brightness

# Blur point sources slightly (simulating PSF)
star_field_image = gaussian(star_field_image, sigma=0.8)

# Add Gaussian noise
star_field_image += np.random.normal(0, 0.05, star_field_image.shape)
star_field_image = np.clip(star_field_image, 0, 1)
# --------------------------------------

# 1. Setup figure and axes
fig, ax = plt.subplots(figsize=(8, 8))
plt.subplots_adjust(left=0.25, bottom=0.25)

# 2. Define the initial image display
initial_sigma = 1.0
initial_denoised = gaussian(star_field_image, sigma=initial_sigma)
img_display = ax.imshow(initial_denoised, cmap='gray', vmin=0, vmax=1)
ax.set_title(f'Gaussian Filtered Image (σ={initial_sigma:.1f})')
ax.axis('off')

# 3. Create the slider widget
ax_slider = plt.axes([0.25, 0.1, 0.65, 0.03])
sigma_slider = Slider(
    ax=ax_slider,
    label='Sigma (σ)',
    valmin=0.1,
    valmax=5.0,
    valinit=initial_sigma,
    valstep=0.1
)

# 4. Define the update function
def update(val):
    new_sigma = sigma_slider.val
    
    # Apply the Gaussian filter. Truncate limits the filter kernel size for speed.
    new_denoised = gaussian(star_field_image, sigma=new_sigma, truncate=3.5)
    
    img_display.set_data(new_denoised)
    ax.set_title(f'Gaussian Filtered Image (σ={new_sigma:.1f})')
    
    fig.canvas.draw_idle()

# 5. Connect the slider to the update function
sigma_slider.on_changed(update)

# Note: plt.show() is required to run the interactive loop.
# plt.show()

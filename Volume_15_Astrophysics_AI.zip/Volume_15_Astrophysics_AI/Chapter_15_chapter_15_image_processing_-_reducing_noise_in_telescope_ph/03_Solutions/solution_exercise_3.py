
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from scipy.ndimage import median_filter
import numpy as np
import matplotlib.pyplot as plt

# --- Simulation of Raw Image with Hot Pixels ---
size = 100
raw_image = np.zeros((size, size))
raw_image[30:70, 30:70] = 0.5 # Background structure
raw_image += np.random.normal(0, 0.01, raw_image.shape) # Base noise
# Introduce hot pixels (Impulse noise)
raw_image[10, 10] = 1.0
raw_image[50, 80] = 0.98
raw_image[90, 5] = 1.0
raw_image = np.clip(raw_image, 0, 1)
# ------------------------------------------------

def create_hot_pixel_mask(image, threshold_factor=0.95):
    """
    Identifies hot pixels by comparing the central pixel value to the local median 
    and ensuring the pixel is near saturation (high value).
    """
    # Calculate the local median (5x5 window)
    local_median = median_filter(image, size=5)
    
    # Calculate difference between pixel and local median
    local_difference = image - local_median
    
    # Flag pixels that are significantly brighter than their neighborhood AND globally bright
    # Threshold 0.2 means the pixel is 20% brighter than its neighborhood
    mask = (local_difference > 0.2) & (image > threshold_factor)
    
    return mask

def targeted_median_denoising(image, mask):
    """Applies median filtering only to masked regions."""
    
    # 1. Apply median filter globally to get replacement values for all pixels
    cleaned_full = median_filter(image, size=3)
    
    # 2. Reconstruct the final image
    final_image = np.copy(image)
    
    # Replace the hot pixels (where mask is True) with the cleaned values
    final_image[mask] = cleaned_full[mask]
    
    return final_image

# 1. Hot Pixel Detection
hot_pixel_mask = create_hot_pixel_mask(raw_image, threshold_factor=0.95)

# 2. Targeted Filtering and Reconstruction
cleaned_image = targeted_median_denoising(raw_image, hot_pixel_mask)

# 3. Visualization
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

axes[0].imshow(raw_image, cmap='gray'); axes[0].set_title('Original Raw Image')
axes[1].imshow(hot_pixel_mask, cmap='binary'); axes[1].set_title('Binary Mask (Detected Defects)')
axes[2].imshow(cleaned_image, cmap='gray'); axes[2].set_title('Reconstructed Image (Targeted Denoising)')
for ax in axes: ax.axis('off')
# plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from skimage import data, img_as_float
from skimage.restoration import denoise_bilateral
from skimage.filters import median, gaussian
from skimage.morphology import disk
from scipy.ndimage import uniform_filter

# --- 1. Utility Function: Simulating Realistic Astronomical Noise ---

def add_astronomical_noise(image_array, gaussian_sigma=0.05, salt_pepper_ratio=0.005):
    """
    Adds Gaussian noise (simulating thermal/read noise) and Salt-and-Pepper noise 
    (simulating cosmic rays/hot pixels) to a float image array.
    """
    # Ensure image is float type for accurate noise addition
    noisy_image = np.copy(img_as_float(image_array))
    
    # Add Gaussian Noise (Thermal Noise)
    # This simulates the random fluctuations inherent in long exposures
    gaussian_noise = np.random.normal(loc=0, scale=gaussian_sigma, size=noisy_image.shape)
    noisy_image += gaussian_noise
    
    # Normalize to keep values within [0, 1] after Gaussian addition
    noisy_image = np.clip(noisy_image, 0, 1)

    # Add Salt-and-Pepper Noise (Cosmic Ray/Hot Pixel Simulation)
    # This simulates sharp, isolated impulse noise
    row, col = noisy_image.shape
    num_sp_pixels = int(salt_pepper_ratio * row * col)
    
    # Generate random coordinates for noise placement
    coords = [np.random.randint(0, i - 1, num_sp_pixels) for i in noisy_image.shape]
    
    # Assign random values (0 or 1) for 'salt' (hot) or 'pepper' (dead) pixels
    sp_values = np.random.choice([0.0, 1.0], size=num_sp_pixels)
    
    # Apply the impulse noise
    noisy_image[coords[0], coords[1]] = sp_values
    
    return noisy_image

# --- 2. Core Processing Function: The Denoising Pipeline ---

def nebular_denoising_pipeline(image_data):
    """
    Applies a multi-stage denoising pipeline: Median -> Bilateral.
    This sequence is critical for optimal noise reduction and detail preservation.
    """
    
    # --- Stage 1: Impulse Noise Removal (Hot Pixels/Cosmic Rays) ---
    
    # Median filtering is highly effective against impulse noise (Salt & Pepper/Cosmic Rays)
    # It replaces the central pixel value with the median of its neighbors, 
    # effectively eliminating isolated extreme values without significant blurring.
    # We use a disk-shaped structuring element (selem) for isotropic smoothing.
    median_selem = disk(3) # 3x3 pixel radius disk
    cosmic_ray_cleaned = median(image_data, selem=median_selem, mode='reflect')
    
    # --- Stage 2: Adaptive Thermal Noise Reduction (Bilateral Filtering) ---
    
    # Bilateral filtering smooths noise while preserving edges (star/nebula boundaries).
    # sigma_color: Controls how far intensity values can differ and still be smoothed. 
    #              A smaller value preserves more detail but removes less noise.
    # sigma_spatial: Controls the spatial extent of the filter (how many neighbors are considered).
    # We apply this to the image already cleaned of impulse noise.
    bilateral_filtered = denoise_bilateral(
        image=cosmic_ray_cleaned,
        sigma_color=0.08,  # Intensity tolerance (adjust based on noise level)
        sigma_spatial=10,  # Spatial neighborhood size
        channel_axis=None, # Explicitly handle as grayscale
        mode='reflect'
    )
    
    # --- Stage 3: Comparison Benchmark (Simple Gaussian Blur) ---
    
    # For comparison, apply a standard Gaussian filter to the original noisy image.
    # This demonstrates the standard tradeoff (noise reduction vs. detail loss).
    gaussian_filtered = gaussian(image_data, sigma=2.0, preserve_range=True)
    
    return cosmic_ray_cleaned, bilateral_filtered, gaussian_filtered

# --- 3. Visualization Function ---

def visualize_results(original, noisy, median_cleaned, bilateral_cleaned, gaussian_benchmark):
    """
    Plots the results of the denoising pipeline for visual comparison.
    """
    fig, axes = plt.subplots(2, 3, figsize=(18, 12), sharex=True, sharey=True)
    ax = axes.ravel()
    
    titles = [
        'A. Original Reference Image (Ground Truth)',
        'B. Simulated Noisy Astronomical Image',
        'C. Stage 1: Median Filter (Cosmic Ray Removal)',
        'D. Stage 2: Adaptive Bilateral Filter (Final Result)',
        'E. Simple Gaussian Filter (Benchmark)',
        'F. Residual Noise (Noisy - Bilateral Cleaned)'
    ]
    
    images = [
        original,
        noisy,
        median_cleaned,
        bilateral_cleaned,
        gaussian_benchmark,
        (noisy - bilateral_cleaned) # Highlighting what was removed
    ]

    for i, img in enumerate(images):
        # Use 'gray' colormap standard for scientific grayscale imagery
        ax[i].imshow(img, cmap=plt.cm.gray, vmin=0, vmax=1)
        ax[i].set_title(titles[i], fontsize=12)
        ax[i].axis('off')

    plt.tight_layout()
    plt.show()

# --- 4. Main Execution Block ---

if __name__ == '__main__':
    # Load a suitable image that simulates complex astronomical structure (e.g., a nebula)
    # The 'camera' image provides good gradients and fine details for testing edge preservation.
    original_image = img_as_float(data.camera())
    
    # Ensure the image is normalized and ready for processing
    original_image = original_image / original_image.max()
    
    print("Starting simulation and multi-stage denoising pipeline...")
    
    # Add synthetic noise to simulate real telescope data challenges
    noisy_image = add_astronomical_noise(
        original_image,
        gaussian_sigma=0.06,      # Significant thermal noise
        salt_pepper_ratio=0.003   # Moderate cosmic ray density
    )
    
    # Execute the pipeline
    median_cleaned, bilateral_cleaned, gaussian_benchmark = nebular_denoising_pipeline(noisy_image)
    
    print("Pipeline complete. Generating visualization comparison.")
    
    # Display the results
    visualize_results(
        original_image, 
        noisy_image, 
        median_cleaned, 
        bilateral_cleaned, 
        gaussian_benchmark
    )
    
    # --- Quantitative Assessment (Optional but helpful for verification) ---
    # Calculate Mean Squared Error (MSE) to quantify noise reduction effectiveness
    
    mse_noisy = np.mean((original_image - noisy_image) ** 2)
    mse_median = np.mean((original_image - median_cleaned) ** 2)
    mse_bilateral = np.mean((original_image - bilateral_cleaned) ** 2)
    mse_gaussian = np.mean((original_image - gaussian_benchmark) ** 2)
    
    print("\n--- Quantitative Error Analysis (MSE vs. Ground Truth) ---")
    print(f"Noisy Image MSE:        {mse_noisy:.6f}")
    print(f"Median Filter MSE:      {mse_median:.6f}")
    print(f"Bilateral Filter MSE:   {mse_bilateral:.6f} (Best detail preservation)")
    print(f"Gaussian Filter MSE:    {mse_gaussian:.6f} (Often lowest MSE, but highest blur)")
    
    # Note on MSE: Gaussian often yields the lowest MSE because it smooths the image 
    # aggressively, making the overall pixel differences small. However, this smoothing 
    # comes at the cost of detail, which the Bilateral filter successfully avoids.


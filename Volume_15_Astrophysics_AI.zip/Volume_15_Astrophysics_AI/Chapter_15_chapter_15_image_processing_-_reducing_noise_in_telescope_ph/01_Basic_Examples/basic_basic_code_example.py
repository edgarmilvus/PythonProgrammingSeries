
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from skimage import data, filters, util, color
from scipy.ndimage import gaussian_filter

# --- 1. Setup and Initialization ---

def demonstrate_gaussian_denoising():
    """
    Simulates thermal noise on a simple image and applies a Gaussian filter 
    to demonstrate basic noise reduction in astronomical data processing.
    """
    print("Starting Gaussian Denoising Simulation...")
    
    # Load a standard grayscale image provided by scikit-image (e.g., astronaut)
    # For simplicity, we use a built-in image, treating it as a raw FITS observation.
    original_image_rgb = data.astronaut()
    
    # Convert the image to grayscale (essential for most astronomical processing 
    # where channels are processed independently or data is inherently monochromatic).
    original_image = color.rgb2gray(original_image_rgb)
    
    # Normalize the image data to the range [0, 1] for consistent mathematical operations
    # and to simulate standard floating-point astronomical data formats.
    original_image = original_image / np.max(original_image)
    
    # Define the standard deviation (sigma) for the added noise
    NOISE_SIGMA = 0.15
    
    # Define the standard deviation (sigma) for the Gaussian smoothing filter
    # This value dictates the degree of blurring and noise suppression.
    FILTER_SIGMA = 1.5 
    
    # --- 2. Simulating Noise (Thermal Noise Component) ---
    
    # Generate random Gaussian noise with mean 0 and defined standard deviation.
    # This simulates the random fluctuations caused by thermal effects in the sensor.
    gaussian_noise = np.random.normal(0, NOISE_SIGMA, original_image.shape)
    
    # Add the noise to the original image data.
    noisy_image = original_image + gaussian_noise
    
    # Clip the values to ensure they remain within the valid intensity range [0, 1] 
    # after the noise addition, preventing overflow artifacts.
    noisy_image = np.clip(noisy_image, 0, 1)
    
    print(f"Noise added successfully (Sigma={NOISE_SIGMA}). Image dimensions: {noisy_image.shape}")
    
    # --- 3. Applying the Gaussian Filter (Denoising) ---
    
    # The Gaussian filter performs convolution using a Gaussian kernel.
    # It averages pixel values based on proximity, weighted by the Gaussian function.
    # We use scipy.ndimage's highly optimized implementation for 2D filtering.
    denoised_image = gaussian_filter(
        noisy_image, 
        sigma=FILTER_SIGMA, 
        mode='nearest' # Handles boundary conditions by extending the nearest valid pixel
    )
    
    print(f"Gaussian filter applied (Sigma={FILTER_SIGMA}).")
    
    # --- 4. Visualization and Comparison ---
    
    # Set up the plotting environment to compare the three states: Original, Noisy, Denoised.
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))
    ax = axes.ravel()
    
    # Plot 1: The ideal, noise-free image (the target).
    ax[0].imshow(original_image, cmap='gray')
    ax[0].set_title('A: Original Image (Ideal Observation)')
    ax[0].axis('off')
    
    # Plot 2: The simulated raw telescope data (corrupted by noise).
    ax[1].imshow(noisy_image, cmap='gray')
    ax[1].set_title(f'B: Noisy Image (Simulated Thermal Noise, $\sigma_{{noise}}={NOISE_SIGMA}$)')
    ax[1].axis('off')
    
    # Plot 3: The result after applying the spatial domain filter.
    ax[2].imshow(denoised_image, cmap='gray')
    ax[2].set_title(f'C: Denoised Image (Gaussian Filter, $\sigma_{{filter}}={FILTER_SIGMA}$)')
    ax[2].axis('off')
    
    # Adjust layout for better presentation
    plt.tight_layout()
    plt.show()
    
    print("Denoising process complete. Visualization displayed.")

# Execute the demonstration function
demonstrate_gaussian_denoising()

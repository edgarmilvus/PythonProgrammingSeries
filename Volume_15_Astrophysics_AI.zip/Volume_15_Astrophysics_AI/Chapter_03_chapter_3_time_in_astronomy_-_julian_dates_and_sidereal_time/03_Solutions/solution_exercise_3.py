
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from datetime import datetime, timedelta
from astropy.time import Time
import numpy as np

# Epoch Details
start_time_str = "2024-11-01 10:00:00"
duration_hours = 72
interval_minutes = 45

# 1. Initial Setup
start_time = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S")
time_step = timedelta(minutes=interval_minutes)

# Calculate total number of epochs (72 hours * 60 min/hr / 45 min/step) + 1 for start
num_steps = int((duration_hours * 60) / interval_minutes)
num_epochs = num_steps + 1

# List to store standard Python datetime objects
datetime_list = []

# 2. & 3. Iteration and Time Series Generation
for i in range(num_epochs):
    current_time = start_time + i * time_step
    datetime_list.append(current_time)

# 4. Conversion: Vectorized conversion to astropy Time (assumes input is UTC)
time_series = Time(datetime_list, scale='utc')
jd_list = time_series.jd

# 5. Output
print(f"Start Time: {start_time_str} UTC")
print(f"Interval: {interval_minutes} minutes")
print(f"Total Epochs Generated: {len(jd_list)}")
print("-" * 30)
print("First 5 Julian Dates (JD):")
for jd in jd_list[:5]:
    print(f"{jd:.6f}")
print("-" * 30)
print("Last 5 Julian Dates (JD):")
for jd in jd_list[-5:]:
    print(f"{jd:.6f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from astropy.time import Time
from astropy.coordinates import EarthLocation
import astropy.units as u

# Astronomical Context
# Note: Longitudes are West, hence negative in standard astropy convention.
mk_lat = 19.8206 * u.deg
mk_lon = -155.4681 * u.deg 
paranal_lat = -24.6272 * u.deg
paranal_lon = -70.4043 * u.deg 
T_obs_str = "2025-03-20 00:00:00"

# 1. Define Locations
mauna_kea = EarthLocation(lat=mk_lat, lon=mk_lon)
eso_paranal = EarthLocation(lat=paranal_lat, lon=paranal_lon)

# 2. Define Time (UTC)
T_obs = Time(T_obs_str, scale='utc')

# 3. Calculate LST
# LST is calculated by calling the sidereal_time method on the Time object, 
# providing the location's longitude. 'mean' is used for standard scheduling.
lst_mk = T_obs.sidereal_time('mean', longitude=mauna_kea.lon)
lst_paranal = T_obs.sidereal_time('mean', longitude=eso_paranal.lon)

# 4. Interpretation and Output (formatted as HH:MM:SS)
print(f"Observation Epoch (UTC): {T_obs.isot}")

print(f"\n--- Mauna Kea (Lon: {mauna_kea.lon.to_string(unit=u.deg, sep=':', precision=2)}) ---")
print(f"Local Sidereal Time (LST): {lst_mk.to_string(unit=u.hour, sep=':', precision=2)}")

print(f"\n--- ESO Paranal (Lon: {eso_paranal.lon.to_string(unit=u.deg, sep=':', precision=2)}) ---")
print(f"Local Sidereal Time (LST): {lst_paranal.to_string(unit=u.hour, sep=':', precision=2)}")

# Explanation: The LST values are different because LST is directly tied to the 
# observer's longitude. Since the Earth is rotating, two locations at different 
# longitudes will see different Right Ascensions crossing their meridian 
# (i.e., different LST) at the same Universal Time (UTC).

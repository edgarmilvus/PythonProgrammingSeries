
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from datetime import datetime
from astropy.time import Time

# Input Data
observation_list = [
    "28/02/23 14:05:30",
    "01/03/23 02:15:00",
    "05/03/23 20:45:15",
    "10/03/23 09:00:00",
    "15/03/23 23:59:59"
]
# Format string: DD/MM/YY HH:MM:SS
format_code = "%d/%m/%y %H:%M:%S"

# 1. & 2. Parsing and List Generation
parsed_datetimes = []
for obs_str in observation_list:
    # Use strptime to parse the custom format
    dt_obj = datetime.strptime(obs_str, format_code)
    parsed_datetimes.append(dt_obj)

# 3. Vectorized Conversion (Crucially setting scale='tt')
# astropy assumes the naive datetime objects correspond to the specified scale (TT).
time_array_tt = Time(parsed_datetimes, scale='tt')

# 4. JD Output
print(f"Input Datetimes Parsed (Assumed TT Scale):")
for dt in parsed_datetimes:
    print(f"  {dt}")

print("\nResulting Time Array (Scale: TT):")
print(time_array_tt)

print("\nCorresponding Julian Dates (JD):")
print(time_array_tt.jd)

# 5. Modification Challenge Description: Handling Mixed Time Zones
"""
Modification Challenge: Handling Mixed Time Zones
If the input list contained mixed time zone information (e.g., UTC and EST), 
the naive datetime objects created by strptime() are insufficient, as they lack 
timezone awareness.

Necessary Pre-processing Steps:
1. Define a function or loop that identifies the time zone for each string 
   (e.g., based on an external metadata column or pattern matching).
2. Use the 'pytz' or 'zoneinfo' libraries to localize each datetime object 
   to its specific time zone.
3. Convert all localized datetime objects to a single, standard reference scale, 
   typically UTC, using the .astimezone(pytz.utc) method.
4. Pass the resulting list of timezone-aware UTC datetime objects to the 
   astropy.time.Time() constructor, explicitly setting scale='utc'. 
   astropy can then handle the subsequent high-precision conversion to TT, TDB, etc.
"""

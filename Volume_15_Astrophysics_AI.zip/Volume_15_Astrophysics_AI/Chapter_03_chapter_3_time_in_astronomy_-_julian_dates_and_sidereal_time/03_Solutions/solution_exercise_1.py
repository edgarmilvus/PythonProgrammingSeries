
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from astropy.time import Time, TimeDelta
import numpy as np

# Define the observation times (UTC)
T1_str = "2024-06-15 04:30:00"
T2_str = "2025-01-01 19:00:00"

# 1. Initialization: Convert strings to Time objects (explicitly UTC)
T1 = Time(T1_str, scale='utc', format='iso')
T2 = Time(T2_str, scale='utc', format='iso')

# 2. JD Calculation
jd1 = T1.jd
jd2 = T2.jd

# 3. Time Difference
time_delta = T2 - T1
total_days = time_delta.value

# 4. Breakdown: Convert total seconds to D/H/M/S
total_seconds = time_delta.sec
days = int(total_seconds // 86400)
remaining_seconds = total_seconds % 86400
hours = int(remaining_seconds // 3600)
remaining_seconds %= 3600
minutes = int(remaining_seconds // 60)
seconds = remaining_seconds % 60

print(f"--- Julian Dates (JD) ---")
print(f"JD for T1 ({T1.isot}): {jd1:.5f}")
print(f"JD for T2 ({T2.isot}): {jd2:.5f}")
print(f"\n--- Time Elapsed (T2 - T1) ---")
print(f"Total Duration (Decimal Days): {total_days:.5f} days")
print(f"Duration Breakdown: {days} days, {hours} hours, {minutes} minutes, {seconds:.0f} seconds")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from astropy.time import Time
import astropy.units as u

# The epoch in question
epoch_str = "2025-07-20 12:00:00"

# --- Method 1: The recommended, direct approach ---
# astropy interprets 'epoch_str' as an epoch on the TT scale.
time_obj_1 = Time(epoch_str, scale='tt', format='isot')
jd_tt_method_1 = time_obj_1.jd

# --- Method 2: The original, incorrect sequential approach ---
# astropy interprets 'epoch_str' as an epoch on the UTC scale (default behavior).
time_obj_2_utc = Time(epoch_str, scale='utc', format='isot')

# Convert the object's scale from UTC to TT.
# This calculates TT = UTC + Delta_T (where Delta_T includes TAI-UTC and TT-TAI)
time_obj_2_converted = time_obj_2_utc.tt
jd_tt_method_2_incorrect = time_obj_2_converted.jd

# --- Correction ---
# The only way to make Method 2 match Method 1 is to ensure the input string 
# is interpreted as TT initially, which requires setting scale='tt' at initialization.
# If we had to use two steps, we would need to manually apply the TT-UTC offset 
# to the input string before creating the UTC object, which defeats the purpose 
# of astropy. The correct approach is Method 1.

# For demonstration, we show the corrected logic requires the initial scale setting:
time_obj_3_corrected = Time(epoch_str, scale='tt', format='isot')
jd_tt_method_3_corrected = time_obj_3_corrected.jd

# Precision Demonstration
error_magnitude_days = abs(jd_tt_method_1 - jd_tt_method_2_incorrect)
error_magnitude_seconds = error_magnitude_days * 86400.0

print(f"Epoch: {epoch_str}")
print("-" * 40)
print(f"JD (Method 1 - Direct TT Input): {jd_tt_method_1:.8f}")
print(f"JD (Method 2 - UTC Input, then Convert): {jd_tt_method_2_incorrect:.8f}")
print(f"JD (Correction): {jd_tt_method_3_corrected:.8f}")
print("-" * 40)
print(f"Difference (Days): {error_magnitude_days:.8f}")
print(f"Difference (Seconds): {error_magnitude_seconds:.3f} s")

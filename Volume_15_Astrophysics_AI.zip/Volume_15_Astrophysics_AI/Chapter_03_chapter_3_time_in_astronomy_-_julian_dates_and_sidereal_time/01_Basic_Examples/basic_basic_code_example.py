
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# Import the necessary Time object from astropy
from astropy.time import Time
import numpy as np 

# --- 1. Define the Observation Time and Scale ---
# We define the specific moment of the Apollo 11 moon landing (UTC)
time_string = '1969-07-20 20:17:40.000'
# Critical: Always define the time scale. UTC is the standard civil time scale.
time_scale = 'utc' 

# --- 2. Create the Astropy Time Object ---
# The Time class handles the complex conversion rules internally.
# We specify the format string (astropy uses yyyy-mm-dd style placeholders) 
# and the scale.
obs_time = Time(time_string, format='yyyy-mm-dd hh:mm:ss.sss', scale=time_scale)

# --- 3. Extract the Julian Date (JD) ---
# JD is the number of days elapsed since the reference epoch (4713 BC).
julian_date = obs_time.jd

# --- 4. Extract the Modified Julian Date (MJD) ---
# MJD = JD - 2400000.5 days. This reduces the number of leading digits,
# improving precision and readability for modern observations.
modified_julian_date = obs_time.mjd

# --- 5. Output the results ---
print(f"--- Input Time Data ---")
print(f"Gregorian Date/Time (Input): {time_string}")
print(f"Time Scale Used: {time_scale.upper()}")
print("-" * 45)
print(f"Calculated Julian Date (JD): {julian_date:.8f}")
print(f"Calculated Modified Julian Date (MJD): {modified_julian_date:.8f}")

# --- 6. Demonstrate Time Differences (Duration Calculation) ---
# Create a second time point, exactly 24 hours later, for comparison
time_later_string = '1969-07-21 20:17:40.000'
obs_time_later = Time(time_later_string, format='yyyy-mm-dd hh:mm:ss.sss', scale=time_scale)
    
# Calculate the difference between the two JD values
jd_difference = obs_time_later.jd - obs_time.jd
    
print("-" * 45)
print(f"JD of time 24 hours later: {obs_time_later.jd:.8f}")
print(f"Difference in JD (Expected 1.0 day): {jd_difference:.8f}")

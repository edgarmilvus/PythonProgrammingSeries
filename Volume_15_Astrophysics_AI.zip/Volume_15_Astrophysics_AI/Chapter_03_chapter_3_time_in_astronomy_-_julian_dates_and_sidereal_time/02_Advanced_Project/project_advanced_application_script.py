
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

from astropy.time import Time, TimeDelta
from astropy.coordinates import EarthLocation, Angle, get_sidereal_time
import astropy.units as u
import datetime

# --- Configuration: Observatory and Target Parameters ---

# Define the observatory location (Example: Mount Wilson, CA approximation)
OBS_LAT = 34.22 * u.deg
OBS_LON = -118.06 * u.deg 
OBS_HEIGHT = 1742 * u.m

# Target Right Ascension (RA) for observation (Example: A known Pulsar)
TARGET_RA_STR = "19h 34m 43.0s" 
DAYS_TO_SCHEDULE = 7

# 1. Setup location and target coordinates using astropy objects
observatory = EarthLocation(lat=OBS_LAT, lon=OBS_LON, height=OBS_HEIGHT)
target_ra = Angle(TARGET_RA_STR)

# Sidereal Rate Correction: Ratio of a Mean Solar Day to a Mean Sidereal Day
# This factor converts a required angle shift (LST) into a required UTC time shift.
SIDEREAL_RATE_FACTOR = 1.00273790935 

print("--- High-Precision Transit Scheduler for Observational Planning ---")
print(f"Observatory Location: {observatory.lat:.2f}, {observatory.lon:.2f}")
print(f"Target Right Ascension (RA): {target_ra.to_string(unit=u.hour, sep=':', precision=2)}\n")

def find_transit_time(start_utc_date, location, ra_target):
    """
    Calculates the precise UTC time when the target RA culminates (LST = RA)
    by calculating the required time offset from a known reference point.
    """
    # 2. Define search reference point: 12:00 UTC on the specified day
    # This ensures the calculation window centers around the expected transit.
    start_dt = datetime.datetime.combine(start_utc_date, datetime.time(12, 0, 0))
    start_time_astropy = Time(start_dt, format='datetime', scale='utc')

    # 3. Calculate LST at the reference point
    lst_start = get_sidereal_time('local', start_time_astropy, location=location)

    # 4. Calculate the required angular shift (Delta_LST)
    # The .wrap_at('24h') ensures the difference is always the shortest path (0 to 24 hours)
    delta_lst = (ra_target - lst_start).wrap_at('24h')
    
    # 5. Convert Delta_LST (in seconds of angle) into a UTC time shift (in seconds)
    # Divide by the SIDEREAL_RATE_FACTOR to account for the Earth's orbital motion.
    time_shift_seconds = delta_lst.to(u.second).value / SIDEREAL_RATE_FACTOR
    
    # 6. Create the TimeDelta object and calculate the final transit time
    transit_delta = TimeDelta(time_shift_seconds * u.second)
    transit_time = start_time_astropy + transit_delta

    # 7. Verification: Calculate LST at the derived transit time
    lst_check = get_sidereal_time('local', transit_time, location=location)
    
    return transit_time, lst_check


# 8. Main Scheduling Loop and Output Generation
start_date = datetime.datetime.utcnow().date()
schedule = []

for i in range(DAYS_TO_SCHEDULE):
    # Determine the UTC date for the current iteration
    current_date_utc = start_date + datetime.timedelta(days=i)
    
    # Execute the transit calculation
    transit_utc, lst_at_transit = find_transit_time(current_date_utc, observatory, target_ra)

    # Format output strings
    date_str = current_date_utc.strftime("%Y-%m-%d")
    # Use millisecond precision for high-precision timekeeping
    time_str = transit_utc.datetime.strftime("%H:%M:%S.%f")[:-3] 
    lst_str = lst_at_transit.to_string(unit=u.hour, sep=':', precision=3)

    schedule.append({
        "Date": date_str,
        "UTC Transit Time": time_str,
        "LST (Check)": lst_str
    })

# 9. Output Results Table
print(f"{'Date':<12} | {'UTC Transit Time':<20} | {'LST at Transit (Check)':<25}")
print("-" * 60)
for entry in schedule:
    print(f"{entry['Date']:<12} | {entry['UTC Transit Time']:<20} | {entry['LST (Check)']:<25}")

# 10. Demonstration of Julian Date Conversion
if schedule:
    first_transit_str = schedule[0]['Date'] + " " + schedule[0]['UTC Transit Time']
    first_transit_time = Time(first_transit_str, format='iso', scale='utc')
    
    print("\n--- High-Precision Time Conversion ---")
    print(f"First Transit Time (UTC ISO): {first_transit_time.iso}")
    print(f"Corresponding Julian Date (JD): {first_transit_time.jd:.6f}")
    print(f"Corresponding Modified Julian Date (MJD): {first_transit_time.mjd:.6f}")
    
    # Calculating the LST shift between successive nights
    second_transit_str = schedule[1]['Date'] + " " + schedule[1]['UTC Transit Time']
    second_transit_time = Time(second_transit_str, format='iso', scale='utc')
    
    time_difference = second_transit_time - first_transit_time
    print(f"Time difference between transits (UTC): {time_difference.to(u.hour):.4f}")
    # This difference should be slightly less than 24 hours (approx 23h 56m)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import numpy as np
from astropy.io import fits
from datetime import datetime
import random # Added for simulating varied data

# --- 1. Configuration and Setup ---

OUTPUT_DIR = "survey_reports"
SIMULATED_DATA_DIR = "simulated_survey_data"
FILE_COUNT = 7 # Increased file count slightly for better simulation

def setup_environment():
    """
    Creates necessary directories and simulates FITS files, including one potentially saturated file.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(SIMULATED_DATA_DIR, exist_ok=True)
    
    print(f"Creating {FILE_COUNT} simulated FITS files in {SIMULATED_DATA_DIR}...")
    
    for i in range(1, FILE_COUNT + 1):
        filename = os.path.join(SIMULATED_DATA_DIR, f"obs_field_M{100 + i}_{i:03d}.fits")
        
        # Determine data characteristics: make one file saturated for QA check
        if i == 4:
            # Simulate a saturated image (max value for uint16 is 65535)
            data = np.random.randint(65000, 65536, size=(512, 512), dtype=np.uint16)
            filter_used = 'V'
            exposure_time = 120.0
        else:
            # Normal, non-saturated data
            data = np.random.randint(500, 35000, size=(512, 512), dtype=np.uint16)
            filter_used = random.choice(['R', 'G', 'B', 'Ha'])
            exposure_time = random.uniform(60.0, 300.0)
        
        # Create Primary HDU
        hdu = fits.PrimaryHDU(data)
        
        # Populate critical header keywords
        date_str = f'2024-07-{(i % 30) + 1:02d}T{random.randint(0, 23):02d}:30:00'
        hdu.header['DATE-OBS'] = date_str, 'Observation Date and Time (UT)'
        hdu.header['EXPTIME'] = round(exposure_time, 2), 'Exposure time in seconds'
        hdu.header['FILTER'] = filter_used, 'Photometric filter used'
        hdu.header['OBJECT'] = f'M{100 + i}', 'Target astronomical object'
        hdu.header['BUNIT'] = 'ADU', 'Data unit: Analog-to-Digital Units'
        hdu.header['NAXIS'] = 2, 'Number of data axes'
        
        # Write the HDU list to a file
        hdul = fits.HDUList([hdu])
        hdul.writeto(filename, overwrite=True, checksum=True) # Adding checksum for integrity
        hdul.close()
    print("Setup complete. FITS files created.")

# --- 2. Core Processing Logic ---

def process_fits_file(filepath: str) -> dict:
    """
    Reads a single FITS file, extracts metadata, calculates statistics, and performs QA.
    Uses astropy.io.fits context manager for guaranteed resource release.
    """
    results = {
        'filename': os.path.basename(filepath),
        'status': 'Processed OK',
        'mean_adu': None,
        'max_adu': None,
        'exposure_s': None,
        'filter': None,
        'date_obs': None,
        'data_shape': None
    }
    
    # Define the saturation limit for 16-bit unsigned data
    SATURATION_LIMIT = 65535 

    try:
        # Open the FITS file using the context manager
        with fits.open(filepath, checksum=True) as hdul:
            # 1. Verify file integrity using checksum (if written)
            if not hdul.verify_checksum():
                results['status'] = 'Error: Checksum failure'
                return results

            # 2. Access the Primary HDU (index 0)
            primary_hdu = hdul[0]
            header = primary_hdu.header

            # 3. Extract Metadata from Header
            results['exposure_s'] = header.get('EXPTIME')
            results['filter'] = header.get('FILTER')
            results['date_obs'] = header.get('DATE-OBS')
            
            # 4. Access Data Array and Calculate Statistics (Lazy loading optimization)
            # .data accesses the NumPy array. This is where I/O occurs.
            data = primary_hdu.data
            
            if data is None or data.size == 0:
                results['status'] = 'Error: Empty or missing primary data'
                return results

            results['data_shape'] = data.shape
            
            # Use NumPy for fast statistical calculation
            results['mean_adu'] = round(np.mean(data), 2)
            results['max_adu'] = int(np.max(data))
            
            # 5. Data Quality Check (Saturation)
            if results['max_adu'] >= SATURATION_LIMIT:
                 results['status'] = 'WARNING: Potential Saturation Detected'
            
            return results

    except FileNotFoundError:
        results['status'] = 'Error: File not found'
        return results
    except fits.VerifyError as e:
        results['status'] = f'Error: FITS structural verification failed ({e})'
        return results
    except Exception as e:
        results['status'] = f'CRITICAL ERROR: FITS read failure ({type(e).__name__})'
        return results

# --- 3. Execution and Reporting ---

def run_survey_analysis():
    """Main function to orchestrate the survey analysis, reporting, and cleanup."""
    setup_environment()
    
    fits_files = sorted([
        os.path.join(SIMULATED_DATA_DIR, f) 
        for f in os.listdir(SIMULATED_DATA_DIR) 
        if f.endswith('.fits')
    ])
    
    if not fits_files:
        print("No FITS files found to process.")
        return

    print(f"\nStarting analysis of {len(fits_files)} FITS files...")
    
    all_results = []
    
    # Iterate and process, collecting structured data
    for i, filepath in enumerate(fits_files):
        print(f"  -> Processing file {i+1}/{len(fits_files)}: {os.path.basename(filepath)}")
        result = process_fits_file(filepath)
        all_results.append(result)

    # Summarize findings
    warnings = sum(1 for r in all_results if 'WARNING' in r['status'])
    errors = sum(1 for r in all_results if 'Error' in r['status'])
    
    print(f"\n--- Analysis Summary ---")
    print(f"Total files processed: {len(all_results)}")
    print(f"Warnings (Potential Saturation): {warnings}")
    print(f"Errors (Read/Integrity Failure): {errors}")

    # Generate final JSON report
    report_filename = os.path.join(OUTPUT_DIR, f"qa_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    
    with open(report_filename, 'w') as f:
        json.dump(all_results, f, indent=4)
        
    print(f"\nReport saved to: {report_filename}")
    
    # Clean up simulated files
    for f in os.listdir(SIMULATED_DATA_DIR):
        os.remove(os.path.join(SIMULATED_DATA_DIR, f))
    os.rmdir(SIMULATED_DATA_DIR)
    
    # Print a snippet of the results for verification
    print("\n--- Sample Report Snippet (First Two Entries) ---")
    print(json.dumps(all_results[0], indent=2))
    print(json.dumps(all_results[3], indent=2)) # Showing the saturated file
    print("-------------------------------------------------\n")

if __name__ == '__main__':
    run_survey_analysis()

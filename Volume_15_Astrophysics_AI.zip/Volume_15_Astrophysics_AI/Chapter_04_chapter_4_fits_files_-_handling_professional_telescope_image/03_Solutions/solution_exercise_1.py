
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from astropy.io import fits
import os

# --- Simulation: Create the required FITS file (M42_raw.fits) for testing ---
def create_mock_fits_1(filename='M42_raw.fits'):
    # Create 100x150 data
    data = np.random.randint(100, 5000, size=(100, 150), dtype=np.int16)
    hdu = fits.PrimaryHDU(data)
    
    # Add mandatory keywords
    hdu.header['DATE-OBS'] = ('2024-03-15T04:30:00', 'Observation date')
    hdu.header['EXPTIME'] = (120.5, 'Total exposure time (s)')
    hdu.header['INSTRUME'] = ('ACAM-1', 'Instrument name')
    hdu.header['RA'] = (83.8220833, 'Right Ascension (deg)')
    hdu.header['DEC'] = (-5.3911111, 'Declination (deg)')
    
    hdul = fits.HDUList([hdu])
    hdul.writeto(filename, overwrite=True, output_verify='silentfix')
    hdul.close()
# --- End Simulation ---

def audit_fits_file(filepath: str) -> dict:
    """
    Opens a FITS file, audits critical header keywords in HDU 0,
    and extracts statistical metrics from the primary data array.
    """
    MANDATORY_KEYWORDS = ['DATE-OBS', 'EXPTIME', 'INSTRUME', 'NAXIS1', 'NAXIS2', 'RA', 'DEC']
    
    # 1. Use context manager for safe file handling
    with fits.open(filepath) as hdul:
        primary_hdu = hdul[0]
        header = primary_hdu.header
        required_values = {}
        
        print(f"--- Auditing File: {filepath} ---")
        
        # 2. & 3. Check for mandatory keywords and print warnings if missing
        for keyword in MANDATORY_KEYWORDS:
            value = header.get(keyword)
            if value is None:
                print(f"WARNING: Required keyword {keyword} is missing from the header.")
            else:
                required_values[keyword] = value
                print(f"Keyword {keyword}: {value}")
        
        # 4. Extract data array and verify dimensions
        data = primary_hdu.data
        
        if data is None:
            raise ValueError("Primary HDU contains no data array.")

        # NAXIS1 corresponds to the second dimension (columns), NAXIS2 to the first (rows)
        naxis1 = required_values.get('NAXIS1')
        naxis2 = required_values.get('NAXIS2')

        if naxis1 != data.shape[1] or naxis2 != data.shape[0]:
            raise ValueError(
                f"Data dimension mismatch! Header: ({naxis2}, {naxis1}), Data: {data.shape}"
            )
        
        print(f"Data dimensions verified: {data.shape[1]}x{data.shape[0]}.")

        # 5. Calculate statistics
        stats = {
            'shape': data.shape,
            'dtype': str(data.dtype),
            'min': np.min(data),
            'max': np.max(data),
            'mean': np.mean(data)
        }
        
    return stats

# Example usage
FILE_PATH_1 = 'M42_raw.fits'
create_mock_fits_1(FILE_PATH_1)
results = audit_fits_file(FILE_PATH_1)
print("\n--- Statistical Report ---")
print(results)
os.remove(FILE_PATH_1)

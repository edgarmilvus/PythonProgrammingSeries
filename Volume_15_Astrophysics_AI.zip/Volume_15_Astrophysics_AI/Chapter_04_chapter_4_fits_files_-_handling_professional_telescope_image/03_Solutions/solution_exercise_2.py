
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
from astropy.io import fits
import os

# --- Simulation: Create the required FITS file (NGC1300_science.fits) ---
def create_mock_fits_2(filename='NGC1300_science.fits'):
    # Primary Image Data (HDU 0)
    image_data = np.zeros((50, 50), dtype=np.int32)
    primary_hdu = fits.PrimaryHDU(image_data)
    
    # Binary Table Data (HDU 1: STAR_CATALOG)
    N_stars = 500
    x_coords = np.random.uniform(0, 50, N_stars)
    fluxes = np.random.lognormal(mean=7.0, sigma=0.5, size=N_stars)
    
    col1 = fits.Column(name='X_IMAGE', format='D', array=x_coords)
    col2 = fits.Column(name='FLUX_AUTO', format='E', array=fluxes)
    
    cols = fits.ColDefs([col1, col2])
    catalog_hdu = fits.BinTableHDU.from_columns(cols)
    catalog_hdu.header['EXTNAME'] = 'STAR_CATALOG'
    
    # Another dummy extension (HDU 2)
    error_map_hdu = fits.ImageHDU(data=np.ones((50, 50)), name='ERROR_MAP')

    hdul = fits.HDUList([primary_hdu, catalog_hdu, error_map_hdu])
    hdul.writeto(filename, overwrite=True)
    hdul.close()
# --- End Simulation ---

def map_fits_structure(filepath: str) -> tuple[int, float]:
    """
    Analyzes a multi-HDU FITS file, maps its structure, and extracts
    statistical data from the 'STAR_CATALOG' binary table extension.
    """
    mean_flux = 0.0
    total_hdus = 0
    
    with fits.open(filepath) as hdul:
        total_hdus = len(hdul)
        print(f"--- FITS File Structure Mapping ({total_hdus} HDUs) ---")
        
        for i, hdu in enumerate(hdul):
            # 1. HDU Structure Mapping
            hdu_type = type(hdu).__name__
            extname = hdu.header.get('EXTNAME', 'N/A')
            print(f"HDU {i}: Type={hdu_type}, EXTNAME='{extname}'")
            
            # 2. Targeted Catalog Identification
            if extname == 'STAR_CATALOG' and hdu_type == 'BinTableHDU':
                print(f"\n--- Found Target Catalog: HDU {i} ---")
                
                # 3. Table Data Extraction (as a record array)
                table_data = hdu.data
                
                # 4. Column Analysis
                if table_data is not None and 'FLUX_AUTO' in table_data.names and 'X_IMAGE' in table_data.names:
                    
                    n_entries = len(table_data)
                    fluxes = table_data['FLUX_AUTO']
                    x_coords = table_data['X_IMAGE']
                    
                    mean_flux = np.mean(fluxes)
                    std_x = np.std(x_coords)
                    
                    print(f"Total entries (stars): {n_entries}")
                    print(f"Mean FLUX_AUTO: {mean_flux:.2f}")
                    print(f"Standard Deviation of X_IMAGE: {std_x:.2f}")
                else:
                    print("ERROR: STAR_CATALOG data or required columns missing.")

    return total_hdus, mean_flux

# Example usage
FILE_PATH_2 = 'NGC1300_science.fits'
create_mock_fits_2(FILE_PATH_2)
total_hdus, calculated_mean_flux = map_fits_structure(FILE_PATH_2)
print(f"\nFunction Return: Total HDUs={total_hdus}, Mean Flux={calculated_mean_flux:.2f}")
os.remove(FILE_PATH_2)

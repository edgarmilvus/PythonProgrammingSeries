
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from astropy.io import fits
import os

def create_and_modify_fits(filename: str):
    """
    Creates a FITS file from a NumPy array, modifies its header extensively
    to log calibration status and history, and verifies the output.
    """
    # 1. Create data array
    data = np.zeros((100, 100), dtype=np.float32)
    
    # 2. Create PrimaryHDU
    hdu = fits.PrimaryHDU(data)
    header = hdu.header
    
    print(f"--- Generating Header for {filename} ---")

    # 3. Keyword Modification (using the three-argument form: keyword, value, comment)
    header.set('BUNIT', 'ADU', 'Units of raw detector counts')
    header.set('DATAMAX', 65535.0, 'Maximum allowed pixel value (16-bit saturation)')
    header.set('CALIBRAT', True, 'Image has passed preliminary calibration checks')
    
    # 4. History Logging using dedicated method
    header.add_history("Pipeline execution started on 2024-05-01.")
    header.add_history("Flat-field correction applied on 2024-05-01 using pipeline v1.2.")
    header.add_history("Cosmic ray removal performed with L.A.Cosmic algorithm.")
    
    # 5. Comment Insertion
    header.add_comment("Result of preliminary pipeline processing, suitable for photometric analysis.")
    
    # Assemble HDU list
    hdul = fits.HDUList([hdu])
    
    # 6. File Writing (ensure overwrite=True)
    print(f"Writing file: {filename} (overwriting if exists)...")
    hdul.writeto(filename, overwrite=True)
    hdul.close()

    # 7. Verification: Reopen the file and print header
    print(f"\n--- Verification: Reopening and inspecting header ---")
    with fits.open(filename) as verify_hdul:
        verify_header = verify_hdul[0].header
        
        # Print enough lines to show the updates
        print(str(verify_header)[:800]) 

# Example execution
FILE_PATH_3 = 'calibrated_output.fits'
create_and_modify_fits(FILE_PATH_3)

if os.path.exists(FILE_PATH_3):
    os.remove(FILE_PATH_3)

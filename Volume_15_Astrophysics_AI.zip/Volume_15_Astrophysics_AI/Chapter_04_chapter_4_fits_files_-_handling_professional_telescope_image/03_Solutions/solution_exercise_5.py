
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from astropy.io import fits
import sys

REQUIRED_KEYWORDS = {
    'TELESCOP': ('Generic 1m', 'Name of the observatory telescope'),
    'OBSERVER': ('Unknown', 'Name of the principal observer'),
    'TEMP_CCD': (-120.0, 'CCD operating temperature in Celsius'),
    'FILTER': ('V_BAND', 'Filter used for observation'),
    'PIPELINE': ('v2.1.0', 'Software pipeline version used for reduction')
}

def generate_standard_header(keyword_dict: dict) -> fits.Header:
    """
    Generates a FITS header based on a template and allows interactive updates
    for key observation parameters.
    """
    # 1. Initialize an empty Header object
    header = fits.Header()
    
    print("--- Generating Standard Header Template ---")

    # 2. Dynamic Population: Loop through the dictionary and use header.set()
    for keyword, (value, comment) in keyword_dict.items():
        # Use the three-argument form (keyword, value, comment)
        header.set(keyword, value, comment)
        print(f"Added: {keyword} = {value}")

    # 3. & 4. Interactive Update
    print("\n--- Interactive Update Required ---")
    
    # Check if we are in an environment that supports interactive input
    if sys.stdin.isatty():
        try:
            # Prompt for OBSERVER
            new_observer = input(f"Enter new OBSERVER name (Current: {header['OBSERVER']}): ")
            if new_observer:
                # Update the value, preserving the original comment
                header.set('OBSERVER', new_observer)
                print(f"Updated OBSERVER to: {new_observer}")
            else:
                print("OBSERVER name skipped, retaining default.")
                
            # Prompt for FILTER
            new_filter = input(f"Enter new FILTER name (Current: {header['FILTER']}): ")
            if new_filter:
                header.set('FILTER', new_filter)
                print(f"Updated FILTER to: {new_filter}")
            else:
                print("FILTER name skipped, retaining default.")
                
        except EOFError:
            print("\nWARNING: Input failed (EOF). Using default values.")
            
    else:
        # Simulate update for verification in non-interactive environments
        header.set('OBSERVER', 'Simulated_User', 'Name of the principal observer')
        header.set('FILTER', 'R_BAND', 'Filter used for observation')
        print("Non-interactive environment detected. Using simulated updates.")
        
    return header

# Example execution:
final_header = generate_standard_header(REQUIRED_KEYWORDS)

print("\n--- Final Generated FITS Header ---")
print(final_header)

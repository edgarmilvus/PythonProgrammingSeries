
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from astropy.io import fits
import os

# --- Simulation: Create a file large enough to demonstrate slicing (2000x2000) ---
def create_mock_fits_4(filename='huge_survey_field.fits', size=2000):
    # Create data where values correspond to their index for verification
    data = np.arange(size * size, dtype=np.float32).reshape(size, size)
    hdu = fits.PrimaryHDU(data)
    
    hdul = fits.HDUList([hdu])
    hdul.writeto(filename, overwrite=True)
    hdul.close()
    return size
# --- End Simulation ---

def extract_central_region(filepath: str, full_size: int, slice_size: int) -> float:
    """
    Efficiently extracts a central slice from a large FITS file using 
    memory-mapping to avoid loading the entire dataset.
    """
    # 1. Coordinate Calculation
    if full_size < slice_size:
        raise ValueError("Slice size cannot exceed full size.")
        
    start_index = (full_size - slice_size) // 2
    end_index = start_index + slice_size
    
    print(f"Calculated ROI: [{start_index}:{end_index}, {start_index}:{end_index}]")
    
    total_flux = 0.0
    
    # 2. Memory-Mapped Access (memmap=True is default)
    with fits.open(filepath, memmap=True) as hdul:
        
        # 3. Access the data object (memory-mapped, not yet loaded)
        data_object = hdul[0].data
        
        # 4. Targeted Slicing: This operation reads ONLY the sliced region from disk.
        # This is where the memory-mapping efficiency is utilized.
        central_region = data_object[start_index:end_index, start_index:end_index]
        
        # 5. Verification and Analysis
        if central_region.shape != (slice_size, slice_size):
            raise RuntimeError(f"Extracted slice shape mismatch: {central_region.shape}")
            
        print(f"Extracted region shape verified: {central_region.shape}")
        
        # 6. Calculate and return the sum
        total_flux = np.sum(central_region)
        
    return total_flux

# Example usage:
FILE_PATH_4 = 'huge_survey_field.fits'
# We test the function using a 2000x2000 mock file, but the logic scales to 20000x20000
ACTUAL_SIZE = create_mock_fits_4(FILE_PATH_4, size=2000) 

# Start index calculation for 2000x2000 -> 512x512: (2000 - 512) / 2 = 744
total_flux = extract_central_region(FILE_PATH_4, full_size=ACTUAL_SIZE, slice_size=512) 

print(f"\nTotal flux in the 512x512 central ROI: {total_flux}")
os.remove(FILE_PATH_4)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import os
from astropy.io import fits

# --- 1. Setup and FITS File Creation (Necessary for a self-contained example) ---
FITS_FILENAME = "test_galaxy_image.fits"
DUMMY_SHAPE = (10, 10)

def create_dummy_fits():
    """Creates a simple Primary HDU FITS file for demonstration."""
    # Create a 2D array representing simulated image data (e.g., pixel intensity)
    # This simulates a 10x10 image where pixel values range from 0 to 99
    data = np.arange(DUMMY_SHAPE[0] * DUMMY_SHAPE[1], dtype=np.int16).reshape(DUMMY_SHAPE)

    # Create the Primary Header Data Unit (HDU). This is the main container for the image.
    primary_hdu = fits.PrimaryHDU(data)

    # Add essential metadata to the header. Keywords must be 8 characters or less.
    primary_hdu.header['OBSERVER'] = ('Dr. K. Stellar', 'Name of the person who took the data')
    primary_hdu.header['TELESCOP'] = 'Hubble Simulator'
    primary_hdu.header['EXPTIME'] = (300.0, 'Exposure time in seconds')
    primary_hdu.header['OBJECT'] = ('M101', 'Target object name')

    # FITS files are collections of HDUs. Create an HDUList.
    hdul = fits.HDUList([primary_hdu])
    
    # Write the list of HDUs to the disk. overwrite=True prevents errors if the file exists.
    hdul.writeto(FITS_FILENAME, overwrite=True)
    hdul.close() # Explicitly close the list object after writing
    print(f"Successfully created dummy FITS file: {FITS_FILENAME}")

# Execute the creation function
create_dummy_fits()

# --- 2. Reading, Inspecting, and Extracting Data ---

print("\n--- Starting FITS File Analysis ---")

# Use a 'with' statement for safe file handling. This guarantees the file handle is closed.
try:
    with fits.open(FITS_FILENAME) as hdul:
        # The 'hdul' variable is now an HDUList object representing the file structure.

        # A. Inspection: Print the overall structure of the HDU List
        print("\n[A] HDU List Structure (hdul.info()):")
        hdul.info()

        # B. Accessing the Primary HDU (index 0)
        # FITS standards dictate that the primary image data is almost always at index 0.
        primary_hdu = hdul[0]

        # C. Accessing the Header (Metadata)
        # The .header attribute returns a specialized dictionary-like object (Header)
        header = primary_hdu.header
        print("\n[C] Extracted Header Metadata:")
        
        # Accessing keywords directly using dictionary-like syntax
        print(f"Target Object: {header['OBJECT']}")
        print(f"Telescope Used: {header['TELESCOP']}")
        print(f"Exposure Time (s): {header['EXPTIME']}")
        
        # Demonstrating access to the comment associated with a keyword
        print(f"Comment for EXPTIME: {header.comments['EXPTIME']}")

        # D. Accessing the Data Array (The image itself)
        # The .data attribute returns the image data as a NumPy array view
        image_data = primary_hdu.data
        print("\n[D] Extracted Image Data Array:")
        print(f"Data Type (Numpy dtype): {image_data.dtype}")
        print(f"Data Shape (Dimensions): {image_data.shape}")
        
        # Display the corner of the image data for verification
        print(f"First 5x5 block of data:\n{image_data[:5, :5]}")

except FileNotFoundError:
    print(f"Error: FITS file not found at {FITS_FILENAME}")
except Exception as e:
    print(f"An unexpected error occurred during FITS processing: {e}")

finally:
    # --- 3. Cleanup ---
    if os.path.exists(FITS_FILENAME):
        os.remove(FITS_FILENAME)
        print(f"\nCleanup: Removed {FITS_FILENAME}")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import matplotlib.pyplot as plt
import numpy as np
import os

# --- 1. Define Stellar Data (Temperature in Kelvin, Luminosity in Solar Units) ---

# Data represents a diverse set of stellar types for demonstration
star_names = ['The Sun (G2V)', 'Rigel (B8Ia)', 'Sirius B (White Dwarf)']
# Effective Temperature (K): Note the vast range
raw_temperatures = np.array([5778, 12100, 25000]) 
# Luminosity (L/L_sun): Note the vast range
raw_luminosities = np.array([1, 85000, 0.0025]) 

# --- 2. Data Transformation: Applying Logarithmic Scales ---

# The HR Diagram traditionally uses log scales due to the immense ranges involved.
# We use log10 for both axes.
log_temperatures = np.log10(raw_temperatures)
log_luminosities = np.log10(raw_luminosities)

# --- 3. Setting up the Plotting Environment ---

plt.figure(figsize=(10, 7)) # Define the size of the visualization canvas

# --- 4. Plotting the Data Points ---

# Use a scatter plot to represent individual stars
plt.scatter(log_temperatures, log_luminosities, 
            c=['gold', 'blue', 'white'], 
            edgecolors='black', 
            s=150, 
            label='Sample Stars')

# Annotate each point with its name for clarity
for i, name in enumerate(star_names):
    # Adjust position slightly for better visibility
    plt.annotate(name, (log_temperatures[i] + 0.01, log_luminosities[i]), fontsize=9)

# --- 5. HR Diagram Specific Formatting: The Critical Step ---

# The X-axis (Temperature) must decrease from left to right in the HR Diagram.
# This inversion is non-negotiable for standard astrophysical convention.
plt.gca().invert_xaxis() 

# --- 6. Labeling and Aesthetics ---

plt.title('Basic Hertzsprung-Russell Diagram Sample')
plt.xlabel('Log$_{10}$ Effective Temperature (Log K)')
plt.ylabel('Log$_{10}$ Luminosity (Log L/L$_\odot$)')
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()

# --- 7. Saving the Output ---

# Determine the current working directory to save the output file
output_path = os.path.join(os.getcwd(), 'basic_hr_diagram.png')
plt.savefig(output_path, dpi=300)
print(f"HR Diagram saved successfully to: {output_path}")

# Display the plot (optional, depending on execution environment)
plt.show()

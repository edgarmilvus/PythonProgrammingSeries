
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import random
import time

# 1. Define the Asynchronous Context Manager
class AstroAPIConnector:
    """Manages asynchronous resource connection and guaranteed cleanup."""
    def __init__(self, api_url):
        self.api_url = api_url

    async def __aenter__(self):
        # Simulate connection establishment
        print("--- API Connection Established ---")
        await asyncio.sleep(0.1) 
        return self # Return the connection object (self)

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Resource cleanup, guaranteed to run
        await asyncio.sleep(0.1)
        if exc_type is not None:
            print(f"Warning: An exception was caught during the block execution ({exc_type.__name__}).")
        
        print("--- API Connection Closed ---")
        
        # Returning False allows the exception (if one occurred) to propagate
        return False 

# 2. Simulate Asynchronous Fetching
async def fetch_spectroscopic_data(star_id):
    """Simulates fetching spectroscopic data with a random failure chance."""
    
    # Randomly raise an exception (5% failure rate)
    if random.random() < 0.05:
        raise ConnectionError(f"Failed to fetch data for {star_id}")
        
    # Simulate network latency
    await asyncio.sleep(random.uniform(0.01, 0.05))
    
    # Simulate data return
    classes = ['O', 'B', 'A', 'F', 'G', 'K', 'M']
    classification = f'{random.choice(classes)}{random.randint(0, 9)}V'
    
    return star_id, classification

# 3. Execution
async def main_async_fetch():
    star_ids = [f"Star_{i:04d}" for i in range(1000)] # Using 1000 for faster demonstration
    
    successful_fetches = 0
    failed_fetches = 0
    
    # Use the asynchronous context manager
    async with AstroAPIConnector(api_url="http://simulated.api") as connection:
        # Create concurrent tasks
        tasks = [fetch_spectroscopic_data(star_id) for star_id in star_ids]
        
        # Use asyncio.gather to run tasks concurrently, collecting exceptions
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for result in results:
            if isinstance(result, Exception):
                failed_fetches += 1
            else:
                successful_fetches += 1
                
    print(f"\n--- Summary ---")
    print(f"Total tasks attempted: {len(star_ids)}")
    print(f"Successful fetches: {successful_fetches}")
    print(f"Failed fetches: {failed_fetches}")

# 4. Verification (Run the asynchronous main function)
if __name__ == '__main__':
    asyncio.run(main_async_fetch())

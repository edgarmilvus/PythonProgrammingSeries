
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings

# Suppress runtime warnings for log(0) or log(negative) during simulation setup
warnings.filterwarnings('ignore', category=RuntimeWarning)

# --- Data Simulation ---
np.random.seed(42)
N = 5000
data = pd.DataFrame({
    'm_V': np.random.uniform(5, 15, N),
    # Generate mostly positive parallax, but include invalid values for EAFP test
    'parallax_mas': np.abs(np.random.normal(5, 5, N)) + 0.1,
    'color_index': np.random.normal(0.5, 0.8, N)
})
# Introduce intentional invalid data (zero/negative parallax)
data.loc[100:150, 'parallax_mas'] = np.random.uniform(-5, 0, 51)
data.loc[200:205, 'parallax_mas'] = 0.0
data.dropna(subset=['m_V', 'parallax_mas', 'color_index'], inplace=True)


def calculate_mv_eafp(m_v, pi_mas):
    """
    Calculates M_V using EAFP. Returns np.nan if ValueError occurs (pi <= 0).
    M_V = m_V + 5 + 5 * log10(pi_mas / 1000)
    """
    pi_arcsec = pi_mas / 1000.0
    
    try:
        # Attempt the calculation directly
        M_V = m_v + 5 + 5 * np.log10(pi_arcsec)
        # Ensure result is finite before returning
        return M_V if np.isfinite(M_V) else np.nan
        
    except ValueError:
        # Catches log(x) where x <= 0
        return np.nan
    except Exception:
        # Catch any other unexpected error
        return np.nan

# Apply calculation and clean data
data['M_V'] = data.apply(
    lambda row: calculate_mv_eafp(row['m_V'], row['parallax_mas']),
    axis=1
)
data.dropna(subset=['M_V'], inplace=True)

# --- Visualization ---
plt.figure(figsize=(10, 8))
plt.scatter(data['color_index'], data['M_V'], s=5, alpha=0.6, color='darkblue')

plt.gca().invert_yaxis() # Invert Y-axis for standard HR Diagram
plt.title('Hertzsprung-Russell Diagram (Initial Generation)')
plt.xlabel('Color Index (C, decreasing temperature to the left)')
plt.ylabel('Absolute V-band Magnitude ($M_V$, increasing luminosity up)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()

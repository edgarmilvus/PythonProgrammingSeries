
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import time
import numpy as np
import pandas as pd
from math import log10

# --- Data Simulation for Comparison ---
N_test = 100000
test_data = pd.DataFrame({
    'm_V': np.random.uniform(5, 15, N_test),
    'pi': np.random.normal(5, 10, N_test),
    'pi_err': np.random.uniform(0.5, 5, N_test)
})
# Ensure pi is slightly positive for some cases where pi/pi_err is small
test_data.loc[test_data['pi'] < 0, 'pi'] = np.abs(test_data.loc[test_data['pi'] < 0, 'pi']) * 0.1
test_data.loc[5000:5010, 'pi_err'] = 0.0 # Introduce zero error

# 1. LBYL Implementation
def calculate_mv_lbyl(m_v, pi, pi_err):
    """LBYL: Checks conditions explicitly before calculation."""
    # Check 1 & 2: Validity checks
    if pi <= 0 or pi_err == 0:
        return np.nan
        
    # Check 3: Quality filter
    if pi / pi_err <= 5:
        return np.nan
        
    pi_arcsec = pi / 1000.0
    return m_v + 5 + 5 * log10(pi_arcsec)


# 2. EAFP Implementation
class ParallaxQualityError(Exception):
    """Custom exception for poor parallax quality."""
    pass

def calculate_mv_eafp(m_v, pi, pi_err):
    """EAFP: Attempts calculation and catches exceptions."""
    try:
        # Check for zero error first (critical for division)
        if pi_err == 0:
            raise ZeroDivisionError 
            
        # Quality filter check is embedded, raising a custom exception
        if pi / pi_err <= 5:
            raise ParallaxQualityError
            
        # Calculation attempt (will raise ValueError if pi <= 0)
        M_V = m_v + 5 + 5 * log10(pi / 1000.0)
        
        if not np.isfinite(M_V):
             return np.nan
        return M_V
        
    except (ValueError, ZeroDivisionError, ParallaxQualityError):
        # Catch all expected failures
        return np.nan
    except Exception:
        # Catch unexpected errors
        return np.nan

# 3. Comparative Analysis
print(f"Testing performance on {N_test} records:")

# LBYL Timing
start_time_lbyl = time.time()
test_data.apply(lambda row: calculate_mv_lbyl(row['m_V'], row['pi'], row['pi_err']), axis=1)
time_lbyl = time.time() - start_time_lbyl
print(f"LBYL Execution Time: {time_lbyl:.4f} seconds.")

# EAFP Timing
start_time_eafp = time.time()
test_data.apply(lambda row: calculate_mv_eafp(row['m_V'], row['pi'], row['pi_err']), axis=1)
time_eafp = time.time() - start_time_eafp
print(f"EAFP Execution Time: {time_eafp:.4f} seconds.")

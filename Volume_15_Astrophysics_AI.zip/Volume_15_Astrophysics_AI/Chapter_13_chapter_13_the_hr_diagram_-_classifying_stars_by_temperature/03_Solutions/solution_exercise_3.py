
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Assuming 'data' DataFrame from Exercise 2 is available and classified
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 1. Isolating the MS
ms_data = data[data['Stellar_Class'] == 'MS'].copy()

# Ensure we have enough data points for binning
if len(ms_data) < 100:
    M_V_MSTO = 2.0
    C_MSTO = 0.5
    cluster_age_gyr = 5.0 # Placeholder age
else:
    # 2. Binning and Smoothing: Use 20 bins across the color range
    C_min = ms_data['color_index'].min()
    C_max = ms_data['color_index'].max()
    bins = np.linspace(C_min, C_max, 21)
    
    ms_data['C_Bin'] = pd.cut(ms_data['color_index'], bins=bins, include_lowest=True)
    
    # Calculate the 10th percentile M_V (representing the brightest stars/upper envelope)
    binned_envelope = ms_data.groupby('C_Bin')['M_V'].quantile(0.1).reset_index()
    # Calculate the midpoint of the bin for plotting purposes
    binned_envelope['C_Mid'] = binned_envelope['C_Bin'].apply(lambda x: x.mid)
    
    # 3. Identifying the Turn-Off: Minimum M_V in the envelope
    M_V_MSTO = binned_envelope['M_V'].min()
    msto_point = binned_envelope[binned_envelope['M_V'] == M_V_MSTO].iloc[0]
    C_MSTO = msto_point['C_Mid']

    # 4. Age Calculation Proxy
    def estimate_cluster_age(M_V_MSTO):
        """Calculates age in Gyr based on MSTO luminosity."""
        M_bol_sun = 4.74
        # log10(tau) = 10.0 + 0.4 * (M_V_MSTO - M_bol_sun)
        log_tau_years = 10.0 + 0.4 * (M_V_MSTO - M_bol_sun)
        tau_years = 10**log_tau_years
        tau_Gyr = tau_years / 1e9
        return tau_Gyr

    cluster_age_gyr = estimate_cluster_age(M_V_MSTO)

# 5. Visualization
plt.figure(figsize=(10, 8))
plt.scatter(ms_data['color_index'], ms_data['M_V'], s=5, alpha=0.5, color='blue', label='Main Sequence Stars')

if len(ms_data) >= 100:
    plt.plot(binned_envelope['C_Mid'], binned_envelope['M_V'], color='red', linewidth=2, label='MS Upper Envelope')
    plt.scatter(C_MSTO, M_V_MSTO, s=150, color='gold', edgecolor='black', zorder=5, 
                label=f'MSTO Point ($M_V={M_V_MSTO:.2f}$)')

plt.gca().invert_yaxis()
plt.title(f'Main Sequence Turn-Off (MSTO) Analysis\nEstimated Cluster Age: {cluster_age_gyr:.2f} Gyr')
plt.xlabel('Color Index (C)')
plt.ylabel('Absolute V-band Magnitude ($M_V$)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()

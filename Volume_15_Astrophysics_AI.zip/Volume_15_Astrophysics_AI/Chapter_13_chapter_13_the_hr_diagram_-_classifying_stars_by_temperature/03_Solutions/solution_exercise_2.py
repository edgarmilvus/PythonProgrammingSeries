
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Assuming 'data' DataFrame from Exercise 1 is available and cleaned
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Re-run simulation setup if needed (for isolated execution)
try:
    data.head()
except NameError:
    # Placeholder setup if Exercise 1 was not run immediately before
    np.random.seed(42)
    N = 5000
    data = pd.DataFrame({
        'm_V': np.random.uniform(5, 15, N),
        'parallax_mas': np.abs(np.random.normal(5, 5, N)) + 0.1,
        'color_index': np.random.normal(0.5, 0.8, N)
    })
    data['M_V'] = data['m_V'] + 5 + 5 * np.log10(data['parallax_mas'] / 1000.0)
    data.dropna(subset=['M_V'], inplace=True)


def classify_star(M_V, C):
    """Classifies a star based on defined HR diagram boundaries."""
    
    # 1. Giants/Supergiants (High Luminosity, Low M_V)
    if M_V < 2:
        if M_V < -2:
            return 'Supergiant'
        return 'Giant'
    
    # 2. White Dwarfs (High M_V, relatively hot, low C)
    if M_V > 10 and C < 0.8:
        return 'WD'
    
    # 3. Main Sequence (Defined by a diagonal band)
    # M_V roughly between 5*C - 5 (upper MS) and 5*C + 1 (lower MS)
    if (5 * C - 5) < M_V < (5 * C + 1):
        return 'MS'
    
    return 'Unclassified'

# Apply classification
data['Stellar_Class'] = data.apply(
    lambda row: classify_star(row['M_V'], row['color_index']),
    axis=1
)

# 4. Set Comprehension for Uniqueness
unique_classes = {cls for cls in data['Stellar_Class'] if pd.notna(cls)}
print(f"Unique Stellar Classes found: {unique_classes}")

# 5. Visual Verification
class_colors = {
    'MS': 'blue', 'Giant': 'orange', 'Supergiant': 'red', 
    'WD': 'purple', 'Unclassified': 'gray'
}

plt.figure(figsize=(10, 8))
for stellar_class, color in class_colors.items():
    subset = data[data['Stellar_Class'] == stellar_class]
    plt.scatter(
        subset['color_index'], subset['M_V'], s=5, alpha=0.6, 
        color=color, label=f'{stellar_class} ({len(subset)})'
    )

plt.gca().invert_yaxis()
plt.title('HR Diagram Programmatically Classified Stellar Populations')
plt.xlabel('Color Index (C)')
plt.ylabel('Absolute V-band Magnitude ($M_V$)')
plt.legend(markerscale=3)
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()

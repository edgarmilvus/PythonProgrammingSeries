
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import curve_fit

# --- 1. CONFIGURATION AND DATA GENERATION ---

# Set visualization style
sns.set_style("darkgrid")

# Define astronomical constants (used for classification logic)
# These constants define the approximate boundaries of the stellar populations
MAIN_SEQUENCE_SLOPE = -4.0
MAIN_SEQUENCE_INTERCEPT_ZERO = 5.0
GIANT_THRESHOLD_MAG = 2.0
WD_THRESHOLD_MAG = 10.0

def generate_synthetic_data(n_stars=5000):
    """Generates a synthetic dataset mimicking real stellar properties."""
    
    # Initialize DataFrame
    data = pd.DataFrame()
    
    # Generate Main Sequence (MS) stars (majority)
    n_ms = int(n_stars * 0.85)
    
    # B-V (Color Index) for MS stars (0.3 to 1.5, hotter to cooler)
    data['B_V'] = np.random.uniform(0.3, 1.5, n_ms)
    
    # Absolute Magnitude (M_abs) based on typical MS relation (M_abs approx 5 * B_V - 1)
    # Adding noise to simulate the width of the MS band
    ms_noise = np.random.normal(0, 1.2, n_ms)
    data['M_abs'] = (data['B_V'] * 5.5 - 1.5) + ms_noise
    
    # Generate White Dwarfs (WD) (small, hot, dim)
    n_wd = int(n_stars * 0.05)
    wd_bv = np.random.uniform(-0.1, 0.4, n_wd)
    wd_m_abs = np.random.uniform(10, 15, n_wd)
    
    wd_data = pd.DataFrame({
        'B_V': wd_bv,
        'M_abs': wd_m_abs
    })
    
    # Generate Giants/Supergiants (G/SG) (large, bright)
    n_g = int(n_stars * 0.10)
    g_bv = np.random.uniform(0.5, 1.8, n_g) # Redder colors
    g_m_abs = np.random.uniform(-5, 0, n_g) # Very bright (low magnitude)
    
    g_data = pd.DataFrame({
        'B_V': g_bv,
        'M_abs': g_m_abs
    })
    
    # Combine all generated data
    data = pd.concat([data, wd_data, g_data], ignore_index=True)
    
    # Simulate Parallax (pi) and Apparent Magnitude (m) for completeness,
    # although we use the pre-calculated M_abs for simplicity in this advanced example
    # as the focus is classification, not raw data conversion.
    
    # Parallax (in arcseconds, based on Distance Modulus: d = 1/pi)
    # M = m - 5 log10(d) + 5  =>  m = M + 5 log10(d) - 5
    # Let's assume an average distance for the population (e.g., 100 pc, so pi=0.01)
    distance_pc = 10**((data['M_abs'] - data['M_abs'].mean() + 5) / 5) * 10 
    data['Parallax_mas'] = (1000 / distance_pc) + np.random.normal(0, 0.5, n_stars)
    data['Parallax_mas'] = data['Parallax_mas'].clip(lower=0.1) # Ensure positive parallax
    
    # Calculate Apparent Magnitude 'm' (simulated observation)
    data['Apparent_Magnitude'] = data['M_abs'] + 5 * np.log10(distance_pc / 10)
    
    # Drop any NaNs that might occur from log operations on edge cases
    data.dropna(inplace=True)
    
    return data

# Load or generate data
stellar_data = generate_synthetic_data(n_stars=15000)
print(f"Dataset generated with {len(stellar_data)} stars.")
print(stellar_data.head())

# --- 2. ASTRONOMICAL CONVERSIONS (If starting from raw data) ---

def calculate_absolute_magnitude(m, parallax_mas):
    """
    Calculates Absolute Magnitude (M) from Apparent Magnitude (m) and Parallax (pi).
    M = m + 5 * log10(parallax_arcsec) + 5
    Parallax is given in milliarcseconds (mas), must convert to arcseconds (arcsec).
    1 arcsec = 1000 mas
    """
    # Convert mas to arcsec
    parallax_arcsec = parallax_mas / 1000.0
    
    # Handle zero or negative parallax (invalid/noisy data)
    parallax_arcsec[parallax_arcsec <= 0] = np.nan
    
    # Distance Modulus: 5 * log10(d/10)
    # Since d = 1/pi (where pi is in arcsec), d/10 = 1/(10*pi)
    # M = m + 5 + 5 * log10(pi)
    
    # M = m + 5 * np.log10(parallax_arcsec) + 5 
    # Note: If M_abs was not pre-calculated in the synthetic data, we would use:
    # return m + 5 * np.log10(parallax_arcsec) + 5
    
    # Since our synthetic data already has M_abs, we skip this calculation step
    # but the function is provided for theoretical completeness when using raw data.
    return stellar_data['M_abs'] # Returning the pre-calculated value for robustness

# Apply the calculation (though redundant here, it demonstrates the pipeline step)
stellar_data['M_abs_Recalculated'] = calculate_absolute_magnitude(
    stellar_data['Apparent_Magnitude'], 
    stellar_data['Parallax_mas']
)
# We will use the original 'M_abs' for classification as it is cleaner synthetic data.


# --- 3. EMPIRICAL TEMPERATURE ESTIMATION ---

# Empirical relationship (simplified) between B-V color index and effective temperature (T_eff in Kelvin)
# This is a highly non-linear relationship, modeled here using an exponential decay approximation
# T_eff ≈ 4600 * (1 / (0.92 * (B-V) + 1.7) + 1 / (0.92 * (B-V) + 0.62))
# A simpler, inverse power approximation is often used: T_eff = A * (B-V)^B + C
# We use a standard polynomial fit for visualization clarity in the classification step.

def bv_to_teff(bv):
    """Converts B-V color index to approximate Effective Temperature (T_eff) in Kelvin."""
    # Source: Adapted from Flower (1996) and general stellar models.
    # Note: HR diagram plots T_eff on a reverse log scale.
    
    # For classification, we often use the B-V index directly on the x-axis,
    # or a derived temperature. Let's return B-V index directly for the plot,
    # and define a pseudo-temperature for the classification logic.
    return bv

stellar_data['T_eff_Proxy'] = bv_to_teff(stellar_data['B_V'])


# --- 4. PROGRAMMATIC STELLAR CLASSIFICATION ---

def classify_star(row):
    """
    Classifies a single star based on its M_abs and B-V index (T_eff proxy).
    This function implements the physical boundaries of the HR diagram regions.
    """
    bv = row['B_V']
    m_abs = row['M_abs']
    
    # CRITICAL LOGIC: Define the Main Sequence band boundaries
    # The MS is defined by a central line (M_abs = 5.5 * B_V - 1.5) plus/minus a deviation.
    # Upper boundary (Giants/Supergiants are above this)
    ms_upper_bound = 5.5 * bv - 1.5 - 2.0 
    
    # Lower boundary (White Dwarfs are below this, or very cool dwarfs)
    ms_lower_bound = 5.5 * bv - 1.5 + 2.5
    
    # 1. Giant/Supergiant Region (High Luminosity, low magnitude)
    # If the star is significantly brighter than the expected Main Sequence luminosity for its color.
    if m_abs < ms_upper_bound and m_abs < GIANT_THRESHOLD_MAG:
        return 'Giant/Supergiant'
    
    # 2. White Dwarf Region (Low Luminosity, often hot/blue)
    # White Dwarfs are dim (high magnitude) and typically bluer (B-V < 0.5)
    if m_abs > WD_THRESHOLD_MAG and bv < 0.6:
        return 'White Dwarf'
    
    # 3. Main Sequence Region
    # If it falls within the defined MS band
    if m_abs >= ms_upper_bound and m_abs <= ms_lower_bound:
        return 'Main Sequence'
    
    # 4. Other/Subdwarfs (Edge cases or stars outside typical boundaries)
    return 'Other/Subdwarf'

# Apply the classification function across the entire dataset
stellar_data['Stellar_Class'] = stellar_data.apply(classify_star, axis=1)

# Report the distribution of classifications
print("\nStellar Classification Distribution:")
print(stellar_data['Stellar_Class'].value_counts())


# --- 5. VISUALIZATION: THE HR DIAGRAM PLOT ---

def plot_hr_diagram(data):
    """Generates the HR Diagram, colored by classification."""
    
    plt.figure(figsize=(14, 10))
    
    # 5a. Plotting the raw data (density map for visual clarity)
    # Use hexbin or KDE plot for large datasets to visualize density, 
    # which is crucial for identifying the central Main Sequence spine.
    
    ax = sns.jointplot(
        x=data['B_V'], 
        y=data['M_abs'], 
        kind="hex", 
        cmap="plasma", 
        height=8,
        marginal_kws=dict(bins=30, fill=True)
    )
    
    # Invert the Y-axis (Absolute Magnitude: Brighter stars have lower magnitude, are at the top)
    ax.ax_joint.invert_yaxis()
    
    # Invert the X-axis (B-V Index: Bluer/Hotter stars are on the left, lower B-V)
    # Note: If plotting T_eff, we would use log scale and invert. Since we use B-V, 
    # the standard astronomical convention is B-V increasing to the right (Redder/Cooler).
    
    ax.set_axis_labels("Color Index (B-V, Proxy for Temperature)", "Absolute Magnitude ($M_V$, Proxy for Luminosity)")
    ax.fig.suptitle("Hertzsprung-Russell Diagram: Density Mapping", y=1.02, fontsize=16)
    
    # Add labels for key temperature ranges (approximate)
    ax.ax_joint.text(-0.2, -7, 'Hot/Blue (O, B)', rotation=90, color='white', backgroundcolor='black', alpha=0.7)
    ax.ax_joint.text(1.8, -7, 'Cool/Red (K, M)', rotation=90, color='white', backgroundcolor='black', alpha=0.7)
    
    plt.show()
    
    # 5b. Plotting the Classification Results
    
    plt.figure(figsize=(14, 10))
    
    # Define colors for classification
    palette = {
        'Main Sequence': '#3498db',
        'Giant/Supergiant': '#e74c3c',
        'White Dwarf': '#9b59b6',
        'Other/Subdwarf': '#7f8c8d'
    }
    
    # Plot the classified data
    sns.scatterplot(
        x='B_V', 
        y='M_abs', 
        hue='Stellar_Class', 
        data=data, 
        palette=palette,
        s=10, 
        alpha=0.6,
        edgecolor=None
    )
    
    plt.title("HR Diagram with Programmatic Stellar Classification", fontsize=16)
    plt.xlabel("Color Index (B-V)")
    plt.ylabel("Absolute Magnitude ($M_V$)")
    
    # Invert the Y-axis (Luminosity)
    plt.gca().invert_yaxis()
    
    # Add annotations for key regions
    plt.text(1.2, 13, 'White Dwarfs', fontsize=12, color=palette['White Dwarf'])
    plt.text(0.8, -3, 'Giants/Supergiants', fontsize=12, color=palette['Giant/Supergiant'])
    plt.text(0.5, 5, 'Main Sequence', fontsize=12, color=palette['Main Sequence'])
    
    plt.legend(title='Stellar Class', loc='lower left')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.show()

# Execute the visualization functions
plot_hr_diagram(stellar_data)


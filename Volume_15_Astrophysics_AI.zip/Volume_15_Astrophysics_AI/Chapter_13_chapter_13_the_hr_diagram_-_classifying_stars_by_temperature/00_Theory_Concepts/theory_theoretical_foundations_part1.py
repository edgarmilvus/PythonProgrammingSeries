
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

# Theoretical Foundations: Preparing HR Diagram Data Structure

# 1. Import necessary libraries (will be used in the practical section)
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 2. Define Spectral Classes and their corresponding approximate temperatures (in Kelvin)
# O B A F G K M
# This array establishes the temperature gradient for the X-axis (Hot to Cold)
spectral_temperatures = {
    'O': 30000,
    'B': 15000,
    'A': 8500,
    'F': 6500,
    'G': 5780,  # Sun
    'K': 4500,
    'M': 3000
}

# 3. Sample Stellar Data (Fictionalized for demonstration, based on typical HR positions)
# Data structure: (Spectral Class, Absolute Magnitude (M_V), Color Index (B-V), Stellar Type)
stellar_data = [
    ('O5', -5.5, -0.35, 'Main Sequence (Hot)'),      # Top Left MS
    ('A1', 0.5, 0.05, 'Main Sequence'),
    ('G2', 4.8, 0.65, 'Main Sequence (Sun-like)'),
    ('M0', 9.0, 1.40, 'Main Sequence (Cool)'),       # Bottom Right MS
    ('K0III', -1.0, 1.00, 'Red Giant'),              # Upper Right
    ('M5III', -3.0, 1.60, 'Red Giant'),              # Upper Right (Cooler, more luminous)
    ('A5V', 11.0, 0.20, 'White Dwarf'),              # Bottom Left (Hot, dim)
    ('B8V', 12.5, -0.10, 'White Dwarf')              # Bottom Left (Hotter, dimmer)
]

# Convert the list of tuples into a DataFrame for easier manipulation
df_stars = pd.DataFrame(stellar_data, columns=['Spectral_Class', 'Absolute_Magnitude', 'Color_Index_BV', 'Stellar_Type'])

# 4. Preparing the Axes for Plotting

# X-Axis Data: We will use the Color Index (B-V) as the primary observational variable.
X_data = df_stars['Color_Index_BV']

# Y-Axis Data: Absolute Magnitude (M_V).
Y_data = df_stars['Absolute_Magnitude']

# 5. Key Requirement for HR Plotting: Inverting the X and Y Axes

# The HR Diagram requires:
# a) Y-axis (Magnitude) to be inverted (Lower values are higher on the plot).
# b) X-axis (Temperature/Color) to be inverted (Lower values/Bluer colors are on the left).

# When plotting, we will use Matplotlib's functionality to invert the axes:
# ax.invert_yaxis()
# ax.invert_xaxis()

# Example of how the data looks before plotting inversion:
print("--- Sample HR Data Structure ---")
print(df_stars)
print("\nNote: Absolute Magnitude (Y) values are lower for brighter stars.")
print("Note: Color Index (X) values are lower (more negative) for hotter stars.")

# End of theoretical setup

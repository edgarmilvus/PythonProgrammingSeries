
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
import lightkurve as lk
from astropy.io import fits
import sys
import logging
from typing import Optional, Dict, Any

# Configure basic logging for clearer output status
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

# --- Configuration Management: The Secure Setup ---

# Define the expected Environment Variable name for secure API access.
# In a real scenario, this token might grant access to restricted datasets.
MAST_API_KEY_NAME = "KEPLER_MAST_TOKEN"

# Safely attempt to retrieve the API key using os.environ.get().
# This is crucial: if the variable isn't set, 'mast_token' will be None,
# preventing the script from crashing (KeyError).
mast_token: Optional[str] = os.environ.get(MAST_API_KEY_NAME)

# --- Target Definition and Parameters ---

# KIC ID of a known exoplanet candidate (Kepler-10, known for its hot, rocky planet).
TARGET_KIC_ID = "KIC 11904151"
MISSION_NAME = 'Kepler'
CADENCE_TYPE = 'long'

# --- Data Acquisition Function ---

def fetch_kepler_data(kic_id: str, mission: str, cadence: str, token: Optional[str]) -> Optional[lk.LightCurve]:
    """
    Searches for and downloads the primary light curve for a given KIC ID
    from the specified mission (e.g., Kepler).
    
    Args:
        kic_id: The Kepler Input Catalog ID (KIC ID).
        mission: The astronomical mission ('Kepler', 'TESS', etc.).
        cadence: The observation cadence ('long' or 'short').
        token: Optional security token retrieved from environment variables.
        
    Returns:
        The first downloaded LightCurve object, or None if retrieval fails.
    """
    
    logger.info(f"Starting data fetch for target KIC: {kic_id} from {mission}.")
    
    # Security Check Simulation: Acknowledge the presence or absence of the token.
    if token:
        logger.info(f"Token found for {MAST_API_KEY_NAME}. Configuring secure access (simulated).")
        # In a real deployment, lk.config.set_mast_token(token) might be used here.
    else:
        logger.warning(f"No MAST API Token found in environment variables. Proceeding with public access.")
    
    try:
        # 1. Search the MAST archive using the lightkurve search function.
        # This returns a table-like object (SearchResult) listing available data files.
        search_results = lk.search_lightcurve(
            target=kic_id, 
            mission=mission, 
            cadence=cadence
        )
        
        # Check if the search yielded any results
        if not search_results:
            logger.error(f"No {mission} light curves found for {kic_id} with {cadence} cadence.")
            return None
        
        logger.info(f"Found {len(search_results)} potential light curve files.")
        
        # 2. Download all the found light curves.
        # This returns a LightCurveCollection object, which is a list of individual LightCurve objects.
        lc_collection = search_results.download_all()
        
        if lc_collection:
            # 3. Access the first downloaded LightCurve object for immediate use.
            first_lc = lc_collection[0]
            
            logger.info(f"Successfully downloaded {len(lc_collection)} light curve files.")
            logger.info(f"First light curve contains {len(first_lc.time)} data points over {first_lc.mission} Quarter {first_lc.quarter}.")
            
            # Print the structure of the data object
            logger.info(f"Data object type: {type(first_lc)}")
            logger.info(f"Data columns available: {first_lc.flux.name}, {first_lc.time.name}, etc.")
            
            return first_lc
        else:
            logger.error(f"Download failed for {kic_id}. Collection was empty after download attempt.")
            return None
    
    # Catching broad exceptions ensures the script doesn't halt unexpectedly
    except Exception as e:
        logger.critical(f"A critical error occurred during data fetching: {type(e).__name__}: {e}")
        return None

# --- Execution Block ---

# Call the function to retrieve the data object
kepler_lc_object = fetch_kepler_data(
    kic_id=TARGET_KIC_ID,
    mission=MISSION_NAME,
    cadence=CADENCE_TYPE,
    token=mast_token
)

# Final confirmation check and next steps preparation
if kepler_lc_object:
    logger.info("\n[SUCCESS] Basic Kepler data retrieval complete. Data is ready for cleaning and phase folding.")
    # The 'kepler_lc_object' is now a LightCurve object ready for analysis in subsequent chapters.
    
    # Example: Accessing the raw flux values
    first_five_flux = kepler_lc_object.flux[:5].value
    logger.info(f"First five raw flux values: {first_five_flux}")
    
else:
    logger.error("\n[FAILURE] Data retrieval failed. Check KIC ID, network connection, or API token configuration.")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

import numpy as np
import pandas as pd
from astropy.io import fits
# lightkurve is the standard library for Kepler/TESS data handling
import lightkurve as lk 
from scipy.signal import savgol_filter

# --- 1. Conceptual Data Acquisition ---
# In a real scenario, we would download FITS files from the NASA Exoplanet Archive
# For this theoretical setup, we simulate loading a Kepler Light Curve (KLC) object.

def load_and_clean_kepler_data(kic_id: int, quarter: int) -> pd.DataFrame:
    """
    Simulates loading a raw Kepler light curve, removing flagged quality issues,
    and performing initial normalization.
    """
    print(f"Loading Kepler data for KIC {kic_id}, Quarter {quarter}...")
    
    try:
        # Fetching data using lightkurve (requires internet access)
        # We target the specific long-cadence file
        lc_collection = lk.search_lightcurve(f'KIC {kic_id}', quarter=quarter, cadence='long').download_all()
        
        if not lc_collection:
            print("Error: No light curve found for specified parameters.")
            return None

        # Stitch all quarters together (if multiple files were downloaded)
        lc = lc_collection.stitch()
        
    except Exception as e:
        print(f"Failed to download data: {e}")
        # Create dummy data for demonstration if download fails
        time = np.linspace(0, 90, 1000) # 90 days of observation
        flux_baseline = 1.0
        # Add some noise and simulated stellar variability
        flux = flux_baseline + 0.005 * np.sin(time / 10) + np.random.normal(0, 0.001, 1000)
        lc = lk.LightCurve(time=time, flux=flux)
        print("Using simulated data for demonstration.")


    # --- 2. Initial Cleaning and Quality Flagging ---
    # Kepler data comes with quality flags indicating issues (e.g., thruster firings, cosmic rays)
    # We remove data points marked as bad quality.
    lc_clean = lc.remove_nans().remove_outliers(sigma=5)
    
    # --- 3. Normalization and Detrending Preparation ---
    # We normalize the flux so the median flux is 1.0. This is essential for
    # comparing transits of different star brightnesses.
    lc_norm = lc_clean.normalize()

    # Apply a high-pass filter (Savitzky-Golay) to remove long-term stellar trends 
    # (e.g., rotation or instrumentation drift) while preserving short-term transits.
    # Window length determines the scale of features smoothed out.
    window_length = 201 # Must be odd
    polyorder = 3
    
    # Calculate the trend (the smooth stellar variability)
    trend = savgol_filter(lc_norm.flux.value, window_length, polyorder)
    
    # Detrended flux is the observed flux divided by the trend
    detrended_flux = lc_norm.flux.value / trend

    # Create a clean DataFrame output
    data = pd.DataFrame({
        'time': lc_norm.time.value,
        'flux': detrended_flux
    })

    print(f"Data cleaned and ready for period analysis. Total points: {len(data)}")
    return data

# Example usage (Conceptual - KIC 8462852 is Tabbys Star)
# data_df = load_and_clean_kepler_data(kic_id=8462852, quarter=1)

# The resulting 'flux' column now represents the residual light variation, 
# where any planetary transit signal is ideally preserved, centered around a baseline of 1.0.
# This cleaned 1D time series is the input for the next step: Phase Folding.

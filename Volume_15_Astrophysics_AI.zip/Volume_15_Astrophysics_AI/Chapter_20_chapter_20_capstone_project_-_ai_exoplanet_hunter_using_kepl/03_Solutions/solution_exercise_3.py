
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                             roc_auc_score, confusion_matrix, f1_score)
import matplotlib.pyplot as plt
import seaborn as sns

# --- Simulate Test Results and Metadata ---
np.random.seed(42)
N_TEST = 1000
# Imbalanced data: 10% True Planets (Class 1), 90% Non-Planets (Class 0)
y_true = np.concatenate([np.ones(100), np.zeros(900)]).astype(int)
np.random.shuffle(y_true)

# Simulate probabilities (Model struggles with shallow and long-period planets)
probs = np.clip(y_true + np.random.normal(0, 0.3, N_TEST), 0.05, 0.95)
probs[y_true == 0] = np.clip(probs[y_true == 0] - 0.2, 0.05, 0.95) # Make non-planets easier to classify

# Simulate astrophysical metadata (Depth in ppm, Period in days)
depth_ppm = np.random.lognormal(mean=np.log(1000), sigma=0.8, size=N_TEST)
period_days = np.random.lognormal(mean=np.log(15), sigma=0.6, size=N_TEST)

# Determine optimal threshold using F1 score (common practice for unbalanced data)
thresholds = np.linspace(0.01, 0.99, 100)
f1_scores = [f1_score(y_true, probs >= t) for t in thresholds]
optimal_threshold = thresholds[np.argmax(f1_scores)]
y_pred = (probs >= optimal_threshold).astype(int)

# Combine data into a DataFrame for easy segmentation
df = pd.DataFrame({
    'y_true': y_true,
    'y_pred': y_pred,
    'probs': probs,
    'depth_ppm': depth_ppm,
    'period_days': period_days
})

# 1. Standard Metric Calculation
TN, FP, FN, TP = confusion_matrix(y_true, y_pred).ravel()

accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred, zero_division=0)
recall = recall_score(y_true, y_pred, zero_division=0)
specificity = TN / (TN + FP) if (TN + FP) > 0 else 0
f1 = f1_score(y_true, y_pred, zero_division=0)
auroc = roc_auc_score(y_true, probs)

# 2. False Positive Rate (FPR) Analysis
fpr = FP / (FP + TN)

print("--- 1 & 2. Standard Metrics and FPR ---")
print(f"Optimal Threshold: {optimal_threshold:.4f}")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision (Planet): {precision:.4f}")
print(f"Recall (Planet/TPR): {recall:.4f}")
print(f"Specificity (TNR): {specificity:.4f}")
print(f"F1 Score: {f1:.4f}")
print(f"AUROC: {auroc:.4f}")
print(f"False Positive Rate (FPR): {fpr:.4f} (FP / (FP + TN))")
print("-" * 40)

# 3. Segmented Performance Reporting
def calculate_metrics_for_segment(segment_df):
    if len(segment_df) == 0:
        return {'Precision': 0.0, 'Recall': 0.0, 'F1': 0.0}
    
    true = segment_df['y_true']
    pred = segment_df['y_pred']
    
    return {
        'Precision': precision_score(true, pred, zero_division=0),
        'Recall': recall_score(true, pred, zero_division=0),
        'F1': f1_score(true, pred, zero_division=0)
    }

# Segment 3a: Transit Depth
depth_bins = {
    'Shallow (< 500 ppm)': df[df['depth_ppm'] < 500],
    'Medium (500 - 2000 ppm)': df[(df['depth_ppm'] >= 500) & (df['depth_ppm'] < 2000)],
    'Deep (>= 2000 ppm)': df[df['depth_ppm'] >= 2000]
}

depth_report = {
    k: {m: v[m] for m in ['Recall', 'Precision']}
    for k, v in depth_bins.items()
}

# Segment 3b: Orbital Period
period_bins = {
    'Short Period (< 10 days)': df[df['period_days'] < 10],
    'Long Period (>= 10 days)': df[df['period_days'] >= 10]
}

period_report = {
    k: {m: v[m] for m in ['F1']}
    for k, v in period_bins.items()
}

print("--- 3. Segmented Performance Report ---")
print("A. Performance by Transit Depth (Planet Class):")
for k, v in depth_report.items():
    print(f"  {k}: Recall={v['Recall']:.4f}, Precision={v['Precision']:.4f}")
print("\nB. Performance by Orbital Period (Planet Class F1):")
for k, v in period_report.items():
    print(f"  {k}: F1 Score={v['F1']:.4f}")
print("-" * 40)

# 4. Confusion Matrix Visualization
cm = confusion_matrix(df['y_true'], df['y_pred'])
# Normalize by true class population (rows sum to 1)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

plt.figure(figsize=(6, 5))
sns.heatmap(cm_normalized, annot=True, fmt=".2f", cmap="Blues",
            xticklabels=['Non-Planet (0)', 'Planet (1)'],
            yticklabels=['True Non-Planet (0)', 'True Planet (1)'])
plt.title('Normalized Confusion Matrix (Row Sum = 1)')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.show()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# gunicorn_config.py

import multiprocessing

# 1. Gunicorn Configuration
# Bind to all interfaces on port 8000
bind = "0.0.0.0:8000"

# Use synchronous workers (suitable for CPU-bound tasks like model inference)
# For GPU inference, asynchronous workers or specific GPU management tools are needed,
# but for standard CPU deployment, sync workers are simpler and robust.
worker_class = "sync" 

# Calculate optimal workers: 2 * CPU cores + 1
workers = (multiprocessing.cpu_count() * 2) + 1 
# Example: If 4 cores, workers = 9

# Timeout for requests (in seconds)
timeout = 30

# Logging
loglevel = 'info'
accesslog = '-' # Standard output
errorlog = '-'  # Standard output

# Pre-load application: Setting preload_app = True forces the application 
# (and the heavy model) to be loaded in the master process before forking. 
# However, this can cause issues with resources like database connections 
# or GPU memory. A safer approach for large models is to let each worker 
# load the model after forking, ensuring the model is loaded only once 
# per worker (which is achieved by initializing the global MODEL variable 
# outside of the request handler, as done in app.py).
preload_app = False 

# Post-fork hook: Ensures model loading happens after the worker process starts
def post_fork(server, worker):
    # The load_model_globally() call in app.py handles the loading 
    # when the module is imported by the worker.
    pass 


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from scipy.signal import savgol_filter
from scipy.interpolate import interp1d

# --- Simulation of Kepler Data (Placeholder for FITS loading) ---
# Time (days), Flux (normalized), Error
TIME = np.linspace(0, 90, 10000)
FLUX_BASELINE = 1.0 + 0.01 * np.sin(2 * np.pi * TIME / 30) # Stellar variability
FLUX = FLUX_BASELINE + np.random.normal(0, 0.0001, 10000)
# Simulate a transit signal (P=10 days, T0=5 days, Duration=0.1 days, Depth=0.005)
P, T0, D = 10.0, 5.0, 0.1
transit_mask = np.abs((TIME - T0 + P/2) % P - P/2) < D/2
FLUX[transit_mask] -= 0.005
FLUX[np.random.randint(0, 10000, 10)] = 1.05 # Simulate outliers
FLUX_ERR = np.ones_like(FLUX) * 0.0001
# ----------------------------------------------------------------

def clean_data(time, flux, flux_err, sigma=3.0):
    """1. Data Cleaning: 3-sigma clipping."""
    median_flux = np.median(flux)
    std_flux = np.std(flux - median_flux)
    
    # Identify outliers relative to the median
    is_outlier = np.abs(flux - median_flux) > sigma * std_flux
    
    # Filter arrays, keeping only non-outliers
    time_clean = time[~is_outlier]
    flux_clean = flux[~is_outlier]
    flux_err_clean = flux_err[~is_outlier]
    
    return time_clean, flux_clean, flux_err_clean

def baseline_detrend(time, flux, window_length=151, polyorder=3):
    """
    2. Baseline Detrending using Savitzky-Golay filter.
    Window length must be odd. Chosen to be long (151 points) 
    to capture long-term stellar variability without truncating the transit (which is short).
    """
    if len(flux) < window_length:
        # Handle short segments by returning median-normalized flux
        return flux / np.median(flux)
        
    # Apply SG filter to estimate the baseline trend
    baseline = savgol_filter(flux, window_length=window_length, polyorder=polyorder)
    
    # Detrended flux: (Raw Flux) / (Baseline Trend)
    detrended_flux = flux / baseline
    return detrended_flux

def phase_fold(time, flux_detrended, P, T0):
    """3. Phase Folding Implementation."""
    # Calculate phase using modulo arithmetic
    phase = ((time - T0) / P) % 1
    
    # Wrap phase to the range [-0.5, 0.5] centered on transit
    phase[phase >= 0.5] -= 1.0
    
    # Sort by phase
    sort_indices = np.argsort(phase)
    return phase[sort_indices], flux_detrended[sort_indices]

def normalize_and_bin(phase, flux_folded, P, D, output_length=2000):
    """4 & 5. Signal Normalization and Fixed-Length Output."""
    
    # 4. Signal Normalization
    # Define out-of-transit (OOT) region: |phi| > 1.5 * (Duration/Period)
    # This ensures we only use the flat baseline for normalization.
    oot_threshold = 1.5 * (D / P)
    oot_mask = np.abs(phase) > oot_threshold
    
    if np.sum(oot_mask) == 0:
        # Fallback if no OOT data is found (e.g., very long transit relative to period)
        baseline_median = 1.0 
    else:
        baseline_median = np.median(flux_folded[oot_mask])
    
    # Normalize: baseline should be 1.0
    flux_normalized = flux_folded / baseline_median
    
    # Center the phase around 0.0 and define the target phase range
    target_phase_min = -0.5
    target_phase_max = 0.5
    
    # 5. Fixed-Length Binning via Linear Interpolation
    # Define the target phase grid
    target_phase_grid = np.linspace(target_phase_min, target_phase_max, output_length)
    
    # Create an interpolation function
    # Note: Interpolation requires sorted unique phases, which phase_fold already provided.
    interp_func = interp1d(phase, flux_normalized, kind='linear', 
                           bounds_error=False, fill_value=1.0) # Fill OOT gaps with baseline 1.0
    
    binned_light_curve = interp_func(target_phase_grid)
    
    # Final normalization step: Ensure baseline is exactly 0.0 for the model input
    # (By convention, some models prefer 0.0 baseline, while others prefer 1.0. 
    # We enforce 0.0 baseline for typical AI input normalization)
    binned_light_curve_zero_baseline = binned_light_curve - 1.0
    
    return binned_light_curve_zero_baseline

# --- Execution Pipeline ---
T_c, F_c, E_c = clean_data(TIME, FLUX, FLUX_ERR)
F_detrended = baseline_detrend(T_c, F_c)
Ph, F_folded = phase_fold(T_c, F_detrended, P, T0)
LC_final = normalize_and_bin(Ph, F_folded, P, D, output_length=2000)

# Verification of output shape
# print(f"Final light curve shape: {LC_final.shape}")
# print(f"Median flux (should be near 0.0): {np.median(LC_final)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_6.py
# Description: Solution for Exercise 6
# ==========================================

import numpy as np
import torch
import torch.nn as nn

# --- 1. Diagnosis: Calculate Class Ratio ---
# Simulate 10,000 training samples
N_TOTAL = 10000
N_PLANET = 500  # Minority Class (5%)
N_NON_PLANET = N_TOTAL - N_PLANET # Majority Class (95%)

# Simulate labels (0: Non-Planet, 1: Planet)
labels = np.concatenate([np.zeros(N_NON_PLANET), np.ones(N_PLANET)]).astype(int)
np.random.shuffle(labels)

# Calculate counts
counts = np.bincount(labels)
N_0, N_1 = counts[0], counts[1]

ratio_minority_to_majority = N_1 / N_0

print(f"Total Samples: {N_TOTAL}")
print(f"Class 0 (Non-Planet): {N_0} samples")
print(f"Class 1 (Planet): {N_1} samples")
print(f"Minority/Majority Ratio: 1:{1/ratio_minority_to_majority:.2f}")
print("-" * 40)

# --- 2. Implementation of Class Weighting (Inverse Frequency) ---
C = 2 # Total number of classes
N_total = N_TOTAL

# Calculate raw inverse frequencies
# W_c = N_total / (N_c * C)
W_0 = N_total / (N_0 * C)
W_1 = N_total / (N_1 * C)

# Normalize weights so the average weight is 1 (optional, but good practice)
# We prioritize W_1 being much higher than W_0
class_weights_numpy = np.array([W_0, W_1])
# class_weights_numpy = class_weights_numpy / np.sum(class_weights_numpy) * C # Alternative normalization

# Convert weights to PyTorch Tensor
class_weights_tensor = torch.tensor(class_weights_numpy, dtype=torch.float32)

print(f"Calculated Weights (W_0, W_1): {class_weights_numpy}")
print(f"Weight assigned to Non-Planet (W_0): {W_0:.4f}")
print(f"Weight assigned to Planet (W_1): {W_1:.4f} (19x higher)")
print("-" * 40)

# --- 3. Loss Function Integration ---
# Assume we are using PyTorch's CrossEntropyLoss
# The 'weight' parameter applies a penalty factor to the loss for each class.

# Example: Initializing the loss function
loss_fn_weighted = nn.CrossEntropyLoss(weight=class_weights_tensor)

# Example Training Step Simulation:
# Simulate model outputs (logits) and true labels
dummy_logits = torch.randn(16, 2) # Batch size 16, 2 classes
dummy_targets = torch.randint(0, 2, (16,)) # True labels

# Calculate weighted loss
weighted_loss = loss_fn_weighted(dummy_logits, dummy_targets)

print("Loss Function Integration:")
print(f"PyTorch CrossEntropyLoss initialized with weights: {class_weights_tensor}")
# print(f"Example Weighted Loss: {weighted_loss.item():.4f}")

# --- 4. Hypothesis and Verification ---


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# app.py

import os
import json
from flask import Flask, request, jsonify

# Global variable to hold the model (initialized by Gunicorn workers)
MODEL = None 
MODEL_PATH = "path/to/trained_vit1d_model.pt"

def load_model_globally():
    """
    Simulates loading a heavy model into memory.
    This function is called once per Gunicorn worker process initialization.
    """
    global MODEL
    if MODEL is None:
        try:
            # Placeholder for actual PyTorch/TF model loading
            # e.g., MODEL = torch.load(MODEL_PATH, map_location='cpu')
            MODEL = {"status": "loaded", "version": "1.0"} 
            print(f"--- Model loaded successfully in worker {os.getpid()} ---")
        except FileNotFoundError:
            print(f"Error: Model file not found at {MODEL_PATH}")
            MODEL = None
    return MODEL is not None

def create_app():
    """2. Application Factory Pattern."""
    app = Flask(__name__)

    # 3. Efficient Model Loading Hook (using Flask's before_first_request or a global init)
    # Gunicorn workers execute this file, initializing the global MODEL variable.
    # We rely on the worker startup process to handle this, as Flask's 
    # before_first_request is less reliable in Gunicorn's multi-process environment.
    
    # We explicitly call the loading function outside of the request handlers
    # but inside the module scope to ensure it runs upon worker startup.
    load_model_globally()

    @app.route('/health', methods=['GET'])
    def health_check():
        """4. Health Check Endpoint."""
        model_status = MODEL is not None
        return jsonify({
            "status": "ready",
            "model_loaded": model_status,
            "pid": os.getpid()
        }), 200

    @app.route('/predict', methods=['POST'])
    def predict():
        if MODEL is None:
            return jsonify({"error": "Model not yet loaded."}), 503
        
        # Example inference logic (using the globally loaded MODEL)
        try:
            data = request.json
            # Preprocessing (as per Exercise 1) happens here
            # Prediction: MODEL.predict(processed_data)
            
            # Placeholder result
            result = {"prediction": "Planet Candidate", "probability": 0.98}
            return jsonify(result), 200
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    return app

if __name__ == '__main__':
    # Development server (not used in Gunicorn production)
    app = create_app()
    app.run(host='0.0.0.0', port=5000)

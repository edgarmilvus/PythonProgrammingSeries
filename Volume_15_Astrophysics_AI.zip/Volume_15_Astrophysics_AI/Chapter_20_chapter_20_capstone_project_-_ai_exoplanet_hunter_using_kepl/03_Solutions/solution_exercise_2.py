
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn
import torch.nn.functional as F

# Hyperparameters
INPUT_LENGTH = 2000 # L
PATCH_SIZE = 20     # P
EMBED_DIM = 128     # D
NUM_HEADS = 8
NUM_LAYERS = 6
NUM_CLASSES = 2

class PatchEmbedding1D(nn.Module):
    """1. 1D Patch Embedding Layer using Conv1D."""
    def __init__(self, in_channels, embed_dim, patch_size, input_length):
        super().__init__()
        self.patch_size = patch_size
        self.embed_dim = embed_dim
        
        # Use Conv1D with kernel_size=patch_size and stride=patch_size
        # to efficiently split the 1D sequence into non-overlapping patches.
        self.projection = nn.Conv1d(
            in_channels=in_channels,
            out_channels=embed_dim,
            kernel_size=patch_size,
            stride=patch_size
        )
        
        # Calculate the number of patches (tokens)
        self.num_patches = input_length // patch_size

    def forward(self, x):
        # x shape: (Batch, Channels=1, Length=2000)
        
        # Conv1D output shape: (B, Embed_Dim, Num_Patches)
        x = self.projection(x)
        
        # Reshape for Transformer: (B, Num_Patches, Embed_Dim)
        # Permute (B, D, N) -> (B, N, D)
        x = x.transpose(1, 2) 
        return x

class TransformerEncoderBlock(nn.Module):
    """3. Transformer Encoder Block."""
    def __init__(self, embed_dim, num_heads, mlp_dim):
        super().__init__()
        
        # Multi-Head Self-Attention (MHSA)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.attn = nn.MultiheadAttention(embed_dim, num_heads, batch_first=True)
        
        # Feed-Forward Network (FFN)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, mlp_dim),
            nn.GELU(),
            nn.Linear(mlp_dim, embed_dim)
        )

    def forward(self, x):
        # Layer Norm + MHSA + Skip Connection
        norm_x = self.norm1(x)
        attn_output, _ = self.attn(norm_x, norm_x, norm_x)
        x = x + attn_output # Residual connection 1

        # Layer Norm + FFN + Skip Connection
        norm_x = self.norm2(x)
        mlp_output = self.mlp(norm_x)
        x = x + mlp_output # Residual connection 2
        
        return x

class ViT1D(nn.Module):
    def __init__(self, input_length=INPUT_LENGTH, patch_size=PATCH_SIZE, 
                 embed_dim=EMBED_DIM, num_layers=NUM_LAYERS, num_heads=NUM_HEADS, 
                 num_classes=NUM_CLASSES):
        super().__init__()
        
        # 1. Patch Embedding
        self.patch_embed = PatchEmbedding1D(in_channels=1, embed_dim=embed_dim, 
                                            patch_size=patch_size, input_length=input_length)
        num_patches = self.patch_embed.num_patches
        
        # Learnable [CLS] token prepended to the sequence
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        
        # 2. Learnable Positional Embeddings (N_patches + 1 for CLS)
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim))
        
        # Transformer Encoder Stack
        self.encoder_layers = nn.ModuleList([
            TransformerEncoderBlock(embed_dim, num_heads, mlp_dim=embed_dim * 4)
            for _ in range(num_layers)
        ])
        
        self.norm = nn.LayerNorm(embed_dim)
        
        # 4. Classification Head (using the CLS token output)
        self.head = nn.Linear(embed_dim, num_classes)

    def forward(self, x):
        # x shape: (B, L) -> (B, 1, L)
        x = x.unsqueeze(1) 
        
        # 1. Patching: (B, N_patches, D)
        x = self.patch_embed(x)
        
        # Prepend CLS token: (B, 1, D) -> (B, N_patches + 1, D)
        cls_tokens = self.cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        
        # 2. Add Positional Embeddings
        x = x + self.pos_embed
        
        # 3. Transformer Encoder Stack
        for layer in self.encoder_layers:
            x = layer(x)
        
        # 4. Classification Head
        # Use only the CLS token output (index 0)
        cls_output = self.norm(x[:, 0])
        
        logits = self.head(cls_output)
        return logits

# 5. Model Instantiation and Verification
model = ViT1D()
dummy_input = torch.randn(4, INPUT_LENGTH) # Batch size 4, Length 2000
output = model(dummy_input)

# Function to estimate parameters (simplified)
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

# print(f"Model Output Shape: {output.shape}")
# print(f"Total Trainable Parameters: {count_parameters(model):,}")

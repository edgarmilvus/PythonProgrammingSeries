
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
from astropy import units as u
from astropy import constants as const

# --- 1. Core System Definition and Unit Handling ---

class OrbitalSystemAnalyzer:
    """
    A class designed to perform unit-aware astrophysical calculations 
    for a two-body orbital system using astropy Quantities.
    This ensures all inputs and calculated results maintain dimensional integrity.
    """
    
    def __init__(self, primary_mass_solar: float, orbital_radius_ly: float, planet_mass_earth: float):
        """
        Initializes the system with non-SI input units.
        
        :param primary_mass_solar: Mass of the central body in Solar Masses (M_sun).
        :param orbital_radius_ly: Orbital distance in Light-Years (ly).
        :param planet_mass_earth: Mass of the orbiting body in Earth Masses (M_earth).
        """
        # Retrieve fundamental constants using astropy.constants
        self.G = const.G  # Gravitational Constant (m^3 kg^-1 s^-2)
        self.c = const.c  # Speed of Light in vacuum (m/s)
        
        # Define system parameters as astropy Quantities, attaching units immediately
        self.M_primary = primary_mass_solar * u.M_sun
        self.R_orbit = orbital_radius_ly * u.ly
        self.M_planet = planet_mass_earth * u.M_earth
        
        print(f"--- Initializing System ---")
        # Displaying initial values converted to standard SI and common AU for verification
        print(f"Primary Mass: {self.M_primary.to(u.kg):.4e}")
        print(f"Orbital Radius: {self.R_orbit.to(u.au):.2f} AU")
        
    def calculate_orbital_velocity(self):
        """
        Calculates the circular orbital velocity (v) using v = sqrt(G * M / R).
        The result is automatically unit-checked and returned in SI units (m/s).
        """
        # Use the astropy Quantities directly in the formula
        # Dimensional analysis check: (m^3 kg^-1 s^-2 * kg / m) = m^2 s^-2. Sqrt yields m/s.
        v_squared = (self.G * self.M_primary) / self.R_orbit
        v_orbit = np.sqrt(v_squared)
        
        # Ensure the velocity is converted and simplified to standard velocity units
        v_orbit_si = v_orbit.to(u.m / u.s)
        
        print("\n--- Orbital Kinematics ---")
        print(f"Orbital Velocity (SI): {v_orbit_si:.4e}")
        print(f"Orbital Velocity (km/s): {v_orbit_si.to(u.km / u.s):.2f}")
        
        # Store the velocity for period calculation
        self._v_orbit = v_orbit_si
        return v_orbit_si

    def calculate_orbital_period(self):
        """
        Calculates the orbital period (T) using T = 2 * pi * R / v.
        The result is automatically unit-checked and returned in SI units (s).
        """
        if not hasattr(self, '_v_orbit'):
            self.calculate_orbital_velocity()
            
        # Calculate period. Units check: (length / velocity) = (m / (m/s)) = s
        T_orbit = (2 * np.pi * self.R_orbit) / self._v_orbit
        
        # Convert to human-readable time units (years)
        T_orbit_years = T_orbit.to(u.yr)
        
        print(f"Orbital Period (SI): {T_orbit.to(u.s):.4e}")
        print(f"Orbital Period (Years): {T_orbit_years:.4f}")
        return T_orbit
        
    def analyze_relativistic_energy(self):
        """
        Compares the planet's kinetic energy to the rest mass energy of a small asteroid.
        This demonstrates complex unit mixing (KE vs E=mc^2) and comparison in Joules.
        """
        if not hasattr(self, '_v_orbit'):
            self.calculate_orbital_velocity()
            
        # Define a small asteroid mass (1000 kg) explicitly in SI units
        M_asteroid = 1000 * u.kg
        
        # 1. Kinetic Energy (KE) of the planet: KE = 0.5 * m * v^2
        # Units check: (kg * (m/s)^2) = kg * m^2 / s^2 = Joule (J)
        KE_planet = 0.5 * self.M_planet * (self._v_orbit ** 2)
        
        # 2. Rest Mass Energy (E0) of the asteroid: E0 = m * c^2
        # Units check: (kg * (m/s)^2) = Joule (J)
        E0_asteroid = M_asteroid * (self.c ** 2)
        
        # Convert both energies to Joules (J) for direct comparison
        KE_joules = KE_planet.to(u.J)
        E0_joules = E0_asteroid.to(u.J)
        
        print("\n--- Relativistic Energy Comparison ---")
        print(f"Planet Kinetic Energy (J): {KE_joules:.4e}")
        print(f"Asteroid Rest Energy (J): {E0_joules:.4e}")
        
        # Calculate the ratio (unitless check)
        energy_ratio = E0_joules / KE_joules
        
        print(f"Ratio (E_asteroid / KE_planet): {energy_ratio:.2f} (Unit: {energy_ratio.unit})")
        
        # Dimensional analysis check: Ensure the result of the ratio is dimensionless
        if energy_ratio.unit == u.dimensionless_unscaled:
            print("Dimensional Check: Ratio is correctly dimensionless.")
        else:
            # This is a critical check for scientific integrity
            raise u.UnitsError("Dimensional mismatch detected in energy ratio.")


# --- 2. Execution Block ---

if __name__ == "__main__":
    # Define system parameters: A massive star and a distant planet
    STAR_MASS = 15.0      # Primary Mass (15 Solar Masses)
    ORBIT_RADIUS = 0.0005 # Orbital Radius (0.0005 Light Years, approx 31.6 AU)
    PLANET_MASS = 5.0     # Planet Mass (5 Earth Masses)
    
    # 1. Instantiate the analyzer, which defines all input quantities
    system = OrbitalSystemAnalyzer(
        primary_mass_solar=STAR_MASS,
        orbital_radius_ly=ORBIT_RADIUS,
        planet_mass_earth=PLANET_MASS
    )

    # 2. Execute kinematic calculations
    v = system.calculate_orbital_velocity()
    T = system.calculate_orbital_period()
    
    # 3. Execute energy comparison
    system.analyze_relativistic_energy()

    # 4. Demonstrate explicit unit conversion and validation outside the class
    # Convert the orbital radius from Light Years to Parsecs
    R_parsec = system.R_orbit.to(u.pc)
    print(f"\nValidation Check: Orbital Radius in Parsecs: {R_parsec:.6f}")
    
    # Demonstrate unit manipulation: Calculate momentum (p = m * v)
    momentum = system.M_planet * v
    print(f"Planet Momentum: {momentum.to(u.kg * u.m / u.s):.4e}")
    
    # Verify the mass of the primary star in Solar Masses using the astropy constant
    # The M_sun constant itself is a Quantity
    solar_mass_check = system.M_primary / const.M_sun
    print(f"Mass Verification: Primary mass is {solar_mass_check:.1f} M_sun.")

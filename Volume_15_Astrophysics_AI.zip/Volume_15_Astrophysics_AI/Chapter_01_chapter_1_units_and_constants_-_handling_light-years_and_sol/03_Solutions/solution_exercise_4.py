
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import astropy.units as u
from astropy.constants import G

def calculate_gravitational_force(mass_1, mass_2, distance):
    """
    Computes the gravitational force between two masses separated by a distance.

    Parameters
    ----------
    mass_1 : astropy.units.Quantity
        The mass of the first object (e.g., 2.0 * u.M_sun).
    mass_2 : astropy.units.Quantity
        The mass of the second object (e.g., 5.0e24 * u.kg).
    distance : astropy.units.Quantity
        The separation distance (e.g., 0.001 * u.ly).

    Returns
    -------
    astropy.units.Quantity
        The gravitational force F, guaranteed to be in Newtons (u.N).
    """
    # Retrieve G (Gravitational Constant)
    G_const = G

    # 3. Internal Conversion: Convert inputs to SI base units (kg and m)
    # This defensive step ensures the calculation is robust against mixed units.
    m1_si = mass_1.to(u.kg)
    m2_si = mass_2.to(u.kg)
    r_si = distance.to(u.m)

    # Calculate the force F = G * m1 * m2 / r^2
    force = G_const * m1_si * m2_si / (r_si**2)

    # 4. Unit Return: Ensure the final result is in Newtons (N)
    # Note: N is equivalent to kg * m / s^2
    force_newtons = force.to(u.N)
    return force_newtons

# 5. Testing Scenario:
m1_test = 2.0 * u.M_sun
m2_test = 5.0e24 * u.kg
r_test = 0.001 * u.ly

# Calculate the force
F_result = calculate_gravitational_force(m1_test, m2_test, r_test)

print(f"Input m1: {m1_test}")
print(f"Input m2: {m2_test}")
print(f"Input r: {r_test}")
print(f"\nCalculated Gravitational Force: {F_result:e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import astropy.units as u
from astropy.constants import c

# 1. Define distance D in pc
distance_D = 5.2 * u.pc

# 2. Retrieve speed of light c
speed_c = c

# 3. Calculate the one-way travel time t_one_way = D / c
# Astropy handles the conversion from pc to m automatically during division
t_one_way = distance_D / speed_c

# 4. Calculate the round-trip time T_round_trip
T_round_trip = 2 * t_one_way

# 5. Convert the final result T_round_trip to hours
T_hours = T_round_trip.to(u.hour)

# Print the final numerical result rounded to two decimal places
print(f"Distance to probe: {distance_D}")
print(f"Round-trip delay: {T_round_trip}")
print(f"\nRound-trip delay converted to hours: {T_hours.value:.2f} hours")

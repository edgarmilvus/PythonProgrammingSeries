
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import astropy.units as u
from astropy.constants import G, M_sun

# 1. Retrieve G and M_sun
G_const = G
M_solar = M_sun

# 2. Define M and a as unit-aware quantities
star_mass = 1.5 * M_solar
semi_major_axis = 3.5e11 * u.m

# Ensure G and M are in consistent SI units for calculation integrity
G_si = G_const.si
M_si = star_mass.si

# 3. Calculate the orbital period T using Kepler's Third Law
# T = 2*pi * sqrt(a^3 / (G * M))
T = 2 * np.pi * np.sqrt(semi_major_axis**3 / (G_si * M_si))

# 4. Verify that the resulting quantity T has units of time (seconds)
print(f"Calculated Period (T): {T}")
print(f"Dimensional Check (Unit): {T.unit}")

# 5. Convert the final result T into Earth years
T_years = T.to(u.year)

print(f"\nOrbital Period in Earth Years: {T_years:.3f}")

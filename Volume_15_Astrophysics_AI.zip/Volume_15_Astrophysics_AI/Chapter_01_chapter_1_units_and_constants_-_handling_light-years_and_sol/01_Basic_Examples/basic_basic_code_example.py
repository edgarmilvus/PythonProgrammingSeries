
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# basic_astrophysics_constants.py

# 1. Import the necessary submodule, aliasing it for convenience.
import astropy.constants as const

# --- Accessing Fundamental Physical Constants ---

# 2. Access the speed of light in vacuum (c).
# This constant is now defined exactly and has zero uncertainty.
C_LIGHT = const.c

# 3. Access the Newtonian gravitational constant (G).
# G is measured empirically and thus carries an uncertainty.
G_GRAVITY = const.G

# --- Accessing Astronomical Constants/Reference Units ---

# 4. Access the Solar Mass (M_sun).
# This is a key astronomical reference mass, used extensively in stellar physics.
M_SOLAR = const.M_sun

# 5. Define a multi-line format string for clean, structured output.
# Using a template ensures all constants are displayed uniformly.
OUTPUT_FORMAT = (
    "\n--- {name} ---\n"
    "Value: {value}\n"
    "Unit: {unit}\n"
    "Uncertainty: {uncertainty}\n"
    "Reference: {reference}"
)

# --- Displaying the Constants ---

print("--- Astropy Constants Showcase ---")

# 6. Display the attributes of the Speed of Light (c).
print(OUTPUT_FORMAT.format(
    name=C_LIGHT.name,
    value=C_LIGHT.value,
    unit=C_LIGHT.unit,
    uncertainty=C_LIGHT.uncertainty,
    reference=C_LIGHT.reference
))

# 7. Display the attributes of the Gravitational Constant (G).
print(OUTPUT_FORMAT.format(
    name=G_GRAVITY.name,
    value=G_GRAVITY.value,
    unit=G_GRAVITY.unit,
    uncertainty=G_GRAVITY.uncertainty,
    reference=G_GRAVITY.reference
))

# 8. Display the attributes of the Solar Mass (M_sun).
print(OUTPUT_FORMAT.format(
    name=M_SOLAR.name,
    value=M_SOLAR.value,
    unit=M_SOLAR.unit,
    uncertainty=M_SOLAR.uncertainty,
    reference=M_SOLAR.reference
))

# 9. Perform a quick, raw calculation (E=mc^2) to demonstrate value extraction.
# Note: We must explicitly use the .value attribute for raw arithmetic.
energy_equivalent = M_SOLAR.value * (C_LIGHT.value ** 2)
print(f"\n--- Derived Value Check (E=mc^2) ---")
print(f"Energy equivalent of 1 Solar Mass (Joules): {energy_equivalent:.4e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
import sys

# --- Configuration and Constants (SI Units) ---
G = 6.674e-11
M_SUN = 1.989e30
M_SAT = 1.0 # Mass of test particle

R0_MAG = 1.496e11 # Initial radius (1 AU)
R0 = np.array([R0_MAG, 0.0]) 

# Simulation Parameters
DT = 5000.0  # Time step (smaller for better stability near critical points)
MAX_DISTANCE_FACTOR = 10.0 # Stop if R > 10 * R0
MAX_STEPS = 50000 # Max steps allowed (prevents infinite loops for slow escape)

# Theoretical Escape Velocity Calculation
V_ESC = np.sqrt(2 * G * M_SUN / R0_MAG)

# --- Core Simulation Functions (Re-used from Ex 1 & 2) ---

def calculate_acceleration(R, G, M):
    r_mag = np.linalg.norm(R)
    # Check for singularity (should not happen, but good practice)
    if r_mag == 0: return np.zeros(2) 
    r_hat = R / r_mag
    A = -G * M / r_mag**2 * r_hat
    return A

def euler_cromer_step(R, V, dt, G, M):
    A = calculate_acceleration(R, G, M)
    V_new = V + A * dt
    R_new = R + V_new * dt
    return R_new, V_new

# --- Simulation Wrapper and Plotting ---

def run_simulation_and_plot(vx, vy):
    """Encapsulates the simulation, termination, and plotting."""
    
    V0 = np.array([vx, vy])
    R = [R0]
    V = [V0]
    
    # Run integration with termination condition
    for i in range(MAX_STEPS):
        R_new, V_new = euler_cromer_step(R[-1], V[-1], DT, G, M_SUN)
        
        R.append(R_new)
        V.append(V_new)
        
        # Termination condition: Check if distance exceeds threshold
        r_mag = np.linalg.norm(R_new)
        if r_mag > MAX_DISTANCE_FACTOR * R0_MAG:
            print(f"Simulation terminated: Body reached {MAX_DISTANCE_FACTOR} AU radius (Open Orbit).")
            break
            
    R_arr = np.array(R)
    
    # Check orbit type based on final position
    if np.linalg.norm(R_arr[-1]) > R0_MAG * (MAX_DISTANCE_FACTOR - 1):
        orbit_type = "Hyperbolic/Parabolic (Open)"
        color = 'r'
    else:
        orbit_type = "Elliptical (Closed)"
        color = 'b'

    # Plotting
    plt.figure(figsize=(8, 8))
    plt.plot(R_arr[:, 0], R_arr[:, 1], color, label=f'Trajectory ({orbit_type})', linewidth=2, alpha=0.7)
    plt.plot(0, 0, 'yo', markersize=10, label='Central Body (Sun)')
    plt.plot(R0[0], R0[1], 'go', markersize=7, label='Start Position')
    
    # Set appropriate limits based on trajectory
    max_r_plot = np.max(np.abs(R_arr))
    if orbit_type == "Elliptical (Closed)":
        limit = 1.5 * R0_MAG
    else:
        limit = max_r_plot * 1.1
        
    plt.xlim(-limit, limit)
    plt.ylim(-limit, limit)
    
    plt.title(f'Orbital Trajectory: $V_x={vx:.2f}, V_y={vy:.2f}$ m/s')
    plt.xlabel('X Position (m)')
    plt.ylabel('Y Position (m)')
    plt.axis('equal')
    plt.grid(True)
    plt.legend()
    plt.ticklabel_format(style='sci', axis='both', scilimits=(0,0))
    plt.show()


# --- Interactive Loop ---

def main_interactive():
    print("--- Orbital Phase Space Explorer ---")
    print(f"Fixed Initial Radius (R0): {R0_MAG:.2e} m (approx 1 AU)")
    print(f"Theoretical Escape Velocity (V_esc): {V_ESC:.2f} m/s")
    print("------------------------------------")

    while True:
        try:
            print("\nInput initial velocity components (Vx, Vy):")
            vx_input = input("Enter initial Vx (m/s, default 0.0): ")
            if vx_input.lower() in ['q', 'quit']:
                break
            vx = float(vx_input or 0.0)
            
            vy_input = input(f"Enter initial Vy (m/s, default {V_ESC * 0.7:.2f}): ")
            if vy_input.lower() in ['q', 'quit']:
                break
            # Use 70% of escape velocity as a good starting point for ellipse
            vy_default = V_ESC * 0.7 
            vy = float(vy_input or vy_default)
            
            run_simulation_and_plot(vx, vy)
            
        except ValueError:
            print("Invalid input. Please enter a numerical value or 'q' to quit.")
        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == '__main__':
    # Example V_y inputs for testing:
    # 1. Closed Ellipse (Earth speed): 29780 m/s
    # 2. Escape (Parabolic/Hyperbolic): 42120 m/s (V_esc)
    # 3. Circular (V_circ = V_esc / sqrt(2)): 29780 m/s
    
    # To enable automated testing, the interactive loop is guarded by __name__ == '__main__':
    # main_interactive() 
    
    # For submission clarity, we run a test case and then the interactive loop setup.
    print("Running initial test case (V_circ):")
    run_simulation_and_plot(0.0, 29780.0) 
    
    # Uncomment the line below to start the interactive loop:
    # main_interactive()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# --- Configuration and Constants (DRY) ---
G = 6.674e-11
M_SUN = 1.989e30
M_SAT = 5.972e24

R0 = np.array([1.496e11, 0.0])
V0 = np.array([0.0, 29780.0])
T_PERIOD = 2 * np.pi * np.sqrt(R0[0]**3 / (G * M_SUN))

# Simulation Parameters
DT = 10000.0
N_PERIODS = 10  # Run for 10 periods for comparison
TOTAL_TIME = N_PERIODS * T_PERIOD
N_STEPS = int(TOTAL_TIME / DT)

# Re-use acceleration and stability functions from Exercise 1
def calculate_acceleration(R, G, M):
    r_mag = np.linalg.norm(R)
    r_hat = R / r_mag
    A = -G * M / r_mag**2 * r_hat
    return A

# --- Integration Step Implementations ---

def euler_cromer_step(R, V, dt, G, M):
    """Euler-Cromer (Symplectic) step."""
    A = calculate_acceleration(R, G, M)
    V_new = V + A * dt
    R_new = R + V_new * dt
    return R_new, V_new

def forward_euler_step(R, V, dt, G, M):
    """Forward Euler (Non-Symplectic, Unstable) step."""
    A = calculate_acceleration(R, G, M)
    # R update uses CURRENT V
    R_new = R + V * dt
    # V update uses CURRENT A
    V_new = V + A * dt
    return R_new, V_new

# --- Refactored Simulation Wrapper ---

def simulate_orbit(initial_conditions, total_time, dt, integrator_method, G, M):
    """
    Generic simulation function accepting an integrator_method (callable).
    Initial conditions: (R0, V0)
    """
    R0, V0 = initial_conditions
    n_steps = int(total_time / dt)
    
    R = np.zeros((n_steps, 2))
    V = np.zeros((n_steps, 2))
    R[0], V[0] = R0, V0
    
    for i in range(n_steps - 1):
        # The integrator_method is called here, passing the necessary constants
        R[i+1], V[i+1] = integrator_method(R[i], V[i], dt, G, M)
        
    T = np.linspace(0, n_steps * dt, n_steps)
    return T, R, V

# --- RK4 Conceptual Framework ---

def derivatives(t, state, G, M):
    """
    Required derivative function F(t, state) for RK4 solvers (like scipy.integrate.solve_ivp).
    State vector is [x, y, vx, vy].
    Return vector is [vx, vy, ax, ay].
    """
    # Unpack state
    R = state[:2]  # [x, y]
    V = state[2:]  # [vx, vy]
    
    # Calculate acceleration
    A = calculate_acceleration(R, G, M)
    
    # Return derivatives [dR/dt, dV/dt] = [V, A]
    return np.concatenate((V, A))

# --- Execution and Comparison ---

initial_conditions = (R0, V0)

# 1. Run Euler-Cromer (Stable)
T_ec, R_ec, V_ec = simulate_orbit(initial_conditions, TOTAL_TIME, DT, euler_cromer_step, G, M_SUN)

# 2. Run Forward Euler (Unstable)
T_fe, R_fe, V_fe = simulate_orbit(initial_conditions, TOTAL_TIME, DT, forward_euler_step, G, M_SUN)

# 3. Stability Analysis (Re-using Ex 1 logic)
# We need the energy calculation function again
def calculate_energy(M, m, R_array, V_array, G):
    R_mag = np.linalg.norm(R_array, axis=1)
    V_mag_sq = np.sum(V_array**2, axis=1)
    K = 0.5 * m * V_mag_sq
    U = -G * M * m / R_mag
    return K + U

E_ec = calculate_energy(M_SUN, M_SAT, R_ec, V_ec, G)
E_fe = calculate_energy(M_SUN, M_SAT, R_fe, V_fe, G)

def calculate_drift(E_array):
    initial_val = E_array[0]
    abs_deviation = np.max(np.abs(E_array - initial_val))
    return (abs_deviation / np.abs(initial_val)) * 100

drift_ec = calculate_drift(E_ec)
drift_fe = calculate_drift(E_fe)

print(f"\nSimulation Comparison over {N_PERIODS} Periods:")
print(f"Euler-Cromer Energy Drift: {drift_ec:.6f} %")
print(f"Forward Euler Energy Drift: {drift_fe:.6f} %")

# 4. Visualization
plt.figure(figsize=(10, 10))
plt.plot(R_ec[:, 0], R_ec[:, 1], label=f'Euler-Cromer (Drift: {drift_ec:.2f} %)', linewidth=1)
plt.plot(R_fe[:, 0], R_fe[:, 1], label=f'Forward Euler (Drift: {drift_fe:.2f} %)', linewidth=1, linestyle='--')
plt.plot(0, 0, 'yo', markersize=10, label='Sun')
plt.plot(R0[0], R0[1], 'go', markersize=5, label='Start Position')

plt.title(f'Comparison of Integration Methods over {N_PERIODS} Periods')
plt.xlabel('X Position (m)')
plt.ylabel('Y Position (m)')
plt.axis('equal')
plt.grid(True)
plt.legend()
plt.ticklabel_format(style='sci', axis='both', scilimits=(0,0))
plt.show()

# Conclusion on Forward Euler Failure
"""
Instructor's Conclusion on Forward Euler:
The Forward Euler method is fundamentally unstable for long-term orbital simulations because it is non-symplectic. 
In the context of conservative systems like the two-body problem, non-symplectic integrators do not preserve the phase space area. 
Specifically, the Forward Euler method systematically overestimates or underestimates the forces or velocities, leading to a constant injection 
or removal of energy from the system. In this case, the orbit spirals outward (energy grows) or inward (energy decays) rapidly 
over multiple periods, violating the principle of energy conservation and failing to reproduce the closed, periodic nature of the ellipse.
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# --- Configuration and Constants (DRY Principle) ---
G = 6.674e-11  # Gravitational Constant (N m^2 / kg^2)
M_SUN = 1.989e30 # Mass of the Sun (kg)
M_SAT = 5.972e24 # Mass of the orbiting body (e.g., Earth) (kg)

# Initial Conditions (Earth orbit approximation)
R0 = np.array([1.496e11, 0.0])  # Initial position (m) (1 AU)
V0 = np.array([0.0, 29780.0])   # Initial velocity (m/s)
T_PERIOD = 2 * np.pi * np.sqrt(R0[0]**3 / (G * M_SUN)) # Approx 1 year

# Simulation Parameters
DT = 10000.0  # Time step (seconds)
N_PERIODS = 1
TOTAL_TIME = N_PERIODS * T_PERIOD
N_STEPS = int(TOTAL_TIME / DT)

# --- Core Simulation Functions (Required to generate data) ---

def calculate_acceleration(R, G, M):
    """Calculates the gravitational acceleration vector A = -G M R / ||R||^3."""
    r_mag = np.linalg.norm(R)
    r_hat = R / r_mag
    A = -G * M / r_mag**2 * r_hat
    return A

def euler_cromer_step(R, V, dt, G, M):
    """Performs one step of the Euler-Cromer integration."""
    A = calculate_acceleration(R, G, M)
    V_new = V + A * dt
    R_new = R + V_new * dt
    return R_new, V_new

def simulate_orbit(R0, V0, dt, n_steps, G, M):
    """Runs the full Euler-Cromer simulation."""
    R = np.zeros((n_steps, 2))
    V = np.zeros((n_steps, 2))
    R[0], V[0] = R0, V0
    
    for i in range(n_steps - 1):
        R[i+1], V[i+1] = euler_cromer_step(R[i], V[i], dt, G, M)
        
    T = np.linspace(0, n_steps * dt, n_steps)
    return T, R, V

# --- Verification Module Functions ---

def calculate_energy(M, m, R_array, V_array, G):
    """
    Calculates Kinetic (K), Potential (U), and Total Energy (E) for all timesteps.
    R_array and V_array must be N x 2 NumPy arrays.
    """
    R_mag = np.linalg.norm(R_array, axis=1)
    V_mag_sq = np.sum(V_array**2, axis=1)
    
    # 1. Kinetic Energy: K = 0.5 * m * ||V||^2
    K = 0.5 * m * V_mag_sq
    
    # 2. Potential Energy: U = -G * M * m / ||R||
    U = -G * M * m / R_mag
    
    # 3. Total Energy: E = K + U
    E = K + U
    
    return K, U, E

def calculate_angular_momentum(m, R_array, V_array):
    """
    Calculates the magnitude of the Angular Momentum L = ||m (R x V)||.
    Since motion is 2D (in the XY plane), R x V results in a vector along Z.
    We take the Z component (R_x * V_y - R_y * V_x).
    """
    # Vectorized cross product component (R x V)_z
    L_z = R_array[:, 0] * V_array[:, 1] - R_array[:, 1] * V_array[:, 0]
    
    L = m * L_z
    return L

def analyze_stability(E_array, L_array):
    """Calculates statistical metrics for stability."""
    
    def get_metrics(data, label):
        initial_val = data[0]
        mean_val = np.mean(data)
        std_dev = np.std(data)
        
        # Percentage Drift: max(|E_i - E_0|) / |E_0| * 100%
        abs_deviation = np.max(np.abs(data - initial_val))
        percentage_drift = (abs_deviation / np.abs(initial_val)) * 100
        
        print(f"\n--- {label} Stability Metrics ---")
        print(f"Initial Value: {initial_val:.4e} J/kg or kg m^2/s")
        print(f"Mean Value: {mean_val:.4e}")
        print(f"Standard Deviation: {std_dev:.4e}")
        print(f"Percentage Drift: {percentage_drift:.6f} %")
        return mean_val, std_dev, percentage_drift

    E_metrics = get_metrics(E_array, "Energy (E)")
    L_metrics = get_metrics(L_array, "Angular Momentum (L)")
    return E_metrics, L_metrics

# --- Execution and Visualization ---

# 1. Run Simulation
T_arr, R_arr, V_arr = simulate_orbit(R0, V0, DT, N_STEPS, G, M_SUN)

# 2. Calculate Conservation Quantities
K_arr, U_arr, E_arr = calculate_energy(M_SUN, M_SAT, R_arr, V_arr, G)
L_arr = calculate_angular_momentum(M_SAT, R_arr, V_arr)

# 3. Analyze Stability
analyze_stability(E_arr, L_arr)

# 4. Visualization
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Plot 1: Total Energy vs Time
ax1.plot(T_arr / T_PERIOD, E_arr, label='Total Energy (E)')
ax1.set_ylabel('Energy (Joules)')
ax1.set_title('Conservation of Total Mechanical Energy (Euler-Cromer)')
ax1.grid(True, linestyle='--')
ax1.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
ax1.axhline(E_arr[0], color='r', linestyle=':', label='Initial Energy')

# Plot 2: Angular Momentum vs Time
ax2.plot(T_arr / T_PERIOD, L_arr, label='Angular Momentum (L)', color='C1')
ax2.set_xlabel('Time (Orbital Periods)')
ax2.set_ylabel('Angular Momentum (kg m^2/s)')
ax2.set_title('Conservation of Angular Momentum (Euler-Cromer)')
ax2.grid(True, linestyle='--')
ax2.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
ax2.axhline(L_arr[0], color='r', linestyle=':', label='Initial Momentum')

plt.tight_layout()
plt.show()

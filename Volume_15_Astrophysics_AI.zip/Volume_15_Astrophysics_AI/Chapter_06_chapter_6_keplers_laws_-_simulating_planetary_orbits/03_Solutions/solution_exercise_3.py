
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# --- Configuration and Constants ---
G = 6.674e-11
M_SUN = 1.989e30
M_SAT = 5.972e24 # Satellite mass (Earth)

R0 = np.array([1.496e11, 0.0])
V0 = np.array([0.0, 29780.0])
T_PERIOD = 2 * np.pi * np.sqrt(R0[0]**3 / (G * M_SUN))

# Perturbation Constants (Jupiter approximation)
M_JUPITER = 1.898e27 # Mass of Jupiter (kg)
# Fixed position of Jupiter, roughly 5.2 AU away on the negative Y axis
R_JUPITER = np.array([0.0, -7.784e11]) 

# Simulation Parameters
DT = 10000.0
N_PERIODS = 20 # Extended run to visualize precession
TOTAL_TIME = N_PERIODS * T_PERIOD
N_STEPS = int(TOTAL_TIME / DT)

# --- Modified Acceleration Function ---

def calculate_acceleration(R_sat, G, M_sun, M_pert, R_pert):
    """
    Calculates the net acceleration on the satellite due to the Sun and one perturbing body.
    """
    # 1. Acceleration due to the Sun (A_Sun)
    r_sun_mag = np.linalg.norm(R_sat)
    r_sun_hat = R_sat / r_sun_mag
    A_sun = -G * M_sun / r_sun_mag**2 * r_sun_hat
    
    # 2. Acceleration due to the Perturber (A_Jupiter)
    R_rel_pert = R_sat - R_pert
    r_pert_mag = np.linalg.norm(R_rel_pert)
    r_pert_hat = R_rel_pert / r_pert_mag
    A_pert = -G * M_pert / r_pert_mag**2 * r_pert_hat
    
    # Total Acceleration
    A_total = A_sun + A_pert
    return A_total

# --- Integration and Simulation (Euler-Cromer) ---

def euler_cromer_step_perturbed(R, V, dt, G, M_sun, M_pert, R_pert):
    """Euler-Cromer step using the modified acceleration function."""
    A = calculate_acceleration(R, G, M_sun, M_pert, R_pert)
    V_new = V + A * dt
    R_new = R + V_new * dt
    return R_new, V_new

def simulate_perturbed_orbit(R0, V0, dt, n_steps, G, M_sun, M_pert, R_pert):
    R = np.zeros((n_steps, 2))
    V = np.zeros((n_steps, 2))
    R[0], V[0] = R0, V0
    
    for i in range(n_steps - 1):
        R[i+1], V[i+1] = euler_cromer_step_perturbed(R[i], V[i], dt, G, M_sun, M_pert, R_pert)
        
    T = np.linspace(0, n_steps * dt, n_steps)
    return T, R, V

# --- Energy Calculation for Analysis (Only Sun-Satellite System) ---

def calculate_sun_sat_energy(M_sun, m_sat, R_array, V_array, G):
    """Calculates the energy of the satellite relative to the Sun ONLY."""
    R_mag = np.linalg.norm(R_array, axis=1)
    V_mag_sq = np.sum(V_array**2, axis=1)
    K = 0.5 * m_sat * V_mag_sq
    U = -G * M_sun * m_sat / R_mag
    return K + U

# --- Execution ---

# 1. Run Perturbed Simulation
T_pert, R_pert, V_pert = simulate_perturbed_orbit(
    R0, V0, DT, N_STEPS, G, M_SUN, M_JUPITER, R_JUPITER
)

# 2. Run Unperturbed Simulation (M_pert = 0)
T_unpert, R_unpert, V_unpert = simulate_perturbed_orbit(
    R0, V0, DT, N_STEPS, G, M_SUN, 0.0, np.array([0.0, 0.0])
)

# 3. Analyze Energy Drift (Sun-Satellite system)
E_pert = calculate_sun_sat_energy(M_SUN, M_SAT, R_pert, V_pert, G)
E_unpert = calculate_sun_sat_energy(M_SUN, M_SAT, R_unpert, V_unpert, G)

def calculate_drift(E_array):
    initial_val = E_array[0]
    abs_deviation = np.max(np.abs(E_array - initial_val))
    return (abs_deviation / np.abs(initial_val)) * 100

drift_pert = calculate_drift(E_pert)
drift_unpert = calculate_drift(E_unpert)

print(f"\nEnergy Drift (Sun-Satellite System) over {N_PERIODS} Periods:")
print(f"Unperturbed System Drift: {drift_unpert:.6f} % (Expected low)")
print(f"Perturbed System Drift: {drift_pert:.6f} % (Expected high)")

# 4. Visualization
plt.figure(figsize=(10, 10))
plt.plot(R_unpert[:, 0], R_unpert[:, 1], label='Unperturbed Orbit (Perfect Ellipse)', linewidth=1, linestyle='--')
plt.plot(R_pert[:, 0], R_pert[:, 1], label='Perturbed Orbit (Precession)', linewidth=1.5, alpha=0.8)
plt.plot(0, 0, 'yo', markersize=12, label='Sun (Central Body)')
plt.plot(R_JUPITER[0], R_JUPITER[1], 'bo', markersize=10, label='Jupiter (Fixed Perturber)')
plt.plot(R0[0], R0[1], 'go', markersize=5, label='Start Position')

plt.title(f'Orbital Perturbation by a Third Body (20 Periods)')
plt.xlabel('X Position (m)')
plt.ylabel('Y Position (m)')
plt.axis('equal')
plt.grid(True)
plt.legend()
plt.ticklabel_format(style='sci', axis='both', scilimits=(0,0))
plt.show()

# Analysis of Conservation
"""
Analysis of Conservation in Perturbed System:
The total mechanical energy of the *isolated* satellite-Sun system is NOT conserved when Jupiter is included because Jupiter exerts an external force on that system. 
This external force performs work on the satellite, continuously exchanging energy with the satellite-Sun pair. 
Therefore, while the total energy of the *entire* three-body system (Sun + Satellite + Jupiter) would be conserved (if we treated all bodies dynamically), the energy calculated solely based on the Sun-Satellite potential and the satellite's kinetic energy shows significant drift, reflecting the work done by the perturbing body (Jupiter).
"""


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
from scipy.constants import G

# --- 1. Physical Constants and Simulation Parameters (Using SI Units) ---

# Masses (kg)
M_SUN = 1.989e30
M_JUPITER = 1.898e27
M_PROBE = 1000.0  # Mass of the probe (negligible for the forces exerted on the Sun/Jupiter)

# Conversion factors
AU = 1.496e11  # meters (Astronomical Unit)
DAY = 86400.0  # seconds

# Simulation setup
TIME_STEP = 0.5 * DAY  # Reduced step for better accuracy during flyby
TOTAL_TIME = 1200.0 * DAY
STEPS = int(TOTAL_TIME / TIME_STEP)
SAFETY_RADIUS = 1000.0  # Minimum distance check (1 km)

# Initial positions (Heliocentric Frame, Sun at origin [0, 0])
# Jupiter: 5.2 AU out, positioned roughly for an intercept
r_jupiter_init = np.array([0.0, 5.2 * AU])
# Probe: Starting near Earth orbit (1 AU), slightly ahead
r_probe_init = np.array([1.0 * AU, 0.2 * AU])

# Initial velocities (v_circ = sqrt(GM/r))
# Jupiter's initial circular velocity magnitude
v_jupiter_mag = np.sqrt(G * M_SUN / (5.2 * AU))
# Probe velocity: slightly faster than Earth's orbital speed for an intercept trajectory
v_probe_mag = np.sqrt(G * M_SUN / (1.0 * AU)) * 1.10 

v_jupiter_init = np.array([-v_jupiter_mag, 0.0]) # Jupiter moving left (negative x)
v_probe_init = np.array([0.0, v_probe_mag])       # Probe moving up (positive y)

# --- 2. Core Physics Functions: N-Body Acceleration ---

def calculate_acceleration(r_target, m_source, r_source=np.array([0.0, 0.0])):
    """Calculates the gravitational acceleration vector on r_target due to m_source."""
    r_vector = r_source - r_target
    r_mag = np.linalg.norm(r_vector)
    
    # Safety check to prevent numerical instability near collision
    if r_mag < SAFETY_RADIUS:
        return np.zeros(2)

    # Acceleration magnitude: (G * M) / r^2
    magnitude = (G * m_source) / (r_mag**2)
    # Direction: unit vector * magnitude
    acceleration = magnitude * (r_vector / r_mag)
    return acceleration

def total_acceleration(r_probe, r_jupiter):
    """Calculates the vector sum of acceleration on the probe from both the Sun and Jupiter."""
    # a_sun: Acceleration due to the Sun (source at origin)
    a_sun = calculate_acceleration(r_probe, M_SUN)
    # a_jupiter: Acceleration due to Jupiter (source at r_jupiter)
    a_jupiter = calculate_acceleration(r_probe, M_JUPITER, r_jupiter)
    
    return a_sun + a_jupiter

# --- 3. Simulation Setup and Velocity Verlet Integration Loop ---

# Initialize history arrays for storing trajectory
r_probe_hist = np.zeros((STEPS, 2))
v_probe_hist = np.zeros((STEPS, 2))
r_jupiter_hist = np.zeros((STEPS, 2))
r_probe = r_probe_init
v_probe = v_probe_init
r_jupiter = r_jupiter_init
v_jupiter = v_jupiter_init

# Calculate initial acceleration (a_n)
a_n = total_acceleration(r_probe, r_jupiter)

print(f"Starting Simulation: {STEPS} steps over {TOTAL_TIME/DAY:.0f} days.")

for i in range(STEPS):
    # Store the current state before updating
    r_probe_hist[i] = r_probe
    v_probe_hist[i] = v_probe
    r_jupiter_hist[i] = r_jupiter
    
    dt = TIME_STEP
    dt_sq = dt**2

    # 3a. Update Probe Position (r_{n+1}): r_{n+1} = r_n + v_n*dt + 0.5*a_n*dt^2
    r_probe_new = r_probe + v_probe * dt + 0.5 * a_n * dt_sq
    
    # 3b. Update Jupiter's State (Simplified Integration for Perturber)
    # Calculate Jupiter's acceleration due to the Sun
    a_jupiter_n = calculate_acceleration(r_jupiter, M_SUN)
    # Use Euler integration for Jupiter, as its orbit is nearly perfect Keplerian
    r_jupiter = r_jupiter + v_jupiter * dt
    v_jupiter = v_jupiter + a_jupiter_n * dt

    # 3c. Calculate new acceleration (a_{n+1}) at the new probe position
    a_n_plus_1 = total_acceleration(r_probe_new, r_jupiter)
    
    # 3d. Update Probe Velocity (v_{n+1}): v_{n+1} = v_n + 0.5 * (a_n + a_{n+1}) * dt
    v_probe_new = v_probe + 0.5 * (a_n + a_n_plus_1) * dt

    # 3e. Prepare for next iteration: shift state variables
    r_probe = r_probe_new
    v_probe = v_probe_new
    a_n = a_n_plus_1
        
# --- 4. Post-Simulation Analysis (Verification of Assist) ---

v_initial_mag = np.linalg.norm(v_probe_hist[0])
v_final_mag = np.linalg.norm(v_probe_hist[-1])
min_distance = np.min(np.linalg.norm(r_probe_hist - r_jupiter_hist, axis=1))

print("\n--- Gravitational Assist Simulation Summary ---")
print(f"Total Simulation Time: {TOTAL_TIME/DAY:.0f} days.")
print(f"Closest Approach to Jupiter: {min_distance / 1000:.0f} km")
print(f"Initial Probe Speed (Heliocentric): {v_initial_mag / 1000:.2f} km/s")
print(f"Final Probe Speed (Heliocentric):   {v_final_mag / 1000:.2f} km/s")

speed_increase_percent = ((v_final_mag - v_initial_mag) / v_initial_mag) * 100

if speed_increase_percent > 0.5:
    print(f"\nResult: SUCCESSFUL GRAVITY ASSIST.")
    print(f"Orbital energy increased. Speed gain: +{speed_increase_percent:.2f}%")
else:
    print(f"\nResult: FAILED. Insufficient speed gain detected.")

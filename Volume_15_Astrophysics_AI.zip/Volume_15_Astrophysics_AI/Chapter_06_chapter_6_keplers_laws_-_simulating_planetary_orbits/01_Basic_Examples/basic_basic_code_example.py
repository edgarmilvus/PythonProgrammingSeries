
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt

# --- 1. PHYSICAL CONSTANTS AND INITIAL SETUP ---

# Gravitational Constant G (SI units: m^3 kg^-1 s^-2)
G = 6.67430e-11
# Mass of the Central Body (Sun) (SI units: kg)
M_sun = 1.989e30

# Initial Conditions (Approximating Earth's orbit at perihelion)
# We use NumPy arrays to represent 2D vectors (x, y)
# Position vector r0 (meters). Placed on the positive x-axis. (~1 AU)
R_AU = 1.496e11 # 1 Astronomical Unit in meters
r0 = np.array([R_AU, 0.0])

# Velocity vector v0 (meters/second). Initial velocity is purely in the y-direction.
V_EARTH = 2.978e4 # Earth's average orbital speed
v0 = np.array([0.0, V_EARTH])

# --- 2. SIMULATION PARAMETERS ---

# Total duration of the simulation (1 Earth year in seconds)
TOTAL_TIME = 365.25 * 24 * 3600
# Time step (dt) for integration (6 hours in seconds). Smaller dt means higher accuracy.
DT = 3600.0 * 6
# Calculate the total number of discrete steps
NUM_STEPS = int(TOTAL_TIME / DT)

# --- 3. DATA STORAGE AND INITIALIZATION ---

# Array to store the X and Y positions at every step.
# Dimensions: (Number of steps, 2 dimensions)
positions = np.zeros((NUM_STEPS, 2))
# Store the initial position in the first row
positions[0] = r0

# Initialize the current state variables for the loop
r_current = r0.copy()
v_current = v0.copy()

# --- 4. ACCELERATION FUNCTION ---

def calculate_acceleration(r_vec, M_central):
    """
    Calculates the acceleration vector (a) due to gravity.
    a = - (G * M / r^2) * r_hat
    """
    # Calculate the magnitude (distance r) using the Euclidean norm
    r_mag = np.linalg.norm(r_vec)

    # Check for division by zero (e.g., if the planet hits the Sun)
    if r_mag == 0:
        return np.zeros(2)

    # Calculate the unit vector pointing from the central body to the planet
    r_hat = r_vec / r_mag

    # Calculate the magnitude of the gravitational acceleration
    # The negative sign ensures the acceleration vector points toward the origin (attraction)
    a_mag = - (G * M_central) / (r_mag**2)

    # The acceleration vector is the magnitude times the unit vector
    return a_mag * r_hat

# --- 5. MAIN INTEGRATION LOOP (Euler-Cromer Method) ---

print(f"Starting simulation: {NUM_STEPS} steps over {TOTAL_TIME/3600/24/365.25:.2f} years.")

for i in range(1, NUM_STEPS):
    # 5a. Calculate acceleration (a) at the current position (r_current)
    a = calculate_acceleration(r_current, M_sun)

    # 5b. Update velocity (v_current) based on acceleration (a) and time step (DT)
    # This is the 'Euler' part of the update for velocity
    v_current = v_current + a * DT

    # 5c. Update position (r_current) using the *newly calculated* velocity (v_current)
    # This crucial step makes it the 'Cromer' or Semi-Implicit Euler method,
    # which ensures better energy conservation than standard Euler.
    r_current = r_current + v_current * DT

    # 5d. Store the new position vector for plotting
    positions[i] = r_current

print("Simulation complete.")

# --- 6. VISUALIZATION ---

# Scale the positions back to Astronomical Units (AU) for readable plotting
x_au = positions[:, 0] / R_AU
y_au = positions[:, 1] / R_AU

plt.figure(figsize=(8, 8))
# Plot the orbit path
plt.plot(x_au, y_au, label='Simulated Orbit')
# Plot the Sun
plt.plot(0, 0, 'o', color='gold', markersize=10, label='Sun (Origin)')

# Formatting and Display
plt.title(f'Orbital Simulation using Euler-Cromer Integration ({NUM_STEPS} steps)')
plt.xlabel('X Position (AU)')
plt.ylabel('Y Position (AU)')
# Crucially, ensure the aspect ratio is equal so the orbit isn't distorted
plt.gca().set_aspect('equal', adjustable='box')
plt.grid(True, linestyle=':', alpha=0.7)
plt.legend()
plt.show()

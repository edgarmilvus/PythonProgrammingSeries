
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================
from scipy.optimize import curve_fit

# 1. Define the Mock Model Class
class BinaryModelLimbDarkened:
    """
    A simplified analytical model representing an eclipsing binary.
    """
    @staticmethod
    def calculate_flux(phase, inclination, radius_ratio, separation, u):
        """
        Calculates flux with linear limb darkening coefficient 'u'.
        
        Note: This is a simplified mathematical representation for the exercise.
        In reality, this would involve elliptic integrals (e.g., Mandel & Agol).
        """
        # Center phase around 0.5 for the eclipse calculation
        x = phase - 0.5
        
        # Simplified geometry: distance between stellar centers on the sky plane
        # (Approximation for small phases near eclipse)
        z = np.sqrt((x * separation)**2 + (inclination/90.0)**2)
        
        # Determine if eclipse is happening (z < sum of radii)
        # We assume R_primary=1 (normalized), so threshold is roughly 1 + radius_ratio
        
        # --- LIMB DARKENING IMPLEMENTATION ---
        # If u=0 (uniform), the profile is box-like.
        # If u>0, the center is brighter, edges dimmer.
        # We approximate this by modulating the eclipse depth based on how close
        # the occultor is to the center of the star.
        
        # Base eclipse depth (geometric)
        depth = radius_ratio**2 
        
        # Limb darkening modulation: 
        # Making the eclipse 'rounder' as u increases
        ld_factor = 1.0 - u * (1.0 - np.exp(-z**2))
        
        # Generate the flux dip (Gaussian-like approximation for the eclipse shape)
        # We use a super-gaussian to simulate the 'flat bottom' vs 'round bottom'
        eclipse_profile = depth * ld_factor * np.exp(-(z**4)/0.0001)
        
        return 1.0 - eclipse_profile

# 2. Prepare Data for Fitting
# Use the phase-folded data from Exercise 3 (assuming P is refined)
final_period = period_detected # Use the LS period for this example
phase_data, flux_data = phase_fold(t_clean, f_clean, final_period, T0_guess)

# Shift phase to put eclipse in the middle (0.5) for the simplified model logic above
phase_shifted = (phase_data + 0.5) % 1.0 
sort_k = np.argsort(phase_shifted)
p_fit = phase_shifted[sort_k]
f_fit = flux_data[sort_k]

# 3. Optimization with Bounds
# Parameters: [inclination, radius_ratio, separation, u]
# Initial guesses
p0 = [88.0, 0.1, 50.0, 0.5] 

# Bounds: u must be between 0 and 1
# inclination: 0-90, k: 0-1, a: >0, u: 0-1
bounds = ([0, 0, 0, 0], [90, 1, 200, 1])

try:
    p_opt, p_cov = curve_fit(
        BinaryModelLimbDarkened.calculate_flux, 
        p_fit, 
        f_fit, 
        p0=p0, 
        bounds=bounds
    )
    
    print("Fitted Parameters:")
    print(f"Inclination (i): {p_opt[0]:.2f} deg")
    print(f"Radius Ratio (k): {p_opt[1]:.4f}")
    print(f"Separation (a):  {p_opt[2]:.2f}")
    print(f"Limb Darkening (u): {p_opt[3]:.4f}")

    # Visualization of the Fit
    plt.figure(figsize=(10, 6))
    plt.scatter(p_fit, f_fit, s=5, color='gray', alpha=0.5, label='Observational Data')
    
    model_flux = BinaryModelLimbDarkened.calculate_flux(p_fit, *p_opt)
    plt.plot(p_fit, model_flux, color='red', lw=2, label=f'Best Fit (u={p_opt[3]:.2f})')
    
    plt.xlabel("Orbital Phase")
    plt.ylabel("Normalized Flux")
    plt.legend()
    plt.title("Physical Modeling with Limb Darkening")
    plt.xlim(0.4, 0.6) # Zoom in on the eclipse
    plt.show()

except Exception as e:
    print(f"Fitting failed: {e}")
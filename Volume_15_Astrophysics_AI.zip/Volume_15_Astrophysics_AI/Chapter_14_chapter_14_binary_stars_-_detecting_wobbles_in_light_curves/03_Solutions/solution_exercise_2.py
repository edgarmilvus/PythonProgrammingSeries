
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from astropy.timeseries import LombScargle

def compute_lomb_scargle(time_cleaned, flux_cleaned, flux_err_cleaned):
    # 1. Define frequency grid
    # We search from a period of ~30 days (1/30) down to 0.5 days (frequency=2)
    min_freq = 1/30.0
    max_freq = 2.0
    frequency = np.linspace(min_freq, max_freq, 10000)
    
    # 2. Instantiate and compute LombScargle
    ls = LombScargle(time_cleaned, flux_cleaned, flux_err_cleaned)
    power = ls.power(frequency)
    
    # 3. Find P_max and f_peak
    best_freq_idx = np.argmax(power)
    f_peak = frequency[best_freq_idx]
    power_max = power[best_freq_idx]
    period = 1.0 / f_peak
    
    # 4. Calculate FAP thresholds
    # We ask: what power level corresponds to these probabilities?
    fap_levels = [0.1, 0.01, 0.001]
    fap_thresholds = ls.false_alarm_level(fap_levels)
    
    # Calculate the specific FAP for our peak
    fap_value = ls.false_alarm_probability(power_max)
    
    # 5. Plot the result
    plt.figure(figsize=(12, 6))
    plt.plot(frequency, power, color='black', lw=1)
    
    # Plot FAP lines
    colors = ['green', 'orange', 'red']
    labels = ['10% FAP', '1% FAP', '0.1% FAP']
    for val, col, lab in zip(fap_thresholds, colors, labels):
        plt.axhline(val, color=col, linestyle='--', label=lab)
        
    plt.axvline(f_peak, color='blue', alpha=0.5, label=f'Peak Period: {period:.4f} d')
    plt.xlabel("Frequency (1/day)")
    plt.ylabel("Lomb-Scargle Power")
    plt.title(f"Periodogram (Peak FAP = {fap_value:.2e})")
    plt.legend()
    plt.show()
    
    return period, power_max, fap_value

# Apply to previous data
period_detected, p_max, fap = compute_lomb_scargle(t_clean, f_clean, err_clean)

if fap < 0.001:
    print(f"SUCCESS: Period {period_detected:.4f} d is statistically significant (>99.9% confidence).")
else:
    print("WARNING: Period detection is not statistically significant.")

    

#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================
from ipywidgets import interact, FloatSlider
import matplotlib.pyplot as plt

def phase_fold(time, flux, period, T0):
    """
    Folds the time series data based on a period and reference time T0.
    Returns sorted phase and corresponding flux.
    """
    # Calculate phase
    phase = ((time - T0) / period) % 1
    
    # Sort indices to make plotting cleaner (optional for scatter, needed for line plots)
    sort_idx = np.argsort(phase)
    return phase[sort_idx], flux[sort_idx]

# Estimate T0: The time of the deepest flux minimum (primary eclipse)
T0_guess = t_clean[np.argmin(f_clean)]

def interactive_phase_plot(P_trial):
    # 1. Fold data
    ph, fl = phase_fold(t_clean, f_clean, P_trial, T0_guess)
    
    # 2. Plot
    plt.figure(figsize=(10, 6))
    plt.scatter(ph, fl, s=5, alpha=0.6, color='purple')
    
    # Formatting
    plt.xlabel("Orbital Phase")
    plt.ylabel("Normalized Flux")
    plt.title(f"Phase Folded at P = {P_trial:.5f} days")
    plt.ylim(np.min(fl)-0.05, np.max(fl)+0.05)
    plt.grid(True)
    plt.show()

# Setup the widget
# We create a slider centered on the LS period found in Ex 2
slider = FloatSlider(
    value=period_detected, 
    min=period_detected - 0.1, 
    max=period_detected + 0.1, 
    step=0.0001,
    description='Period (d):',
    continuous_update=False
)

print("Interact with the slider to refine the period:")
interact(interactive_phase_plot, P_trial=slider);

#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================
import numpy as np
import matplotlib.pyplot as plt

def clean_light_curve(time, flux, flux_err, sigma_threshold=3.0, max_iterations=5):
    """
    Iteratively removes outliers from light curve data using sigma clipping.
    """
    # Create a boolean mask where True indicates a good data point
    mask = np.ones(len(flux), dtype=bool)
    
    iteration = 0
    while iteration < max_iterations:
        # Calculate statistics based ONLY on currently valid data
        current_flux = flux[mask]
        median_flux = np.median(current_flux)
        std_flux = np.std(current_flux)
        
        # Identify outliers in this pass
        # We check the distance of ALL points from the current median
        # against the current standard deviation
        abs_diff = np.abs(flux - median_flux)
        new_mask = abs_diff < (sigma_threshold * std_flux)
        
        # Check for convergence: if the mask hasn't changed, stop early
        if np.array_equal(mask, new_mask):
            print(f"Converged after {iteration} iterations.")
            break
            
        mask = new_mask
        iteration += 1
        
    return time[mask], flux[mask], flux_err[mask], mask

# --- Simulation and Plotting Code ---

# 1. Generate Dummy Data with Noise and Outliers
np.random.seed(42)
t_raw = np.linspace(0, 10, 500)
# Signal: A simple eclipsing binary approximation (inverted sine-like)
signal = 1.0 - 0.3 * np.exp(-np.sin(2 * np.pi * t_raw / 2.5)**10) 
noise = np.random.normal(0, 0.01, size=len(t_raw))
f_raw = signal + noise
err_raw = np.ones_like(f_raw) * 0.01

# Add outliers (Cosmic rays)
outlier_indices = np.random.choice(len(t_raw), 10, replace=False)
f_raw[outlier_indices] += np.random.uniform(0.1, 0.3, 10) # Spikes upwards

# 2. Apply the Cleaning Function
t_clean, f_clean, err_clean, final_mask = clean_light_curve(t_raw, f_raw, err_raw)

# 3. Visualization
plt.figure(figsize=(12, 6))

# Plot valid data
plt.scatter(t_clean, f_clean, color='blue', s=10, label='Cleaned Data')

# Plot outliers (inverse of the final mask)
rejected_mask = ~final_mask
plt.scatter(t_raw[rejected_mask], f_raw[rejected_mask], 
            color='red', marker='x', s=50, label='Rejected Outliers')

plt.xlabel("Time (Days)")
plt.ylabel("Normalized Flux")
plt.title("Exercise 1: Iterative Sigma Clipping Results")
plt.legend()
plt.grid(alpha=0.3)
plt.show()
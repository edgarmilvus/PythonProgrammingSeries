
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

# Conceptual Python Workflow for Detecting Binary Star Periods

# 1. Data Acquisition and Preprocessing
# Load time (t) and flux (f) data, handle missing values, and normalize flux.
# This stage often involves complex cleaning routines (e.g., outlier rejection).
t_raw = [...] # Irregularly sampled observation times
f_raw = [...] # Corresponding flux measurements

# 2. Spectral Analysis using Lomb-Scargle
# The goal is to find the frequency (or period) that best explains the variance.
# We define a range of frequencies (or periods) to test.
import numpy as np
from astropy.timeseries import LombScargle

# Define the frequency grid to search (e.g., periods from 0.1 to 100 days)
min_period = 0.1
max_period = 100.0
# Convert periods to frequencies (frequency = 1 / period)
frequencies = np.linspace(1.0 / max_period, 1.0 / min_period, 10000)

# Calculate the Lomb-Scargle periodogram power spectrum
ls = LombScargle(t_raw, f_raw)
power = ls.power(frequencies)

# 3. Period Determination
# Find the frequency corresponding to the maximum power peak.
best_frequency = frequencies[np.argmax(power)]
best_period = 1.0 / best_frequency

# 4. Phase Folding
# Use the determined period (P) to fold the time series data.
P = best_period
T0 = t_raw[np.argmin(f_raw)] # Estimate T0 as the time of the deepest observed dip

# Calculate the phase for every time point
# The modulo operator (%) is key here, ensuring the phase wraps between [0, 1).
# Note: This is an example of calculating the phase index, which is mathematically
# equivalent to the concept of Extended Slicing (e.g., [start:stop:step]) 
# often used in array manipulation, where the 'step' defines the interval or periodicity.
# While direct Extended Slicing isn't used for phase calculation, the underlying
# principle of selecting elements based on a periodic interval is shared.
phase = ((t_raw - T0) / P) % 1.0

# 5. Visualization and Modeling
# Sort the phased data for plotting and fitting.
# The resulting (phase, flux) plot reveals the clean eclipse profile.
sort_idx = np.argsort(phase)
phase_sorted = phase[sort_idx]
flux_sorted = f_raw[sort_idx]

# Next steps would involve fitting a physical model to (phase_sorted, flux_sorted)
# to derive stellar parameters.

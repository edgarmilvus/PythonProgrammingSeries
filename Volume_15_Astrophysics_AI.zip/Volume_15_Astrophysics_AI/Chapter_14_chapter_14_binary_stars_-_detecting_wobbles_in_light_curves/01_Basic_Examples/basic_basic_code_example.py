
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# ======================================================================
# 1. Define Simulation Parameters
# ======================================================================

# Define the total observation time in days (e.g., 10 nights of intermittent observation)
TOTAL_TIME = 10.0
# Define the number of data points collected (simulating observation frequency)
NUM_POINTS = 500
# Define the known orbital period of the simulated binary system (in days)
PERIOD = 1.5
# Define the maximum depth of the eclipse (10% dimming)
ECLIPSE_DEPTH = 0.1
# Define the standard deviation of the Gaussian noise (instrument/atmosphere error)
NOISE_LEVEL = 0.005

# Generate evenly spaced time stamps from 0 to TOTAL_TIME
time = np.linspace(0, TOTAL_TIME, NUM_POINTS)

# Generate a baseline flux (normalized to 1.0, meaning 100% brightness)
baseline_flux = np.ones(NUM_POINTS)

# ======================================================================
# 2. Introduce the "Wobble" (The Eclipse Signature)
# ======================================================================

def create_box_eclipse(t, period, depth, duration=0.1):
    """Calculates the flux dip based on the orbital phase."""
    
    # Calculate the phase: (time % period) / period. This wraps time into the range [0, 1)
    phase = (t % period) / period
    
    # Define the phase window where the eclipse occurs (centered at phase 0.5)
    eclipse_start = 0.5 - duration / 2
    eclipse_end = 0.5 + duration / 2
    
    # Create a boolean mask: True where the phase is within the eclipse window
    is_eclipsed = (phase >= eclipse_start) & (phase <= eclipse_end)
    
    # Use np.where to apply the flux dip only during the eclipse
    flux_dip = np.where(is_eclipsed, -depth, 0)
    return flux_dip

# Apply the simulated eclipse to the baseline flux (the noise-free signal)
eclipse_signature = create_box_eclipse(time, PERIOD, ECLIPSE_DEPTH)
raw_flux = baseline_flux + eclipse_signature

# ======================================================================
# 3. Add Realistic Noise
# ======================================================================

# Generate random Gaussian (normal) noise centered at zero
noise = np.random.normal(0, NOISE_LEVEL, NUM_POINTS)

# Final observed light curve data (Signal + Noise)
observed_flux = raw_flux + noise

# ======================================================================
# 4. Data Inspection and Visualization
# ======================================================================

print(f"--- Simulated Light Curve Data Summary ---")
print(f"Total Observations: {len(observed_flux)}")
print(f"Time Span: {TOTAL_TIME} days")
print(f"Mean Flux (Before Detrending): {np.mean(observed_flux):.5f}")
print("-" * 40)

# Set up the plotting environment
plt.figure(figsize=(14, 7))

# Plot the raw time series data using small markers to show individual observations
plt.plot(time, observed_flux, 'k.', markersize=3, alpha=0.6, label='Observed Noisy Data')
# Plot the idealized, noise-free signal for comparison, showing the true "wobble"
plt.plot(time, raw_flux, 'r-', linewidth=1.5, alpha=0.8, label='Ideal Signal (Ground Truth)')

# Labeling and titles
plt.title(f"Raw Light Curve of a Simulated Eclipsing Binary (P={PERIOD} days)", fontsize=16)
plt.xlabel("Time (Days)", fontsize=14)
plt.ylabel("Relative Flux (Arbitrary Units)", fontsize=14)
plt.legend(loc='lower left')
plt.grid(True, linestyle=':', alpha=0.7)
plt.ylim(0.85, 1.05) # Set limits to focus on the variation
plt.show()

# ======================================================================
# 5. Essential Pre-processing: Detrending (Normalization)
# ======================================================================

# In real astronomy, the mean flux often drifts due to factors like airmass,
# changing filter transparency, or temperature variations.
# We normalize the data so the baseline flux is precisely 1.0.

mean_flux_value = np.mean(observed_flux)

# Divide every flux measurement by the overall mean
normalized_flux = observed_flux / mean_flux_value

print(f"\n--- Detrending Summary ---")
print(f"Original Mean Flux: {mean_flux_value:.5f}")
print(f"Normalized Mean Flux (Target: 1.00000): {np.mean(normalized_flux):.5f}")
print(f"Data is now ready for Period Analysis (Lomb-Scargle).")
print("-" * 40)

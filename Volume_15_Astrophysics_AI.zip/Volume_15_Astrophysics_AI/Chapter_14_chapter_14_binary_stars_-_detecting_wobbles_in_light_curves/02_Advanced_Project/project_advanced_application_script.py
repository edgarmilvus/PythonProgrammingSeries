
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from astropy.timeseries import LombScargle
from scipy.optimize import curve_fit
import warnings

# Suppress potential warnings from Astropy/SciPy regarding optimization convergence
warnings.filterwarnings("ignore", category=RuntimeWarning)

# --- Part 1: Data Simulation (Creating a Realistic Noisy Light Curve) ---

def simulate_eclipsing_binary(P=3.5, t0=1.0, depth=0.015, duration=0.08, baseline_flux=1.0, noise_level=0.0015):
    """
    Generates a synthetic light curve for a simple eclipsing binary system.

    Parameters:
        P (float): Orbital period (days).
        t0 (float): Time of primary eclipse center (days).
        depth (float): Fractional depth of the eclipse.
        duration (float): Duration of the eclipse relative to the period (0 to 1).
        baseline_flux (float): Normalization constant for out-of-eclipse flux.
        noise_level (float): Standard deviation of Gaussian noise added.

    Returns:
        tuple: (time array, flux array, flux error array)
    """
    # Create a time base: 1000 points over 30 periods
    time = np.linspace(0, P * 30, 5000)
    
    # Calculate the phase relative to the period and t0
    phase = (time - t0) / P
    phase = phase - np.floor(phase) # Normalize phase to [0, 1)

    # Calculate the normalized phase difference from the center (0.0 or 0.5)
    # We model only the primary eclipse centered at phase 0.0
    phase_from_center = np.abs(phase - 0.5)
    
    # Ensure phase_from_center wraps correctly for the primary eclipse at 0.0
    # If phase > 0.5, the distance to 1.0 is 1 - phase. Distance to 0.0 is phase.
    # We consider the distance to the nearest eclipse center (0.0 or 0.5)
    
    # Calculate the distance to the nearest eclipse center (0.0 or 0.5)
    # This simplifies modeling primary and secondary eclipses if they are equal depth
    phase_dist = np.minimum(phase, 1.0 - phase)
    
    # Model the eclipse: a simple box shape
    # Eclipses happen near phase 0.0 and phase 0.5
    # The duration is defined relative to the period.
    
    # Check for primary eclipse (near phase 0.0)
    is_primary_eclipse = (phase_dist < duration / 2)
    
    # Initialize flux at the baseline
    flux = np.full_like(time, baseline_flux)
    
    # Apply the eclipse depth
    flux[is_primary_eclipse] = baseline_flux - depth
    
    # Add Gaussian noise
    np.random.seed(42) # For reproducibility
    noise = np.random.normal(0, noise_level, len(time))
    flux += noise
    
    # Estimate the flux error (constant for simplicity, based on noise level)
    flux_err = np.full_like(time, noise_level)
    
    return time, flux, flux_err

# --- Part 2: Model Definition (The Box Transit/Eclipse Model) ---

def eclipsing_binary_model(phase, depth, duration):
    """
    A simple rectangular model for an eclipsing binary light curve.
    Used for fitting the phase-folded data.
    Assumes baseline flux of 1.0 and eclipse centered at phase 0.5 (or 0.0).
    
    Note: The phase input here must be normalized to [0, 1] and centered.
    """
    model_flux = np.ones_like(phase)
    
    # Calculate the distance to the center of the eclipse (phase 0.5)
    # We use (phase - 0.5) and then wrap the absolute value
    phase_centered = np.abs(phase - 0.5)
    
    # Check if the phase is within the duration of the eclipse
    # duration is the total width, so we check half the width
    eclipse_mask = (phase_centered < duration / 2)
    
    # Apply the depth to the masked regions
    model_flux[eclipse_mask] = 1.0 - depth
    
    return model_flux

# --- Part 3: The Core Analysis Pipeline ---

def analyze_light_curve(time, flux, flux_err, min_period=0.5, max_period=10.0, num_freqs=10000):
    """
    Main pipeline function to detect the period, phase fold, and fit the light curve.
    """
    print(f"--- Starting Analysis on {len(time)} data points ---")
    
    # 1. Data Normalization and Cleaning
    # Calculate the median flux to normalize the data
    median_flux = np.median(flux)
    normalized_flux = flux / median_flux
    normalized_flux_err = flux_err / median_flux
    
    print(f"Data normalized. Median flux: {median_flux:.4f}")
    
    # 2. Lomb-Scargle Periodogram Calculation
    # Determine the frequency grid
    frequency, power = LombScargle(time, normalized_flux, normalized_flux_err).autopower(
        minimum_frequency=1.0 / max_period, 
        maximum_frequency=1.0 / min_period,
        nyquist_factor=1.0, # Use 1.0 for dense sampling
        samples_per_peak=10
    )
    
    # 3. Period Determination
    # Find the frequency corresponding to the maximum power
    best_freq_index = np.argmax(power)
    best_frequency = frequency[best_freq_index]
    best_period = 1.0 / best_frequency
    
    print(f"Lomb-Scargle Peak Power: {power[best_freq_index]:.3f}")
    print(f"Detected Best Period (P_det): {best_period:.4f} days")
    
    # 4. Phase Folding
    # Calculate the phase using the detected period
    phase = (time / best_period) % 1.0
    
    # For visualization and fitting, we center the primary eclipse at phase 0.5
    # We shift the phase so the data wraps around the center (0.0 -> 0.5)
    phase_centered = (phase + 0.5) % 1.0 
    
    # Sort the data by phase for plotting and fitting stability
    sort_indices = np.argsort(phase_centered)
    phase_sorted = phase_centered[sort_indices]
    flux_sorted = normalized_flux[sort_indices]
    err_sorted = normalized_flux_err[sort_indices]
    
    # 5. Model Fitting (using scipy.optimize.curve_fit)
    
    # Initial guesses for the parameters (depth, duration)
    # Estimate depth from the minimum flux in the folded curve
    initial_depth = 1.0 - np.min(flux_sorted)
    # Estimate duration (e.g., 5% of the period)
    initial_duration = 0.05
    
    p0 = [initial_depth, initial_duration]
    
    # Set bounds: depth must be positive, duration must be between 0 and 1
    bounds = ([0.0, 0.001], [0.1, 1.0]) 
    
    try:
        # Fit the model to the phase-folded data
        popt, pcov = curve_fit(
            f=eclipsing_binary_model, 
            xdata=phase_sorted, 
            ydata=flux_sorted, 
            p0=p0, 
            sigma=err_sorted, 
            bounds=bounds,
            absolute_sigma=True # Use sigma as true errors
        )
        
        # Extract fitted parameters and their standard deviations
        fit_depth, fit_duration = popt
        perr = np.sqrt(np.diag(pcov))
        depth_err, duration_err = perr
        
        print("\n--- Model Fit Results ---")
        print(f"Fitted Depth (d): {fit_depth*1000:.2f} ppt (±{depth_err*1000:.2f} ppt)")
        print(f"Fitted Duration (D): {fit_duration*best_period:.4f} days (±{duration_err*best_period:.4f} days)")
        
    except RuntimeError:
        print("Warning: Model fitting failed to converge.")
        fit_depth, fit_duration = initial_depth, initial_duration
        depth_err, duration_err = 0, 0
    
    # 6. Visualization and Output
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    fig.suptitle(f"Automated Binary Star Characterization (P = {best_period:.4f} d)", fontsize=16)

    # Plot 1: Lomb-Scargle Periodogram
    ax1.plot(1.0 / frequency, power, color='gray', linestyle='-', alpha=0.7)
    ax1.axvline(best_period, color='red', linestyle='--', label=f'Detected P: {best_period:.4f} d')
    ax1.set_xlim(min_period, max_period)
    ax1.set_xlabel("Period (days)")
    ax1.set_ylabel("Lomb-Scargle Power")
    ax1.set_title("Periodogram Analysis")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Plot 2: Phase-Folded Light Curve with Model Fit
    
    # Plot the raw phase-folded data (scatter plot)
    ax2.errorbar(phase_centered, normalized_flux, yerr=normalized_flux_err, 
                 fmt='.', color='black', alpha=0.3, label='Folded Data')
    
    # Plot the folded data *again* to show the full transit shape (wrapping the x-axis)
    # This is crucial for visual continuity of the eclipse
    ax2.errorbar(phase_centered + 1.0, normalized_flux, yerr=normalized_flux_err, 
                 fmt='.', color='black', alpha=0.3)
    
    # Create the fitted model curve
    phase_model = np.linspace(0, 2.0, 500)
    # The model function expects phase centered at 0.5, so we adjust phase_model
    model_fit = eclipsing_binary_model(phase_model, fit_depth, fit_duration)
    
    # Plot the fitted model
    ax2.plot(phase_model, model_fit, color='red', linewidth=2, 
             label=f'Fitted Model (Depth={fit_depth*1000:.2f} ppt)')

    ax2.set_xlim(0.0, 2.0)
    ax2.set_xlabel(f"Phase (P = {best_period:.4f} days)")
    ax2.set_ylabel("Normalized Relative Flux")
    ax2.set_title("Phase-Folded Light Curve and Box Model Fit")
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
    
    # Return the key findings
    return {
        'period': best_period,
        'depth': fit_depth,
        'depth_error': depth_err,
        'duration': fit_duration * best_period
    }

# --- Part 4: Execution ---

if __name__ == "__main__":
    # 1. Simulate the data for a binary system
    # P=3.5 days, 1.5% depth, 0.08 fractional duration
    T, F, E = simulate_eclipsing_binary(P=3.5, depth=0.015, duration=0.08, noise_level=0.0015)
    
    # 2. Run the analysis pipeline
    results = analyze_light_curve(T, F, E)
    
    print("\n--- Final Characterization Summary ---")
    print(f"Orbital Period: {results['period']:.4f} days")
    print(f"Eclipse Depth: {results['depth']*1000:.2f} ppt")
    print(f"Eclipse Duration: {results['duration']:.4f} days")


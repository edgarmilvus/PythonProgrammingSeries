
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from astroquery.mast import Observations
from astropy import units as u

target_name = "Abell 1689"

# 1. Efficient Query Construction
# Use query_criteria to enforce multiple constraints server-side.
# MAST handles the comparison operators (>=, >, <) within the query criteria dictionary.
criteria = {
    "target_name": target_name,
    "productType": "science",
    "t_exptime": (1000.0, None),  # Specifies t_exptime > 1000 seconds
    "instrument_name": "ACS",
    "filters": "F814W"
}

# The query automatically uses implicit AND logic for all criteria provided.
print(f"Executing optimized query for {target_name}...")
optimized_table = Observations.query_criteria(**criteria)

# 2. Leveraging ORM Concepts (Conceptual)
# Comment: Enforcing constraints like t_exptime > 1000 seconds at the query stage 
# (server-side filtering) is analogous to using an ORM's WHERE clause. This minimizes 
# network transfer by only fetching relevant rows, avoiding the need to download 
# potentially millions of records just to filter them locally in Python memory.

if optimized_table is None or len(optimized_table) == 0:
    print("No observations found matching all criteria.")
else:
    print(f"\nFound {len(optimized_table)} observations matching all constraints.")
    
    # 3. Data Integrity Check
    # Calculate the total cumulative exposure time
    total_exposure_time = optimized_table['t_exptime'].sum() * u.s
    
    print(f"Total cumulative exposure time for usable data: {total_exposure_time.to(u.hour):.2f}")
    print("\nFirst 3 matching observation IDs:")
    print(optimized_table['obsid', 't_exptime', 'filters'][:3])

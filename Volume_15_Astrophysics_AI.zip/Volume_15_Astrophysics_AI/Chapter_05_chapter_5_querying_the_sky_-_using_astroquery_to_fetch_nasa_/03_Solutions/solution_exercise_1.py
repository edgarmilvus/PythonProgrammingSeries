
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from astropy.coordinates import SkyCoord, Angle
from astropy import units as u
from astroquery.mast import Mast
from astroquery.ned import Ned

# 1. Dual Query Execution
object_name = "M31"

# Query MAST Name Resolver (often returns a single coordinate result)
mast_result = Mast.resolve_object(object_name)
# mast_result is a SkyCoord object in degrees

# Query NED (returns an Astropy Table)
ned_table = Ned.query_object(object_name)

# 2. Coordinate Retrieval and SkyCoord Conversion

# --- MAST Coordinates ---
# mast_result is already a SkyCoord object from the resolve_object function
mast_coords = mast_result 

# --- NED Coordinates ---
# 3. Pythonic Filtering (Astropy Table)
# The NED table often lists the primary entry first. We select the first row.
# For robust filtering, one might use boolean masking on 'Type' or 'Distance_Ref'
# but here we assume the primary entry is index 0.
primary_ned_entry = ned_table[0]

# Extract RA/Dec from the selected NED row (usually returned in hms/dms format)
ned_ra_str = primary_ned_entry['RA']
ned_dec_str = primary_ned_entry['DEC']

# Convert NED strings to SkyCoord
ned_coords = SkyCoord(ned_ra_str, ned_dec_str, unit=(u.hourangle, u.deg))

# 4. Consistency Check
# Calculate the angular separation between the two coordinate sources
separation = mast_coords.separation(ned_coords)

# Define tolerance (0.1 arcseconds)
tolerance = 0.1 * u.arcsec

print(f"MAST Coordinates (RA, Dec): {mast_coords.to_string('hmsdms')}")
print(f"NED Coordinates (RA, Dec): {ned_coords.to_string('hmsdms')}")
print(f"Angular Separation: {separation.to(u.arcsec):.3f}")

if separation <= tolerance:
    print("\nRESULT: Coordinates agree within the 0.1 arcsecond tolerance.")
else:
    print("\nRESULT: Coordinates show a significant discrepancy (greater than 0.1 arcseconds).")

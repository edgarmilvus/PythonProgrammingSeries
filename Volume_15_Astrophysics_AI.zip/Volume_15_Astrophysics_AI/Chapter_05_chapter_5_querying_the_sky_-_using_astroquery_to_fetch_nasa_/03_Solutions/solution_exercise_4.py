
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from astropy.table import Table
import numpy as np
import os
from astropy.io import fits # Required for FITS serialization

# Simulation of Kepler data table
data = [
    (1001, 5500, 1.0, 'G2V'),
    (1002, 2800, 0.05, 'M0V'),  # Invalid radius (too small)
    (1003, 9999, 1.5, 'F0V'),  # Invalid temperature (placeholder)
    (1004, 6000, 150.0, 'K0III'), # Invalid radius (too large placeholder)
    (1005, 4500, 0.8, 'K5V')
]
t = Table(rows=data, names=('kepid', 'teff', 'r_star', 'sptype'))

# 1. Pythonic Cleaning (Boolean Masking)
# Define the mask for physically plausible stellar radii (0.1 to 100 solar radii)
radius_mask = (t['r_star'] >= 0.1) & (t['r_star'] <= 100.0)

# Apply the mask to create the cleaned table
t_cleaned = t[radius_mask]

print(f"Initial rows: {len(t)}. Rows after radius cleaning: {len(t_cleaned)}.")

# 2. Flag Generation (Vectorized Boolean Logic)
# Define the mask for valid effective temperature (3000 K to 10000 K)
temp_mask = (t_cleaned['teff'] >= 3000) & (t_cleaned['teff'] <= 10000)

# Create the new Boolean column directly from the mask
t_cleaned['is_valid_temperature'] = temp_mask

print("\nCleaned Table with Validation Flag:")
print(t_cleaned['kepid', 'r_star', 'teff', 'is_valid_temperature'])

# 3. Serialization Readiness (Write to FITS)
output_filename = 'cleaned_kepler_data.fits'
t_cleaned.write(output_filename, format='fits', overwrite=True)

print(f"\nSuccessfully wrote cleaned data to {output_filename}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from astropy.coordinates import SkyCoord
from astropy import units as u
from astroquery.mast import Observations
import numpy as np

# 1. Coordinate Initialization
transient_ra = '09h 55m 52.2s'
transient_dec = '+69d 40m 47.1s'

# Initialize SkyCoord explicitly defining the frame and units
target_coords = SkyCoord(transient_ra, transient_dec, frame='icrs')

# Define search radius
search_radius = 30 * u.arcsec

print(f"Searching MAST around {target_coords.to_string('hmsdms')} with radius {search_radius}")

# 2. Region Query
# Use the query_region method for spatial search
obs_table = Observations.query_region(
    coordinates=target_coords,
    radius=search_radius
)

if obs_table is None or len(obs_table) == 0:
    print("No observations found in the specified region.")
else:
    initial_count = len(obs_table)

    # 3. Instrument Filtering (Boolean Masking)
    # Filter for WFC3 observations
    wfc3_mask = (obs_table['instrument_name'] == 'WFC3')
    wfc3_obs = obs_table[wfc3_mask]

    print(f"\nTotal observations found: {initial_count}")
    print(f"Observations remaining after WFC3 filter: {len(wfc3_obs)}")

    # 4. Handling Missing Data (Exposure Time Validation)
    # Filter out rows where exposure time is zero or null (using > 0 check)
    # Astropy Table comparisons handle masked (null) values gracefully.
    valid_exposure_mask = (wfc3_obs['t_exptime'] > 0.0)
    
    # Apply the final mask
    final_obs_table = wfc3_obs[valid_exposure_mask]
    
    final_count = len(final_obs_table)

    print(f"Observations remaining after filtering t_exptime > 0: {final_count}")
    print("\nFirst 5 Usable WFC3 Observations:")
    print(final_obs_table['obsid', 'instrument_name', 't_exptime'][:5])

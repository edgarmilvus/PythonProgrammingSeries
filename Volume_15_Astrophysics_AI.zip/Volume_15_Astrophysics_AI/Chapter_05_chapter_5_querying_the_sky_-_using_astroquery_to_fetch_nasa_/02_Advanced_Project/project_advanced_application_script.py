
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import sys
from astropy.coordinates import SkyCoord
from astropy import units as u
from astropy.table import Table
# Import specific astroquery modules
from astroquery.simbad import Simbad
from astroquery.mast import Observations

# --- Configuration and Constants ---
TARGET_NAME = "M 101"
SEARCH_RADIUS = 5.0 * u.arcmin  # 5 arcminutes search radius defines the search box
TARGET_INSTRUMENTS = ['ACS', 'WFC3', 'STIS'] # Instruments of interest for HST
MIN_EXPOSURE_TIME = 1.0 * u.s # Filter out very short calibration exposures

def resolve_coordinates(target_name: str) -> SkyCoord:
    """Uses Simbad to resolve the target name into precise Astropy SkyCoord."""
    print(f"--- 1. Resolving coordinates for {target_name} via Simbad...")
    try:
        # Configure Simbad to return coordinates in decimal degrees (d)
        Simbad.add_votable_fields('ra(d)', 'dec(d)')
        result_table = Simbad.query_object(target_name)
        
        if result_table is None or len(result_table) == 0:
            raise ValueError(f"Simbad could not find coordinates for {target_name}.")
        
        # Extract RA and Dec from the first result row
        ra_deg = result_table['RA_d'][0]
        dec_deg = result_table['DEC_d'][0]
        
        # Create an Astropy SkyCoord object, essential for MAST query
        coords = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg, frame='icrs')
        print(f"   -> Found coordinates: {coords.ra.deg:.4f} RA, {coords.dec.deg:.4f} Dec")
        return coords
        
    except Exception as e:
        print(f"Error during coordinate resolution: {e}")
        sys.exit(1)

def query_mast_archive(coords: SkyCoord, radius: u.Quantity) -> Table:
    """Queries the MAST archive for observations within the specified region."""
    print(f"\n--- 2. Querying MAST for observations within {radius}...")
    # Observations.query_region uses the SkyCoord object and radius unit quantity
    obs_table = Observations.query_region(coordinates=coords, radius=radius)
    print(f"   -> Found {len(obs_table)} total observations in the region.")
    return obs_table

def analyze_and_filter_observations(obs_table: Table) -> (Table, Table):
    """Filters the table based on mission/instrument and aggregates exposure times."""
    print("\n--- 3. Filtering and Analysis Pipeline ---")
    
    # CRITICAL FILTER 1: Ensure the observation belongs to the HST project
    # We also check for non-NULL obsid, which often indicates a valid science product
    hst_filter = (obs_table['obsid'] != 'NULL') & (obs_table['project'] == 'HST')
    filtered_hst = obs_table[hst_filter]
    print(f"   -> Retained {len(filtered_hst)} HST observations.")

    # CRITICAL FILTER 2: Filter by specific instruments (ACS, WFC3, STIS)
    # This uses a list comprehension combined with boolean indexing
    inst_filter = [i in TARGET_INSTRUMENTS for i in filtered_hst['instrument_name']]
    filtered_inst = filtered_hst[inst_filter]
    print(f"   -> Retained {len(filtered_inst)} observations matching instruments: {TARGET_INSTRUMENTS}.")

    # CRITICAL FILTER 3: Filter by minimum exposure time
    # First, handle cases where 'exposure_time' might be masked or missing (common in archival data)
    exposure_mask = (filtered_inst['exposure_time'].mask == False)
    filtered_exp = filtered_inst[exposure_mask]
    
    # Apply minimum time filter (MAST exposure_time is typically in seconds)
    time_filter = filtered_exp['exposure_time'] >= MIN_EXPOSURE_TIME.to_value(u.s)
    final_table = filtered_exp[time_filter]
    print(f"   -> Final filtered count: {len(final_table)} observations.")

    # --- Aggregation Step (Astropy Table Grouping) ---
    print("\n--- 4. Calculating Total Integration Time per Instrument ---")
    
    # Group the final table based on the 'instrument_name' column
    grouped_data = final_table.group_by('instrument_name')
    
    # Use the aggregate method to sum the 'exposure_time' for all rows within each group
    summary_table = grouped_data.groups.aggregate(sum)
    
    # Clean up and format the summary table for output
    summary_table = summary_table[['instrument_name', 'exposure_time']]
    summary_table.rename_column('exposure_time', 'Total_Exposure_s')
    
    # Explicitly re-attach the unit for display purposes
    summary_table['Total_Exposure_s'] = summary_table['Total_Exposure_s'] * u.s
    
    return final_table, summary_table

# --- Main Execution Flow ---
if __name__ == "__main__":
    try:
        # 1. Resolve Target Coordinates
        target_coords = resolve_coordinates(TARGET_NAME)
        
        # 2. Fetch Observations from MAST
        raw_observations = query_mast_archive(target_coords, SEARCH_RADIUS)
        
        if len(raw_observations) == 0:
            print("No observations found in the specified region. Exiting.")
            sys.exit(0)
            
        # 3. Process, Filter, and Aggregate Data
        final_obs_table, exposure_summary = analyze_and_filter_observations(raw_observations)
        
        # 4. Final Output Reporting
        print("\n" + "="*70)
        print(f"ARCHIVE ANALYSIS COMPLETE for {TARGET_NAME}")
        print("="*70)
        
        print("\n[SUMMARY OF TOTAL INTEGRATION TIME]")
        # Set the print format for the time column and use pprint for clean terminal output
        exposure_summary['Total_Exposure_s'].info.format = '%.1f'
        exposure_summary.pprint(show_unit=True)
        
        print("\n[SAMPLE OF FILTERED OBSERVATIONS (Top 5)]")
        # Display a subset of columns from the final table
        final_obs_table['obsid', 'instrument_name', 't_min', 't_max', 'exposure_time'][:5].pprint(max_width=-1)

    except Exception as e:
        # Catch any unexpected runtime errors, particularly network issues
        print(f"\n[FATAL ERROR] An unexpected error occurred in the main pipeline: {e}")
        sys.exit(1)

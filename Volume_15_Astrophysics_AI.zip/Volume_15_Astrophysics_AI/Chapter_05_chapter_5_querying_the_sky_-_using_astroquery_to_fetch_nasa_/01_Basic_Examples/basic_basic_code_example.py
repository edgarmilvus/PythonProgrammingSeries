
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import astropy.units as u
from astropy.coordinates import SkyCoord
from astroquery.ned import Ned
from astroquery.mast import Mast
import sys 

# --- PART 1: Coordinate Resolution using NED ---

# 1. Define the target object name. M31 is the Andromeda Galaxy.
TARGET_NAME = "M31"

print(f"--- 1. Resolving Coordinates for {TARGET_NAME} using NED ---")

# 2. Use the NED service to retrieve basic object information.
# The result is returned as an Astropy Table object.
try:
    # We use query_object() which is optimized for single-name lookups.
    ned_result_table = Ned.query_object(TARGET_NAME)
except Exception as e:
    # Handle potential network or API errors gracefully.
    print(f"Error querying NED for {TARGET_NAME}: {e}")
    sys.exit(1) # Exit the script upon failure

# 3. Extract the Right Ascension (RA) and Declination (Dec) from the table.
# NED provides these in decimal degrees. We access the first (and usually only) row [0].
try:
    ra_deg = ned_result_table['RA(deg)'][0]
    dec_deg = ned_result_table['DEC(deg)'][0]
except IndexError:
    print(f"Error: NED returned an empty result for {TARGET_NAME}.")
    sys.exit(1)

# 4. Create a standardized Astropy SkyCoord object.
# This object combines the coordinates with necessary metadata (units and frame).
target_coord = SkyCoord(
    ra=ra_deg * u.degree, 
    dec=dec_deg * u.degree, 
    frame='icrs' # ICRS is the standard celestial reference system
)

print(f"Resolved Coordinates (ICRS): RA={target_coord.ra.deg:.4f} deg, Dec={target_coord.dec.deg:.4f} deg")

# --- PART 2: Querying the MAST Archive using Coordinates ---

# 5. Define the search radius. M31 is large, so we use a generous radius.
search_radius = 0.5 * u.degree # Half a degree radius

print(f"\n--- 2. Querying MAST for HST Observations within {search_radius} of M31 ---")

# 6. Use the Mast service to search for observations based on criteria.
# We pass the SkyCoord object and the radius object directly.
mast_observations = Mast.query_criteria(
    coordinates=target_coord,
    radius=search_radius,
    obs_collection="HST" # Filter specifically for Hubble Space Telescope data
)

# 7. Print the summary results.
if mast_observations is not None and len(mast_observations) > 0:
    print(f"\nSuccessfully found {len(mast_observations)} total HST observations.")
    print("\nMetadata Summary (First 5 entries):")
    # Display relevant columns for quick inspection
    summary_data = mast_observations[['obsid', 'instrument_name', 't_exptime', 'filters']][:5]
    print(summary_data)
else:
    print("\nNo HST observations found in the specified radius or query failed.")

print("\nQuery process complete.")

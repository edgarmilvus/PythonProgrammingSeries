
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
import numpy as np
import os

# --- Configuration Constants ---
# Define constants for the expected input image size
# Standard practice is to use small sizes (e.g., 64x64) for rapid experimentation.
IMG_WIDTH = 64
IMG_HEIGHT = 64
CHANNELS = 3  # 3 channels for color images (Red, Green, Blue)
INPUT_SHAPE = (IMG_HEIGHT, IMG_WIDTH, CHANNELS)

# For binary classification (Spiral vs. Elliptical), the output dimension is 1.
NUM_CLASSES = 1 

# --- 1. Model Definition Function ---
def create_minimal_cnn(input_shape):
    """
    Defines a basic Sequential CNN architecture for feature extraction 
    and binary classification.
    """
    # The Sequential API stacks layers linearly.
    model = Sequential([
        # First Convolutional Block: Feature Learning
        # 32 filters (feature detectors), 3x3 kernel size, ReLU activation.
        # input_shape is required only for the very first layer.
        Conv2D(32, (3, 3), activation='relu', input_shape=input_shape, name='conv_1_features'),
        
        # Max Pooling: Downsampling the feature map by half (2x2 window).
        # This reduces computation and enforces translation invariance.
        MaxPooling2D((2, 2), name='pool_1_downsample'),

        # Second Convolutional Block: Deeper Feature Learning
        # Increases the number of filters to capture more complex patterns.
        Conv2D(64, (3, 3), activation='relu', name='conv_2_features'),
        MaxPooling2D((2, 2), name='pool_2_downsample'),

        # --- Transition to Classification Head ---
        
        # Flatten: Converts the 3D feature map (Height x Width x Channels) 
        # into a 1D vector, preparing data for the fully connected layers.
        Flatten(name='flatten_vector'), 

        # Dense Layer 1: High-level combination of learned features
        Dense(128, activation='relu', name='dense_hidden'),

        # Output Layer: Classification Decision
        # 1 unit for the binary probability score.
        # Sigmoid activation ensures the output is constrained between 0 and 1.
        Dense(NUM_CLASSES, activation='sigmoid', name='output_probability') 
    ])
    return model

# --- 2. Instantiation and Review ---
# Instantiate the model with the defined input dimensions.
galaxy_classifier = create_minimal_cnn(INPUT_SHAPE)

print("--- Minimal CNN Architecture for Galaxy Classification ---")
# Display the detailed architecture, layer names, and output shapes.
galaxy_classifier.summary()

# --- 3. Compilation (Defining the Learning Strategy) ---
# Compilation prepares the model for training by setting the optimizer, loss, and metrics.
galaxy_classifier.compile(
    optimizer='adam',
    # Binary Cross-Entropy is the standard loss function for two-class probability output.
    loss='binary_crossentropy', 
    metrics=['accuracy']
)

# --- 4. Simulated Prediction (Verification of Data Flow) ---
# To predict, the model requires input in the format: (Batch Size, H, W, C).
# We create a dummy batch containing 1 random image (1, 64, 64, 3).
BATCH_SIZE = 1
dummy_input = np.random.rand(BATCH_SIZE, IMG_HEIGHT, IMG_WIDTH, CHANNELS).astype('float32')

print("\n--- Simulating Prediction with Dummy Data ---")
# The model processes the input through the layers.
prediction = galaxy_classifier.predict(dummy_input, verbose=0)

# The output is a matrix of shape (Batch Size, NUM_CLASSES)
print(f"Input Shape provided to model: {dummy_input.shape}")
print(f"Output Shape received from model: {prediction.shape}")
print(f"Raw Output Probability Score: {prediction[0][0]:.4f}")

# Interpretation: Applying a standard threshold (0.5) to the probability
THRESHOLD = 0.5
if prediction[0][0] >= THRESHOLD:
    print("Interpretation: Predicted Class 1 (Likely Spiral Galaxy)")
else:
    print("Interpretation: Predicted Class 0 (Likely Elliptical Galaxy)")

# --- 5. Demonstrating Accessing Environment Variables (for configuration) ---
# Although not strictly necessary for this minimal example, 
# this demonstrates how configuration might be loaded in a real application.
try:
    # Access a hypothetical environment variable defining the model version
    model_version = os.environ.get('GALAXY_MODEL_VERSION', 'v1.0-default')
    print(f"\nConfiguration Check: Loaded Model Version from ENV: {model_version}")
except Exception as e:
    print(f"Error accessing environment variables: {e}")

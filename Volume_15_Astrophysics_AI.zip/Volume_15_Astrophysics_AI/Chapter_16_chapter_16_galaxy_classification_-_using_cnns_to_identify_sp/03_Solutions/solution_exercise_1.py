
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import tensorflow as tf
import os

# --- Configuration ---
IMG_SIZE = (128, 128)
BATCH_SIZE = 32
SEED = 42

# Placeholder directories (assumes standard structure: data/train/Spiral, data/train/Elliptical)
TRAIN_DIR = 'data/train' 
VAL_DIR = 'data/val'

# 1. Define the Augmentation Pipeline (Applied ONLY to Training Data)
data_augmentation = tf.keras.Sequential([
    # Random Rotation (up to +/- 20 degrees, factor=0.055 approx)
    tf.keras.layers.RandomRotation(factor=0.055, seed=SEED), 
    
    # Random Horizontal and Vertical Flipping
    tf.keras.layers.RandomFlip("horizontal_and_vertical", seed=SEED),
    
    # Random Zoom (up to 10%)
    tf.keras.layers.RandomZoom(height_factor=0.1, width_factor=0.1, seed=SEED),
], name="data_augmentation")


# 2. Define the Preprocessing Function (Normalization)
def preprocess(image, label):
    """Scales pixel values from [0, 255] to [0.0, 1.0]."""
    image = tf.cast(image, tf.float32) / 255.0
    return image, label

# 3. Data Loader Implementation and Pipeline Construction
def create_pipeline(data_dir, is_training=True):
    # Load dataset from directory structure
    dataset = tf.keras.utils.image_dataset_from_directory(
        data_dir,
        labels='inferred',
        label_mode='binary', 
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        shuffle=is_training,
        seed=SEED
    )
    
    # Apply Normalization
    dataset = dataset.map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)

    if is_training:
        # Apply Real-Time Augmentation ONLY to the training set
        dataset = dataset.map(lambda x, y: (data_augmentation(x, training=True), y),
                              num_parallel_calls=tf.data.AUTOTUNE)
    
    # 4. Performance Optimization: Caching and Prefetching
    dataset = dataset.cache()
    dataset = dataset.prefetch(buffer_size=tf.data.AUTOTUNE)
    
    return dataset

# Example usage (assuming TRAIN_DIR and VAL_DIR exist with images):
# train_ds = create_pipeline(TRAIN_DIR, is_training=True)
# val_ds = create_pipeline(VAL_DIR, is_training=False)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import tensorflow as tf
from tensorflow.keras import layers, models

# Configuration
INPUT_SHAPE = (128, 128, 3) 

# 1. Define the Reusable ConvBlock Function
def ConvBlock(x, filters, name):
    """
    Defines a single modular Convolutional Block: 
    Conv -> BatchNorm -> ReLU -> MaxPool.
    """
    x = layers.Conv2D(filters, (3, 3), padding='same', name=f'{name}_conv')(x)
    x = layers.BatchNormalization(name=f'{name}_bn')(x)
    x = layers.ReLU(name=f'{name}_relu')(x)
    # MaxPool reduces spatial dimensions by half (e.g., 128 -> 64)
    x = layers.MaxPool2D((2, 2), strides=(2, 2), name=f'{name}_pool')(x) 
    return x

# 2. Architecture Specification and Model Construction
def GalaxyMorphologyClassifier(input_shape):
    inputs = tf.keras.Input(shape=input_shape, name="input_image")
    
    # Initial size: 128x128x3
    
    # ConvBlock 1: 32 filters (Output: 64x64x32)
    x = ConvBlock(inputs, 32, name='block1')
    
    # ConvBlock 2: 64 filters (Output: 32x32x64)
    x = ConvBlock(x, 64, name='block2')
    
    # ConvBlock 3: 128 filters (Output: 16x16x128)
    x = ConvBlock(x, 128, name='block3')
    
    # Classification Head
    x = layers.Flatten(name='flatten')(x)
    
    # Dense Layer 1: 64 units
    x = layers.Dense(64, activation='relu', name='dense_hidden')(x)
    
    # Output Layer: Single unit with Sigmoid for binary classification
    outputs = layers.Dense(1, activation='sigmoid', name='output_classification')(x)
    
    model = models.Model(inputs=inputs, outputs=outputs, name='GalaxyMorphologyClassifier')
    return model

# 3. Model Compilation and Summary
model = GalaxyMorphologyClassifier(INPUT_SHAPE)

model.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)

print("--- Model Summary ---")
model.summary()

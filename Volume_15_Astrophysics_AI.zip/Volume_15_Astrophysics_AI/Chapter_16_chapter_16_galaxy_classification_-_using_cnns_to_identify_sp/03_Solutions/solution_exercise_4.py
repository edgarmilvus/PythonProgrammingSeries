
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# --- Simulation of Evaluation Results ---
NUM_TEST_SAMPLES = 500
THRESHOLD = 0.5
class_names = ['Elliptical (0)', 'Spiral (1)']

# Simulate True Labels (y_true) and Imperfect Predictions (y_pred_labels)
y_true = np.concatenate([np.ones(NUM_TEST_SAMPLES//2), np.zeros(NUM_TEST_SAMPLES//2)])
np.random.shuffle(y_true)

# Simulate predictions with an 88% overall accuracy
error_rate = 0.12
y_pred_labels = np.where(np.random.rand(NUM_TEST_SAMPLES) < error_rate, 
                         1 - y_true, # Flip the label for errors
                         y_true)     # Keep the label for correct predictions

# 1. Metric Calculation
print("--- Classification Report ---")
print(classification_report(y_true, y_pred_labels, target_names=class_names))

# 2. Confusion Matrix Generation
cm = confusion_matrix(y_true, y_pred_labels)

plt.figure(figsize=(6, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False,
            xticklabels=class_names, yticklabels=class_names)
plt.title('Confusion Matrix')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.show()

# 3. Misclassification Analysis Setup (Identifying FN and FP indices)
# FN: True Spiral (1), Predicted Elliptical (0)
fn_indices = np.where((y_true == 1) & (y_pred_labels == 0))[0]
# FP: True Elliptical (0), Predicted Spiral (1)
fp_indices = np.where((y_true == 0) & (y_pred_labels == 1))[0]

print(f"\nTotal False Negatives (FN): {len(fn_indices)}")
print(f"Total False Positives (FP): {len(fp_indices)}")

# --- Misclassification Analysis (Astronomical Interpretation) ---

# False Negatives (Spirals mistaken for Ellipticals):
# 1. Edge-on Inclination: Spiral galaxies viewed edge-on lose their distinct arm structure and appear as smooth, elongated disks, which are morphologically indistinguishable from certain ellipticals or lenticulars (S0).
# 2. Low Surface Brightness (LSB): Spirals with very faint arms or low contrast. The CNN's feature detectors fail to pick up the subtle, low-frequency spiral structure, leading to a default classification of 'smooth' (Elliptical).
# 3. Early-Type Spirals (Sa/Sb): These often have large central bulges and tightly wound, indistinct arms, making them morphologically closer to ellipticals than late-type, grand-design spirals.

# False Positives (Ellipticals mistaken for Spirals):
# 1. Tidal Features/Mergers: A true elliptical undergoing a minor merger or exhibiting faint tidal tails (remnants of past mergers) can introduce asymmetric structure that the CNN misinterprets as nascent spiral arms or disk features.
# 2. Image Artifacts/Noise: High noise levels, especially in deep field images, or the presence of bright foreground stars (with diffraction spikes) can create spurious patterns that the CNN confuses with spiral structure.
# 3. Boxy/Disky Ellipticals: Specific subclassifications of ellipticals that possess faint internal structure or dust lanes. While technically smooth, these features introduce enough complexity to trigger the model's 'structure' detectors.

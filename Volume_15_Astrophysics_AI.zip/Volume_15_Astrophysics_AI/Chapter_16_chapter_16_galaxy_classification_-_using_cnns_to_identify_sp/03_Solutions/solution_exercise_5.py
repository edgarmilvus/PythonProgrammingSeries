
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import tensorflow as tf
from tensorflow.keras.applications import VGG16
from tensorflow.keras import layers, models
import numpy as np

# Configuration
INPUT_SHAPE = (128, 128, 3) 
BATCH_SIZE = 32
NUM_EPOCHS = 5 
LEARNING_RATE = 1e-4 # Low LR for training only the head

# --- Simulation of Data Load ---
# Using dummy data for demonstration, replace with actual data pipeline (Ex 1)
dummy_data = np.random.rand(BATCH_SIZE * 10, *INPUT_SHAPE).astype(np.float32)
dummy_labels = np.random.randint(0, 2, BATCH_SIZE * 10)
train_ds_sim = tf.data.Dataset.from_tensor_slices((dummy_data, dummy_labels)).batch(BATCH_SIZE)
val_ds_sim = tf.data.Dataset.from_tensor_slices((dummy_data[:BATCH_SIZE*2], dummy_labels[:BATCH_SIZE*2])).batch(BATCH_SIZE)


# 1. Base Model Selection and 2. Weight Freezing
def build_transfer_model(input_shape):
    # Load VGG16 pre-trained on ImageNet, excluding the top classifier
    base_model = VGG16(weights='imagenet', 
                       include_top=False, 
                       input_shape=input_shape)
    
    # Freeze the convolutional base
    base_model.trainable = False
    
    # 3. Custom Classification Head
    model = models.Sequential([
        base_model, # VGG16 feature extractor
        
        # Global Average Pooling: Reduces 4D output (e.g., 4x4x512) to 2D (2048)
        layers.GlobalAveragePooling2D(name='global_avg_pool'),
        
        # Dropout for regularization
        layers.Dropout(0.3, name='dropout_head'),
        
        # Intermediate Dense layer
        layers.Dense(64, activation='relu', name='dense_head'),
        
        # Final output layer (Binary Classification)
        layers.Dense(1, activation='sigmoid', name='output_head')
    ], name="VGG16_Transfer_Classifier")
    
    return model

transfer_model = build_transfer_model(INPUT_SHAPE)

# 4. Rapid Training (Compilation and Fit)
transfer_model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

print(f"Total trainable parameters: {len(transfer_model.trainable_weights)}")

history = transfer_model.fit(
    train_ds_sim,
    epochs=NUM_EPOCHS,
    validation_data=val_ds_sim,
    verbose=2
)

final_val_accuracy = history.history['val_accuracy'][-1]
print(f"\nValidation Accuracy after {NUM_EPOCHS} epochs: {final_val_accuracy:.4f}")

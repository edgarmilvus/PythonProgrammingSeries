
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import tensorflow as tf
from tensorflow.keras import layers, models, regularizers

# Configuration for Regularization and Scheduling
INPUT_SHAPE = (128, 128, 3) 
L2_REG_STRENGTH = 1e-4 
STEPS_PER_EPOCH = 100 # Placeholder based on dataset size
TOTAL_EPOCHS = 30

# 1. Define the Modified ConvBlock Function (L2 Regularization)
def RegularizedConvBlock(x, filters, name, apply_l2=False):
    """ConvBlock with optional L2 regularization."""
    kernel_reg = regularizers.l2(L2_REG_STRENGTH) if apply_l2 else None
    
    x = layers.Conv2D(filters, (3, 3), padding='same', 
                      kernel_regularizer=kernel_reg, # L2 applied here
                      name=f'{name}_conv')(x)
    x = layers.BatchNormalization(name=f'{name}_bn')(x)
    x = layers.ReLU(name=f'{name}_relu')(x)
    x = layers.MaxPool2D((2, 2), strides=(2, 2), name=f'{name}_pool')(x)
    return x

# 2. Modified Architecture with Dropout and L2
def RegularizedGalaxyClassifier(input_shape):
    inputs = tf.keras.Input(shape=input_shape, name="input_image")
    
    # Block 1 (No L2)
    x = RegularizedConvBlock(inputs, 32, name='block1', apply_l2=False)
    
    # Block 2 (L2 applied)
    x = RegularizedConvBlock(x, 64, name='block2', apply_l2=True)
    
    # Block 3 (L2 applied)
    x = RegularizedConvBlock(x, 128, name='block3', apply_l2=True)
    
    # Classification Head
    x = layers.Flatten(name='flatten')(x)
    
    # Strategic Dropout 1 (p=0.25)
    x = layers.Dropout(0.25, name='dropout_1')(x)
    
    # Dense Layer 1 (L2 applied)
    x = layers.Dense(64, activation='relu', 
                     kernel_regularizer=regularizers.l2(L2_REG_STRENGTH), # L2 applied here
                     name='dense_hidden')(x)
    
    # Strategic Dropout 2 (p=0.5)
    x = layers.Dropout(0.5, name='dropout_2')(x)
    
    # Output Layer
    outputs = layers.Dense(1, activation='sigmoid', name='output_classification')(x)
    
    model = models.Model(inputs=inputs, outputs=outputs, name='Regularized_Classifier')
    return model

# 3. Learning Rate Scheduling Implementation
initial_learning_rate = 0.001
decay_rate = 0.9 

lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    initial_learning_rate,
    decay_steps=STEPS_PER_EPOCH, # Decay occurs after every epoch
    decay_rate=decay_rate,
    staircase=True)

# 4. Model Compilation with Scheduler
model_reg = RegularizedGalaxyClassifier(INPUT_SHAPE)
optimizer = tf.keras.optimizers.Adam(learning_rate=lr_schedule)

model_reg.compile(
    optimizer=optimizer,
    loss='binary_crossentropy',
    metrics=['accuracy']
)

print("--- Regularized Model Compiled ---")

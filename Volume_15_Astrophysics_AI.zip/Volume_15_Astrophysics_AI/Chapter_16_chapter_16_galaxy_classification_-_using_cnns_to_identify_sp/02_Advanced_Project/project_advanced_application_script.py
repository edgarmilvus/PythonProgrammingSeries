
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import pathlib
import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
import matplotlib.pyplot as plt

# --- 1. Configuration and Environment Setup (Pythonic Use of Environment Variables) ---

# Suppress TensorFlow logging and warnings for cleaner output
# This is a common practice in production environments to manage verbosity.
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# Define core hyperparameters
IMAGE_SIZE = (128, 128)  # Standardized size for input images
BATCH_SIZE = 64          # Number of samples per gradient update
EPOCHS = 15              # Number of full passes over the training data
SEED = 42                # Seed for reproducibility
VALIDATION_SPLIT = 0.2   # Percentage of training data to use for validation
CLASS_NAMES = ['Elliptical', 'Spiral']
NUM_CLASSES = len(CLASS_NAMES)

# Define the root directory for data (using pathlib for robust path handling)
DATA_ROOT = pathlib.Path("./galaxy_classification_data")

# --- 2. Data Simulation and Directory Structure Setup ---
# In a real scenario, this data would already exist. Since we cannot include 
# the actual image dataset, we create a mock structure to ensure the script 
# is logically runnable and demonstrates the necessary data preparation steps.

def setup_mock_data_structure(root_dir: pathlib.Path):
    """Creates a mock directory structure mimicking a real image dataset."""
    print(f"Setting up mock data structure at: {root_dir}")

    # Define the required subdirectories
    subdirs = [
        root_dir / 'train' / 'Elliptical',
        root_dir / 'train' / 'Spiral',
        root_dir / 'test' / 'Elliptical',
        root_dir / 'test' / 'Spiral',
    ]

    for d in subdirs:
        d.mkdir(parents=True, exist_ok=True)
    
    # Simulate the existence of dummy files (required by image_dataset_from_directory)
    # We use simple text files as placeholders, though TensorFlow expects images.
    # For actual execution, these must be replaced by real .jpg or .png files.
    for i in range(5): # Create 5 dummy files in each folder
        (subdirs[0] / f'e_img_{i}.txt').touch()
        (subdirs[1] / f's_img_{i}.txt').touch()

    print("Mock data structure created. (NOTE: Real images required for actual training.)")


# --- 3. Data Loading and Preprocessing Pipeline ---

def load_and_prepare_data(data_root: pathlib.Path):
    """
    Loads image data from directories using tf.keras.utils.
    Automatically handles splitting and initial resizing.
    """
    print("\nLoading data...")
    
    # 3.1. Training and Validation Data
    # We use a validation split directly during loading
    train_ds = tf.keras.utils.image_dataset_from_directory(
        data_root / 'train',
        labels='inferred',
        label_mode='binary',  # For binary classification (0 or 1)
        image_size=IMAGE_SIZE,
        interpolation='bilinear',
        batch_size=BATCH_SIZE,
        seed=SEED,
        validation_split=VALIDATION_SPLIT,
        subset='training',
    )

    val_ds = tf.keras.utils.image_dataset_from_directory(
        data_root / 'train',
        labels='inferred',
        label_mode='binary',
        image_size=IMAGE_SIZE,
        interpolation='bilinear',
        batch_size=BATCH_SIZE,
        seed=SEED,
        validation_split=VALIDATION_SPLIT,
        subset='validation',
    )
    
    # 3.2. Test Data (for final, unbiased evaluation)
    test_ds = tf.keras.utils.image_dataset_from_directory(
        data_root / 'test',
        labels='inferred',
        label_mode='binary',
        image_size=IMAGE_SIZE,
        interpolation='bilinear',
        batch_size=BATCH_SIZE,
        seed=SEED,
        shuffle=False, # Important for consistent evaluation
    )

    # 3.3. Optimization (Pythonic use of dataset methods)
    # Prefetching and caching improve I/O performance by overlapping data 
    # preprocessing and model execution.
    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)
    test_ds = test_ds.cache().prefetch(buffer_size=AUTOTUNE)
    
    print(f"Dataset loaded. Classes: {train_ds.class_names}")
    return train_ds, val_ds, test_ds


# --- 4. Model Definition: The Custom CNN Architecture ---

def build_galaxy_cnn(input_shape: tuple) -> models.Model:
    """
    Defines a custom Convolutional Neural Network (CNN) architecture 
    optimized for morphological feature extraction.
    """
    print("\nBuilding CNN model...")
    
    model = models.Sequential([
        # 4.1. Input Layer: Rescaling pixel values from [0, 255] to [0, 1]
        layers.Rescaling(1./255, input_shape=input_shape),

        # 4.2. Feature Extraction Block 1
        layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        layers.MaxPooling2D(pool_size=(2, 2)),
        
        # 4.3. Feature Extraction Block 2
        layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        layers.MaxPooling2D(pool_size=(2, 2)),

        # 4.4. Feature Extraction Block 3 (Deeper layers capture complex features)
        layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
        layers.MaxPooling2D(pool_size=(2, 2)),

        # 4.5. Transition to Dense Layers
        layers.Flatten(),
        
        # 4.6. Dense Classification Head
        layers.Dense(256, activation='relu'),
        layers.Dropout(0.5), # Regularization to prevent overfitting
        
        # 4.7. Output Layer (Sigmoid for binary classification)
        # Since label_mode='binary' was used, the output must be a single unit with sigmoid.
        layers.Dense(1, activation='sigmoid') 
    ])

    # Compile the model
    model.compile(
        optimizer=optimizers.Adam(learning_rate=0.001),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.Precision(), tf.keras.metrics.Recall()]
    )
    
    model.summary()
    return model


# --- 5. Training and Evaluation Pipeline ---

def plot_training_history(history):
    """Visualizes the model's performance metrics over epochs."""
    
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    epochs_range = range(EPOCHS)

    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 2, 1)
    plt.plot(epochs_range, acc, label='Training Accuracy')
    plt.plot(epochs_range, val_acc, label='Validation Accuracy')
    plt.legend(loc='lower right')
    plt.title('Training and Validation Accuracy')

    plt.subplot(1, 2, 2)
    plt.plot(epochs_range, loss, label='Training Loss')
    plt.plot(epochs_range, val_loss, label='Validation Loss')
    plt.legend(loc='upper right')
    plt.title('Training and Validation Loss')
    
    plt.show()


def main():
    """Main execution function for the galaxy classification pipeline."""
    
    # 1. Setup Data Environment
    if not DATA_ROOT.exists():
        setup_mock_data_structure(DATA_ROOT)
        print("\n*** WARNING ***: Mock data structure created. Replace placeholder files with real images to run training.")
        # Exit gracefully if the user has not replaced the dummy files
        # In a real book environment, we would provide a small sample dataset.
        # Here, we assume the reader understands the need for actual images.

    # 2. Load Data
    try:
        train_ds, val_ds, test_ds = load_and_prepare_data(DATA_ROOT)
    except Exception as e:
        print(f"\nERROR during data loading. Ensure {DATA_ROOT} contains valid images.")
        print(f"Details: {e}")
        # We must exit here if the data loading fails, as the model cannot train.
        sys.exit(1)


    # 3. Define and Build Model
    input_shape = IMAGE_SIZE + (3,) # (128, 128, 3) for RGB images
    model = build_galaxy_cnn(input_shape)

    # 4. Train Model
    print("\nStarting model training...")
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=EPOCHS
    )

    # 5. Evaluate Model on Test Set
    print("\nEvaluating model on the test set...")
    # Note: The test set evaluation may fail if the mock data does not contain 
    # enough unique batches, but the structure remains correct.
    test_results = model.evaluate(test_ds, verbose=1)
    
    print("\n--- Final Test Metrics ---")
    print(f"Loss: {test_results[0]:.4f}")
    print(f"Accuracy: {test_results[1]:.4f}")
    print(f"Precision: {test_results[2]:.4f}")
    print(f"Recall: {test_results[3]:.4f}")
    print("--------------------------")
    
    # 6. Post-Training Analysis
    # plot_training_history(history) # Uncomment in a live environment

if __name__ == '__main__':
    main()


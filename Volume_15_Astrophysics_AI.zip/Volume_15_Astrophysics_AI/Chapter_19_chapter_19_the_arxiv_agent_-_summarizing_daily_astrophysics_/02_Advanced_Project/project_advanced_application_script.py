
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

# --- External Library Imports ---
# We use the official ArXiv API client
import arxiv

# We use Pydantic for defining the structured output schema
from pydantic import BaseModel, Field, ValidationError

# --- Configuration and Mocking ---
# NOTE: In a real environment, replace this mock function with an actual call
# to the OpenAI, Anthropic, or equivalent LLM API that supports structured JSON output.

def call_llm_with_structured_output(
    system_prompt: str,
    user_prompt: str,
    output_schema: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """
    Mocks an LLM API call that enforces structured JSON output based on a schema.
    In a real implementation, this would use the OpenAI/Anthropic client
    with the 'response_format={"type": "json_object"}' parameter or equivalent.
    """
    print(f"\n[LLM MOCK] Processing Paper...")
    print(f"  System Persona: {system_prompt[:50]}...")
    print(f"  Schema enforced: {output_schema['title']}")
    
    # Simulate a successful LLM response based on the required structure
    # The LLM reads the user_prompt (containing the paper text) and fills the schema.
    try:
        mock_response_data = {
            "paper_title": user_prompt.splitlines()[0].replace("PAPER TEXT START:", "").strip(),
            "authors": ["Simulated Author 1", "Simulated Author 2"],
            "key_methodology": "A novel application of Vision Transformers (ViT) to analyze cosmic microwave background (CMB) data, utilizing transfer learning from large image datasets to improve feature extraction from noisy astrophysical images.",
            "key_results": "The ViT model achieved a 15% reduction in noise-induced classification errors compared to traditional CNNs, successfully identifying three new potential lensing anomalies in the Planck data.",
            "implications": "This work validates the use of deep learning models designed for terrestrial vision tasks in complex astrophysical data analysis, opening new avenues for automated anomaly detection in large-scale sky surveys.",
            "confidence_score": 0.95
        }
        return mock_response_data
    except Exception as e:
        print(f"LLM Mock Error: {e}")
        return None

def extract_text_from_pdf(pdf_path: str) -> str:
    """
    Mocks the complex process of downloading and extracting text from the PDF.
    In a real implementation, this would use libraries like 'pypdf' or 'pdfminer.six'.
    For demonstration, we return placeholder text that the LLM will 'summarize'.
    """
    # Simulate reading the first page of a paper
    return f"""
    PAPER TEXT START: The Impact of Vision Transformers on CMB Anomaly Detection.
    Abstract: We present a comprehensive study on applying Vision Transformers (ViT) 
    to analyze cosmological data, specifically focusing on the Cosmic Microwave Background (CMB). 
    Traditional Convolutional Neural Networks (CNNs) struggle with long-range dependencies 
    in large sky maps. Our methodology involves adapting a pre-trained ViT model 
    to process full-sky maps, treating them as sequences of patches. 
    Results show significant improvement in identifying subtle lensing effects 
    and non-Gaussian features. This suggests a powerful new toolset for future 
    cosmological surveys like Euclid and LSST.
    """

# --- Pydantic Data Model for Structured Output ---

class ArXivSummary(BaseModel):
    """
    Defines the strict structure the LLM must adhere to for the summary.
    This ensures consistency and easy parsing of the scientific findings.
    """
    paper_title: str = Field(description="The full, exact title of the research paper.")
    authors: List[str] = Field(description="List of primary authors (up to 5).")
    key_methodology: str = Field(description="A concise summary of the primary scientific method or model used (e.g., 'Bayesian analysis using MCMC', 'Vision Transformer application').")
    key_results: str = Field(description="The most important quantitative or qualitative results reported in the paper.")
    implications: str = Field(description="The broader impact of this research on the field of astrophysics or cosmology.")
    confidence_score: float = Field(description="The LLM's confidence (0.0 to 1.0) that the summary accurately reflects the paper's core findings.")

# --- The Sentinel ArXiv Agent Class ---

class ArXivResearchAgent:
    """
    An autonomous agent designed to scan ArXiv daily, download relevant papers,
    and generate structured, abstractive summaries using an LLM.
    """
    def __init__(self, category: str = "astro-ph.CO", max_papers: int = 5):
        """Initializes the agent with target parameters."""
        self.category = category
        self.max_papers = max_papers
        self.output_file = f"daily_arxiv_summary_{datetime.now().strftime('%Y%m%d')}.json"
        
        # Initialize the ArXiv client
        self.client = arxiv.Client(
            page_size=max_papers,
            delay_seconds=1.0, # Be polite to the API
            num_retries=5
        )
        
        # Define the LLM's persona and instruction set
        self.system_prompt = (
            "You are a highly specialized research assistant in theoretical astrophysics. "
            "Your task is to analyze raw scientific text and distill the content into a structured, "
            "critical summary. Do not use flowery language. Focus only on the 'what' and 'how' of the science. "
            "You MUST return the output as a valid JSON object conforming strictly to the provided schema."
        )

    def _fetch_daily_papers(self) -> List[arxiv.Result]:
        """
        Queries the ArXiv API for papers in the target category published 
        within the last 24 hours.
        """
        print(f"\n[STEP 1] Searching ArXiv for new papers in category: {self.category}...")
        
        # Calculate the date range for the last 24 hours
        yesterday = datetime.now() - timedelta(days=1)
        search_query = (
            f"cat:{self.category} AND submittedDate:[{yesterday.strftime('%Y%m%d')} TO {datetime.now().strftime('%Y%m%d')}]"
        )
        
        search = arxiv.Search(
            query=search_query,
            max_results=self.max_papers,
            sort_by=arxiv.SortCriterion.SubmittedDate,
            sort_order=arxiv.SortOrder.Descending
        )
        
        results = list(self.client.results(search))
        print(f"Found {len(results)} relevant papers.")
        return results

    def _get_paper_text(self, paper: arxiv.Result) -> Optional[str]:
        """
        Handles the download and text extraction for a single paper.
        In a production environment, this would handle file storage and cleanup.
        """
        try:
            # 1. Determine download location (temporary)
            download_dir = "./temp_arxiv_pdfs"
            os.makedirs(download_dir, exist_ok=True)
            filename = f"{paper.entry_id.split('/')[-1]}.pdf"
            filepath = os.path.join(download_dir, filename)
            
            print(f"  -> Downloading {filename}...")
            
            # 2. Download the PDF
            # NOTE: For this demonstration script, we comment out the actual download 
            # to avoid large file I/O and rely on the mock extractor.
            # paper.download_pdf(dirpath=download_dir, filename=filename) 
            
            # 3. Extract text (using mock function)
            raw_text = extract_text_from_pdf(filepath) 
            
            # 4. Cleanup (optional, but good practice)
            # os.remove(filepath) 
            # os.rmdir(download_dir) # Only if empty
            
            return raw_text
        except Exception as e:
            print(f"  [ERROR] Could not process paper {paper.title}: {e}")
            return None

    def _summarize_paper(self, paper_text: str, paper_metadata: arxiv.Result) -> Optional[Dict[str, Any]]:
        """
        Sends the extracted text to the LLM for structured summarization.
        """
        # Generate the JSON schema dynamically from the Pydantic model
        schema = ArXivSummary.model_json_schema()
        
        # Construct the detailed user prompt
        user_prompt = (
            f"Analyze the following raw text from an astrophysics preprint. "
            f"The paper's metadata is: Title='{paper_metadata.title}', Authors='{', '.join(paper_metadata.authors)}'. "
            f"The full text is provided below. Generate a summary that strictly follows the required JSON schema.\n\n"
            f"--- RAW TEXT ---\n{paper_text}"
        )
        
        # Call the LLM (using the mock function)
        raw_llm_output = call_llm_with_structured_output(
            system_prompt=self.system_prompt,
            user_prompt=user_prompt,
            output_schema=schema
        )
        
        if not raw_llm_output:
            print("  [ERROR] LLM returned no output or failed.")
            return None

        # Validate and parse the raw LLM output against the Pydantic model
        try:
            # Pydantic validates the structure and types
            validated_summary = ArXivSummary(**raw_llm_output)
            
            # Convert back to a standard dictionary for storage
            summary_dict = validated_summary.model_dump()
            
            # Add ArXiv specific metadata for tracking
            summary_dict['arxiv_id'] = paper_metadata.entry_id.split('/')[-1]
            summary_dict['primary_category'] = paper_metadata.primary_category
            summary_dict['published_date'] = paper_metadata.published.strftime('%Y-%m-%d')
            summary_dict['arxiv_url'] = paper_metadata.pdf_url
            
            print(f"  -> Successfully summarized and validated summary for: {summary_dict['paper_title']}")
            return summary_dict
            
        except ValidationError as e:
            print(f"  [VALIDATION ERROR] LLM output failed Pydantic validation: {e}")
            return None

    def run_daily_scan(self):
        """
        The main orchestration method for the Sentinel Agent.
        """
        start_time = time.time()
        print("="*60)
        print(f"STARTING ARXIV SENTINEL AGENT SCAN ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})")
        print("="*60)
        
        # 1. Fetch relevant papers
        papers = self._fetch_daily_papers()
        
        if not papers:
            print("No new papers found in the specified category today. Exiting.")
            return

        summaries: List[Dict[str, Any]] = []
        
        # 2. Iterate and process each paper
        print(f"\n[STEP 2] Processing {len(papers)} papers with LLM...")
        for i, paper in enumerate(papers):
            print(f"\n--- Processing Paper {i+1}/{len(papers)}: {paper.title} ---")
            
            # A. Get text content (simulated download/extraction)
            raw_text = self._get_paper_text(paper)
            
            if raw_text:
                # B. Summarize using structured LLM call
                summary = self._summarize_paper(raw_text, paper)
                if summary:
                    summaries.append(summary)
            
            # Implement a small delay to mimic real-world processing time
            time.sleep(0.5) 

        # 3. Output and Persistence
        print("\n[STEP 3] Writing results to file...")
        if summaries:
            final_output = {
                "scan_date": datetime.now().strftime('%Y-%m-%d'),
                "category": self.category,
                "total_papers_summarized": len(summaries),
                "summaries": summaries
            }
            
            with open(self.output_file, 'w', encoding='utf-8') as f:
                json.dump(final_output, f, indent=4)
            
            print(f"\nSUCCESS: Scan complete. {len(summaries)} structured summaries saved to: {self.output_file}")
        else:
            print("WARNING: No papers were successfully summarized.")

        end_time = time.time()
        print(f"\nTotal execution time: {end_time - start_time:.2f} seconds.")

# --- Execution Block ---
if __name__ == "__main__":
    # Ensure the environment is set up (API keys for real LLM calls)
    # os.environ['OPENAI_API_KEY'] = 'sk-...' # Placeholder for real execution

    # Initialize and run the agent for Cosmology (astro-ph.CO), processing up to 3 papers
    sentinel = ArXivResearchAgent(category="astro-ph.CO", max_papers=3)
    sentinel.run_daily_scan()

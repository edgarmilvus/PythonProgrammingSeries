
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import arxiv
import datetime
from typing import List, Dict, Optional

# --- 1. Define Search Constants and Parameters ---
# The specific topic we are tracking daily
SEARCH_QUERY = 'exoplanet transit spectroscopy' 
# Limit the number of results to keep the initial query fast and focused
MAX_RESULTS = 3 
# Restrict the search to the general Astrophysics category
ASTRO_CATEGORY = 'astro-ph' 

def search_arxiv(query: str, max_results: int, category: str) -> List[Dict]:
    """
    Executes a structured search against the ArXiv API using the dedicated 
    Python library and returns a clean list of paper metadata dictionaries.
    
    Args:
        query (str): The specific search phrase.
        max_results (int): The maximum number of papers to retrieve.
        category (str): The ArXiv category identifier (e.g., 'astro-ph').
        
    Returns:
        List[Dict]: A list where each dictionary contains structured paper data.
    """
    print(f"--- Initiating ArXiv search for: '{query}' (Max: {max_results}) ---")
    
    # --- 2. Initialize the ArXiv Client and Set API Etiquette ---
    # The Client manages the connection and enforces good behavior (rate limiting)
    client = arxiv.Client(
        page_size=max_results,
        delay_seconds=3.0, # Wait 3 seconds between requests (crucial for politeness)
        num_retries=5      # Allow up to 5 attempts on transient network errors
    )

    # --- 3. Construct the Specific Search Request ---
    # We combine the category filter with the specific query term
    search = arxiv.Search(
        query=f"cat:{category} AND {query}",
        max_results=max_results,
        sort_by=arxiv.SortCriterion.SubmittedDate, # Prioritize the newest papers
        sort_order=arxiv.SortOrder.Descending     # Newest first
    )
    
    results_list = []
    
    try:
        # --- 4. Fetch Results and Iterate through the Generator ---
        # client.results(search) returns a generator, which is highly memory-efficient
        for result in client.results(search):
            
            # --- 5. Extract and Structure the Raw API Data ---
            # Clean up the entry_id URL to get the simple ArXiv ID (e.g., 2405.00123)
            arxiv_id = result.entry_id.split('/')[-1] 
            
            paper_data = {
                "title": result.title.strip(), # Remove leading/trailing whitespace
                "authors": [author.name for author in result.authors], # List comprehension for clean author names
                "published": result.published.strftime("%Y-%m-%d"), # Format datetime object for readability
                "arxiv_id": arxiv_id,
                "primary_category": result.primary_category
            }
            results_list.append(paper_data)
            
            # Simple console feedback during processing
            print(f"  [+] Retrieved: {paper_data['title'][:60]}...")
            
    except Exception as e:
        # Robust error handling for network or API issues
        print(f"CRITICAL ERROR during ArXiv search: {e}")
        return []

    return results_list

# --- 6. Main Execution Block ---
if __name__ == "__main__":
    
    # Execute the search function
    top_papers = search_arxiv(
        query=SEARCH_QUERY, 
        max_results=MAX_RESULTS, 
        category=ASTRO_CATEGORY
    )

    # --- 7. Display the Structured Output ---
    print("\n========================================================")
    print("           DAILY ASTROPHYSICS PREPRINT SUMMARY          ")
    print("========================================================")
    
    if not top_papers:
        print("Search yielded no results or encountered a critical error.")
    else:
        for i, paper in enumerate(top_papers):
            print(f"\n--- PAPER {i+1} ---")
            print(f"Title: {paper['title']}")
            print(f"ID: {paper['arxiv_id']}")
            print(f"Date: {paper['published']}")
            # Display only the first three authors, adding 'et al.' if there are more
            author_display = ', '.join(paper['authors'][:3])
            if len(paper['authors']) > 3:
                 author_display += ' et al.'
            print(f"Authors: {author_display}")
            print(f"Category: {paper['primary_category']}")
            
    print("\n--- ArXiv Interface Complete ---")

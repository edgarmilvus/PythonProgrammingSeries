
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import arxiv
import datetime
from typing import List
from pydantic import BaseModel, Field

# 1. Pydantic Schema Definition
class ArXivMetadata(BaseModel):
    """Strict schema for ArXiv paper metadata."""
    arxiv_id: str = Field(description="The unique ArXiv identifier (e.g., 2301.00001)")
    title: str = Field(description="The full title of the paper.")
    authors: List[str] = Field(description="List of all authors.")
    abstract_text: str = Field(description="The full abstract text.")
    pdf_url: str = Field(description="Direct URL to the PDF file.")

def fetch_daily_preprints(categories: List[str], days_ago: int = 1) -> List[ArXivMetadata]:
    """
    Queries the ArXiv API for papers in specified categories submitted within the last N days.
    """
    target_date = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days_ago)
    
    # 2. Category Filtering: Constructing the query string
    query_parts = [f"cat:{c}" for c in categories]
    query = " OR ".join(query_parts)
    
    print(f"Querying ArXiv with: {query}")
    
    client = arxiv.Client()
    search = arxiv.Search(
        query=query,
        max_results=50, # Limit results for efficiency
        sort_by=arxiv.SortCriterion.SubmittedDate,
        sort_order=arxiv.SortOrder.Descending
    )

    results_list: List[ArXivMetadata] = []
    
    try:
        # 4. Data Transformation and Filtering
        for result in client.results(search):
            # Filtering by submission date (ArXiv API search is often broad)
            if result.published.date() >= target_date.date():
                
                # Extracting data and transforming into the Pydantic model
                try:
                    metadata = ArXivMetadata(
                        arxiv_id=result.entry_id.split('/')[-1],
                        title=result.title,
                        authors=[author.name for author in result.authors],
                        abstract_text=result.summary,
                        pdf_url=result.pdf_url
                    )
                    results_list.append(metadata)
                except Exception as e:
                    print(f"Skipping malformed result {result.entry_id}: {e}")
                    continue
        
        return results_list
        
    # 5. Error Handling
    except Exception as e:
        print(f"ArXiv API retrieval failed: {e}")
        return []

# Example Usage (Mocked or actual execution)
# daily_papers = fetch_daily_preprints(['astro-ph.CO', 'astro-ph.GA'], days_ago=1)
# print(f"Retrieved {len(daily_papers)} validated papers.")
# if daily_papers:
#     print(daily_papers[0].json(indent=2))

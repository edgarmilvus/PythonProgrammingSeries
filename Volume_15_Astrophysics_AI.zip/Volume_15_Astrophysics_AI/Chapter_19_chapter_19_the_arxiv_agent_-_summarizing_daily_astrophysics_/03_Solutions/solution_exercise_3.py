
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import random
import json
from pydantic import BaseModel, Field
from typing import Literal

# --- Schemas from Exercise 1 (Mocked for context) ---
class ArXivMetadata(BaseModel):
    arxiv_id: str
    title: str
    abstract_text: str
    authors: List[str] = []
    pdf_url: str = ""

# 1. Define the External Tool
def check_citation_impact(arxiv_id: str) -> int:
    """Simulates querying an external database for recent citation counts."""
    print(f"-> TOOL CALL: Checking recent citation impact for {arxiv_id}...")
    # Returns a random number between 0 and 15
    return random.randint(0, 15)

# --- Agent Decision Model ---
class AgentAction(BaseModel):
    """The structured decision the LLM must make."""
    action: Literal['SKIP', 'CHECK_IMPACT', 'SUMMARIZE'] = Field(
        description="The chosen action for the paper."
    )
    reasoning: str = Field(
        description="Brief explanation for the chosen action."
    )

# --- Mock LLM for Planning Step ---
def mock_llm_planner(metadata: ArXivMetadata) -> AgentAction:
    """Simulates the LLM deciding the next step."""
    
    # Heuristic simulation: If title contains 'theory' or 'math', CHECK_IMPACT, else SUMMARIZE
    if 'theory' in metadata.title.lower() or 'mathematics' in metadata.title.lower():
        action = 'CHECK_IMPACT'
        reasoning = "Paper appears highly theoretical; checking impact before proceeding to costly summarization."
    elif 'black hole' in metadata.title.lower():
        action = 'SUMMARIZE'
        reasoning = "Paper is highly relevant to core research areas and should be summarized immediately."
    else:
        action = 'SKIP'
        reasoning = "Paper topic is outside the primary focus (e.g., instrumentation or niche subfield)."
        
    return AgentAction(action=action, reasoning=reasoning)

# --- Mock Summarization Function ---
def summarize_paper(metadata: ArXivMetadata) -> str:
    """Simulates the final, expensive summarization step."""
    return f"SUMMARY GENERATED: {metadata.title[:30]}..."

# 3. Reasoning Step Modification and 4. Conditional Execution
def process_paper(metadata: ArXivMetadata):
    """The core agent loop for processing a single paper."""
    print(f"\n--- Processing {metadata.arxiv_id}: {metadata.title} ---")
    
    # LLM Planning Step
    try:
        action = mock_llm_planner(metadata)
    except Exception as e:
        print(f"Error during planning: {e}. Skipping.")
        return
    
    print(f"LLM Decision: {action.action} (Reason: {action.reasoning})")

    if action.action == 'SKIP':
        print("-> Result: Skipped based on initial assessment.")
        return "Skipped"

    elif action.action == 'CHECK_IMPACT':
        # Conditional Tool Execution
        citations = check_citation_impact(metadata.arxiv_id)
        print(f"-> Tool Result: Citations found: {citations}")
        
        if citations < 5:
            print("-> Result: Low Impact (Citations < 5). Skipping summarization.")
            return "Skipped (Low Impact)"
        else:
            print("-> Result: High Impact confirmed. Proceeding to SUMMARIZE.")
            # Fall through to SUMMARIZE logic
            summary = summarize_paper(metadata)
            print(f"-> Final Action: {summary}")
            return "Summarized"

    elif action.action == 'SUMMARIZE':
        summary = summarize_paper(metadata)
        print(f"-> Final Action: {summary}")
        return "Summarized"

# Example Run
mock_papers = [
    ArXivMetadata(arxiv_id='2401.00001', title='Theoretical Mathematics of Multiverse Geometry', abstract_text='...'),
    ArXivMetadata(arxiv_id='2401.00002', title='Observing the Black Hole Shadow in M87', abstract_text='...'),
    ArXivMetadata(arxiv_id='2401.00003', title='A New Detector for X-ray Astronomy', abstract_text='...'),
]

# Set random seed for predictable impact check results (for demonstration)
random.seed(42) 
for paper in mock_papers:
    process_paper(paper)

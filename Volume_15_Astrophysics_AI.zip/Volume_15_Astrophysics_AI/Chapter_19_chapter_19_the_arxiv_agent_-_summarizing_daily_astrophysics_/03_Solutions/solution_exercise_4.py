
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import schedule
import time
import json
from typing import List, Dict, Any

# Mock data structure for the report
ReportData = List[Dict[str, Any]]

# 2. Asynchronous Report Writer Context Manager
class AsyncReportWriter:
    """
    Asynchronous context manager for safely writing structured data to a JSON file.
    Guarantees the file handle is closed upon exit.
    """
    def __init__(self, filename: str):
        self.filename = filename
        self.file_handle = None

    async def __aenter__(self):
        # 2a. Asynchronously open the file handle
        # In a true async environment, this would use aiofiles or similar.
        # We simulate the async I/O by wrapping standard file opening.
        print(f"-> ASYNC CONTEXT: Entering context, opening file: {self.filename}")
        try:
            # Note: Standard open() is blocking, but for simulation, we use it 
            # within the async structure to show the pattern.
            self.file_handle = open(self.filename, 'w')
            return self.file_handle
        except Exception as e:
            print(f"Error opening file: {e}")
            raise

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # 2b. Ensure the file is closed cleanly, regardless of exceptions
        print("-> ASYNC CONTEXT: Exiting context, ensuring file closure.")
        if self.file_handle:
            self.file_handle.close()
            
        if exc_type:
            print(f"-> ERROR DETECTED: An exception of type {exc_type.__name__} occurred during writing.")
            # Returning False here would re-raise the exception; returning True suppresses it.
            return False 

# 3. Agent Integration
async def run_agent_pipeline(report_data: ReportData):
    """Simulates the final stage of the agent pipeline."""
    print("Agent Pipeline: Finalizing report data...")
    
    # Simulate a potential error during data serialization
    # if len(report_data) > 3:
    #     raise ValueError("Simulated serialization failure!")

    # Use the asynchronous context manager
    try:
        async with AsyncReportWriter("daily_report.json") as f:
            # Simulate the asynchronous writing process
            await asyncio.sleep(0.1) 
            json.dump(report_data, f, indent=2)
            print(f"Agent Pipeline: Successfully wrote {len(report_data)} items to report.")
            
    except Exception as e:
        print(f"Agent Pipeline failed to write report: {e}")
        # The __aexit__ method guarantees the file is closed even if this block fails.

# 1. Scheduled Execution Setup
def run_daily_agent():
    """The main synchronous function called by the scheduler."""
    print(f"\n--- Running Daily ArXiv Agent at {datetime.datetime.now().time()} ---")
    
    # Mock data retrieval and processing results
    mock_results = [
        {"id": "2401.1", "summary": "Summary A"},
        {"id": "2401.2", "summary": "Summary B"},
    ]
    
    # Run the asynchronous pipeline
    asyncio.run(run_agent_pipeline(mock_results))
    print("--- Daily Agent Run Complete ---")

# Setup the scheduler
schedule.every().day.at("09:00").do(run_daily_agent)
print("Scheduler initialized. Daily run set for 09:00.")

# Main loop for production deployment (simulated)
def start_scheduler_loop(duration_seconds=5):
    """Simulates the long-running process checking for scheduled jobs."""
    start_time = time.time()
    while time.time() - start_time < duration_seconds:
        schedule.run_pending()
        time.sleep(1)
        
# To run this in a real environment, you would remove the duration_seconds limit.
# start_scheduler_loop(1) 

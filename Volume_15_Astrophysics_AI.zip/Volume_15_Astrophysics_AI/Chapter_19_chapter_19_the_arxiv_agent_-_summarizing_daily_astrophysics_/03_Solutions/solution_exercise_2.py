
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json
from pydantic import BaseModel, Field
from typing import List, Dict

# --- Mocking LLM API components ---
# In a real scenario, replace this with OpenAI/Anthropic SDK calls
class MockLLMError(Exception):
    pass

def mock_llm_call(prompt: str, json_schema: Dict) -> str:
    """Simulates an LLM call that returns structured JSON."""
    
    # Simple simulation of a successful structured output
    mock_data = {
        "methodology_and_data_sources": "The authors analyzed data from the Hubble Space Telescope's deep field survey, employing a novel machine learning classifier to identify Type Ia supernovae light curves.",
        "key_quantitative_results": "The analysis yielded a revised Hubble constant value of 67.8 ± 0.9 km/s/Mpc, confirming previous measurements at 1-sigma confidence. A total of 45 new high-redshift supernovae were cataloged.",
        "broader_astrophysical_implications": "This work reduces the tension between local and cosmological measurements of the Hubble constant, suggesting that systematic errors in local distance ladders may be smaller than previously assumed, impacting standard cosmological models."
    }
    return json.dumps(mock_data)

# --- Schemas from Exercise 1 (Required for function signature) ---
class ArXivMetadata(BaseModel):
    arxiv_id: str
    title: str
    authors: List[str]
    abstract_text: str
    pdf_url: str

# 1. Summary Schema Definition
class AstrophysicsSummary(BaseModel):
    """Structured summary tailored for astrophysics research analysis."""
    methodology_and_data_sources: str = Field(
        description="A concise description of the observational techniques, simulation methods, or specific datasets used (e.g., VLT spectroscopy, N-body simulations, SDSS data)."
    )
    key_quantitative_results: str = Field(
        description="The main findings, focusing strictly on numerical results, statistical significance, confirmed predictions, or measured values (e.g., 'mass = 10^8 M_sun', 'p-value < 0.01')."
    )
    broader_astrophysical_implications: str = Field(
        description="The significance of the work for the field, explaining how the results impact current models, theories, or future observational strategies (e.g., implications for dark matter models or galaxy evolution)."
    )
    
def generate_structured_summary(metadata: ArXivMetadata) -> AstrophysicsSummary:
    """
    Uses an LLM to generate a structured summary based on the paper's abstract.
    """
    # Get the required JSON schema for the LLM
    output_schema = AstrophysicsSummary.schema()
    
    # 2. Dynamic System Prompt Construction
    system_prompt = f"""
    You are an expert Astrophysics Research Assistant. Your task is to analyze the provided abstract and extract the key information into a structured JSON object.
    
    STRICT INSTRUCTIONS:
    1. Do NOT include any introductory or concluding text outside the JSON object.
    2. The output MUST be a valid JSON object that strictly conforms to the provided JSON schema.
    3. Analyze the text and fill the fields accurately based on the detailed field descriptions provided in the schema.
    
    --- RAW ABSTRACT ---
    {metadata.abstract_text}
    
    --- REQUIRED JSON SCHEMA ---
    {json.dumps(output_schema, indent=2)}
    """
    
    print(f"Generating summary for: {metadata.title}")

    try:
        # 3. LLM Invocation and Parsing (using mock)
        # In a real setup, you would pass the schema to the LLM API's response_format parameter.
        raw_json_output = mock_llm_call(system_prompt, output_schema)
        
        # Validate and parse the output using Pydantic
        summary_data = json.loads(raw_json_output)
        validated_summary = AstrophysicsSummary(**summary_data)
        
        return validated_summary
        
    # 3. Robust Error Handling for JSON parsing
    except json.JSONDecodeError as e:
        print(f"ERROR: LLM returned malformed JSON for {metadata.arxiv_id}. {e}")
        # Return a fallback error object
        return AstrophysicsSummary(
            methodology_and_data_sources="ERROR: Failed to parse LLM output.",
            key_quantitative_results="N/A",
            broader_astrophysical_implications="N/A"
        )
    except MockLLMError as e:
        print(f"ERROR: LLM API call failed: {e}")
        # Return a fallback error object
        return AstrophysicsSummary(
            methodology_and_data_sources="ERROR: LLM API call failed.",
            key_quantitative_results="N/A",
            broader_astrophysical_implications="N/A"
        )

# Example Usage:
# mock_metadata = ArXivMetadata(
#     arxiv_id="2401.12345",
#     title="A New Measurement of the Hubble Constant using Supernovae",
#     authors=["A. Smith", "B. Jones"],
#     abstract_text="We present a comprehensive analysis of 45 high-redshift Type Ia supernovae observed by HST. Our methodology involved a novel machine learning classifier to filter out contaminants. This led to a revised Hubble constant of 67.8 ± 0.9 km/s/Mpc. This result significantly reduces the existing tension with CMB measurements, providing strong constraints on dark energy models.",
#     pdf_url="http://arxiv.org/pdf/2401.12345"
# )
# summary = generate_structured_summary(mock_metadata)
# print("\n--- Structured Summary ---")
# print(summary.json(indent=2))

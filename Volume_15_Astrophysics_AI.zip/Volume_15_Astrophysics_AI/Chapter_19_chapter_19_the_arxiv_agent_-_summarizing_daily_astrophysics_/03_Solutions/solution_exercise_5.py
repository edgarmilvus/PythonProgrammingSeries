
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import logging
import time
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type, before_sleep
from typing import List, Dict, Any
import json
from pydantic import BaseModel, Field

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Mock LLM API and Exceptions ---
# Simulate common OpenAI/Anthropic transient errors
class RateLimitError(Exception):
    """Simulates hitting a rate limit."""
    pass
class APIConnectionError(Exception):
    """Simulates a temporary network issue."""
    pass
class InternalServerError(Exception):
    """Simulates a temporary server-side issue."""
    pass
class PermanentError(Exception):
    """Simulates an unrecoverable error (e.g., bad API key)."""
    pass

# 1. Identify Transient Errors
TRANSIENT_ERRORS = (
    RateLimitError, 
    APIConnectionError, 
    InternalServerError
)

# --- Schemas from Exercise 2 (Required for function signature) ---
class ArXivMetadata(BaseModel):
    arxiv_id: str
    title: str
    abstract_text: str
class AstrophysicsSummary(BaseModel):
    methodology_and_data_sources: str = Field(description="...")
    key_quantitative_results: str = Field(description="...")
    broader_astrophysical_implications: str = Field(description="...")

# --- Logging Hook ---
def log_retry_attempt(retry_state):
    """Logs the retry attempt and the time until the next attempt."""
    logging.warning(
        f"Attempt {retry_state.attempt_number} failed with {type(retry_state.outcome.exception).__name__}. "
        f"Retrying in {retry_state.next_action.sleep} seconds..."
    )

# Global counter to simulate failure on first two calls
call_count = 0

def mock_llm_api_call(prompt):
    """Simulates an LLM call that fails transiently twice."""
    global call_count
    call_count += 1
    
    if call_count <= 2:
        logging.info(f"Mock LLM Call: Attempt {call_count} (Simulating failure).")
        if call_count == 1:
            raise RateLimitError("Rate limit exceeded.")
        if call_count == 2:
            raise APIConnectionError("Network timeout.")
            
    logging.info(f"Mock LLM Call: Attempt {call_count} (Success).")
    # Successful mock response (must be valid JSON for parsing)
    return json.dumps({
        "methodology_and_data_sources": "Success after retry.",
        "key_quantitative_results": "100%",
        "broader_astrophysical_implications": "Resilience demonstrated."
    })

# 2, 3, 4. Use tenacity with Exponential Backoff and Logging
@retry(
    # Stop after a maximum of 3 attempts
    stop=stop_after_attempt(3),
    # Wait exponentially: 1s, 2s, 4s, ...
    wait=wait_exponential(multiplier=1, min=1, max=10),
    # Retry only on defined transient errors
    retry=retry_if_exception_type(TRANSIENT_ERRORS),
    # Log before sleeping
    before_sleep=log_retry_attempt,
    # Reraise exception if it is a PermanentError (not retried)
    reraise=True 
)
def generate_structured_summary_resilient(metadata: ArXivMetadata) -> AstrophysicsSummary:
    """
    LLM summarization function wrapped with exponential backoff.
    """
    raw_json_output = mock_llm_api_call("Summarize this abstract: " + metadata.abstract_text)
    
    # Parse and validate the successful JSON output
    summary_data = json.loads(raw_json_output)
    return AstrophysicsSummary(**summary_data)

# 5. Final Fallback Wrapper
def safe_generate_summary(metadata: ArXivMetadata) -> AstrophysicsSummary:
    """
    Handles the final failure case after all retries are exhausted.
    """
    try:
        return generate_structured_summary_resilient(metadata)
    except TRANSIENT_ERRORS as e:
        logging.error(f"FATAL: All retry attempts failed for {metadata.arxiv_id}. Returning error placeholder.")
        # Return a specific, empty placeholder object
        return AstrophysicsSummary(
            methodology_and_data_sources=f"CRITICAL FAILURE: LLM service unavailable after 3 retries. Last error: {type(e).__name__}",
            key_quantitative_results="N/A",
            broader_astrophysical_implications="N/A (Agent Resilience Mode)"
        )
    except PermanentError as e:
        # Handle non-retryable errors separately
        logging.error(f"PERMANENT FAILURE: Cannot process due to unrecoverable error: {e}")
        return AstrophysicsSummary(
            methodology_and_data_sources=f"PERMANENT ERROR: {type(e).__name__}",
            key_quantitative_results="N/A",
            broader_astrophysical_implications="N/A"
        )


# Demonstration Run
mock_metadata = ArXivMetadata(
    arxiv_id="2401.12345",
    title="Resilience Test",
    abstract_text="This is a test abstract to demonstrate retry logic."
)

print("\n--- Starting Resilient LLM Call Demonstration ---")
final_summary = safe_generate_summary(mock_metadata)
print("\n--- Final Summary Result ---")
print(final_summary.json(indent=2))

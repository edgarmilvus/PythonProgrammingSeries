
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from skyfield.api import load
from skyfield.timelib import Time
from io import StringIO
import sys

# Define the URL for the fundamental planetary data (SPICE kernel)
# We use the standard DE421 kernel for this basic calculation.
PLANETARY_DATA_URL = 'de421.bsp'

# Example elements for 4 Vesta, simulated in a simplified MPC format.
# Skyfield's `load.minor_planet_ephemeris` expects specific fields:
# Name, Epoch (JD), Semi-major axis (AU), Eccentricity, Inclination (deg), 
# Longitude of Ascending Node (deg), Argument of Periapsis (deg), Mean Anomaly (deg)
VESTA_ELEMENTS_MPC = """
Vesta
E2000
2459800.5  2.36154881  0.09033379  7.13328213  103.88214227  150.12560370  10.59247190
""" 

def calculate_asteroid_ephemeris():
    """
    Loads orbital elements for an asteroid (4 Vesta) and calculates its apparent position 
    relative to a defined observer at a specific time using Skyfield.
    """
    
    # 1. Initialize Skyfield Environment and Load Kernel
    ts = load.timescale()
    try:
        # Load the essential planetary ephemeris data (Earth, Sun, etc.)
        eph = load(PLANETARY_DATA_URL)
    except Exception as e:
        print(f"Error loading planetary data kernel: {e}", file=sys.stderr)
        print("Ensure you have network access or the file is locally cached.")
        return
    
    # 2. Define the Observer Location 
    # Example: Royal Observatory, Greenwich, London (Lat/Lon defined in decimal degrees)
    observer_lat_deg = 51.476852
    observer_lon_deg = 0.000500
    
    # Create the observer object by combining the Earth body with the specific location
    # The result is a 'Topos' object, representing the observer on the Earth's surface.
    observer = eph['earth'] + load.latlon(observer_lat_deg, observer_lon_deg)
    
    # 3. Load the Minor Planet Orbital Elements
    # Use StringIO to treat the VESTA_ELEMENTS_MPC string as if it were a file being read.
    minor_planet_file = StringIO(VESTA_ELEMENTS_MPC)
    
    # The `load.minor_planet_ephemeris` function parses the data based on the 
    # expected MPC format structure.
    minor_planets = load.minor_planet_ephemeris(minor_planet_file)
    
    # Retrieve the specific body (4 Vesta) from the loaded collection
    asteroid = minor_planets['Vesta']
    
    # 4. Define the Time of Observation
    # Calculate the position for midnight UTC on May 1st, 2024.
    time_of_observation = ts.utc(2024, 5, 1, 0, 0, 0)
    
    # 5. Calculate the Apparent Position
    
    # Step A: Calculate the astrometric position (geometric, uncorrected for light travel).
    # This finds the vector from the observer location to the asteroid center.
    astrometric = observer.at(time_of_observation).observe(asteroid)
    
    # Step B: Calculate the apparent position. This applies the crucial 
    # light-time correction—calculating where the asteroid *appears* to be now, 
    # based on where it was when the light started its journey.
    apparent = astrometric.apparent()
    
    # 6. Extract Coordinates and Distance
    # .radec() returns Right Ascension (RA), Declination (Dec), and Distance.
    # RA and Dec are returned in the standard J2000 celestial coordinate frame.
    # The distance object contains methods to convert to various units (e.g., AU, km).
    ra, dec, distance = apparent.radec()
    
    # 7. Output Results
    print(f"--- Ephemeris for 4 Vesta (Minor Planet) ---")
    print(f"Observation Time (UTC): {time_of_observation.utc_strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Observer Location: {observer_lat_deg:.4f} N, {observer_lon_deg:.4f} E")
    print("-" * 50)
    
    # Skyfield's RA/Dec objects have built-in formatting for degrees, hours, minutes, seconds.
    print(f"Right Ascension (RA, J2000): {ra}")
    print(f"Declination (Dec, J2000): {dec}")
    
    # Display the distance in Astronomical Units (AU)
    print(f"Distance from Observer (AU): {distance.au:.8f}")
    print("-" * 50)

if __name__ == '__main__':
    calculate_asteroid_ephemeris()

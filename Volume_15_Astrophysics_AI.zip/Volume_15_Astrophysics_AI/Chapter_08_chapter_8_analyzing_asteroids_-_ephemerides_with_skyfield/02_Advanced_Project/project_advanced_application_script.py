
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import requests
from datetime import datetime, timedelta
from skyfield.api import load, Topos, utc
from skyfield.data import mpc
from skyfield.timelib import Time
from skyfield.framelib import itrs

# --- 1. CONFIGURATION AND CONSTANTS ---

# Define the location of the observer (e.g., Palomar Observatory, California)
PALOMAR = Topos('33.356944 N', '116.865000 W', elevation_m=1706)

# Standard URL for the standard planetary ephemeris kernel (JPL DE421)
EPHEMERIS_URL = 'de421.bsp'

# MPC URL template for fetching specific minor planet orbital elements (3-line format)
# We use the 'K10' format for the latest elements.
MPC_ELEMENTS_URL = (
    'https://minorplanetcenter.net/iau/mpc.html?designation={asteroid_designation}'
)

# Target asteroid designation (e.g., 99942 Apophis)
ASTEROID_DESIGNATION = '99942'

# Minimum altitude required for practical observation (in degrees)
MIN_ALTITUDE_DEG = 20.0

# --- 2. DATA LOADING AND ORBITAL ELEMENT PARSING ---

def load_ephemeris_data():
    """Loads the standard planetary ephemeris and the Skyfield time scale."""
    print(f"Loading planetary data kernel: {EPHEMERIS_URL}...")
    ts = load.timescale()
    planets = load(EPHEMERIS_URL)
    return ts, planets

def fetch_and_parse_mpc_elements(designation, ts):
    """
    Fetches the 3-line orbital elements for the given asteroid designation
    from the MPC and generates a Skyfield MinorPlanet object.
    """
    print(f"Fetching orbital elements for asteroid {designation}...")
    
    # The MPC URL returns a short HTML page containing the 3-line elements.
    # We must parse the content to extract the raw element lines.
    url = MPC_ELEMENTS_URL.format(asteroid_designation=designation)
    
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
    except requests.exceptions.RequestException as e:
        print(f"Error fetching MPC data: {e}")
        return None

    # The MPC page structure is often inconsistent, but the 3-line elements 
    # are usually embedded in <pre> tags or similar plain text blocks.
    # Skyfield's mpc.load_mpc_minor_planet function expects a list of the raw lines.
    
    # Simple heuristic: Split the response text and look for lines starting with the designation.
    # This is highly dependent on the MPC output format, but robust for the standard 3-line output.
    lines = response.text.splitlines()
    element_lines = []
    
    # Identify the three lines belonging to the specific designation
    for line in lines:
        if line.strip().startswith(designation):
            element_lines.append(line.strip())
        
        # We expect exactly three lines for the full element set
        if len(element_lines) == 3:
            break
            
    if len(element_lines) != 3:
        print(f"Error: Could not find 3-line elements for {designation}. Found {len(element_lines)} lines.")
        return None

    print(f"Successfully retrieved orbital elements.")
    # Use Skyfield's built-in parser for MPC format
    minor_planet = mpc.load_mpc_minor_planet(element_lines, ts)
    return minor_planet

# --- 3. CORE CALCULATION LOGIC ---

def calculate_ephemerides(ts: Time, planets, asteroid, observer_topos: Topos):
    """
    Calculates the apparent position and visibility metrics for the asteroid
    over a 24-hour period.
    """
    
    # Define the observation start time (tonight at 00:00 UTC)
    now = datetime.now(utc).replace(hour=0, minute=0, second=0, microsecond=0)
    start_time = ts.utc(now)
    
    # Create an array of times spanning 24 hours, in 1-hour increments (25 total points)
    times = ts.utc([start_time.utc_datetime() + timedelta(hours=i) for i in range(25)])
    
    print(f"\nCalculating ephemerides for 24 hours starting at {times[0].utc_jpl()}...")

    # Define the observer location relative to the solar system barycenter
    earth = planets['earth']
    observer = earth + observer_topos
    
    # Calculate the apparent position vector (includes light-time correction)
    # The target is the asteroid relative to the observer
    astrometric = observer.at(times).observe(asteroid)
    
    # Convert the observed vector to RA/Dec (apparent position)
    ra, dec, distance = astrometric.apparent().frame_of_date().ecliptic_page(times)

    # Convert the observed vector to Altitude and Azimuth (for visibility check)
    alt, az, _ = astrometric.altaz()
    
    # --- 4. DATA FILTERING AND OUTPUT ---
    
    # Create a Boolean mask: True if altitude is above the minimum threshold
    is_visible = alt.degrees > MIN_ALTITUDE_DEG
    
    print("\n--- Filtered Observation Plan for Asteroid {} ---".format(ASTEROID_DESIGNATION))
    print(f"Observer: Palomar (Altitude > {MIN_ALTITUDE_DEG:.1f} deg)")
    print("-------------------------------------------------------")
    print("UTC Time       | RA (h:m:s)      | Dec (d:m:s)     | Alt (deg) | Dist (AU)")
    print("-------------------------------------------------------")

    # Iterate only over the filtered (visible) time steps
    for i, visible in enumerate(is_visible):
        if visible:
            time_str = times[i].utc_strftime('%Y-%m-%d %H:%M')
            
            # Format RA/Dec using Skyfield's built-in formatting methods
            ra_str = ra[i].hours_string(precision=1)
            dec_str = dec[i].dstr(precision=0)
            
            # Distance is automatically calculated in AU by Skyfield
            dist_au = distance.au[i]
            alt_deg = alt.degrees[i]
            
            print(f"{time_str} | {ra_str} | {dec_str} | {alt_deg:8.2f} | {dist_au:7.4f}")
            
    if not np.any(is_visible):
        print(f"\nAsteroid {ASTEROID_DESIGNATION} is not visible above {MIN_ALTITUDE_DEG} degrees during this period.")
        
# --- 5. MAIN EXECUTION ---

if __name__ == "__main__":
    ts, planets = load_ephemeris_data()
    
    # Fetch the orbital elements and create the asteroid object
    asteroid_target = fetch_and_parse_mpc_elements(ASTEROID_DESIGNATION, ts)
    
    if asteroid_target:
        calculate_ephemerides(ts, planets, asteroid_target, PALOMAR)
    else:
        print("Script terminated due to failure in loading asteroid data.")


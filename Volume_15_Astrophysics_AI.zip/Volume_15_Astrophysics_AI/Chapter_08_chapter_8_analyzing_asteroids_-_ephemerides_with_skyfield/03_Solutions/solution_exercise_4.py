
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from skyfield.api import load, units

# 1. Target and Time Window Setup
eph = load('de421.bsp')
ts = load.timescale()
earth = eph['earth']
apophis = eph['99942 Apophis']

# Define the 5-day search window
t_start_survey = ts.utc(2029, 4, 11, 0, 0, 0)
t_end_survey = ts.utc(2029, 4, 15, 0, 0, 0)

# 2. Initial Survey (Hourly steps)
hours_total = (t_end_survey.tt - t_start_survey.tt) * 24.0
times_survey = ts.linspace(t_start_survey, t_end_survey, int(hours_total) + 1)

# Calculate geocentric distance (in kilometers)
distances_survey = earth.at(times_survey).observe(apophis).distance().km

# Find the index of the minimum distance
min_index = np.argmin(distances_survey)
min_time_survey = times_survey[min_index]

print(f"--- Stage 1: Hourly Survey Results ---")
print(f"Approximate Minimum Distance: {distances_survey[min_index]:,.0f} km")
print(f"Approximate Time of Minimum: {min_time_survey.utc_iso()[:16]} UTC")

# 3. Refined Search (1-minute steps)
# Define a 12-hour window centered on the approximate minimum time
T_center = min_time_survey
T_refined_start = ts.utc(T_center.utc_datetime() - units.Hour * 6)
T_refined_end = ts.utc(T_center.utc_datetime() + units.Hour * 6)

# Calculate number of 1-minute steps
minutes_total = int(12 * 60)
times_refined = ts.linspace(T_refined_start, T_refined_end, minutes_total + 1)

# Recalculate distances with high resolution
distances_refined = earth.at(times_refined).observe(apophis).distance().km

# Find the precise minimum
min_index_refined = np.argmin(distances_refined)
min_distance_km = distances_refined[min_index_refined]
min_time_precise = times_refined[min_index_refined]

# 4. Minimization and Output
print("\n--- Stage 2: Refined Search Results ---")
print(f"Precise Time of Closest Approach: {min_time_precise.utc_iso()[:16]} UTC")
print(f"Minimum Geocentric Distance: {min_distance_km:,.3f} km")

# 5. Visualization Preparation (Conceptual)
# Conceptual description of plotting the results:
"""
# To visually confirm the minimum, one would use Matplotlib:
# import matplotlib.pyplot as plt
#
# # Convert Skyfield times to Matplotlib-compatible datetime objects
# date_times = times_refined.utc_datetime()
#
# plt.figure(figsize=(10, 6))
# plt.plot(date_times, distances_refined, label='Geocentric Distance')
# plt.scatter(min_time_precise.utc_datetime(), min_distance_km, 
#             color='red', zorder=5, label='Minimum Distance')
# plt.title('Apophis Close Approach Distance (April 2029)')
# plt.xlabel('Time (UTC)')
# plt.ylabel('Distance (km)')
# plt.grid(True)
# plt.legend()
# plt.show()
"""

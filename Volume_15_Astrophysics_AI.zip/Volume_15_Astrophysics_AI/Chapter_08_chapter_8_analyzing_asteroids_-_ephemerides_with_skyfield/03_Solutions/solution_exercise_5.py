
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import pandas as pd
from skyfield.api import load, T, units

# --- Re-running Exercise 2 Calculation to generate raw data ---
eph = load('de421.bsp')
ts = load.timescale()

# Simulated Keplerian Elements (Epoch 2024-06-01)
T0_epoch = ts.utc(2024, 6, 1)
a = 2.5 * units.AU; e = 0.65; i = 15.0; omega = 45.0; Omega = 120.0; M = 10.0
asteroid = eph.orbital_elements(a=a, e=e, i=i, omega=omega, Omega=Omega, M=M, epoch=T0_epoch)

earth = eph['earth']
sun = eph['sun']

# 90-day time series
T_end = ts.utc(2024, 8, 30)
times = ts.linspace(T0_epoch, T_end, 90)

# Calculate raw Skyfield objects
pos_sun = sun.at(times).observe(asteroid)
pos_earth = earth.at(times).observe(asteroid)

ra, dec, _ = pos_earth.apparent().radec()
geocentric_dist = pos_earth.distance()
heliocentric_dist = pos_sun.distance()

# 2. DataFrame Construction and 3. Unit Conversion
data = {
    # Time Conversion: Skyfield Time object to ISO 8601 string
    'Time_UTC': times.utc_iso(),
    
    # RA Conversion: Hours/Radians to Decimal Degrees (RA is 15 * hours)
    'RA_Deg': ra.hours * 15.0,
    
    # Dec Conversion: Radians to Decimal Degrees
    'Dec_Deg': dec.degrees,
    
    # Distance Conversion: AU to Kilometers
    'Geocentric_Distance_km': geocentric_dist.km,
    'Heliocentric_Distance_km': heliocentric_dist.km
}

df = pd.DataFrame(data)

# 4. Verification: Print the first five rows
print("--- Data Pipeline Output (First 5 Rows) ---")
print(df.head())
print("-" * 50)

# 5. Data Integrity Check
ra_min = df['RA_Deg'].min()
ra_max = df['RA_Deg'].max()

# Check that all RA values are within the standard range [0.0, 360.0]
try:
    assert ra_min >= 0.0 and ra_max <= 360.0, \
        f"RA integrity check failed. Range found: [{ra_min:.2f}, {ra_max:.2f}]"
    print("Data Integrity Check Passed: All RA values are between 0° and 360°.")
except AssertionError as e:
    print(f"Data Integrity Check FAILED: {e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import numpy as np
from skyfield.api import load, T, units
from skyfield.data import mpc

# 1. Setup and Orbital Data
eph = load('de421.bsp')
ts = load.timescale()

# Simulated Keplerian Elements (Epoch J2000.0)
# Reference date T0 = 2024-06-01
T0_epoch = ts.utc(2024, 6, 1)

# Parameters for 2024 AB12
a = 2.5 * units.AU  # Semi-major Axis
e = 0.65            # Eccentricity
i = 15.0            # Inclination (degrees)
omega = 45.0        # Argument of Perihelion (degrees)
Omega = 120.0       # Longitude of Ascending Node (degrees)
M = 10.0            # Mean Anomaly (degrees)

# 2. Custom Body Definition
# Define the asteroid using the Skyfield function for orbital elements
asteroid = eph.orbital_elements(
    a=a, e=e, i=i, omega=omega, Omega=Omega, M=M, epoch=T0_epoch
)

# Define Earth and Sun for reference
earth = eph['earth']
sun = eph['sun']

# 3. Trajectory Calculation (90 days, daily steps)
T_start = T0_epoch
T_end = ts.utc(2024, 8, 30) # 90 days later
times = ts.linspace(T_start, T_end, 90)

results = []

for t in times:
    # Heliocentric position and velocity (Sun is the observer)
    pos_sun = sun.at(t).observe(asteroid)
    r_helio = pos_sun.distance().au
    v_helio = pos_sun.velocity.km_per_s[0] # Magnitude of the velocity vector

    # Geocentric position (Earth is the observer)
    r_geo = earth.at(t).observe(asteroid).distance().au

    # 4. Analysis and Data Collection
    results.append((
        t.tt, # Julian Date (TT)
        r_helio,
        r_geo,
        np.linalg.norm(v_helio) # Orbital velocity magnitude in km/s
    ))

# 5. Data Structure Output (Printing first few rows for verification)
print("Trajectory Data for 2024 AB12 (First 5 days)")
print("-" * 80)
print(" JD (TT) | Heliocentric Dist (AU) | Geocentric Dist (AU) | Orbital Velocity (km/s)")
print("-" * 80)
for row in results[:5]:
    print(f"{row[0]:.4f} | {row[1]:>20.6f} | {row[2]:>18.6f} | {row[3]:>20.4f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from skyfield.api import load, Topos, units

# 1. Kernel and Time Setup
# Load the standard high-precision kernel set
eph = load('de421.bsp')
ts = load.timescale()

# Define the celestial bodies
earth = eph['earth']
vesta = eph['4 Vesta']

# 2. Observer Definition (CTIO)
# Latitude: -30.165° S, Longitude: 70.815° W, Elevation: 2200 meters
ctio = earth + Topos(latitude_degrees=-30.165, 
                     longitude_degrees=-70.815, 
                     elevation_m=2200)

# 3. Time Series Generation
# Start 2025-03-15 02:00 UTC, 4 hours, 30 min steps (9 points)
t0 = ts.utc(2025, 3, 15, 2, 0, 0)
times = ts.utc(t0.utc_datetime() + np.arange(9) * units.Minute * 30)

# 4. Ephemeris Calculation
# Calculate the position vector from CTIO to Vesta
astrometric = ctio.at(times).observe(vesta)
apparent = astrometric.apparent()

# Get coordinates and distance
ra, dec, distance = apparent.radec()
geocentric_distance_au = distance.au

print("Ephemeris for 4 Vesta from CTIO (2025-03-15)")
print("-" * 70)
print("Time (UTC) | RA (J2000) | Dec (J2000) | Geo. Dist. (AU)")
print("-" * 70)

# 5. Output Format
for i in range(len(times)):
    # Format time
    time_str = times[i].utc_strftime('%H:%M:%S')
    
    # Format RA/Dec (using Skyfield's built-in formatting)
    ra_str = ra[i].format(precision=1, unit='hour')
    dec_str = dec[i].format(precision=0, unit='degrees')
    
    print(f"{time_str} | {ra_str} | {dec_str} | {geocentric_distance_au[i]:.4f}")

print("-" * 70)

# Calculate and print horizontal coordinates for the first and last point
alt_az_start = apparent[0].altaz()
alt_az_end = apparent[-1].altaz()

print(f"Start Time (02:00 UTC): Alt={alt_az_start[0].degrees:.2f}°, Az={alt_az_start[1].degrees:.2f}°")
print(f"End Time (06:00 UTC):   Alt={alt_az_end[0].degrees:.2f}°, Az={alt_az_end[1].degrees:.2f}°")

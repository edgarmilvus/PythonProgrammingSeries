
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from skyfield.api import load, Topos, units
from skyfield.timelib import Time

# 1. Target and Time Setup
eph = load('de421.bsp')
ts = load.timescale()
apophis = eph['99942 Apophis']

# Time array spanning 24 hours on April 13, 2029 (10 steps)
t_start = ts.utc(2029, 4, 13, 0, 0, 0)
times = ts.utc(t_start.utc_datetime() + np.arange(10) * units.Hour * 2.5)

# 2. Non-Standard Observer (Sea level station)
lat = 40.0
lon = -100.0
elevation = 0.0 # Sea level
observer = eph['earth'] + Topos(lat, lon, elevation_m=elevation)

# Atmospheric parameters for Apparent calculation
PRESSURE = 1010.0 # hPa
TEMPERATURE = 10.0 # C

# --- Calculation ---
geometric_ra_deg = []
geometric_dec_deg = []
apparent_ra_deg = []
apparent_dec_deg = []
altitudes = []

for t in times:
    # Calculate vector from observer to target
    pos = observer.at(t).observe(apophis)
    
    # 3. Geometric Position (No LTT, no aberration, no refraction)
    # Using .geometric() suppresses LTT and aberration corrections
    geo = pos.geometric()
    ra_g, dec_g, _ = geo.radec()
    geometric_ra_deg.append(ra_g.degrees)
    geometric_dec_deg.append(dec_g.degrees)

    # 4. Apparent Position with Corrections (LTT, Aberration, Refraction)
    # .apparent() includes LTT and aberration.
    # .altaz() with pressure/temp includes atmospheric refraction.
    app = pos.apparent().altaz(pressure_hPa=PRESSURE, temperature_c=TEMPERATURE)
    ra_a, dec_a, _ = app.radec()
    
    apparent_ra_deg.append(ra_a.degrees)
    apparent_dec_deg.append(dec_a.degrees)
    altitudes.append(app[0].degrees)


# 5. Quantify Difference
altitudes = np.array(altitudes)
max_alt_index = np.argmax(altitudes)
t_max_alt = times[max_alt_index]

# Convert RA/Dec differences to radians for angular separation calculation
ra_g_rad = np.radians(geometric_ra_deg[max_alt_index])
dec_g_rad = np.radians(geometric_dec_deg[max_alt_index])
ra_a_rad = np.radians(apparent_ra_deg[max_alt_index])
dec_a_rad = np.radians(apparent_dec_deg[max_alt_index])

# Calculate angular separation (using the standard spherical law of cosines simplification)
# d = arccos(sin(dec1)sin(dec2) + cos(dec1)cos(dec2)cos(ra1 - ra2))
# For small angles, this simplifies to the distance formula in RA/Dec space:
delta_ra = ra_g_rad - ra_a_rad
delta_dec = dec_g_rad - dec_a_rad
separation_rad = np.sqrt(delta_ra**2 * np.cos(dec_g_rad)**2 + delta_dec**2)

# Convert radians to arcseconds
separation_arcsec = separation_rad * units.rad.to(units.arcseconds)

print(f"--- Apophis Position Comparison (2029-04-13) ---")
print(f"Time of Maximum Altitude: {t_max_alt.utc_iso()[:19]} UTC")
print(f"Maximum Altitude: {altitudes[max_alt_index]:.2f}°")
print("-" * 50)
print(f"Geometric RA/Dec: {geometric_ra_deg[max_alt_index]:.6f}° / {geometric_dec_deg[max_alt_index]:.6f}°")
print(f"Apparent RA/Dec:  {apparent_ra_deg[max_alt_index]:.6f}° / {apparent_dec_deg[max_alt_index]:.6f}°")
print("-" * 50)
print(f"Angular difference (Geometric vs. Apparent): {separation_arcsec:.3f} arcseconds")

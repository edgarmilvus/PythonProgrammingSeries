
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import rebound
import numpy as np
import sys

# Ensure the simulation runs silently and efficiently
rebound.set_status(sys.stdout, color=False)

# --- 1. Simulation Initialization and Setup ---

# Initialize the core simulation object
sim = rebound.Simulation()

# Define the units for the simulation:
# (Distance, Mass, Time). This standardizes G and simplifies calculations.
sim.units = ('AU', 'Msun', 'year')

# Select the integrator. IAS15 is a high-order, adaptive, non-symplectic
# integrator widely used for high-precision, long-term planetary simulations.
sim.integrator = "IAS15"

# Set a nominal timestep (dt) in years. IAS15 is adaptive, but setting a
# small initial dt helps stabilize the initial integration step.
sim.dt = 0.001

# --- 2. Adding Particles (The System Bodies) ---

# Particle 0: The Central Star (The Sun)
# Mass is set to 1.0 Solar Mass (Msun).
# By default, this particle is initialized at the origin (0, 0, 0).
sim.add(m=1.0)

# Particle 1: The Orbiting Planet (The Earth)
# Mass of Earth is approximately 3.003e-6 Msun.
# We define its orbit using Keplerian orbital elements relative to the Sun.
# a = Semi-major axis (1.0 AU)
# e = Eccentricity (approx. 0.0167 for Earth)
sim.add(m=3.003e-6, a=1.0, e=0.0167)

# --- 3. Stabilization and Initial Conditions ---

# Crucial step: Move the system into the Center-of-Mass (COM) frame.
# This eliminates linear momentum drift, ensuring the system centroid remains fixed.
sim.move_to_com()

# --- 4. Defining the Integration Parameters ---

T_end = 1.0 # Simulate for exactly 1 Earth year
N_steps = 100 # Number of data points to record
times = np.linspace(0, T_end, N_steps)

# Storage arrays for the Earth's orbital path
x_earth = np.zeros(N_steps)
y_earth = np.zeros(N_steps)

# --- 5. Running the Integration Loop ---

print(f"Starting simulation for {T_end} year(s) with {N_steps} data points...")

for i, t in enumerate(times):
    # Integrate the system forward to the time 't'
    sim.integrate(t)
    
    # Store the current position of the Earth (Particle 1)
    # Note: sim.particles is a list-like object holding all bodies.
    earth = sim.particles[1]
    x_earth[i] = earth.x
    y_earth[i] = earth.y

# --- 6. Output and Verification ---

print("\n--- Simulation Results ---")
print(f"Final Time reached: {sim.t:.6f} years")

# Access the final state of the Earth particle
final_earth = sim.particles[1]

# Display the final coordinates and velocity
print("\nFinal State of Earth (AU, AU/year):")
print(f"Position (x, y, z): ({final_earth.x:.6f}, {final_earth.y:.6f}, {final_earth.z:.6f})")
print(f"Velocity (vx, vy, vz): ({final_earth.vx:.6f}, {final_earth.vy:.6f}, {final_earth.vz:.6f})")

# Verify orbital parameters (should be close to initial values)
print(f"Final Semi-Major Axis (a): {final_earth.a:.6f} AU")
print(f"Final Eccentricity (e): {final_earth.e:.6f}")

# Check the total energy (should be conserved very closely)
print(f"Total Energy at Start: {sim.calculate_energy():.12f}")
sim.integrate(T_end) # Re-integrate to ensure final energy calculation is precise
print(f"Total Energy at End:   {sim.calculate_energy():.12f}")

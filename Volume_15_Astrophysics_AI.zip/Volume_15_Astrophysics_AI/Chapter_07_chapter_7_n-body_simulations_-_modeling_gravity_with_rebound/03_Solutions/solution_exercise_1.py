
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import rebound
import numpy as np
import matplotlib.pyplot as plt

# --- System Parameters ---
M_sun = 1.0
M_Jup = 9.5e-4
M_Sat = 2.8e-4
a_Jup = 5.2
a_Sat = 9.5
T_max = 1000.0  # years
T_log_interval = 10.0 # years

# Jupiter's Period (P_J) calculation for WHFast timestep
# P_J = sqrt(a^3 / M_total) ~ sqrt(5.2^3 / 1.0) approx 11.86 years
P_J = np.sqrt(a_Jup**3 / M_sun)
dt_whfast = P_J / 20.0 # Fixed timestep: 1/20th of Jupiter's period

def setup_simulation():
    """Initializes the simulation with Sun, Jupiter, and Saturn."""
    sim = rebound.Simulation()
    sim.units = ('yr', 'AU', 'Msun')
    sim.add(m=M_sun) # Sun (index 0)
    # Jupiter
    sim.add(m=M_Jup, a=a_Jup, e=0.0, inc=0.0, primary=sim.particles[0])
    # Saturn
    sim.add(m=M_Sat, a=a_Sat, e=0.0, inc=0.0, primary=sim.particles[0])
    sim.move_to_com()
    return sim

# --- Part A: IAS15 (Adaptive, Non-Symplectic) ---
sim_ias15 = setup_simulation()
sim_ias15.integrator = "IAS15"
E0_ias15 = sim_ias15.total_energy()
times_ias15 = np.arange(0, T_max + T_log_interval, T_log_interval)
energies_ias15 = []

for time in times_ias15:
    sim_ias15.integrate(time)
    energies_ias15.append(sim_ias15.total_energy())

E_ias15 = np.array(energies_ias15)
dE_E0_ias15 = np.abs((E_ias15 - E0_ias15) / E0_ias15)

# --- Part B: WHFast (Fixed Step, Symplectic) ---
sim_whfast = setup_simulation()
sim_whfast.integrator = "whfast"
sim_whfast.dt = dt_whfast
E0_whfast = sim_whfast.total_energy()
energies_whfast = []

for time in times_ias15: # Use the same logging times
    sim_whfast.integrate(time)
    energies_whfast.append(sim_whfast.total_energy())

E_whfast = np.array(energies_whfast)
dE_E0_whfast = np.abs((E_whfast - E0_whfast) / E0_whfast)

# --- Analysis and Plotting ---
plt.figure(figsize=(10, 6))
plt.plot(times_ias15, dE_E0_ias15, label='IAS15 (Adaptive)', marker='o', linestyle='--')
plt.plot(times_ias15, dE_E0_whfast, label='WHFast (Symplectic)', marker='x', linestyle='-')
plt.yscale('log')
plt.xlabel('Time (Years)')
plt.ylabel('Fractional Energy Conservation Error $|\Delta E / E_0|$')
plt.title('Energy Conservation Comparison: IAS15 vs. WHFast over 1000 Years')
plt.legend()
plt.grid(True, which="both", ls="--")
plt.show()

# --- Detailed Analysis ---
print(f"\n--- Integrator Analysis ---")
print(f"Initial Energy (E0): {E0_ias15:.6e}")
print(f"WHFast Timestep (dt): {dt_whfast:.4f} years")
print(f"Final Fractional Error (IAS15): {dE_E0_ias15[-1]:.2e}")
print(f"Final Fractional Error (WHFast): {dE_E0_whfast[-1]:.2e}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import rebound
import numpy as np
import matplotlib.pyplot as plt

# --- System Parameters ---
M_A = 1.0 # Star A
M_B = 0.5 # Star B
M_C = 0.3 # Star C (Perturber)
a_in = 1.0 # Inner binary semi-major axis
a_out = 100.0 # Outer perturber semi-major axis
i_out = np.deg2rad(85.0) # High mutual inclination

# Calculate Inner Period (P_in)
P_in = np.sqrt(a_in**3 / (M_A + M_B))
T_total = 10000.0 * P_in # Total run time
N_log_intervals = 50.0 # Log every 50 P_in
T_log_interval = N_log_intervals * P_in

# --- Initialization ---
sim = rebound.Simulation()
sim.units = ('yr', 'AU', 'Msun')
sim.integrator = "IAS15"

# 1. Star A (Primary of inner binary)
sim.add(m=M_A)
# 2. Star B (Inner binary companion, relative to A)
sim.add(m=M_B, a=a_in, e=0.0, inc=0.0, primary=sim.particles[0])

# Move to COM to correctly define the third body's orbit
sim.move_to_com()

# 3. Star C (Perturber, relative to the inner binary's COM)
# We set the outer orbit using the `rebound.Orbit` object
# The total mass of the inner binary is M_A + M_B = 1.5
sim.add(m=M_C, a=a_out, e=0.1, inc=i_out, primary=sim.particles[0]) 
# Note: When using add() after move_to_com(), REBOUND automatically calculates 
# the initial conditions relative to the system's new COM (which is the origin).

# --- Data Collection Loop ---
times = []
eccentricities = []
inclinations = []
time = 0.0

while time < T_total:
    sim.integrate(time)
    
    # Calculate orbits relative to Star A (index 0) for the inner binary (index 1)
    orbits = sim.calculate_orbits(primary=sim.particles[0])
    
    # Extract inner binary elements (orbits[0] corresponds to particle 1 relative to 0)
    eccentricities.append(orbits[0].e)
    # Convert inclination from radians to degrees for analysis
    inclinations.append(np.rad2deg(orbits[0].inc))
    times.append(sim.t)
    
    time += T_log_interval

# --- Visualization and Analysis ---
fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

# Plot 1: Eccentricity
axes[0].plot(np.array(times) / P_in, eccentricities, label='Eccentricity (e)', color='blue')
axes[0].set_ylabel('Eccentricity (e)')
axes[0].set_title('Kozai-Lidov Oscillation in a Hierarchical Triple System')
axes[0].grid(True, linestyle='--')

# Plot 2: Inclination
axes[1].plot(np.array(times) / P_in, inclinations, label='Inclination (i)', color='red')
axes[1].set_ylabel('Inclination (i) [degrees]')
axes[1].set_xlabel(f'Time (Inner Binary Periods, $P_{{in}}$)')
axes[1].grid(True, linestyle='--')

plt.tight_layout()
plt.show()

# --- Analysis of Period ---
# Calculate the period of the secular oscillation
# We look for the time between two peaks in eccentricity
e_array = np.array(eccentricities)
peaks_indices = np.where((e_array[:-2] < e_array[1:-1]) & (e_array[1:-1] > e_array[2:]))[0]
if len(peaks_indices) >= 2:
    period_secular_indices = peaks_indices[1] - peaks_indices[0]
    period_secular_time = period_secular_indices * N_log_intervals
    print(f"\n--- Kozai-Lidov Analysis ---")
    print(f"Inner Period (P_in): {P_in:.3f} years")
    print(f"Approximate Secular Oscillation Period: {period_secular_time:.0f} P_in")


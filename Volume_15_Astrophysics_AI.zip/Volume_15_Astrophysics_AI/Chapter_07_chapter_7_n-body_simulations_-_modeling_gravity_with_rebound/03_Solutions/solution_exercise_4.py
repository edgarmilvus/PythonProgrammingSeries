
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import rebound
import numpy as np
import matplotlib.pyplot as plt

# --- System Setup ---
M_star = 1.0
M_planet = 1e-3
a_planet = 5.0
M_asteroid = 0.0
e_asteroid = 0.8

# Planet Period calculation
P_planet = np.sqrt(a_planet**3 / M_star)
T_total = 100.0 * P_planet # Run for 100 planet periods
T_interval = P_planet / 10.0 # Log every 1/10th of a period

def setup_system():
    sim = rebound.Simulation()
    sim.units = ('yr', 'AU', 'Msun')
    sim.integrator = "IAS15"
    
    sim.add(m=M_star) # Index 0: Star
    sim.add(m=M_planet, a=a_planet, e=0.0, primary=sim.particles[0]) # Index 1: Planet
    
    # Asteroid (Index 2) - highly eccentric orbit
    # Initialize with argument of periapsis (omega) = 0 for simplicity
    sim.add(m=M_asteroid, a=a_planet, e=e_asteroid, primary=sim.particles[0], omega=0.0)
    
    sim.move_to_com()
    return sim

def orbital_data_generator(sim, total_time, interval):
    """
    Generator function that yields the embedding vector (e, omega, E_total) 
    of the asteroid at specified time intervals.
    """
    time = 0.0
    
    while time < total_time:
        sim.integrate(time)
        
        # Calculate orbital elements relative to the primary (Star, index 0)
        orbits = sim.calculate_orbits(primary=sim.particles[0])
        
        # Asteroid is the second orbit object (index 1 in orbits list, index 2 particle)
        asteroid_orbit = orbits[1]
        
        e = asteroid_orbit.e
        omega = asteroid_orbit.omega # Argument of Periapsis (radians)
        E_total = sim.total_energy()
        
        # Yield the embedding vector as a tuple
        yield (sim.t, e, omega, E_total)
        
        time += interval

# --- Data Collection and Processing ---
sim = setup_system()

# 1. Execute the generator and collect all data
# The generator runs the simulation iteratively
raw_data = list(orbital_data_generator(sim, T_total, T_interval))

# 2. Use a single list comprehension to unpack the collected tuples
times, eccentricities, periapsis_arguments, total_energies = [
    list(x) for x in zip(*raw_data)
]

# Convert omega from radians to degrees for plotting clarity
periapsis_arguments_deg = np.rad2deg(periapsis_arguments)

# --- Visualization and Analysis ---
plt.figure(figsize=(10, 6))
plt.plot(times, periapsis_arguments_deg, label='Argument of Periapsis ($\omega$)', color='purple')
plt.xlabel('Time (Years)')
plt.ylabel('Argument of Periapsis $\omega$ (Degrees)')
plt.title('Secular Precession of Asteroid Orbit Induced by Planet')
plt.grid(True, linestyle='--')
plt.show()

print(f"\n--- Generator Analysis ---")
print(f"Total data points collected: {len(times)}")
print(f"Initial Omega: {periapsis_arguments_deg[0]:.2f} degrees")
print(f"Final Omega: {periapsis_arguments_deg[-1]:.2f} degrees")
print("The plot shows the long-term rotation (precession) of the asteroid's orbit.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import rebound
import numpy as np

# --- System Setup ---
M_star = 1.0
a_planets = [1.0, 1.6, 2.5] # Initial semi-major axes
M_planet = 1e-5
dt_fixed = 0.01 # Fixed timestep for WHFast

# Calculate initial instability thresholds based on initial semi-major axes
# Threshold_i,i+1 = 0.25 * (a_i + a_{i+1})
thresholds = [0.25 * (a_planets[i] + a_planets[i+1]) for i in range(len(a_planets) - 1)]

def setup_resonant_system():
    """Initializes the star and three planets."""
    sim = rebound.Simulation()
    sim.units = ('yr', 'AU', 'Msun')
    sim.integrator = "whfast"
    sim.dt = dt_fixed
    sim.add(m=M_star) # Index 0: Star

    for a in a_planets:
        # Add planets on near-circular orbits
        sim.add(m=M_planet, a=a, e=0.01, primary=sim.particles[0])

    sim.move_to_com()
    return sim

def check_stability(sim, thresholds):
    """
    Checks if the distance between any adjacent planet pair is below the threshold.
    Returns True if stable, False if unstable.
    """
    # Iterate over adjacent planets (P1, P2), (P2, P3), etc.
    # sim.particles[1:] selects only the planets, skipping the star (index 0)
    planets = sim.particles[1:]
    
    # Use zip to iterate over adjacent pairs efficiently
    for i, (p1, p2) in enumerate(zip(planets[:-1], planets[1:])):
        # Calculate the distance between the two particles
        distance = p1 - p2
        d_mag = distance.d() # Magnitude of the separation vector
        
        if d_mag < thresholds[i]:
            # Instability detected (short-circuit return)
            return False, (i + 1, i + 2) # Return False and the indices of the unstable pair
            
    return True, None # Stable

# --- Simulation Loop ---
sim = setup_resonant_system()
max_steps = 500000
check_interval = 10 # Check stability every 10 integration steps
instability_detected = False

print(f"Starting simulation with WHFast (dt={dt_fixed}).")
print(f"Instability Thresholds: {thresholds}")

for step in range(max_steps):
    # 1. Advance the simulation time
    sim.integrate(sim.t + dt_fixed)
    
    # 2. Check stability criterion
    if step % check_interval == 0:
        is_stable, unstable_pair = check_stability(sim, thresholds)
        
        if not is_stable:
            instability_detected = True
            p1_idx, p2_idx = unstable_pair
            
            print("\n--- INSTABILITY DETECTED ---")
            print(f"Time of instability: {sim.t:.2f} years")
            print(f"Particles involved (P{p1_idx}, P{p2_idx}) breached the threshold.")
            print(f"Distance between P{p1_idx} and P{p2_idx}: {(sim.particles[p1_idx] - sim.particles[p2_idx]).d():.4f} AU")
            print(f"Required threshold for this pair: {thresholds[p1_idx-1]:.4f} AU")
            
            # 3. Halt the simulation
            break

if not instability_detected:
    print(f"\nSimulation finished after {sim.t:.2f} years without instability.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import rebound
import numpy as np

# --- System Parameters ---
M_sun = 1.0
M_planet = 1e-3
a_planet = 5.0
M_moon = 0.0
a_moon_initial = 0.01

# Moon Period calculation (relative to planet mass)
P_moon = np.sqrt(a_moon_initial**3 / M_planet) 
T_run = 100.0 * P_moon # Run time: 100 moon periods

# Instability Criteria
A_TOLERANCE = 1.1 # 10% change in semi-major axis
E_THRESHOLD = 0.9 # Eccentricity limit

def run_simulation_and_check(inclination_deg):
    """Initializes, runs, and checks stability for a given inclination."""
    try:
        sim = rebound.Simulation()
        sim.units = ('yr', 'AU', 'Msun')
        sim.integrator = "IAS15"

        # 1. Add Sun (Index 0) and Planet (Index 1)
        sim.add(m=M_sun)
        sim.add(m=M_planet, a=a_planet, e=0.0, primary=sim.particles[0])
        
        # 2. Add Moon (Index 2) relative to the Planet (Index 1)
        sim.add(m=M_moon, a=a_moon_initial, e=0.0, inc=np.deg2rad(inclination_deg), 
                primary=sim.particles[1])
        
        sim.move_to_com()
        
        # Run simulation
        sim.integrate(T_run)
        
        # 3. Check final state of the Moon (particle index 2) relative to the Planet (index 1)
        # Use calculate_orbits to get elements relative to the primary (Planet)
        orbits = sim.calculate_orbits(primary=sim.particles[1])
        moon_orbit = orbits[0] # The Moon is the first particle relative to the Planet

        a_final = moon_orbit.a
        e_final = moon_orbit.e

        # Check instability criteria
        if a_final > a_moon_initial * A_TOLERANCE or e_final > E_THRESHOLD:
            return False, a_final, e_final # Unstable
        else:
            return True, a_final, e_final # Stable
            
    except rebound.Escape as error:
        # Catch cases where REBOUND detects an escape
        return False, None, None
    except Exception as e:
        # Catch other errors (e.g., collision if mass was non-zero)
        print(f"Error during simulation: {e}")
        return False, None, None

# --- Stage 1: Initial 5-degree Sweep ---
initial_sweep_inclinations = np.arange(0, 91, 5)
results_5deg = {}
critical_window_start = None

print("--- Stage 1: 5-degree Sweep (0 to 90 degrees) ---")
for i_deg in initial_sweep_inclinations:
    is_stable, a_f, e_f = run_simulation_and_check(i_deg)
    results_5deg[i_deg] = is_stable
    print(f"Inclination {i_deg} deg: {'Stable' if is_stable else 'UNSTABLE'} (a={a_f:.4f}, e={e_f:.4f})")
    
    # Identify the transition point
    if not is_stable and critical_window_start is None:
        # The transition must have occurred in the previous 5-degree window
        critical_window_start = i_deg - 5
        critical_window_end = i_deg
        
# Handle case where instability starts at 0 or 5 degrees
if critical_window_start is None:
    print("System appears stable up to 90 degrees or instability starts below 0.")
    exit()

# --- Stage 2: Refined 1-degree Sweep ---
refined_inclinations = np.arange(critical_window_start + 1, critical_window_end + 1, 1)
critical_inclination = None

print(f"\n--- Stage 2: Refined 1-degree Sweep ({critical_window_start+1} to {critical_window_end} degrees) ---")

for i_deg in refined_inclinations:
    is_stable, a_f, e_f = run_simulation_and_check(i_deg)
    print(f"Inclination {i_deg} deg: {'Stable' if is_stable else 'UNSTABLE'} (a={a_f:.4f}, e={e_f:.4f})")

    if not is_stable:
        critical_inclination = i_deg
        break # Found the lowest unstable inclination

# --- Final Report ---
print("\n=======================================================")
if critical_inclination is not None:
    print(f"The critical inclination (i_c) for this system is approximately:")
    print(f"{critical_inclination} degrees (Lowest inclination resulting in instability).")
else:
    print("Could not locate the critical inclination within the expected window.")
print("=======================================================")

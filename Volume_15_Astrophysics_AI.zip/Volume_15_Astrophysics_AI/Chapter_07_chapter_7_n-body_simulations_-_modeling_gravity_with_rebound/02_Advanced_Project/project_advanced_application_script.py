
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import rebound
import numpy as np
import os

# --- Configuration and Setup ---

def setup_simulation(M_A, M_B, a_bin, e_bin, M_P, a_P, e_P, inc_P):
    """Initializes the REBOUND simulation for a circumbinary planet system.
    
    Parameters are defined in Solar Masses (Msun), AU, and Years (yr).
    """
    
    # 1. Initialize the simulation object
    sim = rebound.Simulation()
    sim.units = ('yr', 'AU', 'Msun')
    sim.integrator = "IAS15"  # High-precision integrator suitable for close encounters and high eccentricity
    sim.dt = 0.05  # Initial timestep in years (IAS15 uses adaptive steps, but this is a starting point)
    sim.testparticle_correction = False # Standard N-body calculation (all masses affect each other)

    # 2. Add the central binary stars (A and B)
    # We use the binary's orbital elements to add them relative to their barycenter.
    
    # Calculate the relative masses and distances for the binary
    m_total_bin = M_A + M_B
    mu_A = M_B / m_total_bin  # Fractional mass of Star A's contribution to the binary separation
    mu_B = M_A / m_total_bin  # Fractional mass of Star B's contribution
    
    # Star A: Positioned opposite Star B relative to the barycenter
    # Initial setup places the bodies on the x-axis at periastron (e=0.6 requires careful placement)
    # For simplicity, we initialize them at a point that satisfies the orbital elements later.
    # REBOUND's 'add' function handles conversion from orbital elements to Cartesian coordinates 
    # relative to the primary, but here we define them relative to the binary barycenter (primary=None).
    
    # Calculate the initial position (x) and velocity (vy) for a circular orbit approximation, 
    # then REBOUND converts this to the highly eccentric orbit defined by 'a_bin' and 'e_bin'.
    
    # NOTE: To correctly initialize an eccentric binary relative to the barycenter using 
    # Cartesian coordinates, we must explicitly calculate the initial state vector.
    # A simpler, robust method is to use REBOUND's built-in orbital element solver for the binary:
    
    # Add Star A (Primary of the binary system)
    sim.add(m=M_A, hash='StarA') 
    
    # Add Star B (Companion, orbiting Star A)
    sim.add(m=M_B, a=a_bin, e=e_bin, primary=sim.particles[0], hash='StarB')
    
    # 3. Add the circumbinary planet (P)
    # The planet is added relative to the system's barycenter (default behavior when primary is not specified).
    sim.add(m=M_P, a=a_P, e=e_P, inc=inc_P, hash='Planet')
    
    # 4. Center the simulation on the system's barycenter
    # This stabilizes the simulation and ensures the total momentum vector is zero.
    sim.move_to_com() 
    
    return sim

def run_stability_analysis(sim, t_max, N_outputs):
    """Runs the simulation, integrates, and records orbital data relative to the binary barycenter."""
    
    times = np.linspace(0, t_max, N_outputs)
    
    # Data storage arrays
    a_planet = np.zeros(N_outputs)
    e_planet = np.zeros(N_outputs)
    
    # Get the particle index for the planet
    planet_index = sim.particles.index_of_hash('Planet')
    
    # Simulation loop
    for i, t in enumerate(times):
        # Integrate to the next time step
        sim.integrate(t)
        
        # --- CRITICAL STEP: Dynamic Barycenter Calculation ---
        
        # 1. Define the binary barycenter (primary reference frame)
        # Find the center of mass (COM) of Star A and Star B at the current time 't'
        pA = sim.particles[sim.particles.index_of_hash('StarA')]
        pB = sim.particles[sim.particles.index_of_hash('StarB')]
        
        m_bin_total = pA.m + pB.m
        
        # Calculate barycenter position (x_com = sum(m*x) / sum(m))
        com_x = (pA.m * pA.x + pB.m * pB.x) / m_bin_total
        com_y = (pA.m * pA.y + pB.m * pB.y) / m_bin_total
        com_z = (pA.m * pA.z + pB.m * pB.z) / m_bin_total
        
        # Calculate barycenter velocity (v_com = sum(m*v) / sum(m))
        com_vx = (pA.m * pA.vx + pB.m * pB.vx) / m_bin_total
        com_vy = (pA.m * pA.vy + pB.m * pB.vy) / m_bin_total
        com_vz = (pA.m * pA.vz + pB.m * pB.vz) / m_bin_total
        
        # 2. Shift the planet's state vector to this barycentric frame
        planet = sim.particles[planet_index]
        
        # Create a temporary ParticleList: [Binary Barycenter (treated as a single mass), Planet]
        temp_parts = rebound.ParticleList(2)
        # Particle 0: The composite mass and state vector of the binary barycenter
        temp_parts[0] = rebound.Particle(m=m_bin_total, x=com_x, y=com_y, z=com_z, 
                                        vx=com_vx, vy=com_vy, vz=com_vz)
        # Particle 1: The planet
        temp_parts[1] = planet 
        
        # Calculate the orbital elements (relative to the barycenter, particle 0)
        # This yields the true, instantaneous orbit of the planet around the binary.
        orbit = temp_parts.calculate_orbits()[0]
        
        # Store the results
        a_planet[i] = orbit.a
        e_planet[i] = orbit.e
        
        # Check for instability (e.g., escape or extreme eccentricity)
        if orbit.e >= 1.0:
            print(f"\n[WARNING] Planet became unbound (e={orbit.e:.4f}) at t={t:.2f} yr.")
            # Fill remaining data with the last stable value and exit loop
            a_planet[i:] = a_planet[i-1] if i > 0 else a_planet[i]
            e_planet[i:] = e_planet[i-1] if i > 0 else e_planet[i]
            break
        
        if i % (N_outputs // 10) == 0:
            print(f"Progress: {100 * i / N_outputs:.1f}% | Time: {t:.2f} yr | a={orbit.a:.3f} AU, e={orbit.e:.3f}")

    return times, a_planet, e_planet

# --- Main Execution Block ---
if __name__ == "__main__":
    print("--- REBOUND Circumbinary Stability Analyzer ---")
    
    # 1. Define System Parameters (A highly eccentric P-type orbit, similar to Kepler-16b setup)
    M_StarA = 1.0     # Solar Masses
    M_StarB = 0.5     # Solar Masses
    a_Binary = 1.0    # AU (Semi-major axis of the binary)
    e_Binary = 0.6    # Eccentricity of the binary (highly eccentric, challenging system)
    
    M_Planet = 1e-4   # Mass of the planet (approx. 1/10th Earth mass)
    a_Planet = 5.0    # AU (Initial semi-major axis of the planet, well outside the binary critical zone)
    e_Planet = 0.05   # Initial eccentricity (nearly circular)
    inc_Planet = 5.0  # Inclination in degrees (introduces 3D coupling)
    
    # Convert inclination to radians for REBOUND
    inc_Planet_rad = np.radians(inc_Planet)
    
    # 2. Simulation Timeline
    T_MAX = 1000.0    # Total simulation time in years
    N_SAMPLES = 2000  # Number of data points to record
    
    # 3. Setup and Run
    try:
        sim = setup_simulation(M_StarA, M_StarB, a_Binary, e_Binary, 
                               M_Planet, a_Planet, e_Planet, inc_Planet_rad)
        
        print(f"\nSimulation initialized. Integrator: {sim.integrator}. Total duration: {T_MAX} yr.")
        
        times, a_data, e_data = run_stability_analysis(sim, T_MAX, N_SAMPLES)
        
        # 4. Final Analysis and Output
        print("\n--- Stability Results ---")
        
        # Calculate the standard deviation of the semi-major axis (a proxy for long-term stability)
        a_std = np.std(a_data)
        e_max = np.max(e_data)
        
        print(f"Initial semi-major axis (a): {a_data[0]:.4f} AU")
        print(f"Final semi-major axis (a): {a_data[-1]:.4f} AU")
        print(f"Maximum eccentricity (e) observed: {e_max:.4f}")
        print(f"Standard Deviation of 'a' over {T_MAX} years: {a_std:.6f}")
        
        # Define stability criteria based on small fluctuations and eccentricity well below 1.0
        if a_std < 0.005 and e_max < 0.7:
            print("CONCLUSION: The system exhibits high long-term orbital stability.")
        elif e_max >= 1.0:
             print("CONCLUSION: INSTABILITY DETECTED. The planet became unbound.")
        else:
            print("CONCLUSION: Marginal stability detected. Significant orbital drift or large eccentricity oscillations observed.")
            
        # Save data for external visualization
        data_out = np.vstack([times, a_data, e_data]).T
        np.savetxt("circumbinary_orbit_evolution.csv", data_out, 
                   header="Time (yr), Semi-major Axis (AU), Eccentricity", comments="#", delimiter=",")
        print("Data saved to circumbinary_orbit_evolution.csv")
        
    except rebound.ReboundError as e:
        print(f"\n[FATAL REBOUND ERROR]: Simulation failed. Details: {e}")


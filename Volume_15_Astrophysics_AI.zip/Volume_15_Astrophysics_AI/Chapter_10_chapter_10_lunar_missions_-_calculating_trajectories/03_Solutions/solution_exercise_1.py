
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np

# 1. Define Physical Constants (using SI units: meters, seconds)
MU_EARTH = 3.986004418e14  # Earth Gravitational Parameter (m^3/s^2)
R_EARTH = 6378.137e3       # Earth Mean Equatorial Radius (m)
LEO_ALTITUDE = 300e3       # LEO Parking Orbit Altitude (m)
R_MOON_AVG = 384.4e6       # Target Apoapsis Distance (m)

# 2. Calculate LEO Radius and Velocity
r_leo = R_EARTH + LEO_ALTITUDE

# V_LEO = sqrt(mu / r)
V_LEO = np.sqrt(MU_EARTH / r_leo)

# 3. Calculate Transfer Orbit Parameters (Hohmann-like transfer)
r_periapsis = r_leo
r_apoapsis = R_MOON_AVG

# Semi-major axis (a) of the transfer ellipse: a = (r_p + r_a) / 2
a_transfer = (r_periapsis + r_apoapsis) / 2

# Calculate Transfer Orbit Velocity (V_TLI) using Vis-viva equation:
# V^2 = mu * (2/r - 1/a)
V_TLI_sq = MU_EARTH * (2 / r_periapsis - 1 / a_transfer)
V_TLI = np.sqrt(V_TLI_sq)

# 4. Determine Delta V TLI
Delta_V_TLI = V_TLI - V_LEO

# Output Formatting
print("--- TLI Baseline Calculation Results ---")
print(f"1. LEO Parking Orbit Radius (r_p): {r_leo / 1e3:.3f} km")
print("-" * 35)

results = {
    "V_LEO (Current Velocity)": V_LEO,
    "V_TLI (Required Transfer Velocity)": V_TLI,
    "Delta_V_TLI (Required Burn Magnitude)": Delta_V_TLI
}

for i, (key, value) in enumerate(results.items(), 2):
    print(f"{i}. {key}: {value:.3f} m/s ({value / 1e3:.3f} km/s)")

print("-" * 35)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

# --- Reusing Constants (km/s) ---
MU_E = 398600.4418
MU_M = 4904.8695
R_M_ORB = 384400.0
R_LEO = 6378.137 + 300.0
R_LLO = 1737.4 + 100.0 # Target LLO radius (100 km altitude)
V_LEO = 7.725          # km/s
V_TLI_MIN = 10.916     # Minimum TLI velocity (km/s)

# Calculate target LLO circular velocity
V_LLO_circ = np.sqrt(MU_M / R_LLO)

# --- Define Integration Logic (Simplified for iteration) ---

# We must define the helper functions again or rely on them being globally available.
# Since this is a standalone solution block, we define the core integration logic inline.

def two_body_eom(t, state_vector, mu):
    r_vec = state_vector[:3]
    v_vec = state_vector[3:]
    r_mag = np.linalg.norm(r_vec)
    a_vec = -mu * r_vec / r_mag**3
    return np.concatenate((v_vec, a_vec))

def get_moon_state(t):
    n = np.sqrt(MU_E / R_M_ORB**3)
    x_m = R_M_ORB * np.cos(n * t); y_m = R_M_ORB * np.sin(n * t)
    vx_m = -R_M_ORB * n * np.sin(n * t); vy_m = R_M_ORB * n * np.cos(n * t)
    return np.array([x_m, y_m, 0.0]), np.array([vx_m, vy_m, 0.0])

R_SOI = R_M_ORB * (MU_M / MU_E)**(2/5)
def soi_crossing_event(t, y):
    r_sc = y[:3]
    r_moon, _ = get_moon_state(t)
    r_moon_sc = np.linalg.norm(r_sc - r_moon)
    return r_moon_sc - R_SOI
soi_crossing_event.terminal = True
soi_crossing_event.direction = -1

def run_optimization_run(V_TLI):
    """Executes Patched Conics and returns V_inf, T_flight, and Delta V TLI."""
    
    # 1. Calculate Delta V TLI
    Delta_V_TLI = V_TLI - V_LEO
    
    # Initial state (V_TLI along Y-axis)
    y0_e = np.array([R_LEO, 0.0, 0.0, 0.0, V_TLI, 0.0])
    
    # Phase 1 Integration (Earth-centric)
    t_span_e = [0, 10 * 24 * 3600] # Max 10 days
    sol_e = solve_ivp(two_body_eom, t_span_e, y0_e, args=(MU_E,), 
                      method='RK45', events=soi_crossing_event, rtol=1e-10)

    if sol_e.t_events[0].size == 0:
        return Delta_V_TLI, np.nan, np.nan # Failed capture
    
    t_soi = sol_e.t_events[0][0]
    y_soi_e = sol_e.y_events[0][0]
    
    # Get Moon state and transform to MCI frame
    R_M_soi, V_M_soi = get_moon_state(t_soi)
    V_M_centric_vec = y_soi_e[3:] - V_M_soi
    
    # V_inf is the magnitude of the velocity vector in the MCI frame
    V_inf = np.linalg.norm(V_M_centric_vec)
    
    # 2. Calculate Delta V LOI
    # V_perilune^2 = V_inf^2 + 2*mu_moon / R_LLO
    V_perilune = np.sqrt(V_inf**2 + 2 * MU_M / R_LLO)
    Delta_V_LOI = V_perilune - V_LLO_circ
    
    return Delta_V_TLI, Delta_V_LOI, t_soi

# --- Optimization Loop ---
V_TLI_range = np.linspace(V_TLI_MIN, V_TLI_MIN + 0.100, 10) # 10 points up to +100 m/s (0.1 km/s)
optimization_results = []

print("--- Running TLI Velocity Optimization ---")

for V_TLI_km_s in V_TLI_range:
    dv_tli, dv_loi, t_flight = run_optimization_run(V_TLI_km_s)
    
    if not np.isnan(dv_loi):
        dv_total = dv_tli + dv_loi
        optimization_results.append({
            'V_TLI (km/s)': V_TLI_km_s,
            'Flight Time (hrs)': t_flight / 3600,
            'DV_TLI (km/s)': dv_tli,
            'DV_LOI (km/s)': dv_loi,
            'DV_Total (km/s)': dv_total
        })

df_opt = pd.DataFrame(optimization_results)

# Identify optimal point
optimal_row = df_opt.loc[df_opt['DV_Total (km/s)'].idxmin()]

print(df_opt.to_markdown(index=False, floatfmt=".4f"))
print("\n--- Optimal Solution ---")
print(f"Optimal V_TLI: {optimal_row['V_TLI (km/s)']:.4f} km/s")
print(f"Minimum Total Delta V: {optimal_row['DV_Total (km/s)']:.4f} km/s")

# Visualization of Trade-off
plt.figure(figsize=(10, 6))
plt.plot(df_opt['V_TLI (km/s)'], df_opt['DV_TLI (km/s)'], label='DV TLI Cost', marker='o')
plt.plot(df_opt['V_TLI (km/s)'], df_opt['DV_LOI (km/s)'], label='DV LOI Cost', marker='s')
plt.plot(df_opt['V_TLI (km/s)'], df_opt['DV_Total (km/s)'], label='DV Total', marker='^', linewidth=2, color='black')
plt.scatter(optimal_row['V_TLI (km/s)'], optimal_row['DV_Total (km/s)'], color='red', s=100, zorder=5, label='Optimal Point')

plt.title('TLI Velocity Optimization: Trade-off between TLI and LOI Costs')
plt.xlabel('Initial TLI Velocity Magnitude (km/s)')
plt.ylabel('Delta V Cost (km/s)')
plt.grid(True)
plt.legend()
plt.show()

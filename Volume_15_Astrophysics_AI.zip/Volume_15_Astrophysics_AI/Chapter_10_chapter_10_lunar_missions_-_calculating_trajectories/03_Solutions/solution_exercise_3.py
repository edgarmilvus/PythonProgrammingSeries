
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from scipy.integrate import solve_ivp
import numpy as np
import matplotlib.pyplot as plt

# --- CR3BP Constants (Normalized Units) ---
MU_E_PHYS = 3.986004418e14  # m^3/s^2
MU_M_PHYS = 4.9048695e12    # m^3/s^2
R_EM_PHYS = 384400e3        # m (Characteristic Length L*)
R_LEO_PHYS = 6378.137e3 + 300e3 # m

# 1. Normalization Factors
MU_TOTAL = MU_E_PHYS + MU_M_PHYS
MU_STAR = MU_M_PHYS / MU_TOTAL
L_STAR = R_EM_PHYS
T_STAR = np.sqrt(L_STAR**3 / MU_TOTAL)
V_STAR = L_STAR / T_STAR

# TLI velocity (from Ex 1, m/s)
V_TLI_PHYS = 10916.35

# 2. RTBP EOM Implementation
def rtbp_eom(t, state_vector, mu_star):
    # state_vector = [x, y, z, dx, dy, dz]
    x, y, z, dx, dy, dz = state_vector
    
    # Earth (P1) is at (-mu_star, 0, 0)
    # Moon (P2) is at (1 - mu_star, 0, 0)
    
    r1_vec = np.array([x + mu_star, y, z])
    r2_vec = np.array([x - (1 - mu_star), y, z])
    
    r1_mag = np.linalg.norm(r1_vec)
    r2_mag = np.linalg.norm(r2_vec)
    
    r1_cubed = r1_mag**3
    r2_cubed = r2_mag**3
    
    # Equations of Motion (Normalized, Rotating Frame)
    # ddot_x - 2*dot_y = x - (1-mu*) * (x+mu*)/r1^3 - mu* * (x-(1-mu*))/r2^3
    ddot_x = 2 * dy + x - \
             (1 - mu_star) * (x + mu_star) / r1_cubed - \
             mu_star * (x - (1 - mu_star)) / r2_cubed
    
    # ddot_y + 2*dot_x = y - (1-mu*) * y/r1^3 - mu* * y/r2^3
    ddot_y = -2 * dx + y - \
             (1 - mu_star) * y / r1_cubed - \
             mu_star * y / r2_cubed
             
    # ddot_z = - (1-mu*) * z/r1^3 - mu* * z/r2^3
    ddot_z = -(1 - mu_star) * z / r1_cubed - mu_star * z / r2_cubed
    
    return np.array([dx, dy, dz, ddot_x, ddot_y, ddot_z])

# 3. Initial Conditions (Conversion to Normalized Rotating Frame)
# Assume TLI burn occurs when SC is on the x-axis, burn along the y-axis (inertial)
# Barycenter is at x=0. Earth is at x = -mu_star.
# SC position relative to Earth: R_LEO_PHYS
x0_inertial = R_LEO_PHYS
y0_inertial = 0
z0_inertial = 0

# Position in rotating frame (relative to barycenter, normalized)
x0_norm = (x0_inertial - MU_STAR * L_STAR) / L_STAR
y0_norm = y0_inertial / L_STAR
z0_norm = z0_inertial / L_STAR

# Velocity in rotating frame (normalized)
# V_rot = V_inertial - omega x R_rot. Normalized omega = 1.
# dx_norm = vx_inertial/V* - y_norm
# dy_norm = vy_inertial/V* + x_norm
vx0_inertial = 0.0
vy0_inertial = V_TLI_PHYS

dx0_norm = vx0_inertial / V_STAR - y0_norm
dy0_norm = vy0_inertial / V_STAR + x0_norm
dz0_norm = 0.0

y0_rtbp = np.array([x0_norm, y0_norm, z0_norm, dx0_norm, dy0_norm, dz0_norm])

# Integration Span (5 days, converted to normalized time)
T_FLIGHT_PHYS = 5.0 * 24 * 3600 # seconds
t_span_norm = [0, T_FLIGHT_PHYS / T_STAR]

# Integration
sol_rtbp = solve_ivp(
    rtbp_eom, t_span_norm, y0_rtbp, 
    args=(MU_STAR,), 
    method='RK45', 
    dense_output=True,
    rtol=1e-12, atol=1e-15
)

# De-normalize results
trajectory_rtbp_norm = sol_rtbp.y.T
trajectory_rtbp_phys = trajectory_rtbp_norm[:, :3] * L_STAR / 1000 # km
time_rtbp_phys = sol_rtbp.t * T_STAR

# Plotting (Focus on XY plane)
plt.figure(figsize=(10, 8))
plt.plot(trajectory_rtbp_phys[:, 0], trajectory_rtbp_phys[:, 1], 
         label='RTBP Trajectory (Rotating Frame)', color='purple')

# Plot primaries (Earth P1, Moon P2)
P1_x = -MU_STAR * L_STAR / 1000
P2_x = (1 - MU_STAR) * L_STAR / 1000
plt.scatter(P1_x, 0, color='blue', marker='o', label='Earth (P1)')
plt.scatter(P2_x, 0, color='gray', marker='o', label='Moon (P2)')

plt.title('TLI Trajectory using Circular Restricted Three-Body Problem (Rotating Frame)')
plt.xlabel('X (km)')
plt.ylabel('Y (km)')
plt.grid(True)
plt.axis('equal')
plt.legend()
plt.show()

# Comparative Analysis (Focus on Moon encounter)
final_r_norm = trajectory_rtbp_norm[-1, :3]
final_v_norm = trajectory_rtbp_norm[-1, 3:]

# Calculate distance to Moon (P2)
r2_final_norm = np.linalg.norm(final_r_norm - np.array([1 - MU_STAR, 0, 0]))
r2_final_phys = r2_final_norm * L_STAR / 1000 # km

# Calculate velocity relative to Moon (P2) in rotating frame
# V_sc_rot = [dx, dy, dz]. V_P2_rot = [0, 0, 0]
v_rel_norm = np.linalg.norm(final_v_norm)
v_rel_phys = v_rel_norm * V_STAR / 1000 # km/s

print("\n--- RTBP Comparative Analysis ---")
print(f"Characteristic Time (T*): {T_STAR:.0f} seconds ({T_STAR/3600:.2f} hours)")
print(f"Normalized Mass Parameter (mu*): {MU_STAR:.6f}")
print(f"Total Integration Time: {time_rtbp_phys[-1] / 3600:.2f} hours")
print(f"Final Distance to Moon (P2): {r2_final_phys:.0f} km")
print(f"Final Relative Velocity (Moon approach): {v_rel_phys:.3f} km/s")

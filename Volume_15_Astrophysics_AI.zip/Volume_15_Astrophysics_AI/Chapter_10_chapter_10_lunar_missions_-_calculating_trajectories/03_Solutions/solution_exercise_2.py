
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from scipy.integrate import solve_ivp
import numpy as np
import matplotlib.pyplot as plt

# --- Constants (km and seconds) ---
MU_E = 398600.4418      # Earth Gravitational Parameter (km^3/s^2)
MU_M = 4904.8695        # Moon Gravitational Parameter (km^3/s^2)
R_E = 6378.137          # Earth Radius (km)
R_M_ORB = 384400.0      # Earth-Moon Average Distance (km)
R_LEO = R_E + 300.0     # LEO Radius (km)

# Mass ratio for SOI calculation
M_EARTH = MU_E / (6.67430e-20) # Approx mass (kg)
M_MOON = MU_M / (6.67430e-20) # Approx mass (kg)

# Calculate SOI Radius (Hill's Sphere approximation)
R_SOI = R_M_ORB * (M_MOON / M_EARTH)**(2/5)

# TLI Velocity from Exercise 1 (converted to km/s)
V_LEO = 7.725  # km/s (from Ex 1: 7725.79 m/s)
V_TLI = 10.916 # km/s (from Ex 1: 10916.35 m/s)
DELTA_V_TLI = V_TLI - V_LEO # 3.190 km/s

# 1. Moon Orbit Model (Simplified Circular Orbit)
def get_moon_state(t):
    """Returns the Moon's position and velocity vectors in ECI frame at time t."""
    n = np.sqrt(MU_E / R_M_ORB**3) # Mean motion (rad/s)
    
    # Assume Moon starts on X-axis at t=0
    x_m = R_M_ORB * np.cos(n * t)
    y_m = R_M_ORB * np.sin(n * t)
    vx_m = -R_M_ORB * n * np.sin(n * t)
    vy_m = R_M_ORB * n * np.cos(n * t)
    
    R_Moon_vec = np.array([x_m, y_m, 0.0])
    V_Moon_vec = np.array([vx_m, vy_m, 0.0])
    return R_Moon_vec, V_Moon_vec

# 2. Equations of Motion (Two-Body Problem)
def two_body_eom(t, state_vector, mu):
    r_vec = state_vector[:3]
    v_vec = state_vector[3:]
    r_mag = np.linalg.norm(r_vec)
    
    a_vec = -mu * r_vec / r_mag**3
    
    return np.concatenate((v_vec, a_vec))

# 3. Coordinate Transformation
def transform_to_moon_frame(r_earth, v_earth, r_moon, v_moon):
    r_moon_centric = r_earth - r_moon
    v_moon_centric = v_earth - v_moon
    return np.concatenate((r_moon_centric, v_moon_centric))

# 4. SOI Event Function (Phase 1: Earth-centric)
def soi_crossing_event(t, y):
    # y = [rx, ry, rz, vx, vy, vz] (Earth-centric)
    r_sc = y[:3]
    r_moon, _ = get_moon_state(t)
    
    r_earth_sc = np.linalg.norm(r_sc)
    r_moon_sc = np.linalg.norm(r_sc - r_moon)
    
    # Event occurs when distance to Moon equals R_SOI
    # We want the function to cross zero when r_moon_sc = R_SOI
    return r_moon_sc - R_SOI

soi_crossing_event.terminal = True
soi_crossing_event.direction = -1 # Trigger when distance decreases (entering SOI)

# --- Integration Setup ---
# Initial state (Earth-centric, starting on X-axis, burn along Y-axis)
r0_e = np.array([R_LEO, 0.0, 0.0])
v0_e = np.array([0.0, V_TLI, 0.0])
y0_e = np.concatenate((r0_e, v0_e))

t_span_e = [0, 5 * 24 * 3600] # Max 5 days

# Phase 1: Earth-Centric Integration
sol_e = solve_ivp(
    two_body_eom, t_span_e, y0_e, 
    args=(MU_E,), 
    method='RK45', 
    events=soi_crossing_event, 
    dense_output=True,
    rtol=1e-10, atol=1e-13
)

# Check if SOI was reached
if sol_e.t_events[0].size == 0:
    print("Error: SOI not reached within 5 days.")
    trajectory_e = sol_e.y.T
    time_e = sol_e.t
else:
    t_soi = sol_e.t_events[0][0]
    y_soi_e = sol_e.y_events[0][0]
    
    # Get Moon state at SOI crossing time
    R_M_soi, V_M_soi = get_moon_state(t_soi)
    
    # Transform state vector to Moon-centric frame
    r_soi_e = y_soi_e[:3]
    v_soi_e = y_soi_e[3:]
    y0_m = transform_to_moon_frame(r_soi_e, v_soi_e, R_M_soi, V_M_soi)

    # Phase 2: Moon-Centric Integration
    t_span_m = [t_soi, t_soi + 1 * 24 * 3600] # Integrate for 1 more day
    
    sol_m = solve_ivp(
        two_body_eom, [t_soi, t_span_m[1]], y0_m, 
        args=(MU_M,), 
        method='RK45', 
        dense_output=True,
        rtol=1e-10, atol=1e-13
    )

    # Combine results for plotting
    trajectory_e = sol_e.y.T
    trajectory_m = sol_m.y.T
    time_e = sol_e.t
    time_m = sol_m.t
    
    # Plotting (2D projection for clarity)
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # Earth
    ax.scatter(0, 0, 0, color='blue', marker='o', label='Earth')
    
    # Moon position at SOI crossing
    ax.scatter(R_M_soi[0], R_M_soi[1], R_M_soi[2], color='gray', marker='o', label='Moon (SOI Time)')

    # Plot Earth Trajectory
    ax.plot(trajectory_e[:, 0], trajectory_e[:, 1], trajectory_e[:, 2], 
            label='Phase 1: Earth-Centric', color='darkorange')
    
    # Plot SOI boundary (approximate circle around Moon)
    u = np.linspace(0, 2 * np.pi, 100)
    x_soi = R_M_soi[0] + R_SOI * np.cos(u)
    y_soi = R_M_soi[1] + R_SOI * np.sin(u)
    ax.plot(x_soi, y_soi, color='gray', linestyle='--', alpha=0.5, label='Moon SOI')
    
    # Plot Moon Trajectory (transformed back to ECI for visualization)
    r_m_eci = trajectory_m[:, :3] + R_M_soi # Simplified: assuming Moon is fixed at R_M_soi for this short phase
    ax.plot(r_m_eci[:, 0], r_m_eci[:, 1], r_m_eci[:, 2], 
            label='Phase 2: Moon-Centric (ECI View)', color='green')

    ax.scatter(r_soi_e[0], r_soi_e[1], r_soi_e[2], color='red', marker='*', s=100, label='SOI Switch Point')

    ax.set_title(f'Patched Conics TLI Trajectory (Total Flight Time: {t_soi/3600:.2f} hrs)')
    ax.set_xlabel('X (km)')
    ax.set_ylabel('Y (km)')
    ax.set_zlabel('Z (km)')
    ax.legend()
    # Set equal aspect ratio for realistic view (important for 3D plots)
    max_range = np.array([trajectory_e[:, 0].max()-trajectory_e[:, 0].min(), trajectory_e[:, 1].max()-trajectory_e[:, 1].min(), trajectory_e[:, 2].max()-trajectory_e[:, 2].min()]).max() / 2.0
    mid_x = (trajectory_e[:, 0].max()+trajectory_e[:, 0].min()) * 0.5
    mid_y = (trajectory_e[:, 1].max()+trajectory_e[:, 1].min()) * 0.5
    mid_z = (trajectory_e[:, 2].max()+trajectory_e[:, 2].min()) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
    plt.show()

print(f"\n--- Patched Conics Results ---")
print(f"Moon SOI Radius calculated: {R_SOI:.2f} km")
if sol_e.t_events[0].size > 0:
    print(f"Time of SOI Crossing: {t_soi / 3600:.2f} hours")
    print(f"Position at SOI (ECI): {r_soi_e/1000:.2f} km")

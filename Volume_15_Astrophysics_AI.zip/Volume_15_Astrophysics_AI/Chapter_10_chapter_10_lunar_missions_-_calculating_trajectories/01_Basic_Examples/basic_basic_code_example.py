
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# --- 1. Define Physical Constants and System Parameters ---

# Gravitational Constant (m^3 kg^-1 s^-2)
G = 6.67430e-11 
# Mass of Earth (kg) - Central body for this simulation
M_EARTH = 5.972e24 
# Standard Gravitational Parameter (mu = G * M)
MU_EARTH = G * M_EARTH

# --- 2. Define the Equations of Motion (The Physics Engine) ---

def ode_system(t, Y):
    """
    Defines the system of first-order differential equations (ODEs).
    
    The state vector Y is structured as:
    Y = [x, y, vx, vy]
    
    The function must return the derivatives dY/dt:
    dY/dt = [dx/dt, dy/dt, dvx/dt, dvy/dt]
          = [vx, vy, ax, ay]
    """
    
    # Unpack the state vector
    x, y, vx, vy = Y
    
    # Calculate the distance (r) from the central body (origin)
    r = np.sqrt(x**2 + y**2)
    
    # Check for singularity (should not happen in real simulation)
    if r == 0:
        return np.zeros_like(Y)
    
    # Calculate the acceleration magnitude (a = mu / r^2)
    # The term MU_EARTH / r**3 is commonly used because when multiplied by 
    # the position vector [x, y], it correctly yields the acceleration vector
    # a = (-mu/r^2) * (r/r) = (-mu/r^3) * r
    accel_magnitude_factor = -MU_EARTH / (r**3)
    
    # Calculate acceleration components (ax and ay)
    ax = accel_magnitude_factor * x
    ay = accel_magnitude_factor * y
    
    # Return the derivatives [dx/dt, dy/dt, dvx/dt, dvy/dt]
    return [vx, vy, ax, ay]

# --- 3. Define Initial Conditions and Time Span ---

# Initial altitude (above Earth's surface) for a LEO (in meters)
ALTITUDE_M = 400e3 
# Earth Radius (m)
R_EARTH = 6371e3 
# Initial radius (position magnitude)
R0 = R_EARTH + ALTITUDE_M 

# Initial position vector: [R0, 0] (starting on the positive x-axis)
x0, y0 = R0, 0 

# Calculate the required velocity for a perfectly circular orbit at R0
# V_circular = sqrt(mu / r)
V_circular = np.sqrt(MU_EARTH / R0)

# Initial velocity vector: [0, V_circular] (tangential to the orbit)
vx0, vy0 = 0, V_circular

# Initial state vector Y0 = [x0, y0, vx0, vy0]
Y0 = [x0, y0, vx0, vy0]

# Time span for the simulation (e.g., 2 orbits)
# Period T = 2 * pi * sqrt(r^3 / mu)
T_PERIOD = 2 * np.pi * np.sqrt(R0**3 / MU_EARTH)
T_SPAN = [0, 2 * T_PERIOD] # Start time 0, End time 2 periods

# --- 4. Perform Numerical Integration ---

# Use the solve_ivp function (Initial Value Problem solver)
# method='RK45' (Runge-Kutta 4(5) is the default and robust choice)
solution = solve_ivp(
    fun=ode_system,      # The function defining the derivatives
    t_span=T_SPAN,       # The time interval to integrate over
    y0=Y0,               # The initial state vector
    rtol=1e-12,          # Relative tolerance for high precision
    atol=1e-12,          # Absolute tolerance
    dense_output=True    # Store intermediate steps for smooth plotting
)

# --- 5. Extract Results and Visualize ---

# Extract the trajectory data
time_points = solution.t
x_trajectory = solution.y[0, :]
y_trajectory = solution.y[1, :]

# Visualization setup
plt.figure(figsize=(8, 8))
plt.plot(x_trajectory / 1e3, y_trajectory / 1e3, label='Satellite Trajectory')
plt.plot(0, 0, 'o', color='blue', markersize=15, label='Earth (Origin)')
plt.xlabel('X Position (km)')
plt.ylabel('Y Position (km)')
plt.title('2D Circular Orbit Simulation (Two-Body Problem)')
plt.axis('equal') # Important for visualizing orbits correctly
plt.grid(True)
plt.legend()
plt.show()

print(f"Simulation completed successfully over {T_SPAN[1]:.2f} seconds.")
print(f"Initial Radius: {R0/1e3:.2f} km")
print(f"Calculated Period: {T_PERIOD:.2f} s ({T_PERIOD/3600:.2f} hours)")

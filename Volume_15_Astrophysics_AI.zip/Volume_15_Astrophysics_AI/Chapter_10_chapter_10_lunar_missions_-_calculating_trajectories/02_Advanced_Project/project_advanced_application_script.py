
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
from scipy.integrate import solve_ivp
from scipy.constants import G

# --- I. Physical Constants and Initial Conditions ---

# Gravitational Parameters (mu = G * M)
MU_EARTH = 3.986004418e14  # Earth standard gravitational parameter (m^3/s^2)
MU_MOON = 4.9048695e12     # Moon standard gravitational parameter (m^3/s^2)

# Distances and Radii
R_EARTH = 6378.137e3       # Equatorial radius of Earth (m)
R_MOON_ORBIT_AVG = 384.4e6 # Average Earth-Moon distance (m)
R_LEO = R_EARTH + 300e3    # Initial Low Earth Orbit altitude (300 km) (m)

# Sphere of Influence (SOI) of the Moon relative to Earth
# R_SOI = R_orbital * (M_secondary / M_primary)^(2/5)
# Using the standard approximation for the Moon's SOI radius (~66,100 km)
R_SOI_MOON = 66.1e6 # meters

# Initial LEO state (Circular orbit, aligned with +Y axis for velocity)
# State vector Y = [x, y, z, vx, vy, vz]
R0_LEO = np.array([R_LEO, 0.0, 0.0]) # Starting on the +X axis
V_LEO = np.sqrt(MU_EARTH / R_LEO)    # Circular velocity formula
V0_LEO = np.array([0.0, V_LEO, 0.0])
Y0_LEO = np.concatenate((R0_LEO, V0_LEO))

# Simulation Time parameters
T_MAX = 5 * 24 * 3600 # Maximum 5 days in seconds

# --- II. Core Dynamics Function (Two-Body Problem relative to Earth) ---

def earth_dynamics(t, Y):
    """
    Calculates the derivatives of the state vector (dY/dt) under the 
    influence of Earth's gravity (Two-Body Approximation, Earth-centric phase).
    Y is the 6-dimensional state vector.
    """
    # Tuple Packing and Unpacking: Separate position and velocity
    R = Y[:3]
    V = Y[3:]
    
    # Calculate radius magnitude (r)
    r_mag = np.linalg.norm(R)
    
    # Calculate acceleration vector (A = dV/dt) using Newton's law of gravitation:
    # a = -mu * r / r^3
    A = -MU_EARTH * R / (r_mag**3)
    
    # dYdt is the 6-dimensional derivative vector: [V, A]
    dYdt = np.concatenate((V, A))
    
    return dYdt

# --- III. Trans-Lunar Injection (TLI) Calculation (DRY Principle) ---

def calculate_tli_burn():
    """
    Calculates the required velocity boost (Delta V) at perigee (LEO) 
    to achieve a transfer orbit (Hohmann-like) with an apogee near the Moon's distance.
    Uses the Vis-viva equation to ensure a single, authoritative calculation of V_transfer.
    """
    # Target semi-major axis (a_transfer) for an apogee at R_MOON_ORBIT_AVG
    r_p = R_LEO                 # Perigee radius (r_p)
    r_a = R_MOON_ORBIT_AVG      # Target Apogee radius (r_a)
    a_transfer = (r_p + r_a) / 2
    
    # Velocity required at perigee (V_p) for the transfer orbit (Vis-viva equation)
    # V = sqrt(mu * (2/r - 1/a))
    V_transfer = np.sqrt(MU_EARTH * (2/R_LEO - 1/a_transfer))
    
    # Delta V required for the burn (V_transfer - V_circular)
    delta_v_tli = V_transfer - V_LEO
    
    print(f"--- TLI Burn Calculation ---")
    print(f"Initial LEO Velocity (V_c): {V_LEO:.3f} m/s")
    print(f"Required Transfer Velocity (V_p): {V_transfer:.3f} m/s")
    print(f"Calculated Delta V TLI: {delta_v_tli:.3f} m/s\n")
    
    # Apply the calculated Delta V to the initial LEO velocity vector (aligned with +Y)
    V_TLI = V0_LEO + np.array([0.0, delta_v_tli, 0.0])
    Y0_TLI = np.concatenate((R0_LEO, V_TLI))
    
    return Y0_TLI

# --- IV. Simulation Control and Event Handling (Middleware Analogy) ---

def moon_soi_event(t, Y):
    """
    Event function for solve_ivp. Triggers when the spacecraft enters the 
    Moon's Sphere of Influence (SOI). This acts as a 'middleware' intercept 
    to stop the integration at the Patched Conics boundary.
    """
    R = Y[:3]
    
    # Assumption for this simplified example: Moon is stationary at [R_MOON_ORBIT_AVG, 0, 0]
    R_MOON_POS = np.array([R_MOON_ORBIT_AVG, 0.0, 0.0])
    
    # Vector from spacecraft to Moon
    R_SC_TO_MOON = R - R_MOON_POS
    r_sc_to_moon_mag = np.linalg.norm(R_SC_TO_MOON)
    
    # Event triggers when distance to Moon equals SOI radius (value crosses zero)
    # Return value is positive outside SOI, zero at boundary, negative inside.
    return r_sc_to_moon_mag - R_SOI_MOON

# Set the event parameters required by solve_ivp
moon_soi_event.terminal = True  # Stop integration when event occurs
moon_soi_event.direction = -1  # Trigger only when crossing from positive (outside) to negative (inside)

# --- V. Execution and Results ---

def run_tli_simulation():
    """
    Main function to execute the TLI simulation and process the results.
    """
    # 1. Calculate and set initial TLI state
    Y0_TLI = calculate_tli_burn()
    
    print(f"Starting TLI Simulation...")
    print(f"Moon SOI Radius: {R_SOI_MOON/1000:.1f} km")
    
    # 2. Integrate the equations of motion using RK45
    solution = solve_ivp(
        fun=earth_dynamics,
        t_span=[0, T_MAX],
        y0=Y0_TLI,
        method='RK45', 
        events=moon_soi_event,
        dense_output=True,
        rtol=1e-9, # Relative tolerance for high precision
        atol=1e-12 # Absolute tolerance
    )

    # 3. Process results based on solution status
    if solution.status == 1:
        print(f"\nSUCCESS: Trajectory reached Moon SOI boundary.")
        
        # Extract the time of the event (the first event, index 0, time index 0)
        t_transfer = solution.t_events[0][0] / (3600 * 24)
        print(f"Transfer Time: {t_transfer:.2f} days")
        
        # Extract the state vector at the moment of SOI entry
        R_final = solution.y_events[0][0][:3]
        V_final = solution.y_events[0][0][3:]
        
        r_final_mag = np.linalg.norm(R_final) / 1000
        v_final_mag = np.linalg.norm(V_final)
        
        print(f"Final Distance from Earth: {r_final_mag:.1f} km")
        print(f"Final Velocity Magnitude: {v_final_mag:.3f} m/s")
        
        # Data preparation for external visualization tools
        print(f"\nTotal trajectory points generated: {len(solution.t)}")
        return solution.t, solution.y.T
        
    else:
        print(f"\nFAILURE: Simulation ended before reaching SOI (Status: {solution.status}).")
        print(f"Reason: {solution.message}")
        return None, None

# Execute the main simulation
if __name__ == "__main__":
    time_points, trajectory_data = run_tli_simulation()
    
    # In a full research environment, this data would be saved 
    # for 3D trajectory plotting using matplotlib or Plotly.
    if trajectory_data is not None:
        print("Trajectory data successfully generated and ready for plotting.")

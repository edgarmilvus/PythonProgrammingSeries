
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
from astropy.coordinates import SkyCoord, Galactic, Ecliptic, ICRS
import astropy.units as u
from astropy.time import Time
import warnings

# Suppress warnings related to Astropy units/frames for clean output
warnings.filterwarnings('ignore', category=u.UnitsWarning)
warnings.filterwarnings('ignore', category=UserWarning)


# --- 1. CONFIGURATION AND INITIAL DATA SIMULATION ---

# Define a specific epoch for the transformations. 
# The Ecliptic frame is time-dependent due to precession.
OBSERVATION_EPOCH = Time("2025-01-01T00:00:00")

# Constraint 1: Target must be close to the Galactic Plane (within 10 degrees)
MAX_GALACTIC_LATITUDE = 10.0 * u.deg
# Constraint 2: Target must be near the Ecliptic North Pole (latitude beta > 80 degrees)
MIN_ECLIPTIC_LATITUDE = 80.0 * u.deg

def create_equatorial_catalog(num_sources=50):
    """
    Generates a synthetic catalog of celestial sources in the ICRS frame.
    ICRS (International Celestial Reference System) is the modern standard 
    for Equatorial coordinates.
    """
    # Generate random RA (0 to 360 degrees) and Dec (-90 to +90 degrees)
    ra_values = np.random.uniform(0, 360, num_sources) * u.deg
    dec_values = np.random.uniform(-90, 90, num_sources) * u.deg
    
    # Manually inject a known source (e.g., a high-latitude galaxy) for diversity
    ra_values[0] = 180.0 * u.deg
    dec_values[0] = 85.0 * u.deg
    
    # Create the Astropy SkyCoord object in the ICRS frame
    icrs_coords = SkyCoord(ra=ra_values, dec=dec_values, frame=ICRS)
    return icrs_coords


# --- 2. CORE TRANSFORMATION AND FILTERING LOGIC ---

def transform_and_filter_targets(initial_catalog):
    """
    Performs chained coordinate transformations and applies multiple constraints 
    to filter the initial catalog down to the final observation list.
    """
    print(f"--- Processing {len(initial_catalog)} sources from ICRS Catalog ---")
    
    # --- Constraint 1: Galactic Plane Proximity ---
    
    # Step 1a: Transform ICRS to Galactic Coordinates
    # The Galactic frame is fixed and does not require an epoch.
    galactic_coords = initial_catalog.transform_to(Galactic())
    
    # Step 1b: Apply Constraint 1: Filter sources near the Galactic Plane (|b| < 10 deg)
    # We use NumPy indexing based on the boolean mask derived from the constraint.
    galactic_filter = np.abs(galactic_coords.b) <= MAX_GALACTIC_LATITUDE
    
    # Filter the original ICRS catalog based on the Galactic constraint
    filtered_icrs_galactic = initial_catalog[galactic_filter]
    
    print(f"-> {np.sum(galactic_filter)} sources passed Galactic Plane proximity filter.")
    
    # --- Constraint 2: Ecliptic Visibility ---
    
    # Step 2a: Define the time-dependent Ecliptic frame
    ecliptic_frame = Ecliptic(obstime=OBSERVATION_EPOCH)
    
    # Step 2b: Transform the *Galactically filtered* ICRS sources to Ecliptic Coordinates
    ecliptic_coords = filtered_icrs_galactic.transform_to(ecliptic_frame)
    
    # Step 2c: Apply Constraint 2: Filter sources near the Ecliptic North Pole (beta > 80 deg)
    # .lat is the Ecliptic latitude (beta).
    ecliptic_filter = ecliptic_coords.lat >= MIN_ECLIPTIC_LATITUDE
    
    print(f"-> {np.sum(ecliptic_filter)} sources passed Ecliptic Pole visibility filter.")
    
    # --- 3. Final Output Generation ---
    
    # Step 3a: Apply the final filter to the ICRS catalog
    final_icrs_catalog = filtered_icrs_galactic[ecliptic_filter]
    
    # Step 3b: Retrieve the corresponding coordinates in the other frames for reporting
    final_galactic_coords = final_icrs_catalog.transform_to(Galactic())
    final_ecliptic_coords = final_icrs_catalog.transform_to(ecliptic_frame)
    
    # Prepare structured output
    results = []
    for i in range(len(final_icrs_catalog)):
        results.append({
            "Source_ID": i + 1,
            "RA_Dec (ICRS)": f"({final_icrs_catalog[i].ra:.3f}, {final_icrs_catalog[i].dec:.3f})",
            "Galactic (l, b)": f"({final_galactic_coords[i].l:.3f}, {final_galactic_coords[i].b:.3f})",
            "Ecliptic (lambda, beta)": f"({final_ecliptic_coords[i].lon:.3f}, {final_ecliptic_coords[i].lat:.3f})"
        })
            
    return results


# --- 3. EXECUTION ---

if __name__ == "__main__":
    
    # Generate the initial catalog of 50 sources
    initial_catalog = create_equatorial_catalog(num_sources=50)
    
    # Perform the chained transformations and filtering
    final_targets = transform_and_filter_targets(initial_catalog)
    
    print("\n--- FINAL OBSERVATION TARGET LIST (Meeting all constraints) ---")
    if final_targets:
        print(f"Total Sources Selected: {len(final_targets)}\n")
        print("{:<5} {:<25} {:<25} {:<25}".format(
            "ID", "ICRS (RA, Dec)", "GALACTIC (l, b)", "ECLIPTIC (lambda, beta)"))
        print("-" * 80)
        for target in final_targets:
            print("{:<5} {:<25} {:<25} {:<25}".format(
                target['Source_ID'], 
                target['RA_Dec (ICRS)'], 
                target['Galactic (l, b)'], 
                target['Ecliptic (lambda, beta)']))
    else:
        print("No sources met both stringent coordinate constraints.")

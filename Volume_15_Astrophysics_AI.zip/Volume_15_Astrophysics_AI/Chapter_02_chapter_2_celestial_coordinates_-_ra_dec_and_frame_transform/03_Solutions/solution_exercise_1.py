
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from astropy.coordinates import SkyCoord, Galactic
from astropy import units as u
import numpy as np

# Input data defined using mixed string units
ra_list = ['10h 45m 03.5s', '03h 12m 58.0s', '17h 45m 40.0s', '22h 00m 11.2s', '06h 30m 00.0s']
dec_list = ['+15d 30m 10.1s', '-45d 05m 22.9s', '-29d 00m 28.1s', '+70d 15m 00.0s', '-05d 00m 00.0s']
object_names = ['Target A', 'Target B', 'Target C', 'Target D', 'Target E']

# 1. Coordinate Definition: Define all targets simultaneously in the ICRS frame
icrs_coords = SkyCoord(ra=ra_list, dec=dec_list, frame='icrs')

# 2. Transformation: Convert the batch to the Galactic frame
galactic_coords = icrs_coords.transform_to(Galactic())

# Extract unitless values for clean formatting
l_deg = galactic_coords.l.to(u.deg).value
b_deg = galactic_coords.b.to(u.deg).value

# 3. Output Formatting
print("--- ICRS to Galactic Transformation Results ---")
print(f"{'Object':<10} | {'Galactic Longitude (l, deg)':<30} | {'Galactic Latitude (b, deg)':<30}")
print("-" * 75)

for name, l, b in zip(object_names, l_deg, b_deg):
    # Output l rounded to three decimal places
    print(f"{name:<10} | {l:30.3f} | {b:30.3f}")

# 4. Data Validation Check: Find target closest to the Galactic Plane (|b| minimum)
abs_b = np.abs(b_deg)
closest_index = np.argmin(abs_b)
closest_target = object_names[closest_index]
min_b = b_deg[closest_index]

print("\n--- Validation Check ---")
print(f"Target closest to the Galactic Plane (smallest |b|): {closest_target}")
print(f"Galactic Latitude (b) for {closest_target}: {min_b:.3f} degrees")

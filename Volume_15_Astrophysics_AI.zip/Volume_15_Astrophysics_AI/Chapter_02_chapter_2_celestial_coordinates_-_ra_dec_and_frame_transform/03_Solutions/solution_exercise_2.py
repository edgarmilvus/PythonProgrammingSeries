
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from astropy.coordinates import SkyCoord, Ecliptic
from astropy import units as u
import numpy as np

raw_targets_deg = [
    (150.123, 25.456), (30.789, -10.111), (270.555, 0.001),
    (95.100, 55.999), (345.001, -5.000), (180.000, 15.000),
    (5.000, 85.000), (200.200, -20.200), (110.110, 30.300),
    (60.600, -60.600)
]

# Separate RA and Dec arrays
ra_deg = [r[0] for r in raw_targets_deg]
dec_deg = [r[1] for r in raw_targets_deg]

# 1. Data Ingestion and Unit Handling: Use u.deg explicitly
icrs_coords = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg, frame='icrs')

# 2. Ecliptic Transformation
ecliptic_coords = icrs_coords.transform_to(Ecliptic())

# 3. Frame Inspection
print("--- Ecliptic Transformation Analysis ---")
print(f"Default Ecliptic Coordinate Representation: {ecliptic_coords.representation_type}")

# 4. Extreme Value Identification (Maximum Ecliptic Latitude beta)
beta_values = ecliptic_coords.lat.to(u.deg).value
max_beta_index = np.argmax(beta_values)

# Extract coordinates of the extreme object
max_beta_icrs_ra = icrs_coords[max_beta_index].ra.deg
max_beta_icrs_dec = icrs_coords[max_beta_index].dec.deg
max_beta_lambda = ecliptic_coords[max_beta_index].lon.deg
max_beta_beta = ecliptic_coords[max_beta_index].lat.deg

print("\n--- Extreme Value Identification ---")
print(f"Target with Maximum Ecliptic Latitude (beta): Index {max_beta_index}")
print(f"Original ICRS (RA, Dec): ({max_beta_icrs_ra:.3f} deg, {max_beta_icrs_dec:.3f} deg)")
print(f"Ecliptic Coordinates (Lambda, Beta): ({max_beta_lambda:.3f} deg, {max_beta_beta:.3f} deg)")

# 5. Coordinate Access (Lambda as a pure NumPy array)
# .to(u.deg).value strips the unit and returns the underlying NumPy array
lambda_np_array = ecliptic_coords.lon.to(u.deg).value

print("\n--- Raw NumPy Array Extraction ---")
print("Ecliptic Longitude (Lambda) as unitless NumPy array:")
print(lambda_np_array)
print(f"Type of extracted array: {type(lambda_np_array)}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from astropy.coordinates import SkyCoord, Galactic
from astropy import units as u
import numpy as np

# Input data simulating output from Agent A
input_data = {
    "source_id": [101, 102, 103],
    "ra_deg": [266.41683, 187.70593, 10.68458],
    "dec_deg": [-29.00781, 12.39115, 41.26901]
}

def transform_to_galactic_agent(input_data):
    """
    Celestial Preprocessor Agent: Transforms ICRS coordinates to Galactic frame
    and performs basic outlier checking, returning a structured dictionary.
    """
    # 6. Simulated Application Context Access
    # This variable represents a configuration setting pulled from the application context.
    TARGET_FRAME = "Galactic"
    print(f"[Agent Context] Target transformation frame set to: {TARGET_FRAME}")

    # 2. Coordinate Handling: Instantiate SkyCoord
    ra = input_data["ra_deg"] * u.deg
    dec = input_data["dec_deg"] * u.deg
    
    icrs_coords = SkyCoord(ra=ra, dec=dec, frame='icrs')

    # 3. Core Transformation
    galactic_coords = icrs_coords.transform_to(Galactic())
    
    # Extract unitless NumPy arrays
    l_deg = galactic_coords.l.to(u.deg).value
    b_deg = galactic_coords.b.to(u.deg).value
    
    # 5. Robust Error Simulation (Outlier Check: |b| > 80 degrees)
    outlier_mask = np.abs(b_deg) > 80.0
    
    if np.any(outlier_mask):
        # Identify the IDs of the outliers
        outlier_ids = np.array(input_data["source_id"])[outlier_mask]
        # Simulated logging/warning
        print(f"[WARNING] Outlier detected: Source IDs {outlier_ids} have |b| > 80 deg. Far from Galactic disk.")

    # 4. Output Structure Generation
    output_data = {
        "source_id": input_data["source_id"],
        "l_deg": l_deg, # NumPy array
        "b_deg": b_deg  # NumPy array
    }
    
    return output_data

# Execution simulation
print("--- Starting Pipeline Agent 2 ---")
processed_data = transform_to_galactic_agent(input_data)

print("\n--- Output Data Structure for Next Agent ---")
for key, value in processed_data.items():
    print(f"{key}: {value}")

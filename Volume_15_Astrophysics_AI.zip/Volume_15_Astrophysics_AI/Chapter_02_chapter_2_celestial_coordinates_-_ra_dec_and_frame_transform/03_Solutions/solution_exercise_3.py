
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from astropy.coordinates import SkyCoord, FK4, ICRS
from astropy.time import Time
from astropy import units as u

# 1. Time Definition
obstime_1965 = Time('1965-01-01 00:00:00', format='utc')

# Barnard's Star B1950 coordinates
ra_b1950 = '17h 57m 48.5s'
dec_b1950 = '+04d 35m 21.0s'

# 2. Coordinate Definition (B1950 in FK4 frame with obstime)
# The FK4 frame handles the B1950 equinox by default, but we specify the
# observation time (1965) to correctly define the coordinate state at that moment.
barnard_b1950 = SkyCoord(
    ra=ra_b1950,
    dec=dec_b1950,
    frame=FK4(obstime=obstime_1965)
)

# 3. Transformation to ICRS (J2000 standard)
# The transformation automatically handles precession from the FK4 frame's
# equinox (B1950) and observation time (1965) to the J2000 standard (ICRS).
barnard_icrs = barnard_b1950.transform_to(ICRS())

# 4. Result Analysis
print("--- Historical FK4 (B1950) to ICRS (J2000) Transformation ---")
print(f"Observation Time: {obstime_1965.isot}")
print(f"\nOriginal B1950 Coordinates (FK4):")
print(f"RA: {barnard_b1950.ra.to_string(unit=u.hour, sep=':', precision=2)}")
print(f"Dec: {barnard_b1950.dec.to_string(unit=u.deg, sep=':', precision=1)}")

print("\nTransformed ICRS (J2000) Coordinates:")
print(f"RA: {barnard_icrs.ra.to_string(unit=u.hour, sep=':', precision=2)}")
print(f"Dec: {barnard_icrs.dec.to_string(unit=u.deg, sep=':', precision=1)}")

# Analysis:
# The RA shifted from 17h 57m to ~17h 58m, and Dec shifted from +04d 35m to ~+04d 42m.
# This represents a substantial shift over 50 years (due to precession and the star's high proper motion).

# 5. Frame Attribute Inspection
print("\n--- Frame Attribute Verification ---")
print(f"FK4 Frame Equinox used for definition: {barnard_b1950.frame.equinox.value}")

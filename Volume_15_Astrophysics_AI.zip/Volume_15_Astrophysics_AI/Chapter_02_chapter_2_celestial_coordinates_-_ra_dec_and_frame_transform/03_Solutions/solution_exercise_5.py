
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from astropy.coordinates import SkyCoord, EarthLocation, AltAz
from astropy.time import Time
from astropy import units as u
import datetime

# 1. Location Definition (CTIO)
ctio = EarthLocation(
    lon=-70.815 * u.deg,
    lat=-30.165 * u.deg,
    height=2200 * u.m
)

# 2. Target Definition (Vega in ICRS)
vega_icrs = SkyCoord(
    ra='18h 36m 56.3s',
    dec='+38d 47m 01.3s',
    frame='icrs'
)

# 3. Interactive Time Input (Simulated)
# We use a fixed, standardized time for reproducible results in an automated environment.
user_time_str = '2025-01-01 04:00:00' 
print("--- Alt/Az Calculation for Vega from CTIO ---")
print(f"Simulating interactive input time (UTC): {user_time_str}")

# Use Time to handle the input string
obstime = Time(user_time_str, format='isot', scale='utc')

# 4. Frame Definition (AltAz)
# AltAz frame requires both the location and the time
altaz_frame = AltAz(obstime=obstime, location=ctio)

# 5. Transformation and Output
vega_altaz = vega_icrs.transform_to(altaz_frame)

# Altitude in DMS format
alt_dms = vega_altaz.alt.to_string(unit=u.deg, sep='dms', precision=1)
# Azimuth in decimal degrees
az_deg = vega_altaz.az.to(u.deg).value

print("\n--- Observation Results ---")
print(f"Observer Location: CTIO")
print(f"Observation Time (UTC): {obstime.isot}")
print(f"Target (Vega) Altitude: {alt_dms}")
print(f"Target (Vega) Azimuth (decimal degrees): {az_deg:.3f} deg")

# 6. Visibility Check
critical_altitude = 30 * u.deg
if vega_altaz.alt < critical_altitude:
    print(f"\n[WARNING] Target is low on the horizon ({vega_altaz.alt:.1f}). Atmospheric extinction may be significant.")
else:
    print(f"\nTarget is high enough for observation (Altitude > {critical_altitude:.0f}).")

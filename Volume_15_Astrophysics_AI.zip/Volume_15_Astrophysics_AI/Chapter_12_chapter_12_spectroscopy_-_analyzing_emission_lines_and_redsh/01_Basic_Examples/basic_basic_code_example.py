
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# 1. Define Universal Constants
# Speed of light (c) in kilometers per second (km/s).
# This constant is essential for translating redshift (a dimensionless ratio) into velocity.
C = 299792.458 

# 2. Define Rest Wavelength (The Theoretical Baseline)
# The H-alpha emission line wavelength (in Angstroms).
# This is the wavelength measured in a laboratory setting (i.e., when the source is stationary).
lambda_rest = 6563.0 

# 3. Define Observed Wavelength (The Simulated Data Input)
# Simulated observation of the H-alpha line from a distant source.
# Note: This observed value (7219.3 Å) is longer than the rest value, indicating redshift.
lambda_observed = 7219.3 

# 4. Calculate Redshift (z)
# The fundamental definition of redshift (z): 
# z = (lambda_observed - lambda_rest) / lambda_rest
# Redshift z is a dimensionless quantity.
redshift_z = (lambda_observed - lambda_rest) / lambda_rest

# 5. Calculate Velocity (v) using the Non-Relativistic Approximation
# For small redshifts (z < 0.1), the velocity (v) is approximated by v = c * z.
# This approximation simplifies the introductory calculation significantly.
velocity_km_s = C * redshift_z

# 6. Output and Interpretation
print(f"--- Astrophysical Redshift Calculation ---")
print(f"Rest Wavelength (Hydrogen H-alpha): {lambda_rest:.2f} Å")
print(f"Observed Wavelength:                {lambda_observed:.2f} Å")
print("-" * 40)
print(f"Calculated Redshift (z):            {redshift_z:.4f}")
print(f"Inferred Recession Velocity (v):    {velocity_km_s:.2f} km/s")

# 7. Relativistic Check (Self-Correction and Context)
# If the calculated velocity is a significant fraction of c (e.g., > 10%), 
# the non-relativistic approximation introduces error.
if velocity_km_s > 0.1 * C:
    print("\n[WARNING] Calculated velocity exceeds 10% of the speed of light.")
    print("A full relativistic calculation is required for accurate results at this high redshift.")
    
    # Calculate relativistic velocity for comparison (optional but instructive)
    # v = c * [((z+1)^2 - 1) / ((z+1)^2 + 1)]
    relativistic_factor = ((redshift_z + 1)**2 - 1) / ((redshift_z + 1)**2 + 1)
    velocity_relativistic = C * relativistic_factor
    print(f"Relativistic Velocity (v_rel):      {velocity_relativistic:.2f} km/s")
    print(f"Difference:                         {velocity_km_s - velocity_relativistic:.2f} km/s")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np

# Simulated input data for the challenge
# Line A: High SNR detection
observed_wavelength_A = 5500.12
amplitude_A = 15.0
noise_std_dev_A = 0.5

# Line B: Low SNR detection
observed_wavelength_B = 6800.50
amplitude_B = 2.5
noise_std_dev_B = 1.0

# Simulated knowledge base (Vector Store lookup result)
# Keys are rounded observed wavelengths, simulating database indexing
spectral_database = {
}

# 1. SNR Calculation Function
def calculate_snr(amplitude, noise_std_dev):
    """Calculates SNR = Amplitude / sigma_noise."""
    if noise_std_dev <= 0:
        return 0.0
    return amplitude / noise_std_dev

# 2 & 3. Agent Modification
def classify_spectrum_weighted(lambda_obs, amplitude, noise_std_dev):
    """
    Modifies the classification agent to incorporate SNR weighting.
    Uses dict.get() for safe retrieval.
    """
    # 1. Calculate SNR (Confidence Score)
    snr = calculate_snr(amplitude, noise_std_dev)

    # 2. Retrieve classification safely (using exact key match for this simulation)
    # Note: In a real system, lambda_obs would be rounded or indexed via a vector search.
    # We use dict.get() as mandated.
    classification = spectral_database.get(lambda_obs, "Unclassified (No Match)")

    # 3. Return the weighted result
    return (classification, snr)

# Test calls
result_A = classify_spectrum_weighted(observed_wavelength_A, amplitude_A, noise_std_dev_A)
result_B = classify_spectrum_weighted(observed_wavelength_B, amplitude_B, noise_std_dev_B)
result_C = classify_spectrum_weighted(9999.99, 10.0, 1.0) # Test for missing key

print("\n--- Retrieval Agent Results ---")
print(f"Observation A (λ={observed_wavelength_A}): Classification='{result_A[0]}', Confidence (SNR)={result_A[1]:.2f}")
print(f"Observation B (λ={observed_wavelength_B}): Classification='{result_B[0]}', Confidence (SNR)={result_B[1]:.2f}")
print(f"Observation C (λ=9999.99): Classification='{result_C[0]}', Confidence (SNR)={result_C[1]:.2f}")

print("\nAnalysis:")
print(f"Result A has high confidence (SNR={result_A[1]:.2f}) because the signal is 30 times the noise.")
print(f"Result B has low confidence (SNR={result_B[1]:.2f}) despite a positive classification, reflecting the poor quality of the measurement.")

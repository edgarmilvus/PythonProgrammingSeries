
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import pandas as pd

# Required constants
SPEED_OF_LIGHT_KMS = 299792.458

# Required input structure
line_data = [
    {'name': 'H-beta', 'rest': 4861.33, 'obs': 6076.66, 'err': 0.08},
    {'name': '[O III]', 'rest': 5006.84, 'obs': 6258.55, 'err': 0.12},
    {'name': 'H-alpha', 'rest': 6562.80, 'obs': 8210.00, 'err': 0.05}
]

# 1. Redshift Calculation Function
def calculate_redshift(lambda_obs, lambda_rest):
    """Calculates redshift z."""
    return (lambda_obs - lambda_rest) / lambda_rest

# Function to calculate redshift uncertainty (Error Propagation)
def calculate_redshift_uncertainty(lambda_obs_err, lambda_rest):
    """
    Calculates uncertainty in z (δz) using:
    δz = (∂z/∂λ_obs) * δλ_obs
    Since z = (λ_obs/λ_rest) - 1, ∂z/∂λ_obs = 1/λ_rest.
    Therefore, δz = δλ_obs / λ_rest.
    """
    return lambda_obs_err / lambda_rest

# 2. Individual Redshifts and Uncertainties
results = []
for line in line_data:
    z = calculate_redshift(line['obs'], line['rest'])
    dz = calculate_redshift_uncertainty(line['err'], line['rest'])
    
    line['z'] = z
    line['dz'] = dz
    line['variance'] = dz**2
    line['weight'] = 1 / line['variance']
    results.append(line)

df = pd.DataFrame(results)

# 3. Weighted Mean Redshift
# Weighted mean z_bar = (Σ w_i * z_i) / (Σ w_i)
sum_wz = np.sum(df['weight'] * df['z'])
sum_w = np.sum(df['weight'])
weighted_mean_z = sum_wz / sum_w

# Uncertainty of the weighted mean: δz_bar = 1 / sqrt(Σ w_i)
weighted_mean_dz = 1 / np.sqrt(sum_w)

# 4. Recession Velocity Function (Relativistic Doppler)
def calculate_velocity(z):
    """Calculates recession velocity v (in km/s) using the relativistic Doppler formula."""
    c = SPEED_OF_LIGHT_KMS
    v_over_c = ((1 + z)**2 - 1) / ((1 + z)**2 + 1)
    return v_over_c * c

# Calculate recession velocity
recession_velocity = calculate_velocity(weighted_mean_z)

# 5. Output
print("\n--- Multi-Line Redshift Analysis ---")
print(df[['name', 'rest', 'obs', 'err', 'z', 'dz']].to_string(index=False, float_format='%.4f'))

print("\n--- Final Kinematic Parameters ---")
print(f"Weighted Mean Redshift (z̄): {weighted_mean_z:.6f} ± {weighted_mean_dz:.6f}")
print(f"Recession Velocity (v): {recession_velocity:.2f} km/s")

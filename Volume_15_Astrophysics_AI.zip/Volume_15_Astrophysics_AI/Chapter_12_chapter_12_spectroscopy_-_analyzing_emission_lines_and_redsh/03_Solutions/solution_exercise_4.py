
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# 1. Feature Vector Definition (Standardized Template: [lambda_A, Amp_A, FWHM_A, ..., lambda_C, Amp_C, FWHM_C])

# Standardized Wavelength Reference Center (e.g., mean of expected observed centers)
WAVE_REF = 7000.0

# 2. Vector Creation (Simulated data, scaled)
# Scaling: Wavelengths are centered relative to WAVE_REF. Amplitudes and FWHM are normalized/scaled.

object_x_features = {
    # Line A (e.g., H-beta)
    'A_obs': 6076.6, 'A_amp': 0.8, 'A_fwhm': 0.05,
    # Line B (e.g., [O III])
    'B_obs': 6258.5, 'B_amp': 1.2, 'B_fwhm': 0.07,
    # Line C (e.g., H-alpha)
    'C_obs': 8210.0, 'C_amp': 2.5, 'C_fwhm': 0.04,
}

# Object Y: Highly similar to X (Quasar candidate)
object_y_features = {
    'A_obs': 6076.9, 'A_amp': 0.75, 'A_fwhm': 0.055,
    'B_obs': 6259.0, 'B_amp': 1.15, 'B_fwhm': 0.072,
    'C_obs': 8211.0, 'C_amp': 2.4, 'C_fwhm': 0.041,
}

# Convert dictionaries to standardized, scaled NumPy vectors
def dict_to_vector(features, ref_wave):
    vector = []
    for line in ['A', 'B', 'C']:
        # Wavelength scaling (relative shift)
        vector.append((features[f'{line}_obs'] - ref_wave) / ref_wave)
        # Amplitude (already relative to continuum)
        vector.append(features[f'{line}_amp'])
        # FWHM (already relative to wavelength, or small value)
        vector.append(features[f'{line}_fwhm'])
    return np.array(vector)

V_X = dict_to_vector(object_x_features, WAVE_REF)
V_Y = dict_to_vector(object_y_features, WAVE_REF)

# 3. Cosine Similarity Implementation
def calculate_similarity(v1, v2):
    """
    Calculates the cosine similarity between two feature vectors.
    Similarity = (A . B) / (||A|| * ||B||)
    """
    dot_product = np.dot(v1, v2)
    norm_v1 = np.linalg.norm(v1)
    norm_v2 = np.linalg.norm(v2)
    
    if norm_v1 == 0 or norm_v2 == 0:
        return 0.0
        
    return dot_product / (norm_v1 * norm_v2)

# 4. Analysis
similarity_score = calculate_similarity(V_X, V_Y)

print(f"Feature Vector V_X (9D):\n{V_X}")
print(f"\nFeature Vector V_Y (9D):\n{V_Y}")
print(f"\nCosine Similarity Score (V_X vs V_Y): {similarity_score:.6f}")

# Comment on classification likelihood
if similarity_score > 0.99:
    classification_comment = "The objects exhibit extremely high spectral similarity, suggesting they belong to the same astrophysical class (e.g., both are Quasars or both are the same type of active galaxy) and likely share a very similar redshift."
elif similarity_score > 0.9:
    classification_comment = "The objects show high spectral similarity, likely belonging to the same broad class, though perhaps exhibiting slight physical differences or measurement variations."
else:
    classification_comment = "The objects show low spectral similarity, suggesting they belong to different astrophysical classes or have vastly different physical properties (e.g., one is a star, the other is a galaxy)."

print(f"\nClassification Likelihood Analysis: {classification_comment}")

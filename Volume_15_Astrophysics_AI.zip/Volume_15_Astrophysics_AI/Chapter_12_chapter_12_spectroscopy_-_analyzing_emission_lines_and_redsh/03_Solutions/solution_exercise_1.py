
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
import matplotlib.pyplot as plt

# 1. Data Simulation
wavelengths = np.linspace(5000, 6000, 1000)
line_center_true = 5550.0
amplitude = 10.0
sigma = 5.0
noise_std = 0.5

# Continuum: Low-order polynomial (simulating a rising background)
continuum = 0.005 * (wavelengths - 5000) + 5.0
# Emission Line (Gaussian)
line_flux = amplitude * np.exp(-0.5 * ((wavelengths - line_center_true) / sigma)**2)
# Noise
noise = np.random.normal(0, noise_std, wavelengths.size)

raw_flux = continuum + line_flux + noise

# 2. Continuum Modeling (3rd degree polynomial fit)
# We assume the edges (5000-5100 and 5900-6000) are line-free.
# For simplicity, we fit the entire range, relying on the low degree to model only the broad trend.
# In professional astronomy, line-free regions (or iterative sigma clipping) are used.
p_coeffs = np.polyfit(wavelengths, raw_flux, 3)
continuum_model = np.poly1d(p_coeffs)(wavelengths)

# 3. Normalization/Subtraction
normalized_flux = raw_flux - continuum_model

# 4. Peak Identification
peak_index = np.argmax(normalized_flux)
lambda_obs_approx = wavelengths[peak_index]

print(f"Approximate observed center wavelength (λ_obs): {lambda_obs_approx:.3f} Å")

# 5. Visualization (Using subplots for clarity)
fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)

# Panel 1: Raw Spectrum and Continuum Model
axes[0].plot(wavelengths, raw_flux, label='Raw Flux + Noise', color='gray', alpha=0.7)
axes[0].plot(wavelengths, continuum_model, label='3rd Degree Continuum Model', color='red', linestyle='--')
axes[0].set_title('Raw Spectrum and Continuum Modeling')
axes[0].legend()
axes[0].set_ylabel('Flux (Arbitrary Units)')

# Panel 2: Normalized Spectrum
axes[1].plot(wavelengths, normalized_flux, label='Normalized Flux (F - F_continuum)', color='blue')
axes[1].axhline(0, color='black', linestyle=':', linewidth=0.5)
axes[1].set_title('Normalized Spectrum (Line Isolation)')
axes[1].set_ylabel('Normalized Flux')

# Panel 3: Normalized Spectrum with Peak Identification
axes[2].plot(wavelengths, normalized_flux, color='blue')
axes[2].plot(lambda_obs_approx, normalized_flux[peak_index], 'ro', label=f'Peak @ {lambda_obs_approx:.3f} Å')
axes[2].set_title('Identified Emission Peak')
axes[2].set_xlabel('Wavelength (Å)')
axes[2].set_ylabel('Normalized Flux')
axes[2].legend()

plt.tight_layout()
plt.show()

# Store normalized data for Exercise 2
data_ex1 = {
    'wavelengths': wavelengths,
    'normalized_flux': normalized_flux,
    'lambda_obs_guess': lambda_obs_approx,
    'amplitude_guess': normalized_flux[peak_index],
    'noise_std': noise_std
}

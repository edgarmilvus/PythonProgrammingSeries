
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from scipy.optimize import curve_fit
from scipy.special import voigt_profile
import numpy as np
import matplotlib.pyplot as plt

# Reuse data from Exercise 1 (assuming the previous code block was executed)
# If running independently, these must be defined:
# wavelengths, normalized_flux, lambda_obs_guess, amplitude_guess, noise_std
if 'data_ex1' not in locals():
    print("WARNING: Running Exercise 2 independently. Simulating data...")
    wavelengths = np.linspace(5000, 6000, 1000)
    normalized_flux = 10 * voigt_profile(wavelengths - 5550, 5, 2) + np.random.normal(0, 0.5, 1000)
    lambda_obs_guess = 5550.0
    amplitude_guess = np.max(normalized_flux)
    noise_std = 0.5
else:
    wavelengths = data_ex1['wavelengths']
    normalized_flux = data_ex1['normalized_flux']
    lambda_obs_guess = data_ex1['lambda_obs_guess']
    amplitude_guess = data_ex1['amplitude_guess']
    noise_std = data_ex1['noise_std']


# 1. Voigt Model Definition
def voigt_model(x, amplitude, center, sigma_G, gamma_L, offset):
    """
    Voigt profile using scipy.special.voigt_profile.
    Note: voigt_profile returns a normalized PDF. We scale it by amplitude
    and add a constant offset (which should be near zero for normalized data).
    """
    # Calculate the Voigt profile for the given parameters
    # The amplitude needs to scale the normalized profile appropriately.
    # We use a normalization factor derived from the peak height of the profile.
    V = voigt_profile(x - center, sigma_G, gamma_L)
    
    # Calculate the peak height of the *normalized* Voigt profile (V_max)
    # This is complex, but for fitting, we can empirically relate the amplitude
    # parameter to the peak height of the resulting scaled profile.
    # We approximate the peak height of the normalized profile V_peak(0)
    # Since voigt_profile is normalized, we use a simple scaling factor.
    # A common fitting practice is to let the 'amplitude' parameter be the peak height.
    # If using the PDF definition, we must rescale.
    
    # A simpler approach for curve_fit is to define 'amplitude' as the peak height:
    # We scale the normalized profile by a factor that brings its peak to 1.
    # The peak of the normalized Voigt profile is V(0, sigma_G, gamma_L).
    # Since voigt_profile returns the PDF, the peak is generally < 1.
    
    # Let's use a standard definition where 'amplitude' is the height at the peak.
    # We find the scaling factor required to make the peak V(0) = 1, then multiply by amplitude.
    
    # For robust fitting, we rely on the library definition:
    # The maximum value of the PDF is used for normalization scaling.
    V_max = voigt_profile(0, sigma_G, gamma_L)
    
    return amplitude * (V / V_max) + offset

# 2. Initial Guess Parameters
# [Amplitude, Center, Gaussian Width (sigma_G), Lorentzian Width (gamma_L), Offset]
initial_guesses = [
    amplitude_guess,
    lambda_obs_guess,
    5.0,  # sigma_G guess (half of the estimated width)
    2.0,  # gamma_L guess (some fraction of the width)
]

# Standard deviation of the normalized flux (used for weights/errors)
# We use the noise standard deviation calculated in Ex 1
sigma_data = np.full_like(normalized_flux, noise_std)

# 3. Profile Fitting
try:
    popt, pcov = curve_fit(
        voigt_model,
        wavelengths,
        normalized_flux,
        p0=initial_guesses,
        sigma=sigma_data,  # Use sigma for weighted fit
        absolute_sigma=True,
        maxfev=5000
    )
except RuntimeError:
    print("Warning: Optimal parameters not found. Check initial guesses.")
    popt = initial_guesses
    pcov = np.diag([1e-6] * len(initial_guesses)) # Placeholder for error

# Fitted parameters
p_amp, p_center, p_sigma_G, p_gamma_L, p_offset = popt

# 4. Parameter Extraction and Error
perr = np.sqrt(np.diag(pcov))
center_error = perr[1]

# 5. Goodness of Fit (Reduced Chi-Squared)
model_fit = voigt_model(wavelengths, *popt)
residuals = normalized_flux - model_fit
chi_sq = np.sum((residuals / sigma_data)**2)
degrees_of_freedom = len(wavelengths) - len(popt)
reduced_chi_sq = chi_sq / degrees_of_freedom

fit_results = {
    'center_obs': p_center,
    'center_error': center_error,
    'reduced_chi_sq': reduced_chi_sq
}

print("\n--- Voigt Profile Fit Results ---")
print(f"Fitted Center Wavelength (λ_obs): {fit_results['center_obs']:.4f} Å")
print(f"1σ Uncertainty (δλ_obs): {fit_results['center_error']:.4e} Å")
print(f"Reduced Chi-Squared (χ²_red): {fit_results['reduced_chi_sq']:.3f}")

# Visualization of the fit
plt.figure(figsize=(10, 5))
plt.plot(wavelengths, normalized_flux, 'k.', markersize=2, label='Normalized Data')
plt.plot(wavelengths, model_fit, 'r-', linewidth=2, label='Voigt Fit')
plt.axvline(p_center, color='r', linestyle='--', label=f'Fitted Center: {p_center:.4f} Å')
plt.title('Voigt Profile Fitting of Emission Line')
plt.xlabel('Wavelength (Å)')
plt.ylabel('Normalized Flux')
plt.legend()
plt.show()

# Store fitted center and error for Exercise 3
data_ex2 = {
    'lambda_obs': p_center,
    'lambda_err': center_error
}

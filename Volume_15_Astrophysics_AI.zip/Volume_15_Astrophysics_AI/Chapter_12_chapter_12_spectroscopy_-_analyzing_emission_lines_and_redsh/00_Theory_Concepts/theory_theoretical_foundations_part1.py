
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

import numpy as np
from scipy.optimize import curve_fit
from scipy.special import wofz # The Faddeeva function, used for Voigt profiles

# --- 1. Gaussian Profile Function ---
# Models thermal broadening. Parameters: lambda (x-axis), A (amplitude), 
# lambda_obs (center wavelength), sigma (width/std dev).
def gaussian(lam, A, lambda_obs, sigma):
    """
    Calculates the intensity based on a Gaussian profile.
    lam: Wavelength array (input data points).
    A: Amplitude (height).
    lambda_obs: Center of the line (mu).
    sigma: Standard deviation (related to FWHM).
    """
    return A * np.exp(-0.5 * ((lam - lambda_obs) / sigma)**2)

# --- 2. Lorentzian Profile Function ---
# Models pressure and natural broadening. gamma is related to FWHM.
def lorentzian(lam, A, lambda_obs, gamma):
    """
    Calculates the intensity based on a Lorentzian profile.
    gamma: Half-width at half-maximum (HWHM).
    """
    return A * (gamma**2 / ((lam - lambda_obs)**2 + gamma**2))

# --- 3. Voigt Profile Function (Numerical Implementation) ---
# The Voigt profile is the convolution of Gaussian and Lorentzian.
# It is calculated efficiently using the Faddeeva function (wofz).
# Parameters: A (amplitude), lambda_obs (center), sigma (Gaussian width), 
# gamma (Lorentzian width).
def voigt(lam, A, lambda_obs, sigma, gamma):
    """
    Calculates the intensity based on a Voigt profile using the Faddeeva function.
    a: The ratio of Lorentzian to Gaussian width (gamma / sigma).
    u: The normalized distance from the line center ((lam - lambda_obs) / (sigma * sqrt(2))).
    """
    # Define the Voigt parameter 'a'
    a = gamma / sigma
    
    # Define the normalized frequency parameter 'u'
    u = (lam - lambda_obs) / (sigma * np.sqrt(2))
    
    # Calculate the complex Voigt function using wofz (Faddeeva function)
    # The real part of the result is proportional to the Voigt profile
    Z = wofz(u + 1j * a)
    
    # Normalization factor for the Voigt profile
    # The factor 1 / (sigma * sqrt(2*pi)) ensures proper scaling
    norm_factor = 1.0 / (sigma * np.sqrt(2 * np.pi))
    
    # The Voigt profile V(u, a) is (Re(Z) * norm_factor)
    # We multiply by amplitude A to scale the fit to the data
    return A * np.real(Z) * norm_factor

# --- 4. Example Usage Setup (Illustrative, data will be provided later) ---
# We simulate a noisy spectral line centered at 656.3 nm (H-alpha rest wavelength)
# with a small redshift shift.
lambda_rest_h_alpha = 656.28 # nm
sim_lambda_obs = 656.55 # nm (Redshifted)

# Simulate data points around the expected line center
wavelength_range = np.linspace(656.0, 657.0, 100)
true_amplitude = 100.0
true_sigma = 0.05
noise = np.random.normal(0, 5, 100)

# Generate synthetic data using the Gaussian model for simplicity
synthetic_intensity = gaussian(wavelength_range, true_amplitude, sim_lambda_obs, true_sigma) + noise

# Initial guess for the fitting routine:
# We guess the center is near the peak of the noisy data, and estimate amplitude/width.
initial_guess = [np.max(synthetic_intensity), wavelength_range[np.argmax(synthetic_intensity)], 0.1]

# Perform the curve fit (using Gaussian here)
# p_opt contains the optimized parameters (A, lambda_obs, sigma)
try:
    p_opt, p_cov = curve_fit(gaussian, wavelength_range, synthetic_intensity, p0=initial_guess)
    
    # Extract the fitted observed wavelength
    fitted_lambda_obs = p_opt[1]
    
    # Calculate Redshift (z)
    redshift_z = (fitted_lambda_obs - lambda_rest_h_alpha) / lambda_rest_h_alpha
    
    # Calculate Kinematic Velocity (v)
    c_kms = 299792.458 # Speed of light in km/s
    velocity_kms = c_kms * redshift_z
    
    # Output results (for demonstration purposes)
    # print(f"Fitted Observed Wavelength (lambda_obs): {fitted_lambda_obs:.4f} nm")
    # print(f"Calculated Redshift (z): {redshift_z:.6f}")
    # print(f"Calculated Velocity: {velocity_kms:.2f} km/s")

except RuntimeError:
    # Handle cases where the fitting algorithm fails to converge
    pass



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.signal import convolve, windows

# --- 1. Astrophysical Constants and Definitions ---

# Speed of light in km/s (used for velocity calculation)
C_LIGHT_KMS = 299792.458
# Hubble Constant (H0) in km/s/Mpc (for distance estimation)
H0 = 70.0 

# Rest wavelength of the Hydrogen Alpha (H-alpha) line in Angstroms (656.3 nm)
# This is the wavelength the line would have if the source were stationary.
H_ALPHA_REST_A = 6563.0 
# Note: We will work in Angstroms (1 nm = 10 Angstroms) as is common in spectroscopy.

def gaussian_model(x, amplitude, mean, sigma, baseline):
    """
    Defines the Gaussian function used for fitting the emission line profile.
    
    Parameters:
        x (array): The independent variable (wavelength).
        amplitude (float): The maximum height of the peak above the baseline.
        mean (float): The center wavelength (mu, which will be lambda_obs).
        sigma (float): The standard deviation (related to the line width).
        baseline (float): The continuum level (y-offset).
    """
    return baseline + amplitude * np.exp(-0.5 * ((x - mean) / sigma)**2)

def calculate_redshift_velocity(lambda_obs, lambda_rest):
    """
    Calculates the cosmological redshift (z) and recessional velocity (v).
    
    Parameters:
        lambda_obs (float): The observed wavelength (from the fit mean).
        lambda_rest (float): The known rest wavelength.
        
    Returns:
        tuple: (redshift z, velocity v in km/s, distance D in Mpc)
    """
    # Redshift calculation: z = (lambda_obs - lambda_rest) / lambda_rest
    redshift_z = (lambda_obs - lambda_rest) / lambda_rest
    
    # Recessional Velocity (non-relativistic approximation for z < 0.2): v = c * z
    # Note: For high redshift quasars (z > 0.2), relativistic corrections are needed.
    velocity_kms = C_LIGHT_KMS * redshift_z
    
    # Distance estimation using Hubble's Law: D = v / H0
    distance_mpc = velocity_kms / H0
    
    return redshift_z, velocity_kms, distance_mpc

# --- 2. Simulation of Noisy Quasar Spectrum Data ---

# Define the wavelength range (e.g., 6000 A to 8000 A)
WAVELENGTHS = np.linspace(6000, 8000, 2000)
# True parameters for the simulated H-alpha line
TRUE_REDSHIFT = 0.1
TRUE_LAMBDA_OBS = H_ALPHA_REST_A * (1 + TRUE_REDSHIFT) # ~7219.3 Angstroms

TRUE_AMPLITUDE = 100.0
TRUE_SIGMA = 5.0
TRUE_BASELINE = 50.0

# Generate the ideal, noiseless flux data
ideal_flux = gaussian_model(
    WAVELENGTHS, 
    TRUE_AMPLITUDE, 
    TRUE_LAMBDA_OBS, 
    TRUE_SIGMA, 
    TRUE_BASELINE
)

# Add significant Gaussian noise to simulate real telescope data
NOISE_LEVEL = 15.0
noise = np.random.normal(0, NOISE_LEVEL, WAVELENGTHS.shape)
raw_flux = ideal_flux + noise

print(f"--- Simulated Quasar Spectrum Generated ---")
print(f"Target Line: H-alpha (Rest: {H_ALPHA_REST_A:.1f} A)")
print(f"Expected Observed Center: {TRUE_LAMBDA_OBS:.2f} A (z={TRUE_REDSHIFT})")
print("-" * 50)

# --- 3. Data Preprocessing: Smoothing and Continuum Estimation ---

# Smoothing the data using a Savitzky-Golay filter (or simple convolution) 
# We use a simple convolution with a Hann window for basic noise reduction.
window_size = 15
hann_window = windows.hann(window_size)
hann_window /= hann_window.sum() # Normalize the window
smoothed_flux = convolve(raw_flux, hann_window, mode='same')

# --- 4. Peak Detection and Initial Guess Generation ---

# Find the index of the maximum flux in the smoothed data
peak_index = np.argmax(smoothed_flux)
lambda_peak = WAVELENGTHS[peak_index]
flux_peak = smoothed_flux[peak_index]

print(f"Step 4: Detected Peak at Wavelength: {lambda_peak:.2f} A")

# Generate initial guesses (p0) for the curve_fit function
# 1. Amplitude: Peak flux minus the estimated continuum (baseline)
initial_amplitude = flux_peak - TRUE_BASELINE 
# 2. Mean: The detected peak wavelength
initial_mean = lambda_peak
# 3. Sigma: A rough estimate of the width (e.g., 1% of the total range, or a fixed value)
initial_sigma = 8.0 
# 4. Baseline: The minimum flux observed (a rough continuum estimate)
initial_baseline = np.min(smoothed_flux) 

p0 = [initial_amplitude, initial_mean, initial_sigma, initial_baseline]
print(f"Initial Guesses (p0): Amplitude={p0[0]:.2f}, Mean={p0[1]:.2f}, Sigma={p0[2]:.2f}, Baseline={p0[3]:.2f}")

# --- 5. Defining the Fitting Window ---

# We only fit the region immediately around the peak to avoid fitting continuum noise.
# Define a window width (e.g., +/- 50 Angstroms around the peak)
window_width = 50.0 
fit_mask = (WAVELENGTHS > (lambda_peak - window_width)) & \
           (WAVELENGTHS < (lambda_peak + window_width))

# Extract the data within the fitting window
w_fit = WAVELENGTHS[fit_mask]
f_fit = raw_flux[fit_mask] # Use the raw, unsmoothed data for the actual fitting

# --- 6. Executing the Non-Linear Least Squares Fit ---

try:
    # bounds define the search space (optional, but highly recommended for robustness)
    # [Amplitude, Mean, Sigma, Baseline]
    lower_bounds = [0, lambda_peak - 10, 1.0, 0]
    upper_bounds = [200, lambda_peak + 10, 20.0, 100]
    
    # Perform the curve fitting
    popt, pcov = curve_fit(
        gaussian_model, 
        w_fit, 
        f_fit, 
        p0=p0, 
        bounds=(lower_bounds, upper_bounds)
    )
    
    # Extract the fitted parameters
    amp_fit, lambda_obs, sigma_fit, baseline_fit = popt
    
    # Calculate the standard deviation (error) for the observed wavelength
    # pcov is the covariance matrix. The diagonal elements are the variances.
    lambda_obs_err = np.sqrt(pcov[1, 1])
    
    print("-" * 50)
    print("Step 6: Gaussian Fit Successful")
    print(f"Fitted Observed Wavelength (lambda_obs): {lambda_obs:.3f} A +/- {lambda_obs_err:.3f} A")
    print(f"Fitted Amplitude: {amp_fit:.2f}, Sigma: {sigma_fit:.2f}")
    
except RuntimeError:
    print("ERROR: Optimal parameters not found for Gaussian fit.")
    exit()

# --- 7. Astrophysical Interpretation and Kinematics ---

# Use the precisely determined lambda_obs for the final calculations
redshift_z, velocity_kms, distance_mpc = calculate_redshift_velocity(
    lambda_obs, 
    H_ALPHA_REST_A
)

print("\n--- Astrophysical Results ---")
print(f"Assumed Rest Wavelength (H-alpha): {H_ALPHA_REST_A:.1f} Angstroms")
print(f"Calculated Cosmological Redshift (z): {redshift_z:.5f}")
print(f"Inferred Recessional Velocity (v): {velocity_kms:,.2f} km/s")
print(f"Estimated Distance (Hubble's Law): {distance_mpc:,.2f} Mpc")
print(f"Estimated Distance (Light Years): {distance_mpc * 3.26e6:,.0f} light years")

# --- 8. Visualization of the Fit ---

# Generate the fitted curve across the entire spectrum range
fitted_curve = gaussian_model(WAVELENGTHS, *popt)

plt.figure(figsize=(12, 7))

# Plot the raw, noisy data
plt.plot(WAVELENGTHS, raw_flux, 'k.', alpha=0.3, label='Raw Quasar Data (Flux)')

# Plot the smoothed data used for initial peak finding
plt.plot(WAVELENGTHS, smoothed_flux, 'b-', label='Smoothed Data', linewidth=1.5)

# Plot the fitted Gaussian profile
plt.plot(WAVELENGTHS, fitted_curve, 'r--', label=f'Fitted Gaussian Profile ($\lambda_{{obs}}$={lambda_obs:.2f} A)', linewidth=2.5)

# Mark the observed and rest wavelengths
plt.axvline(lambda_obs, color='red', linestyle=':', label=f'Observed $\lambda$ ({lambda_obs:.2f} A)')
plt.axvline(H_ALPHA_REST_A, color='green', linestyle=':', label=f'Rest $\lambda$ ({H_ALPHA_REST_A:.1f} A)')

# Highlight the fitting window
plt.axvspan(lambda_peak - window_width, lambda_peak + window_width, 
            color='gray', alpha=0.1, label='Fitting Window')

plt.title(f'Spectroscopic Analysis of Candidate Quasar (Redshift z={redshift_z:.4f})', fontsize=16)
plt.xlabel('Wavelength (Angstroms)')
plt.ylabel('Relative Flux')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

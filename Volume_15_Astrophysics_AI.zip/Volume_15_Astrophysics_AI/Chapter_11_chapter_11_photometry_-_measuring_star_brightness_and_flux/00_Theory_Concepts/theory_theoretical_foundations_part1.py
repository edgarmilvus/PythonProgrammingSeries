
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

# ======================================================================
# CHAPTER 11: PHOTOMETRY THEORETICAL FOUNDATIONS
# Conceptual Code: Relating Flux, Magnitude, and Distance Modulus
# ======================================================================

import numpy as np

# --- 1. Pogson Ratio and Flux Comparison ---

def flux_ratio_from_magnitude_difference(delta_m):
    """
    Calculates the ratio of fluxes (F1/F2) given the difference in magnitudes (m2 - m1).
    F1/F2 = 100^(delta_m / 5)
    """
    return 100**(delta_m / 5.0)

# Example: How much brighter is a magnitude 1 star than a magnitude 6 star?
# delta_m = 6 - 1 = 5
mag_difference = 5.0
flux_ratio_5_mag = flux_ratio_from_magnitude_difference(mag_difference)
# print(f"A 5-magnitude difference corresponds to a flux ratio of: {flux_ratio_5_mag:.2f}")
# Output should be 100.00

# --- 2. Distance Modulus Calculation ---

def calculate_absolute_magnitude(m_apparent, d_parsecs, extinction_A=0.0):
    """
    Calculates Absolute Magnitude (M) using the Distance Modulus formula,
    including an optional term for interstellar extinction (A).
    M = m - (5 * log10(d) - 5) - A
    """
    if d_parsecs <= 0:
        raise ValueError("Distance must be positive.")

    # Distance Modulus (m - M) = 5 * log10(d/10) + A
    distance_modulus = 5 * np.log10(d_parsecs) - 5 + extinction_A

    # M = m - (m - M)
    M_absolute = m_apparent - distance_modulus
    return M_absolute

# Example 1: Star A is 10 pc away (d=10).
# If d=10, the distance modulus (m-M) should be exactly 0.
m_A = 4.0
d_A = 10.0
M_A = calculate_absolute_magnitude(m_A, d_A)
# print(f"Star A (d={d_A} pc): Apparent Mag={m_A}, Absolute Mag={M_A:.2f}")
# Output should be 4.00

# Example 2: Star B is 100 pc away (d=100).
# log10(100/10) = 1. Distance Modulus = 5 * 1 = 5.
m_B = 10.0
d_B = 100.0
M_B = calculate_absolute_magnitude(m_B, d_B)
# print(f"Star B (d={d_B} pc): Apparent Mag={m_B}, Absolute Mag={M_B:.2f}")
# Output should be 5.00

# Example 3: Star C is 1000 pc away with 0.5 magnitudes of extinction.
m_C = 15.0
d_C = 1000.0
A_C = 0.5
M_C = calculate_absolute_magnitude(m_C, d_C, extinction_A=A_C)
# print(f"Star C (d={d_C} pc, A={A_C}): Apparent Mag={m_C}, Absolute Mag={M_C:.2f}")
# log10(1000/10) = 2. Modulus = 5*2 + 0.5 = 10.5. M = 15.0 - 10.5 = 4.5
# Output should be 4.50

# --- 3. Calculating Flux from Magnitude (Conceptual Standard) ---

def flux_from_magnitude(m, F_zero_point):
    """
    Calculates flux (F) given magnitude (m) and the zero-point flux (F_0).
    F = F_0 * 10^(-0.4 * m)
    """
    # Note: 10^(-0.4) is equivalent to (100^(1/5))^(-1) = 2.512^(-1)
    return F_zero_point * (10**(-0.4 * m))

# Define a reference zero-point flux (e.g., for the V filter, in Janskys or W/m^2)
F_V_zero_point = 3.636e-9 # Example value in W/m^2 for m=0
m_target = 5.0
F_target = flux_from_magnitude(m_target, F_V_zero_point)
# print(f"Flux for m={m_target} is: {F_target:.2e} W/m^2")

# ======================================================================

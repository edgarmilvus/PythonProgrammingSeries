
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import sys
from astropy.stats import sigma_clipped_stats
from astropy.table import Table
from photutils.background import Background2D, MedianBackground
from photutils.detection import DAOStarFinder
from photutils.aperture import CircularAperture, CircularAnnulus, aperture_photometry
from photutils.datasets import make_gaussian_sources, make_noise_image

# --- 1. Configuration Constants and Parameters ---
IMAGE_SIZE = 512
FWHM_PIXELS = 4.0  # Full Width at Half Maximum (measure of star sharpness)
THRESHOLD_SIGMA = 5.0 # Detection threshold in standard deviations above background
APERTURE_RADIUS = 2.5 * FWHM_PIXELS / 2.355 # Standard practice: Aperture radius ~1.5 * FWHM
ANNULUS_INNER = 4.0 * FWHM_PIXELS / 2.355 # Inner radius for background annulus
ANNULUS_OUTER = 6.0 * FWHM_PIXELS / 2.355 # Outer radius for background annulus
BKG_BOX_SIZE = 50 # Size of the boxes for 2D background estimation

# --- 2. Synthetic Data Generation (Simulating a Real FITS Image) ---

def generate_stellar_field(size):
    """Creates a synthetic image with stars, noise, and a non-uniform background."""
    print(f"Generating synthetic {size}x{size} image...")
    
    # Define characteristic sources (x, y, flux, FWHM)
    # Target Star (Center, Medium Flux)
    # Reference Star 1 (Top Left, High Flux)
    # Reference Star 2 (Bottom Right, Low Flux)
    sources = Table([
        [256.0, 100.0, 4000.0, FWHM_PIXELS],  # Reference 1
        [256.0, 256.0, 2500.0, FWHM_PIXELS],  # Target Star
        [400.0, 400.0, 1500.0, FWHM_PIXELS]   # Reference 2
    ], names=['x_mean', 'y_mean', 'amplitude', 'fwhm'])
    
    # Generate ideal Gaussian profiles for the stars
    star_data = make_gaussian_sources(size, sources)
    
    # Add realistic Poisson noise (shot noise from photons) and Gaussian read noise
    noise_data = make_noise_image((size, size), mean=100, stddev=5, seed=123)
    
    # Simulate a subtle, non-uniform background gradient (e.g., scattered light)
    gradient = np.linspace(0, 50, size)[:, None] + np.linspace(0, 20, size)
    
    # Final image data
    image_data = star_data + noise_data + gradient
    
    print(f"Synthetic image generated. Max value: {np.max(image_data):.2f}")
    return image_data

# --- 3. Core Photometry Pipeline Function ---

def perform_differential_photometry(data):
    """
    Executes the full aperture photometry workflow on the provided image data.
    """
    
    # --- 3.1 Background Estimation and Subtraction (Global Model) ---
    
    # Calculate the mean and standard deviation of the background using sigma clipping
    # This robustly excludes bright sources (stars) from the background calculation.
    mean_bkg, median_bkg, std_bkg = sigma_clipped_stats(data, sigma=2.0, maxiters=5)
    print(f"\nGlobal Background Stats: Median={median_bkg:.2f}, Std Dev={std_bkg:.2f}")
    
    # Use Background2D to model the spatially varying background
    bkg_estimator = MedianBackground()
    bkg_2d = Background2D(data, (BKG_BOX_SIZE, BKG_BOX_SIZE), filter_size=(3, 3),
                          bkg_estimator=bkg_estimator)
    
    # Subtract the smooth background model from the raw data
    data_subtracted = data - bkg_2d.background

    # --- 3.2 Source Detection using DAOStarFinder ---
    
    # DAOStarFinder is optimized for finding stellar-like sources (Point Spread Functions)
    # It requires the FWHM and the detection threshold (in sigma above background)
    daofind = DAOStarFinder(fwhm=FWHM_PIXELS, threshold=THRESHOLD_SIGMA * std_bkg)
    
    # Find sources in the background-subtracted image
    sources = daofind(data_subtracted)
    
    if sources is None:
        print("Error: No sources detected above the threshold.")
        sys.exit(1)
        
    # Extract coordinates and filter out sources too close to the edge
    positions = np.transpose((sources['xcentroid'], sources['ycentroid']))
    
    # Filter for sources far from the edge (prevent aperture truncation)
    min_dist = ANNULUS_OUTER + 2
    valid_indices = (sources['xcentroid'] > min_dist) & \
                    (sources['xcentroid'] < IMAGE_SIZE - min_dist) & \
                    (sources['ycentroid'] > min_dist) & \
                    (sources['ycentroid'] < IMAGE_SIZE - min_dist)
    
    # Apply filtering
    sources = sources[valid_indices]
    positions = positions[valid_indices]
    
    print(f"Detected {len(sources)} valid stellar sources for photometry.")
    
    # --- 3.3 Define Apertures ---
    
    # 1. Measurement Aperture (measures star + local background)
    apertures = CircularAperture(positions, r=APERTURE_RADIUS)
    
    # 2. Annulus Aperture (measures local background only)
    annulus_apertures = CircularAnnulus(positions, r_in=ANNULUS_INNER, r_out=ANNULUS_OUTER)
    
    # --- 3.4 Perform Photometry on Subtracted Data ---
    
    # Perform photometry on the image that ALREADY has the global background removed.
    # The flux measured here (raw_flux) is the total signal inside the aperture.
    phot_table_aperture = aperture_photometry(data_subtracted, apertures)
    
    # Perform photometry on the Annulus region (measures only the residual background noise)
    phot_table_annulus = aperture_photometry(data_subtracted, annulus_apertures)

    # Combine the results into a single table
    phot_table = Table(phot_table_aperture)
    phot_table['annulus_sum'] = phot_table_annulus['aperture_sum']
    
    # Rename the primary flux column for clarity
    phot_table.rename_column('aperture_sum', 'raw_flux_sum')
    
    # --- 3.5 Local Background Correction (The Differential Step) ---
    
    # Calculate the area of the measurement aperture and the annulus
    aperture_area = apertures.area
    annulus_area = annulus_apertures.area
    
    # Calculate the mean background flux per pixel within the annulus
    # This corrects for small, localized fluctuations missed by the Bkg2D model.
    bkg_mean = phot_table['annulus_sum'] / annulus_area
    
    # Calculate the total background signal contained within the main measurement aperture
    bkg_flux_in_aperture = bkg_mean * aperture_area
    
    # Calculate the final, calibrated flux (Net Flux)
    net_flux = phot_table['raw_flux_sum'] - bkg_flux_in_aperture
    phot_table['net_flux'] = net_flux
    
    # --- 3.6 Calculate Instrumental Magnitude ---
    
    # Instrumental Magnitude (m_inst) = -2.5 * log10(Net Flux) + C
    # C (the zero point) is assumed to be zero here for instrumental measurements.
    
    # Handle potential negative flux values resulting from noise (set to NaN or small positive number)
    # Using np.where to prevent log(0) or log(negative) errors
    valid_flux = np.where(phot_table['net_flux'] > 1e-6, phot_table['net_flux'], 1e-6)
    
    phot_table['instrumental_magnitude'] = -2.5 * np.log10(valid_flux)
    
    return phot_table, sources

# --- 4. Execution and Reporting ---

if __name__ == "__main__":
    
    # Generate the data
    image_data = generate_stellar_field(IMAGE_SIZE)
    
    # Run the pipeline
    final_results, detected_sources = perform_differential_photometry(image_data)
    
    # --- 5. Output Results ---
    
    print("\n--- Photometry Results Table ---")
    
    # Add a descriptive ID column
    final_results['ID'] = np.arange(1, len(final_results) + 1)
    
    # Display coordinates and final results
    output_table = final_results[['ID', 'xcentroid', 'ycentroid', 'raw_flux_sum', 
                                  'annulus_sum', 'net_flux', 'instrumental_magnitude']]
    
    # Format the coordinates and flux values for readability
    for col in ['xcentroid', 'ycentroid']:
        output_table[col].info.formats = '%.2f'
    for col in ['raw_flux_sum', 'annulus_sum', 'net_flux']:
        output_table[col].info.formats = '%.1f'
    output_table['instrumental_magnitude'].info.formats = '%.4f'
    
    print(output_table)
    
    print("\n--- Analysis Summary ---")
    print(f"The target star (ID 2, near center) has an instrumental magnitude of: {output_table['instrumental_magnitude'][1]:.4f}")
    print(f"The brightest reference star (ID 1) is {output_table['instrumental_magnitude'][0]:.4f}")
    
    # Practical Check: A lower magnitude means a brighter star.
    if output_table['instrumental_magnitude'][0] < output_table['instrumental_magnitude'][1]:
        print("Consistency Check: Reference Star 1 is correctly measured as brighter.")
    else:
        print("Warning: Magnitude calculation inconsistency detected.")


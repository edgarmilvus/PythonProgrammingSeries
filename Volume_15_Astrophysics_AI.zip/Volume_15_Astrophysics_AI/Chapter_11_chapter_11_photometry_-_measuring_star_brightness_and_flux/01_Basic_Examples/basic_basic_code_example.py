
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Simulation Parameters ---
# Define the size of our simulated image (21x21 pixels)
IMAGE_SIZE = 21
CENTER = IMAGE_SIZE // 2  # Center pixel coordinate (10)
APERTURE_RADIUS = 5      # Radius of the measurement circle in pixels
STAR_FLUX_PEAK = 500     # Peak brightness of the simulated star
BACKGROUND_LEVEL = 10    # Uniform background noise/sky glow

# --- 2. Create the Image Array and Coordinates ---
# Initialize a blank image array with the background level
image_data = np.full((IMAGE_SIZE, IMAGE_SIZE), BACKGROUND_LEVEL, dtype=np.float32)

# Create coordinate grids (X and Y) for every pixel
y_coords, x_coords = np.indices(image_data.shape)

# Calculate the distance of every pixel from the center (Euclidean distance)
# This is crucial for defining the circular shape of the star and the aperture
distance_from_center = np.sqrt(
    (x_coords - CENTER)**2 + (y_coords - CENTER)**2
)

# --- 3. Simulate the Star (Gaussian Profile) ---
# Stars are not point sources in ground-based images; they are spread out 
# by atmospheric turbulence (seeing) and telescope optics. We simulate this 
# spread using a Gaussian function.
SIGMA = 1.5 # Standard deviation controlling the star's spread (FWHM)
gaussian_profile = STAR_FLUX_PEAK * np.exp(
    -0.5 * (distance_from_center / SIGMA)**2
)

# Add the star profile to the background image
image_data += gaussian_profile

# --- 4. Define the Aperture Mask ---
# Create a boolean mask where True indicates pixels *inside* the defined radius
aperture_mask = distance_from_center < APERTURE_RADIUS

# --- 5. Calculate the Raw Flux ---
# Use the boolean mask to select only the pixels within the aperture
star_pixels = image_data[aperture_mask]

# Sum the values of the selected pixels to get the total raw flux
raw_flux_measurement = np.sum(star_pixels)

# --- 6. Output Results ---
print(f"Image Size: {IMAGE_SIZE}x{IMAGE_SIZE} pixels")
print(f"Aperture Radius: {APERTURE_RADIUS} pixels")
print(f"Total Raw Flux (Star + Background): {raw_flux_measurement:.2f} ADU")

# Example of what the image center looks like (a small preview)
print("\n--- Image Center Snippet (Raw Counts) ---")
print(image_data[CENTER-3:CENTER+4, CENTER-3:CENTER+4].astype(int))

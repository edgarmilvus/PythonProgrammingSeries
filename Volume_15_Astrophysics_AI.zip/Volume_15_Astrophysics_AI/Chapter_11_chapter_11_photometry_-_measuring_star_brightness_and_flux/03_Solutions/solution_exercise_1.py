
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from astropy.io import fits
from photutils.detection import DAOStarFinder
from photutils.background import Background2D, MedianBackground
from photutils.aperture import CircularAperture, AperturePhotometry
from astropy.stats import sigma_clipped_stats
from astropy.table import Table

# --- Setup: Load data (using synthetic data created for demonstration) ---
try:
    data = fits.getdata('NGC_457.fits')
except FileNotFoundError:
    # If the synthetic file wasn't created, generate a simple placeholder
    print("Generating placeholder data...")
    data = np.random.rand(512, 512) * 100 + 1000
    data[200:210, 200:210] += 5000 # Add a bright source

# 1. Calculate global statistics for detection thresholding
mean, median, std = sigma_clipped_stats(data, sigma=2.0)

# 2. Model and subtract background
bkg_estimator = MedianBackground()
bkg = Background2D(data, (50, 50), filter_size=(3, 3),
                   bkg_estimator=bkg_estimator,
                   sigma_clip=sigma_clipped_stats)
bkg_subtracted_data = data - bkg.background # Subtract the smooth background model

# 3. Source Detection
# Use 4-sigma threshold relative to the local background noise (bkg.background_rms)
daofind = DAOStarFinder(fwhm=3.0, threshold=4.0 * np.median(bkg.background_rms))
sources = daofind(bkg_subtracted_data)

# Filter out sources where flux calculation might fail (e.g., negative)
if sources is None:
    print("No sources detected above threshold.")
    sources = Table(names=['xcentroid', 'ycentroid', 'flux'], dtype=[float, float, float])
else:
    # Sort by flux (DAOStarFinder 'flux' column is an estimate) and select top 15
    sources.sort('flux', reverse=True)
    sources = sources[:15]

# Extract coordinates
positions = np.transpose((sources['xcentroid'], sources['ycentroid']))

# 4. Aperture Definition and Photometry
apertures = CircularAperture(positions, r=5.0) # Radius 5 pixels
# Note: Annulus is defined but not used for background subtraction here,
# as Bkg2D already handled the primary subtraction. We use the subtracted image.
# annuli = CircularAnnulus(positions, r_in=10., r_out=15.)

phot_table = AperturePhotometry(bkg_subtracted_data, apertures)

# 5. Measurement Output
# Rename columns for clarity and merge with source ID
phot_table.rename_column('aperture_sum', 'Net_Flux_Counts')
phot_table['ID'] = np.arange(1, len(phot_table) + 1)
phot_table['x'] = sources['xcentroid']
phot_table['y'] = sources['ycentroid']

# Select final required columns and display
final_catalog = phot_table['ID', 'x', 'y', 'Net_Flux_Counts']
print("--- Top 15 Measured Sources ---")
print(final_catalog)

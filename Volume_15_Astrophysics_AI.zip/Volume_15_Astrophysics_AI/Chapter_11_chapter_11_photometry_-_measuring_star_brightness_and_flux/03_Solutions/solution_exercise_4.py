
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np

# Input parameters
N_total = 25000.0  # Total counts in aperture (N*)
F = 18000.0        # Net Flux (Star counts only)
N_ap = 78.54       # Aperture Area (pixels)
N_ann = 157.08     # Annulus Area (pixels)
sigma_bkg = 5.5    # Background standard deviation (counts/pixel)
sigma_read = 8.0   # Detector Read Noise (counts/pixel)
V_star = 15.10     # Assumed calibrated magnitude

# 1. Calculate variances
sigma2_bkg = sigma_bkg**2
sigma2_read = sigma_read**2

# 2. Calculate total flux variance (sigma2_F)
# Formula: sigma^2_F = N* + N_ap * (sigma^2_bkg + sigma^2_read) + (N_ap^2 / N_ann) * sigma^2_bkg

# Term 1: Photon noise (N*)
T1 = N_total

# Term 2: Read noise and background noise integrated over the aperture area
T2 = N_ap * (sigma2_bkg + sigma2_read)

# Term 3: Error introduced by background estimation (sampling error)
T3 = (N_ap**2 / N_ann) * sigma2_bkg

sigma2_F = T1 + T2 + T3

# 3. Calculate flux error
sigma_F = np.sqrt(sigma2_F)

# 4. Propagate error to magnitude
# Magnitude error: sigma_V = 1.0857 * (sigma_F / F)
sigma_V = 1.0857 * (sigma_F / F)

# 5. Final Report
print(f"1. Background Variance (sigma^2_bkg): {sigma2_bkg:.2f}")
print(f"   Read Noise Variance (sigma^2_read): {sigma2_read:.2f}")
print(f"2. Variance Components: T1={T1:.2f}, T2={T2:.2f}, T3={T3:.2f}")
print(f"   Total Flux Variance (sigma^2_F): {sigma2_F:.2f}")
print(f"3. Total Flux Error (sigma_F): {sigma_F:.2f} counts")
print(f"4. Magnitude Error (sigma_V): {sigma_V:.4f} mag")
print("\n--- Final Photometric Result ---")
print(f"Source V Magnitude: {V_star:.2f} ± {sigma_V:.4f}")

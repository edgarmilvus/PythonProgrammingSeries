
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
from astropy.table import Table

# Define placeholder data structures for type consistency
ImageArray = np.ndarray
SourceCatalog = Table
FluxMeasurements = Table

# 1. Identify Key Steps:
# 1. Image Preparation (Background Subtraction)
# 2. Source Detection
# 3. Aperture Photometry (Flux Measurement)
# 4. Zero Point Calculation
# 5. Magnitude Calibration

def step_1_prepare_image(raw_data: ImageArray) -> ImageArray:
    """Models and subtracts the sky background."""
    # Implementation uses photutils.background.Background2D
    bkg_subtracted_data = raw_data # Placeholder
    return bkg_subtracted_data

def step_2_detect_sources(bkg_subtracted_data: ImageArray, detection_threshold: float) -> SourceCatalog:
    """Identifies point sources above a given threshold."""
    # Implementation uses DAOStarFinder
    source_catalog = SourceCatalog(names=['xcentroid', 'ycentroid', 'flux_estimate']) # Placeholder
    return source_catalog

def step_3_perform_aperture_photometry(image_data: ImageArray, source_catalog: SourceCatalog) -> FluxMeasurements:
    """Measures the net flux within defined apertures for detected sources."""
    # Implementation uses CircularAperture and AperturePhotometry
    flux_measurements = FluxMeasurements(names=['ID', 'Net_Flux_Counts']) # Placeholder
    return flux_measurements

def step_4_calculate_zero_point(flux_measurements: FluxMeasurements, V_ref: float, F_ref: float) -> float:
    """Calculates the photometric zero point (ZP) using a reference star."""
    # Requires flux measurements and reference star data
    m_inst_ref = -2.5 * np.log10(F_ref)
    ZP = V_ref - m_inst_ref
    return ZP

def step_5_calibrate_magnitudes(flux_measurements: FluxMeasurements, ZP: float) -> SourceCatalog:
    """Converts instrumental fluxes into calibrated apparent magnitudes."""
    # Requires flux measurements and ZP
    calibrated_catalog = flux_measurements.copy()
    # Logic: m = -2.5 * log10(F) + ZP
    # Implementation: Calculate m_inst, then add ZP
    return calibrated_catalog

# Example of sequential execution flow:
# image_net = step_1_prepare_image(raw_fits_data)
# initial_sources = step_2_detect_sources(image_net, threshold=4.0)
# raw_fluxes = step_3_perform_aperture_photometry(image_net, initial_sources)
# ZP_value = step_4_calculate_zero_point(raw_fluxes, V_ref=14.5, F_ref=10000)
# final_catalog = step_5_calibrate_magnitudes(raw_fluxes, ZP_value)

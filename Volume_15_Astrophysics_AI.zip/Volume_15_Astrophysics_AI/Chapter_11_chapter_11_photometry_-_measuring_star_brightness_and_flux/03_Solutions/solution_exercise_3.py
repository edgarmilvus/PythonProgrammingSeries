
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
from astropy.table import Table
import numpy.lib.recfunctions as rfn
from photutils.aperture import CircularAperture, AperturePhotometry

# --- Mock Initial DAOStarFinder Output ---
# Create a structured array mimicking DAOStarFinder output (30 sources)
N_sources = 30
np.random.seed(42)
initial_data = {
    'id': np.arange(1, N_sources + 1),
    'xcentroid': np.random.uniform(50, 950, N_sources),
    'ycentroid': np.random.uniform(50, 950, N_sources),
    'sharpness': np.random.uniform(0.3, 1.8, N_sources),
    'ellipticity': np.random.uniform(0.0, 0.7, N_sources),
    'flux': np.random.uniform(1000, 10000, N_sources)
}
sources = Table(initial_data)

# Manually insert a known bad source (high sharpness/ellipticity in the bad region)
sources['xcentroid'][2] = 850
sources['ycentroid'][2] = 550
sources['sharpness'][2] = 1.6
sources['ellipticity'][2] = 0.6

# 1. Initial count
N_initial = len(sources)

# 2. Apply coordinate mask (Bad region: X > 800 AND Y > 500)
bad_region_mask = (sources['xcentroid'] > 800) & (sources['ycentroid'] > 500)
coord_filtered_sources = sources[~bad_region_mask]

# 3. Apply sharpness and ellipticity filters
# Sharpness filter: 0.4 < sharpness < 1.2
sharpness_mask = (coord_filtered_sources['sharpness'] > 0.4) & \
                 (coord_filtered_sources['sharpness'] < 1.2)

# Ellipticity filter: ellipticity < 0.4
ellipticity_mask = coord_filtered_sources['ellipticity'] < 0.4

# Combine all quality masks
combined_mask = sharpness_mask & ellipticity_mask

# 4. Filter the source catalog
filtered_sources = coord_filtered_sources[combined_mask]

# 5. Aperture Redefinition and Photometry Rerun (Conceptual)
N_final = len(filtered_sources)

# Prepare coordinates for photometry
final_positions = np.transpose((filtered_sources['xcentroid'], filtered_sources['ycentroid']))
final_apertures = CircularAperture(final_positions, r=5.0)

# Mock image data (since we don't have the background-subtracted image from E1 here)
mock_image = np.zeros((1000, 1000))
# phot_results = AperturePhotometry(mock_image, final_apertures) # Actual photometry call

print(f"Total sources detected initially: {N_initial}")
print(f"Total sources measured after filtering and masking: {N_final}")
print("\n--- Filtered Catalog Snippet ---")
print(filtered_sources['id', 'xcentroid', 'ycentroid', 'sharpness', 'ellipticity'][:5])

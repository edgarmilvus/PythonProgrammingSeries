
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import sunpy.map
from sunpy.net import Fido, attrs as a
import astropy.units as u
import matplotlib.pyplot as plt
from datetime import datetime
import os

# --- Configuration and Setup ---

# 1. Define the specific time window for the observation
# We select a known period (e.g., 2012-07-12) to ensure data availability.
# A very narrow time window guarantees we retrieve only one or two files.
start_time = datetime(2012, 7, 12, 12, 0, 0)
end_time = datetime(2012, 7, 12, 12, 0, 10) # 10-second window

# 2. Define the wavelength channel using Astropy Units
# 171 Angstrom is a standard channel for viewing the quiet corona.
wavelength_channel = 171 * u.angstrom

# 3. Set up the download directory
download_dir = './sunpy_aia_data/'
os.makedirs(download_dir, exist_ok=True)
print(f"Data will be saved to: {os.path.abspath(download_dir)}")

# --- Data Search and Retrieval using Fido ---

# 4. Construct the unified Fido search query
# Fido uses attributes (a) to define the specific data characteristics required.
search_query = Fido.search(
    a.Time(start_time, end_time), # Defines the time span
    a.Instrument('AIA'),         # Specifies the instrument (Atmospheric Imaging Assembly)
    a.Source('SDO'),             # Specifies the source spacecraft (Solar Dynamics Observatory)
    a.Wavelength(wavelength_channel), # Specifies the spectral band
    a.Provider('JSOC')           # Specifies the archive provider (Joint Science Operations Center)
)

# 5. Report the search results
print("\n--- Search Results Summary ---")
print(search_query) # Prints a table summarizing the results found

# 6. Execute the download
# Fido.fetch initiates the actual download process using the paths found in the query.
# The 'path' argument tells SunPy where to save the data.
print("\nInitiating download...")
downloaded_files = Fido.fetch(search_query, path=download_dir)

# --- Data Loading and Visualization ---

# 7. Check if download was successful and load the data
if downloaded_files:
    # sunpy.map.Map is the core object for handling solar images.
    # It automatically reads the FITS header and coordinate information.
    solar_map = sunpy.map.Map(downloaded_files[0])

    # 8. Prepare the visualization using Matplotlib
    plt.style.use('dark_background') # Aesthetic choice for astronomical data
    fig = plt.figure(figsize=(8, 8))
    
    # The .plot() method handles coordinate system projection automatically.
    solar_map.plot() 
    
    # Add context and labels
    plt.colorbar(label=f"Intensity ({solar_map.unit})")
    plt.title(f"SDO/AIA {solar_map.wavelength} Image\nObservation Time: {solar_map.date}")
    plt.xlabel(f"Solar X ({solar_map.spatial_units[0]})")
    plt.ylabel(f"Solar Y ({solar_map.spatial_units[1]})")
    
    plt.show()

    print(f"\nSuccessfully processed and displayed map from: {downloaded_files[0]}")
else:
    print("Error: No files were downloaded. Check network connection or query parameters.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import numpy as np
import pandas as pd
from datetime import datetime

# SunPy and Astropy Imports
import astropy.units as u
from astropy.coordinates import SkyCoord
from sunpy.net import Fido, attrs as a
from sunpy.timeseries import TimeSeries
from sunpy.map import Map
from sunpy.io.file_tools import download_file
from sunpy.visualization.image import imshow_with_scale_hpc

# Image Processing Imports
from skimage.filters import threshold_otsu
from skimage.measure import label, regionprops
from skimage.morphology import binary_dilation, disk

# --- Configuration Constants ---
START_TIME = datetime(2023, 7, 3, 16, 0)
END_TIME = datetime(2023, 7, 3, 17, 0)
WAVELENGTH = 171 * u.angstrom
DATA_PATH = "./solar_data_cache/"

# Ensure the cache directory exists
os.makedirs(DATA_PATH, exist_ok=True)


def fetch_and_process_data(start_time, end_time, wavelength):
    """
    Step 1: Uses Fido to query and download the TimeSeries data for initial flare detection.
    Adheres to DRY by encapsulating data access logic.
    """
    print(f"[{datetime.now().time()}] Searching for AIA data TimeSeries...")

    # Query for the TimeSeries data (lower resolution flux data)
    query = Fido.search(
        a.Time(start_time, end_time),
        a.Instrument.aia,
        a.Wavelength(wavelength),
        a.Sample(1 * u.minute)  # Requesting 1-minute cadence for TS
    )

    # Download the TimeSeries data
    files = Fido.fetch(query, path=DATA_PATH)

    if not files:
        raise FileNotFoundError("No TimeSeries data found for the specified period.")

    # Create a TimeSeries object from the downloaded files
    ts = TimeSeries(files)
    print(f"[{datetime.now().time()}] TimeSeries loaded successfully.")
    return ts


def analyze_flare_event(ts, wavelength):
    """
    Step 2 & 3: Analyzes the TimeSeries for peak intensity and localizes the flare
    using a high-cadence Map corresponding to the peak time.
    """
    # 2.1 Temporal Analysis: Identify the peak flux time
    # We assume 'AIA_171' is the relevant column for flux
    flux_col = f'AIA_{int(wavelength.value)}'
    
    if flux_col not in ts.columns:
        # Fallback if specific column naming convention changed
        print("Warning: Specific flux column not found. Using the first data column.")
        peak_time = ts.data.index[ts.data.iloc[:, 0].idxmax()]
    else:
        peak_time = ts.data.index[ts.data[flux_col].idxmax()]
    
    peak_flux = ts.data.loc[peak_time, flux_col]
    
    print(f"[{datetime.now().time()}] Peak flux detected at: {peak_time} (Flux: {peak_flux:.2f} DN/s)")

    # 2.2 Spatial Data Acquisition: Download the Map closest to the peak time
    # We request high-cadence (12s) Map data for precise localization
    map_query = Fido.search(
        a.Time(peak_time - u.minute, peak_time + u.minute),
        a.Instrument.aia,
        a.Wavelength(wavelength),
        a.Provider.sdo
    )
    
    # Download the single best file closest to the peak time
    map_file = Fido.fetch(map_query[0, 0], path=DATA_PATH)[0]
    sdo_map = Map(map_file)

    # 2.3 Image Processing for Localization
    # Normalize the data and apply Otsu thresholding to find the flare boundary
    data = sdo_map.data.astype(float)
    data[data < 0] = 0 # Ensure non-negative data
    
    # Apply a smoothing filter (binary dilation) to merge adjacent bright pixels
    threshold_value = threshold_otsu(data) * 1.5 # Use 1.5x Otsu threshold for strict flare identification
    binary_mask = data > threshold_value
    
    # Optional: Dilate the mask slightly to ensure the entire flare region is captured
    dilated_mask = binary_dilation(binary_mask, disk(3))

    # Find connected components (potential flares)
    labeled_image = label(dilated_mask)
    regions = regionprops(labeled_image, intensity_image=data)
    
    if not regions:
        return {"status": "No Significant Flare Detected", "time": peak_time}

    # Find the largest and brightest region (the primary flare)
    primary_flare = max(regions, key=lambda r: r.area * r.mean_intensity)
    
    # Calculate the centroid in pixel coordinates
    pixel_centroid = primary_flare.centroid

    # Convert pixel coordinates to Helioprojective Cartesian (HPC) coordinates
    # Note: sdo_map.wcs converts pixel (y, x) to (lon, lat)
    hpc_coord = sdo_map.pixel_to_world(pixel_centroid[1] * u.pix, pixel_centroid[0] * u.pix)

    # 2.4 Structure the Results
    results = {
        "event_time": peak_time.isoformat(),
        "peak_flux_DN_s": peak_flux,
        "hpc_lon_arcsec": hpc_coord.Tx.to(u.arcsec).value,
        "hpc_lat_arcsec": hpc_coord.Ty.to(u.arcsec).value,
        "flare_area_pixels": primary_flare.area,
        "mean_intensity_DN_s": primary_flare.mean_intensity,
        "map_source_file": os.path.basename(map_file)
    }
    
    print(f"[{datetime.now().time()}] Flare localized at HPC: ({results['hpc_lon_arcsec']:.2f}, {results['hpc_lat_arcsec']:.2f}) arcsec.")
    
    return results, sdo_map, primary_flare


# --- Main Execution Block ---
if __name__ == "__main__":
    try:
        # 1. Fetch TimeSeries data
        solar_ts = fetch_and_process_data(START_TIME, END_TIME, WAVELENGTH)

        # 2. Analyze the event and localize the flare
        analysis_output, flare_map, flare_region = analyze_flare_event(solar_ts, WAVELENGTH)

        # 3. Output and Visualization (Simulating Database Insertion Prep)
        print("\n--- Flare Analysis Report ---")
        for key, value in analysis_output.items():
            print(f"{key:<20}: {value}")

        # Optional: Visualize the result (requires matplotlib backend)
        # fig = plt.figure(figsize=(10, 8))
        # ax = fig.add_subplot(111, projection=flare_map)
        # imshow_with_scale_hpc(flare_map.data, ax=ax, cmap='sdoaia171')
        
        # # Overlay the detected flare centroid
        # hpc_coord = SkyCoord(analysis_output['hpc_lon_arcsec'] * u.arcsec, 
        #                      analysis_output['hpc_lat_arcsec'] * u.arcsec, 
        #                      frame=flare_map.coordinate_frame)
        # ax.plot_coord(hpc_coord, 'ro', markersize=10, label='Flare Centroid')
        # ax.set_title(f"Localized Flare at {analysis_output['event_time']}")
        # plt.legend()
        # plt.show()

    except FileNotFoundError as e:
        print(f"CRITICAL ERROR: {e}")
    except Exception as e:
        print(f"An unexpected error occurred during processing: {e}")


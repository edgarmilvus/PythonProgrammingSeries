
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# Required imports for Exercise 4
from unittest import mock
import astropy.units as u

# Custom exception definition required for EAFP handling
class InvalidMetadataError(Exception):
    """Raised when critical FITS metadata is missing or invalid."""
    pass

# Mock setup required for Monkey Patching
CORRUPTED_MOCK_HEADER = {
    'TELESCOP': 'SDO/AIA',
    'DATE-OBS': '2024-01-01T12:00:00.000',
    # WAVE_LENGTH is intentionally missing here
}

# The student must define the refactored function using EAFP:
def validate_fits_metadata_eafp(header):
    """
    Validates critical FITS header keys using the EAFP approach.
    Raises InvalidMetadataError if keys are missing.
    """
    critical_keys = ['WAVE_LENGTH', 'DATE-OBS', 'TELESCOP']
    
    for key in critical_keys:
        try:
            # EAFP: Attempt to access the key directly
            value = header[key]
            
            # Simple value validation (e.g., check if wavelength is positive)
            if key == 'WAVE_LENGTH' and value <= 0:
                 raise InvalidMetadataError(f"Metadata error: '{key}' found but value ({value}) is non-positive.")

        except KeyError:
            # Catch the specific exception raised when the key is missing
            raise InvalidMetadataError(f"Metadata error: Critical key '{key}' is missing from header.")
        except Exception as e:
            # Catch other potential errors during access
            raise InvalidMetadataError(f"Metadata access failed for '{key}': {e}")
            
    return True

# Helper function to mock the source of the header
def mock_getheader_function(file_path):
    return CORRUPTED_MOCK_HEADER

# The student must define the test function using unittest.mock.patch:
def test_eafp_with_monkey_patching():
    """
    Uses monkey patching to inject a corrupted header and asserts EAFP catches the error.
    """
    print("\n--- Running Monkey Patch Test ---")
    
    # 2. Monkey Patching: Replace the source of the header reading
    # We patch the local mock_getheader_function to ensure it returns the corrupted header
    with mock.patch('__main__.mock_getheader_function', return_value=CORRUPTED_MOCK_HEADER) as mock_read:
        
        header = mock_read("path/to/corrupted_file.fits")
        
        # 3. Assert that calling the function raises the custom exception
        try:
            validate_fits_metadata_eafp(header)
            print("Test FAILED: EAFP validation did not raise InvalidMetadataError.")
            assert False
        except InvalidMetadataError as e:
            print(f"Test PASSED: EAFP successfully caught error: {e}")
            assert 'WAVE_LENGTH' in str(e) # Check the error message content
        except Exception as e:
            print(f"Test FAILED: Caught unexpected exception: {type(e).__name__}")
            assert False

# Conceptual Justification:
# EAFP (Easier to Ask for Forgiveness than Permission) is preferred in Python 
# over LBYL (Look Before You Leap) for API and data access because it is more 
# idiomatic, often faster (as exceptions are rare relative to successful access), 
# and handles race conditions better in multithreaded environments. Specifically, 
# LBYL requires two steps (check existence, then access), which can be interrupted, 
# whereas EAFP attempts the action directly, reducing code complexity and potential bugs.

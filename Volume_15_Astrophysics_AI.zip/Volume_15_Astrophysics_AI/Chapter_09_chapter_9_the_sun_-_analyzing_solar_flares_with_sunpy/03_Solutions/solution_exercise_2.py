
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Required imports for Exercise 2 (Segmentation)
import numpy as np
from sunpy.map import Map
from scipy import ndimage as ndi # For morphological operations
import astropy.units as u
from astropy.time import Time
from astropy.coordinates import SkyCoord
import matplotlib.pyplot as plt

def localize_flare_kernel(aia_map):
    """
    Performs statistical segmentation to locate the largest flare kernel.
    """
    data = aia_map.data
    
    # 1. Quiet Sun Masking
    hpc_coords = aia_map.pixel_to_world(np.indices(data.shape) * u.pixel)
    radial_distance = np.sqrt(hpc_coords.Tx.to(u.arcsec)**2 + hpc_coords.Ty.to(u.arcsec)**2)
    disk_radius = aia_map.rsun_arcsec.value
    
    # Define limb buffer (50 pixels * average plate scale)
    pixel_scale = np.mean(aia_map.scale.to(u.arcsec/u.pixel).value)
    limb_buffer_arcsec = 50 * pixel_scale 
    
    # Quiet Sun Mask: On disk, excluding the limb buffer
    quiet_sun_mask = (radial_distance.value < (disk_radius - limb_buffer_arcsec)) & (radial_distance.value > 0)
    
    if not np.any(quiet_sun_mask):
        print("Error: Quiet sun mask is empty.")
        return None, None

    # 2. Statistical Thresholding
    quiet_sun_intensity = data[quiet_sun_mask]
    mu_qs = np.median(quiet_sun_intensity)
    sigma_qs = np.std(quiet_sun_intensity)
    threshold = mu_qs + 5 * sigma_qs
    
    print(f"Quiet Sun Median: {mu_qs:.2f}, Sigma: {sigma_qs:.2f}. Threshold: {threshold:.2f}")

    # 3. Flare Pixel Identification
    flare_candidate_mask = data > threshold
    
    # Connectivity analysis
    labeled_array, num_features = ndi.label(flare_candidate_mask)
    
    if num_features == 0:
        print("No regions exceeded the 5 sigma threshold.")
        return None, None
        
    # Filter by minimum size (100 pixels)
    component_sizes = ndi.sum(flare_candidate_mask, labeled_array, range(1, num_features + 1))
    valid_labels = np.where(component_sizes >= 100)[0] + 1
    
    if len(valid_labels) == 0:
        print("No contiguous region met the minimum size requirement (100 pixels).")
        return None, None

    # Identify the largest valid region
    largest_label = valid_labels[np.argmax(component_sizes[valid_labels - 1])]
    largest_region_mask = labeled_array == largest_label

    # 4. Region of Interest (ROI) Extraction
    y_indices, x_indices = np.where(largest_region_mask)
    x_min, x_max = np.min(x_indices), np.max(x_indices)
    y_min, y_max = np.min(y_indices), np.max(y_indices)
    
    # Add buffer
    buffer = 20
    x_min, x_max = max(0, x_min - buffer), min(data.shape[1], x_max + buffer)
    y_min, y_max = max(0, y_min - buffer), min(data.shape[0], y_max + buffer)

    submap = aia_map.submap(u.Quantity([x_min, x_max] * u.pixel), u.Quantity([y_min, y_max] * u.pixel))
    
    # 5. Coordinate Reporting
    center_pixel = (x_min + x_max) / 2 * u.pixel, (y_min + y_max) / 2 * u.pixel
    center_coord = aia_map.pixel_to_world(*center_pixel)

    print(f"Largest Flare Kernel Center (HPC): {center_coord.to_string('hpc', precision=1)}")
    
    # Visualization
    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1, projection=submap)
    submap.plot(axes=ax, title=f"Localized Flare Kernel (5σ Threshold)")
    plt.show()

    return submap, center_coord

# --- Mock Map Setup (Required for execution without downloading data) ---
# (The mock map creation function from the thought process should be included 
# if this code were to be run directly, but is omitted here for brevity per instructions.)

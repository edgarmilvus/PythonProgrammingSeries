
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Required SunPy imports for Exercise 1
import sunpy.map
import sunpy.net.Fido
from sunpy.net import attrs as a
from sunpy.image.resample import reproject
import astropy.units as u
import matplotlib.pyplot as plt
import numpy as np
import warnings
from sunpy.map.mapbase import MapBase

def retrieve_and_align_maps(start_time_str, end_time_str):
    """
    Retrieves contemporaneous AIA data for 131A and 171A, aligns them, and visualizes the result.
    """
    time_range = a.Time(start_time_str, end_time_str)
    instrument = a.Instrument.aia
    provider = a.Provider.vso

    # 1. Data Retrieval (Robust Fido search and fetch)
    try:
        results = sunpy.net.Fido.search(
            time_range,
            instrument,
            a.Wavelength(131 * u.AA) | a.Wavelength(171 * u.AA),
            a.Sample(12 * u.s),
            provider
        )
        
        if len(results) == 0:
            print("Error: Fido search returned zero results for the specified criteria.")
            return None, None

        # Fetch the first result for each wavelength
        files = sunpy.net.Fido.fetch(results[:, 0]) 

    except Exception as e:
        print(f"Error during Fido search or download (Network/VSO issue): {e}")
        return None, None

    # 2. Map Creation and Validation
    map_131 = None
    map_171 = None
    
    for f in files:
        try:
            m = sunpy.map.Map(f)
            # Metadata check
            if m.meta.get('INSTRUME') != 'AIA' or m.meta.get('TELESCOP') != 'SDO':
                print(f"Warning: Skipping file {f} due to incorrect instrument metadata.")
                continue

            if m.wavelength.to(u.AA).value == 131:
                map_131 = m
            elif m.wavelength.to(u.AA).value == 171:
                map_171 = m
        except Exception as e:
            print(f"Error creating Map from file {f}: {e}")
            
    if not map_131 or not map_171:
        print("Error: Could not successfully create both 131A and 171A maps.")
        return None, None

    # 3. WCS Alignment
    reference_map = map_171
    
    try:
        # Reproject 131A map onto the 171A WCS grid
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # reproject returns the new data array and the new WCS object
            aligned_data, out_wcs = reproject(map_131, reference_map.wcs, reference_map.data.shape)
        
        # Create a new Map object using the reference WCS metadata
        aligned_map_131 = sunpy.map.Map(aligned_data, reference_map.meta)
        
    except Exception as e:
        print(f"Error during map reprojection: {e}")
        return map_171, map_131

    # 4. Visualization
    fig = plt.figure(figsize=(12, 6))
    
    ax1 = fig.add_subplot(1, 2, 1, projection=map_171)
    map_171.plot(axes=ax1, title=f"Original AIA 171Å (Reference) {map_171.date.isot}")
    map_171.draw_limb(axes=ax1, color='white', linewidth=1)

    ax2 = fig.add_subplot(1, 2, 2, projection=aligned_map_131)
    # Use the reference map's normalization for consistent visual scaling
    aligned_map_131.plot(axes=ax2, title=f"Aligned AIA 131Å (Reprojected)", 
                         norm=map_171.plot_settings['norm']) 
    aligned_map_131.draw_limb(axes=ax2, color='white', linewidth=1)
    
    plt.suptitle("Multi-Wavelength Alignment Check")
    plt.tight_layout()
    plt.show()

    return map_171, aligned_map_131

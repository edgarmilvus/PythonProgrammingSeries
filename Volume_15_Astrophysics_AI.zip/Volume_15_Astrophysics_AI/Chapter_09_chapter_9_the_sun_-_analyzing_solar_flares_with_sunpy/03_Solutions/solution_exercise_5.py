
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# Required imports for Exercise 5
from collections import deque
import sunpy.map
import numpy as np
import astropy.units as u
from astropy.time import Time
import random

class FlareMonitoringAgent:
    def __init__(self):
        # 1. Initialize memory (deque)
        # Initializing with baseline values to establish a starting average
        self.recent_peak_fluxes = deque([100.0, 100.0, 100.0], maxlen=3) # LLM Memory Simulation
        print(f"Agent initialized with baseline flux memory: {list(self.recent_peak_fluxes)}")

    def run_detection_cycle(self, current_map):
        """
        Simulates the localization and intensity measurement steps, returning Net Flare Flux.
        """
        data = current_map.data
        
        # Use 99.9th percentile as a proxy for the localized flare peak intensity
        peak_intensity_proxy = np.percentile(data, 99.9)
        
        # Simple background subtraction proxy
        median_bg = np.median(data)
        net_peak_flux = max(0, peak_intensity_proxy - median_bg) * 10 # Scale up for magnitude
        
        return net_peak_flux

    def analyze_and_report(self, current_map):
        current_flux = self.run_detection_cycle(current_map)
        
        # Calculate historical average
        historical_average = np.mean(self.recent_peak_fluxes)
        
        # b. Determine Significance Threshold (150% of historical average)
        significance_threshold = 1.5 * historical_average
        is_significant = current_flux > significance_threshold

        # a. Update memory
        self.recent_peak_fluxes.append(current_flux)
        
        print(f"Cycle {current_map.date.isot}: F_current={current_flux:.2f}. F_avg={historical_average:.2f}. Threshold={significance_threshold:.2f}")

        # c. Generate structured report
        if is_significant:
            print("\n=======================================================")
            print(f"!!! SIGNIFICANT FLARE EVENT DETECTED !!!")
            print(f"Observation Time: {current_map.date.isot}")
            print(f"Peak Net Flux: {current_flux:.2f} DN/s")
            print(f"Historical Context (Last 3 cycles avg): {historical_average:.2f} DN/s")
            print(f"Event Magnitude: {current_flux / historical_average:.2f}x Historical Average")
            print("=======================================================\n")
            
        return is_significant

# The student must generate the DOT visualization code below:
# 4. Pipeline Visualization (Graphviz DOT Code)
DOT_CODE = """
digraph FlareMonitoringAgentPipeline {
    rankdir=LR;
    node [shape=box, style="filled", fillcolor="#E0F7FA"];

    subgraph cluster_memory {
        label = "LLM Context (Deque Memory)";
        bgcolor="#FFFDE7";
        M [label="self.recent_peak_fluxes (N=3)", shape=cylinder, fillcolor="#FFECB3"];
    }

    A [label="1. Input Map (SDO/AIA)", fillcolor="#BBDEFB"];
    B [label="2. run_detection_cycle()"];
    C [label="3. Calculate Current Peak Flux (F_current)"];
    D [label="4. Calculate Historical Average (F_avg)"];
    E [label="5. Significance Check (F_current > 1.5 * F_avg)", shape=diamond, fillcolor="#FFCDD2"];
    F [label="6. Update Memory (M.append(F_current))"];
    G [label="7. Generate Structured Report", fillcolor="#C8E6C9"];

    A -> B;
    B -> C;
    C -> D;
    
    M -> D [label="Read History"];
    F -> M [label="Write New Context"];
    
    D -> E;
    C -> E;
    
    E -> F [label="Always Update"];
    E -> G [label="True (Significant Event)"];
    F -> A [label="Next Cycle", style=dashed];
}
"""
print(DOT_CODE)

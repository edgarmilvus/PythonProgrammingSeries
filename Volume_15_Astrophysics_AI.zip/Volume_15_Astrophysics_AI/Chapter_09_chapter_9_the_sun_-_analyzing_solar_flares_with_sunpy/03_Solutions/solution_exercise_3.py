
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

# Required imports for Exercise 3 (Temporal Analysis)
import pandas as pd
from sunpy.timeseries import TimeSeries
from astropy.time import Time
import matplotlib.pyplot as plt
import numpy as np
from sunpy.map import Map # Used for mock data

# Helper function (simplified Quiet Sun mask for background calculation)
def get_simplified_quiet_sun_mask(data, roi_pixels):
    """
    Creates a mask for the Quiet Sun, excluding the ROI and the edges.
    """
    mask = np.ones(data.shape, dtype=bool)
    
    # Exclude the fixed ROI
    x_min, x_max, y_min, y_max = roi_pixels
    mask[y_min:y_max, x_min:x_max] = False
    
    # Simple edge exclusion (e.g., 50 pixels border) to avoid instrumental artifacts
    mask[:50, :] = False
    mask[-50:, :] = False
    mask[:, :50] = False
    mask[:, -50:] = False
    
    return mask

def generate_normalized_lightcurve(map_list, fixed_roi_pixels):
    """
    Calculates the normalized Net Flare Flux over time for a fixed ROI.
    """
    times = []
    net_flare_fluxes = []
    
    x_min, x_max, y_min, y_max = fixed_roi_pixels
    roi_area = (x_max - x_min) * (y_max - y_min)
    
    if roi_area <= 0:
        raise ValueError("Invalid ROI dimensions.")

    # 1. Intensity Extraction Loop
    for current_map in map_list:
        data = current_map.data
        
        # a. Integrated intensity within the fixed ROI
        roi_intensity_sum = np.sum(data[y_min:y_max, x_min:x_max])
        
        # b. Calculate median background intensity (Quiet Sun)
        qs_mask = get_simplified_quiet_sun_mask(data, fixed_roi_pixels)
        median_background = np.median(data[qs_mask]) if np.sum(qs_mask) > 0 else 0
            
        # c. Calculate the Net Flare Flux
        # Net Flare Flux = (Total ROI) - (Median Background per pixel * ROI Area)
        net_flare_flux = roi_intensity_sum - (median_background * roi_area)
        
        times.append(current_map.date.datetime)
        net_flare_fluxes.append(net_flare_flux)

    # 3. Data Structure
    data_df = pd.DataFrame({'time': times, 'net_flux': net_flare_fluxes}).set_index('time')
    ts = TimeSeries(data_df['net_flux'])

    # 4. Visualization and Classification
    plt.figure(figsize=(10, 5))
    ts.plot(marker='.', linestyle='-')
    plt.title(f"Normalized AIA Flare Light Curve (ROI: {fixed_roi_pixels})")
    plt.ylabel("Net Flare Flux (DN/s)")
    plt.xlabel("Time (UTC)")
    plt.grid(True, linestyle='--', alpha=0.6)

    # Identify peak intensity
    peak_flux = ts.data.max()
    peak_time = ts.data.idxmax()
    
    plt.axvline(peak_time, color='r', linestyle='--', label=f'Peak: {peak_time.strftime("%H:%M:%S")}')
    plt.legend()
    plt.show()

    # Preliminary Classification based on EUV flux magnitude (conceptual)
    # GOES classes are based on X-ray flux (W/m^2). These thresholds are arbitrary 
    # for AIA DN/s but illustrate the classification concept.
    if peak_flux > 5e5:
        classification = "High M-class equivalent"
    elif peak_flux > 1e5:
        classification = "Low M/High C-class equivalent"
    else:
        classification = "C-class equivalent or lower"

    print(f"\n--- Temporal Analysis Results ---")
    print(f"Peak Net Flux: {peak_flux:.2f} DN/s")
    print(f"Time of Peak: {peak_time}")
    print(f"Preliminary AIA Magnitude Suggestion: {classification}")
    
    return ts

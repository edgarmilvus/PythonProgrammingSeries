
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
import numpy as np

# --- 1. Hyperparameters and Configuration ---
# Set the size of the random noise vector (the latent space dimension)
Z_DIM = 100 
# Image dimensions (we simulate 64x64, 3-channel (RGB) nebula images)
IMAGE_SIZE = 64
CHANNELS_IMG = 3
# Learning rates for the two networks
LR_G = 0.0002
LR_D = 0.0002
# Batch size for simulation
BATCH_SIZE = 64
# Use GPU if available
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --- 2. Defining the Generator Network (The Forger) ---
# The Generator takes Z_DIM noise and upscales it to an IMAGE_SIZE output.
class Generator(nn.Module):
    def __init__(self, z_dim, channels_img, features_g):
        super(Generator, self).__init__()
        self.net = nn.Sequential(
            # Input: N x Z_DIM x 1 x 1 (Starts as a tiny feature map)
            nn.ConvTranspose2d(z_dim, features_g * 8, 4, 1, 0, bias=False), 
            # Output: N x (features_g * 8) x 4 x 4
            nn.BatchNorm2d(features_g * 8),
            nn.ReLU(),
            
            nn.ConvTranspose2d(features_g * 8, features_g * 4, 4, 2, 1, bias=False),
            # Output: N x (features_g * 4) x 8 x 8
            nn.BatchNorm2d(features_g * 4),
            nn.ReLU(),
            
            nn.ConvTranspose2d(features_g * 4, features_g * 2, 4, 2, 1, bias=False),
            # Output: N x (features_g * 2) x 16 x 16
            nn.BatchNorm2d(features_g * 2),
            nn.ReLU(),
            
            nn.ConvTranspose2d(features_g * 2, features_g, 4, 2, 1, bias=False),
            # Output: N x features_g x 32 x 32
            nn.BatchNorm2d(features_g),
            nn.ReLU(),
            
            nn.ConvTranspose2d(features_g, channels_img, 4, 2, 1, bias=False),
            # Output: N x CHANNELS_IMG x 64 x 64 (The synthetic image)
            nn.Tanh() # Tanh scales output pixels to the range [-1, 1]
        )

    def forward(self, input):
        return self.net(input)

# --- 3. Defining the Discriminator Network (The Critic) ---
# The Discriminator takes an image and outputs a single probability (real/fake).
class Discriminator(nn.Module):
    def __init__(self, channels_img, features_d):
        super(Discriminator, self).__init__()
        self.net = nn.Sequential(
            # Input: N x CHANNELS_IMG x 64 x 64
            nn.Conv2d(channels_img, features_d, 4, 2, 1, bias=False),
            # Output: N x features_d x 32 x 32
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Conv2d(features_d, features_d * 2, 4, 2, 1, bias=False),
            # Output: N x (features_d * 2) x 16 x 16
            nn.BatchNorm2d(features_d * 2),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Conv2d(features_d * 2, features_d * 4, 4, 2, 1, bias=False),
            # Output: N x (features_d * 4) x 8 x 8
            nn.BatchNorm2d(features_d * 4),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Conv2d(features_d * 4, features_d * 8, 4, 2, 1, bias=False),
            # Output: N x (features_d * 8) x 4 x 4
            nn.BatchNorm2d(features_d * 8),
            nn.LeakyReLU(0.2, inplace=True),
            
            nn.Conv2d(features_d * 8, 1, 4, 1, 0, bias=False),
            # Output: N x 1 x 1 x 1 (A single raw prediction value)
            nn.Sigmoid() # Sigmoid squashes the output to a probability (0 to 1)
        )

    def forward(self, input):
        return self.net(input).view(-1, 1).squeeze(1) # Flatten output to a vector of probabilities

# --- 4. Initialization and Setup ---
# Initialize weights of the networks (standard practice for DCGANs)
def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.normal_(m.weight.data, 0.0, 0.02) # Initialize weights from a normal distribution
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight.data, 1.0, 0.02)
        nn.init.constant_(m.bias.data, 0)

# Instantiate models
netG = Generator(Z_DIM, CHANNELS_IMG, features_g=64).to(DEVICE)
netD = Discriminator(CHANNELS_IMG, features_d=64).to(DEVICE)

# Apply custom weight initialization
netG.apply(weights_init)
netD.apply(weights_init)

# Define Loss function and Optimizers
criterion = nn.BCELoss() # Binary Cross-Entropy Loss is standard for GAN classification
optimizerD = optim.Adam(netD.parameters(), lr=LR_D, betas=(0.5, 0.999))
optimizerG = optim.Adam(netG.parameters(), lr=LR_G, betas=(0.5, 0.999))

# Placeholder data: Simulating a batch of preprocessed nebula images
# In a real scenario, this would be loaded from a DataLoader reading FITS/PNG files.
real_nebulas = torch.randn(BATCH_SIZE, CHANNELS_IMG, IMAGE_SIZE, IMAGE_SIZE).to(DEVICE)

# Define labels for adversarial training
real_label = 1.0
fake_label = 0.0

print(f"GAN initialized. Device: {DEVICE}")

# --- 5. Single Training Step Simulation (The Adversarial Loop) ---

# 5a. Train Discriminator (D) on REAL data
netD.zero_grad()
label = torch.full((BATCH_SIZE,), real_label, dtype=torch.float, device=DEVICE)
output_real = netD(real_nebulas).view(-1)
errD_real = criterion(output_real, label)
errD_real.backward() # Calculate gradients based on real data

D_x = output_real.mean().item() # Track D's average prediction on real data

# 5b. Train Discriminator (D) on FAKE data
noise = torch.randn(BATCH_SIZE, Z_DIM, 1, 1, device=DEVICE) # Generate random noise
fake_images = netG(noise) # Generate synthetic images using G
label.fill_(fake_label) # Flip labels to 'fake' (0.0)
output_fake = netD(fake_images.detach()).view(-1) # Detach G's output to prevent gradient calculation for G during D update
errD_fake = criterion(output_fake, label)
errD_fake.backward() # Calculate gradients based on fake data

D_G_z1 = output_fake.mean().item() # Track D's average prediction on fake data (before G update)

# Combine losses and update Discriminator
errD = errD_real + errD_fake
optimizerD.step()

# 5c. Train Generator (G)
netG.zero_grad()
label.fill_(real_label) # G wants D to think its fake images are REAL (label=1.0)
output = netD(fake_images).view(-1) # Run the (already generated) fake images through D again
errG = criterion(output, label)
errG.backward() # Calculate gradients and update G
optimizerG.step()

D_G_z2 = output.mean().item() # Track D's average prediction on fake data (after G update)

# --- 6. Results Summary (After one step) ---
print("\n--- Single Step Summary ---")
print(f"Discriminator Loss (D): {errD.item():.4f}")
print(f"Generator Loss (G): {errG.item():.4f}")
print(f"D(x) [Real Prediction]: {D_x:.4f} (Should approach 1.0)")
print(f"D(G(z)) [Fake Prediction]: {D_G_z2:.4f} (Should approach 0.5)")

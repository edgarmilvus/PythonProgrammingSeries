
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os
from PIL import Image
import random

# --- 1. Configuration and Hyperparameters ---
# Define the core parameters for the GAN architecture and training environment.
class Config:
    IMAGE_SIZE = 256        # Target resolution for synthetic nebulas (256x256 pixels)
    CHANNELS_IMG = 3        # We assume standard RGB (3 channels) for visual representation
    Z_DIM = 100             # Dimensionality of the latent noise vector (Z)
    FEATURES_G = 64         # Base number of feature maps in the Generator
    FEATURES_D = 64         # Base number of feature maps in the Discriminator
    BATCH_SIZE = 64
    NUM_WORKERS = 4         # For efficient data loading
    LEARNING_RATE = 0.0002
    BETA1 = 0.5             # Beta1 for Adam optimizer (standard for GANs)
    DATA_PATH = "nebula_dataset/" # Placeholder path for where the real images reside

# Initialize configuration object
CFG = Config()

# Set device for computation (GPU if available)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# --- 2. Custom Dataset for Astronomical Images ---
# Astronomical images often require specialized handling (e.g., FITS conversion, high dynamic range).
# This class simulates loading pre-processed JPEG/PNG images from a directory.
class NebulaDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        # List all image files in the directory
        self.image_files = [os.path.join(root_dir, f) for f in os.listdir(root_dir)
                            if f.endswith(('.png', '.jpg', '.jpeg'))]
        
        # Critical check for data availability
        if not self.image_files:
            print(f"Warning: No images found in {root_dir}. Generating dummy data.")
            # Create a simple dummy file structure for demonstration if data is missing
            self._create_dummy_data()
        
        self.image_files = [os.path.join(root_dir, f) for f in os.listdir(root_dir)
                            if f.endswith(('.png', '.jpg', '.jpeg'))]


    def _create_dummy_data(self):
        """Creates placeholder black images if the dataset folder is empty."""
        os.makedirs(self.root_dir, exist_ok=True)
        print("Creating 5 dummy 256x256 black images.")
        for i in range(5):
            dummy_image = Image.fromarray(np.zeros((CFG.IMAGE_SIZE, CFG.IMAGE_SIZE, CFG.CHANNELS_IMG), dtype=np.uint8))
            dummy_image.save(os.path.join(self.root_dir, f"dummy_nebula_{i}.png"))


    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        # Open the image using PIL
        image = Image.open(img_path).convert("RGB")
        
        # Apply defined transformations (resizing, normalization, tensor conversion)
        if self.transform:
            image = self.transform(image)
        
        return image

# Define standard transformations for DCGAN input
# Normalization to [-1, 1] is crucial because the Generator uses the Tanh activation.
image_transforms = transforms.Compose(
    [
        transforms.Resize(CFG.IMAGE_SIZE),
        transforms.CenterCrop(CFG.IMAGE_SIZE),
        transforms.ToTensor(), # Converts image to [0, 1] range
        transforms.Normalize(
            [0.5 for _ in range(CFG.CHANNELS_IMG)], # Mean normalization
            [0.5 for _ in range(CFG.CHANNELS_IMG)], # Standard deviation normalization
        ), # Final range is [-1, 1]
    ]
)

# Initialize the dataset and dataloader
dataset = NebulaDataset(root_dir=CFG.DATA_PATH, transform=image_transforms)
dataloader = DataLoader(
    dataset,
    batch_size=CFG.BATCH_SIZE,
    shuffle=True,
    num_workers=CFG.NUM_WORKERS,
)

# --- 3. Weight Initialization Function ---
# Custom weight initialization is vital for stabilizing GAN training.
def initialize_weights(model):
    # Iterate through all modules (layers) in the model
    for m in model.modules():
        # Initialize Convolutional layers
        if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d, nn.BatchNorm2d)):
            # Standard initialization for Conv layers (mean=0.0, std=0.02)
            nn.init.normal_(m.weight.data, 0.0, 0.02)
        # Initialize Batch Normalization layers
        if isinstance(m, nn.BatchNorm2d) and m.weight is not None:
             # BN gamma (weight) should be initialized close to 1
            nn.init.normal_(m.weight.data, 1.0, 0.02)
            # BN beta (bias) should be initialized to 0
            nn.init.constant_(m.bias.data, 0)

# --- 4. Discriminator Architecture (D) ---
# D takes an image and outputs a single probability (real or fake).
# It uses strided convolutions to progressively reduce the spatial dimensions.
class Discriminator(nn.Module):
    def __init__(self, channels_img, features_d):
        super(Discriminator, self).__init__()
        self.disc = nn.Sequential(
            # Input: N x channels_img x 256 x 256
            nn.Conv2d(channels_img, features_d, kernel_size=4, stride=2, padding=1),
            nn.LeakyReLU(0.2), # Standard activation for D

            # Block 1: 128x128
            self._block(features_d, features_d * 2, 4, 2, 1), # Output: 64x64
            
            # Block 2: 64x64
            self._block(features_d * 2, features_d * 4, 4, 2, 1), # Output: 32x32

            # Block 3: 32x32
            self._block(features_d * 4, features_d * 8, 4, 2, 1), # Output: 16x16
            
            # Block 4: 16x16
            self._block(features_d * 8, features_d * 16, 4, 2, 1), # Output: 8x8

            # Block 5: 8x8
            self._block(features_d * 16, features_d * 32, 4, 2, 1), # Output: 4x4

            # Final Output Layer: 4x4 -> 1x1
            nn.Conv2d(features_d * 32, 1, kernel_size=4, stride=1, padding=0),
            nn.Sigmoid(), # Output probability between 0 and 1
        )

    # Helper function for a standard Discriminator block
    def _block(self, in_channels, out_channels, kernel_size, stride, padding):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False),
            nn.BatchNorm2d(out_channels), # Batch normalization helps stabilize D
            nn.LeakyReLU(0.2),
        )

    def forward(self, x):
        return self.disc(x)

# --- 5. Generator Architecture (G) ---
# G takes a latent noise vector (Z) and upsamples it to the target image size (256x256).
# It uses Transposed Convolutions (deconvolutions).
class Generator(nn.Module):
    def __init__(self, z_dim, channels_img, features_g):
        super(Generator, self).__init__()
        self.gen = nn.Sequential(
            # Start from the latent vector Z (N x z_dim x 1 x 1)
            # Project Z up to a 4x4 feature map
            self._block(z_dim, features_g * 32, 4, 1, 0), # Output: 4x4x(features_g * 32)

            # Block 1: 4x4 -> 8x8
            self._block(features_g * 32, features_g * 16, 4, 2, 1), # Output: 8x8

            # Block 2: 8x8 -> 16x16
            self._block(features_g * 16, features_g * 8, 4, 2, 1), # Output: 16x16

            # Block 3: 16x16 -> 32x32
            self._block(features_g * 8, features_g * 4, 4, 2, 1), # Output: 32x32

            # Block 4: 32x32 -> 64x64
            self._block(features_g * 4, features_g * 2, 4, 2, 1), # Output: 64x64

            # Block 5: 64x64 -> 128x128
            self._block(features_g * 2, features_g, 4, 2, 1), # Output: 128x128

            # Final layer: 128x128 -> 256x256
            nn.ConvTranspose2d(
                features_g, channels_img, kernel_size=4, stride=2, padding=1
            ),
            # Output activation must be Tanh to match the [-1, 1] normalization of the input data
            nn.Tanh(), # Output: N x channels_img x 256 x 256
        )

    # Helper function for a standard Generator block
    def _block(self, in_channels, out_channels, kernel_size, stride, padding):
        return nn.Sequential(
            # Use ConvTranspose2d for upsampling
            nn.ConvTranspose2d(
                in_channels, out_channels, kernel_size, stride, padding, bias=False
            ),
            nn.BatchNorm2d(out_channels), # BN helps G learn faster
            nn.ReLU(), # Standard activation for G
        )

    def forward(self, x):
        return self.gen(x)

# --- 6. Model Initialization and Sanity Check ---

# Instantiate the models
netG = Generator(CFG.Z_DIM, CFG.CHANNELS_IMG, CFG.FEATURES_G).to(DEVICE)
netD = Discriminator(CFG.CHANNELS_IMG, CFG.FEATURES_D).to(DEVICE)

# Apply the custom weight initialization
initialize_weights(netG)
initialize_weights(netD)

# Define Optimizers (Adam is preferred for GANs)
optimizerG = optim.Adam(netG.parameters(), lr=CFG.LEARNING_RATE, betas=(CFG.BETA1, 0.999))
optimizerD = optim.Adam(netD.parameters(), lr=CFG.LEARNING_RATE, betas=(CFG.BETA1, 0.999))

# Define Loss Function (Binary Cross Entropy Loss is standard for the GAN objective)
criterion = nn.BCELoss()

# Fixed noise vector for visualizing generator progress during training (not used here, but essential for real training)
fixed_noise = torch.randn(64, CFG.Z_DIM, 1, 1).to(DEVICE)

# Sanity Check: Generate a batch of fake images and verify dimensions
print("\n--- Model Sanity Check ---")
# Get one batch of real data dimensions
data_iter = iter(dataloader)
if len(dataset) > 0:
    real_batch = next(data_iter)
    print(f"Real Image Batch Shape: {real_batch[0].shape}")
else:
    print("Cannot perform sanity check: Dataset is empty.")
    exit()

# Generate noise vector
noise = torch.randn(CFG.BATCH_SIZE, CFG.Z_DIM, 1, 1).to(DEVICE)

# Perform forward pass through the Generator
fake_images = netG(noise)

# Check the output shape of the Generator
print(f"Generator Output Shape: {fake_images.shape}")

# Perform forward pass through the Discriminator on fake images
output_D_fake = netD(fake_images.detach()).view(-1)
print(f"Discriminator Output (Fake) Shape: {output_D_fake.shape}")

# Perform forward pass through the Discriminator on real images
output_D_real = netD(real_batch.to(DEVICE)).view(-1)
print(f"Discriminator Output (Real) Shape: {output_D_real.shape}")

print("\nDCGAN Architecture successfully initialized and dimensions verified.")
# The script is now ready for the main training loop (not included here).

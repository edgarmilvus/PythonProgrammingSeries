
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

import torch
import torch.nn as nn
import numpy as np

# --- I. Data Preprocessing Utility (Conceptual) ---
def log_stretch_and_normalize(image_data):
    """
    Applies a logarithmic stretch to handle high dynamic range 
    and normalizes the data to [-1, 1] for GAN training.
    Assumes image_data is a numpy array (e.g., from FITS file).
    """
    # 1. Logarithmic Stretching (adjusting for astronomical intensity)
    # Adding a small constant (epsilon) to avoid log(0)
    epsilon = 1e-6
    stretched_data = np.log1p(image_data / np.max(image_data) + epsilon)
    
    # 2. Rescale to [-1, 1] range (necessary for tanh output layer)
    min_val = np.min(stretched_data)
    max_val = np.max(stretched_data)
    
    normalized_data = 2 * ((stretched_data - min_val) / (max_val - min_val)) - 1
    
    return torch.tensor(normalized_data, dtype=torch.float32).permute(2, 0, 1) # C, H, W format

# --- II. DCGAN Architecture Components ---

# Hyperparameters
LATENT_DIM = 100
IMAGE_CHANNELS = 3 # RGB or mapped spectral channels
IMAGE_SIZE = 64 # Starting with a lower resolution for clarity

class Discriminator(nn.Module):
    """
    The Critic: A standard CNN classifier designed to distinguish real nebulas from fake ones.
    Uses strided convolutions for downsampling.
    """
    def __init__(self):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            # Input: (3) x 64 x 64
            nn.Conv2d(IMAGE_CHANNELS, 64, 4, 2, 1, bias=False), # Output: 64 x 32 x 32
            nn.LeakyReLU(0.2, inplace=True),

            # Second Block
            nn.Conv2d(64, 128, 4, 2, 1, bias=False), # Output: 128 x 16 x 16
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),

            # Third Block
            nn.Conv2d(128, 256, 4, 2, 1, bias=False), # Output: 256 x 8 x 8
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),

            # Fourth Block (Final Feature Map)
            nn.Conv2d(256, 512, 4, 2, 1, bias=False), # Output: 512 x 4 x 4
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),

            # Output Layer: Flatten and Sigmoid for binary classification
            nn.Conv2d(512, 1, 4, 1, 0, bias=False), # Output: 1 x 1 x 1
            nn.Sigmoid() # Output probability (Real=1, Fake=0)
        )

    def forward(self, x):
        return self.model(x).view(-1, 1).squeeze(1)

class Generator(nn.Module):
    """
    The Forger: Uses Transposed Convolutions (ConvTranspose2d) to upsample 
    a latent vector into a high-resolution image.
    """
    def __init__(self):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            # Input: Z (100) -> reshaped to 1024 x 1 x 1
            nn.ConvTranspose2d(LATENT_DIM, 512, 4, 1, 0, bias=False), # Output: 512 x 4 x 4
            nn.BatchNorm2d(512),
            nn.ReLU(True),

            # Second Block
            nn.ConvTranspose2d(512, 256, 4, 2, 1, bias=False), # Output: 256 x 8 x 8
            nn.BatchNorm2d(256),
            nn.ReLU(True),

            # Third Block
            nn.ConvTranspose2d(256, 128, 4, 2, 1, bias=False), # Output: 128 x 16 x 16
            nn.BatchNorm2d(128),
            nn.ReLU(True),

            # Fourth Block
            nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False), # Output: 64 x 32 x 32
            nn.BatchNorm2d(64),
            nn.ReLU(True),

            # Output Layer: Generate the final image
            nn.ConvTranspose2d(64, IMAGE_CHANNELS, 4, 2, 1, bias=False), # Output: 3 x 64 x 64
            nn.Tanh() # Activation that scales output to [-1, 1]
        )

    def forward(self, z):
        # Input Z must be reshaped for ConvTranspose2d
        z = z.view(z.size(0), LATENT_DIM, 1, 1)
        return self.model(z)

# --- III. Initialization and Testing Setup ---
def initialize_weights(m):
    """
    Custom weight initialization, critical for stabilizing GAN training.
    Commonly uses N(0, 0.02) initialization.
    """
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight.data, 1.0, 0.02)
        nn.init.constant_(m.bias.data, 0)

# Example Instantiation and Weight Application
netG = Generator()
netG.apply(initialize_weights)

netD = Discriminator()
netD.apply(initialize_weights)

# Example Usage: Generate a batch of 16 synthetic nebulas
batch_size = 16
noise = torch.randn(batch_size, LATENT_DIM, 1, 1)

# G generates the fake data
fake_images = netG(noise)

# D evaluates the fake data
output = netD(fake_images.detach()) # .detach() prevents gradient flow back to G during D's training

# The Discriminator output (D_G_z) should be close to 0 if D is good, or close to 1 if G is good.
# print(f"Discriminator output shape: {output.shape}") 
# print(f"Sample Discriminator score on fake data: {output[0].item():.4f}") 

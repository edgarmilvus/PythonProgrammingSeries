
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
from typing import Any

# 1. Define the Async Context Manager
class AstroStorageClient:
    """
    Simulated asynchronous client for saving generated astronomical images.
    Implements the Asynchronous Context Manager protocol.
    """
    def __init__(self, storage_url: str):
        self.storage_url = storage_url
        self.is_connected = False
        
    async def __aenter__(self) -> 'AstroStorageClient':
        """Simulate establishing an asynchronous connection."""
        print(f"AstroStorageClient: Establishing secure connection to {self.storage_url}...")
        await asyncio.sleep(0.05) # Simulate network handshake delay
        self.is_connected = True
        print("AstroStorageClient: Connection established.")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Simulate closing the connection and performing cleanup."""
        if exc_type is not None:
            print(f"AstroStorageClient: Encountered exception during generation: {exc_val}")
            
        print("AstroStorageClient: Closing connection and flushing buffer...")
        await asyncio.sleep(0.02) # Simulate buffer flush delay
        self.is_connected = False
        print("AstroStorageClient: Connection closed.")
        return True # Return True to suppress exceptions if handled internally

    # 2. Simulate Asynchronous I/O
    async def save_image(self, image_id: int, tensor_data: Any):
        """Simulate writing a large image tensor to remote storage."""
        if not self.is_connected:
            raise ConnectionError("Client is not connected. Use async with.")
            
        # Simulate the time delay of writing a large FITS file
        await asyncio.sleep(0.01) 
        print(f"  [I/O Done] Image {image_id} saved successfully.")

# 3. Integration: High-throughput generation pipeline
async def high_throughput_generation_pipeline(num_images: int):
    """
    Generates and asynchronously saves images, maximizing throughput by
    decoupling generation (fast) from I/O (slow).
    """
    storage_url = "s3://nebula-archive/run-2024-gan"
    
    # Use async with to manage the asynchronous resource lifecycle
    async with AstroStorageClient(storage_url) as client:
        print(f"\n--- Starting High-Throughput Generation ({num_images} images) ---")
        
        # We collect all asynchronous save tasks
        save_tasks = []
        
        for i in range(1, num_images + 1):
            # Simulate GPU generation (instantaneous in this mock)
            generated_tensor = f"Tensor_Data_{i}" 
            print(f"[GPU Done] Image {i} generated.")
            
            # Start the I/O task asynchronously without waiting
            task = client.save_image(i, generated_tensor)
            save_tasks.append(task)
            
        # Wait for all asynchronous storage operations to complete
        print("\nWaiting for all pending I/O tasks to finish...")
        await asyncio.gather(*save_tasks)
        
    print("--- Pipeline Finished ---")

# Execute the asynchronous main function
if __name__ == "__main__":
    # Note: Running 10 images, the total time will be dominated by the 
    # connection/disconnection delays and the longest single asyncio.sleep(0.01) 
    # rather than 10 * 0.01 seconds, demonstrating concurrency.
    asyncio.run(high_throughput_generation_pipeline(10))

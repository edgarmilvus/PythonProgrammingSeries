
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
import csv
from typing import Generator, Dict, Any

# --- Mock Setup (for demonstration purposes) ---
def create_mock_metadata_file(file_path):
    # Create a simulated large metadata file with valid and invalid entries
    data = [
        "Index,RA,Dec,Filter_Band,Quality_Flag",
        "1,15.5,45.2,R,HIGH",
        "2,361.0,-10.0,G,HIGH",  # Invalid RA (out of range)
        "3,100.0,95.0,B,HIGH",   # Invalid Dec (out of range)
        "4,200.1,10.5,I,LOW",    # Invalid Quality Flag
        "5,250.0,50.0,R,HIGH",
        "6,malformed_data,40.0,G,HIGH", # Malformed RA (non-numeric)
        "7,300.0,-50.0,Z,HIGH"
    ]
    with open(file_path, 'w') as f:
        f.write('\n'.join(data))

MOCK_FILE = 'large_nebula_catalog.csv'
create_mock_metadata_file(MOCK_FILE)
# -----------------------------------------------

def stream_and_validate_metadata(file_path: str) -> Generator[Dict[str, Any], None, None]:
    """
    Streams a large CSV file line by line, validates astronomical metadata,
    and yields only high-quality records.
    """
    
    REQUIRED_QUALITY = 'HIGH'
    
    try:
        with open(file_path, 'r') as f:
            # 1. Use Iterating over a File Object (f acts as the iterable)
            header = next(f).strip().split(',') # Read and skip the header
            
            for line_number, line in enumerate(f, start=2):
                line = line.strip()
                if not line:
                    continue

                try:
                    # Parse the line
                    values = line.split(',')
                    if len(values) != len(header):
                        raise ValueError("Incorrect number of columns.")
                        
                    record = dict(zip(header, values))
                    
                    # Type Coercion and Validation
                    ra = float(record['RA'])
                    dec = float(record['Dec'])
                    quality = record['Quality_Flag']
                    
                    # 2. Schema Validation Logic
                    is_valid_ra = 0.0 <= ra <= 360.0
                    is_valid_dec = -90.0 <= dec <= 90.0
                    is_high_quality = quality == REQUIRED_QUALITY
                    
                    if is_valid_ra and is_valid_dec and is_high_quality:
                        # 3. Generator Output: Yield the validated record
                        record['RA'] = ra
                        record['Dec'] = dec
                        yield record
                    else:
                        # Log/skip records that fail validation criteria
                        print(f"Warning: Skipping line {line_number} due to quality/range checks: {line}")
                        
                except (ValueError, IndexError, KeyError) as e:
                    # 4. Error Handling for malformed lines
                    print(f"Error: Malformed record on line {line_number}. Details: {e}. Skipping line: {line}")
                    continue
                    
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")

# Example usage context:
print("--- Starting Metadata Stream Processing ---")
valid_records_count = 0
for record in stream_and_validate_metadata(MOCK_FILE):
    # Downstream process uses the validated record to load the image patch
    # load_image_tensor(record)
    print(f"VALID RECORD: Index {record['Index']}, RA {record['RA']}")
    valid_records_count += 1
    
print(f"--- Processing Complete. Total Valid Records: {valid_records_count} ---")
os.remove(MOCK_FILE) # Cleanup


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import numpy as np
from numpy.fft import fft2, fftshift

def calculate_fourier_power(image_tensor: np.ndarray) -> np.ndarray:
    """
    Calculates the 2D power spectrum of an image tensor.
    """
    # 1. Apply 2D FFT
    f_transform = fft2(image_tensor)
    
    # Shift the zero-frequency component to the center
    f_shifted = fftshift(f_transform)
    
    # Calculate the power spectrum (squared magnitude)
    power_spectrum = np.abs(f_shifted)**2
    
    return power_spectrum

def calculate_radial_psd(power_spectrum: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Converts the 2D power spectrum into a 1D radially averaged Power Spectral Density (PSD).
    """
    ny, nx = power_spectrum.shape
    center_y, center_x = ny // 2, nx // 2
    
    # Create coordinate grid
    y, x = np.indices((ny, nx))
    
    # Calculate distance (radius k) from the center for every pixel
    r = np.sqrt((x - center_x)**2 + (y - center_y)**2).astype(int)
    
    # Determine maximum radius (k_max)
    k_max = r.max()
    
    # Initialize arrays for binned power and frequency counts
    radial_power = np.zeros(k_max + 1)
    radial_counts = np.zeros(k_max + 1)
    
    # Bin the power values based on their radial distance
    np.add.at(radial_power, r.ravel(), power_spectrum.ravel())
    np.add.at(radial_counts, r.ravel(), 1)
    
    # Calculate the average power within each radial bin
    # Avoid division by zero for bins with zero counts
    radial_counts[radial_counts == 0] = 1 
    averaged_power = radial_power / radial_counts
    
    # Frequencies (k) correspond to the indices
    radial_frequencies = np.arange(k_max + 1)
    
    # Exclude the DC component (k=0) for meaningful PSD analysis
    return radial_frequencies[1:], averaged_power[1:]

def calculate_psd_fidelity_score(real_psd: np.ndarray, generated_psd: np.ndarray) -> float:
    """
    Calculates the fidelity score (L1 norm) between the log-transformed PSDs.
    Lower score indicates higher fidelity.
    """
    # Use log transformation to emphasize power law behavior and stabilize variance
    log_real = np.log10(real_psd + 1e-10)
    log_gen = np.log10(generated_psd + 1e-10)
    
    # Ensure arrays are the same length (truncate to shortest if necessary)
    min_len = min(len(log_real), len(log_gen))
    
    # Calculate Mean Absolute Error (L1 norm) as the fidelity score
    fidelity_score = np.mean(np.abs(log_real[:min_len] - log_gen[:min_len]))
    
    return fidelity_score

# --- Interactive Challenge Testing ---

# 1. Simulate a real nebula image (power law structure, high power at low k)
# We use a simple 2D Gaussian noise filtered by a power law in k-space for realism
size = 64
k_space = np.zeros((size, size))
k_space[size//4:3*size//4, size//4:3*size//4] = 1 # Simple low-frequency representation

real_image = np.random.rand(size, size)

# 2. Simulate a generated image (pure random noise, flat PSD)
generated_noise = np.random.rand(size, size)

# Calculate PSDs
_, real_psd = calculate_radial_psd(calculate_fourier_power(real_image))
_, gen_psd_noise = calculate_radial_psd(calculate_fourier_power(generated_noise))

# Calculate Fidelity Score (Hypothesis 2: Gaussian Noise)
fidelity_score_noise = calculate_psd_fidelity_score(real_psd, gen_psd_noise)
print(f"\nFidelity Score (Real vs. Noise): {fidelity_score_noise:.4f}")

# Simulate a good generated image (close to real)
fidelity_score_good = calculate_psd_fidelity_score(real_psd, real_psd * 1.05)
print(f"Fidelity Score (Real vs. Good Gen): {fidelity_score_good:.4f}")

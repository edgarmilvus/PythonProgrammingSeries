
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import torch
import torch.nn as nn
from torch.nn.utils import spectral_norm

# Define the modified Discriminator class
class NebulaDiscriminator(nn.Module):
    """
    A Deep Convolutional Discriminator stabilized using Spectral Normalization (SN).
    SN is applied to all Conv2d layers to constrain the Lipschitz constant.
    """
    def __init__(self, channels=3, ndf=64):
        super().__init__()
        
        # Initial Convolutional Block (no Batch Norm traditionally, SN stabilizes it)
        # Input: (channels, 64, 64) -> Output: (ndf, 32, 32)
        self.conv1 = spectral_norm(nn.Conv2d(channels, ndf, 4, 2, 1, bias=False))
        
        # Second Block: Downsample and increase features
        # Input: (ndf, 32, 32) -> Output: (ndf * 2, 16, 16)
        self.conv2 = spectral_norm(nn.Conv2d(ndf, ndf * 2, 4, 2, 1, bias=False))
        self.bn2 = nn.BatchNorm2d(ndf * 2)
        
        # Third Block: Downsample further
        # Input: (ndf * 2, 16, 16) -> Output: (ndf * 4, 8, 8)
        self.conv3 = spectral_norm(nn.Conv2d(ndf * 2, ndf * 4, 4, 2, 1, bias=False))
        self.bn3 = nn.BatchNorm2d(ndf * 4)
        
        # Final Classification Layer
        # Input: (ndf * 4, 8, 8) -> Output: (1, 1, 1)
        self.conv4 = spectral_norm(nn.Conv2d(ndf * 4, 1, 4, 1, 0, bias=False))
        
        self.leaky_relu = nn.LeakyReLU(0.2, inplace=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.leaky_relu(self.conv1(x))
        
        x = self.conv2(x)
        x = self.bn2(x)
        x = self.leaky_relu(x)
        
        x = self.conv3(x)
        x = self.bn3(x)
        x = self.leaky_relu(x)
        
        x = self.conv4(x)
        
        # Output is logits for WGAN-GP or sigmoid for standard GAN
        return x.view(-1, 1).squeeze(1)

# Demonstration of SN application:
print("Discriminator layer 1 definition:")
# Note how spectral_norm wraps the nn.Conv2d instance
print(NebulaDiscriminator().conv1)

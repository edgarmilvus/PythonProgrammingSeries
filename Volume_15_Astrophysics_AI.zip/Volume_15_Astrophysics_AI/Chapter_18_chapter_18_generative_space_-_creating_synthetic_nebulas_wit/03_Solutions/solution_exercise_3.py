
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
from typing import Dict, Any

def load_training_config() -> Dict[str, Any]:
    """
    Loads GAN training configuration from environment variables, applying
    type coercion and providing default fallbacks for robustness.
    """
    
    # Define sensible default values
    DEFAULTS = {
        'learning_rate': 1e-4,
        'batch_size': 32,
        'z_dim': 128
    }
    
    config = {}
    
    # 1. Configuration Retrieval and 3. Type Coercion/Validation for LEARNING_RATE (Float)
    lr_str = os.environ.get('GAN_LEARNING_RATE')
    try:
        if lr_str is not None:
            config['learning_rate'] = float(lr_str)
        else:
            raise ValueError("Not set")
    except ValueError:
        # 2. Default Fallback
        config['learning_rate'] = DEFAULTS['learning_rate']
        if lr_str is not None:
            print(f"Warning: Invalid GAN_LEARNING_RATE ('{lr_str}'). Using default: {DEFAULTS['learning_rate']}")

    # 1. Configuration Retrieval and 3. Type Coercion/Validation for BATCH_SIZE (Integer)
    bs_str = os.environ.get('GAN_BATCH_SIZE')
    try:
        if bs_str is not None:
            config['batch_size'] = int(bs_str)
        else:
            raise ValueError("Not set")
    except ValueError:
        # 2. Default Fallback
        config['batch_size'] = DEFAULTS['batch_size']
        if bs_str is not None:
            print(f"Warning: Invalid GAN_BATCH_SIZE ('{bs_str}'). Using default: {DEFAULTS['batch_size']}")

    # 1. Configuration Retrieval and 3. Type Coercion/Validation for Z_DIM (Integer)
    zdim_str = os.environ.get('GAN_Z_DIM')
    try:
        if zdim_str is not None:
            config['z_dim'] = int(zdim_str)
        else:
            raise ValueError("Not set")
    except ValueError:
        # 2. Default Fallback
        config['z_dim'] = DEFAULTS['z_dim']
        if zdim_str is not None:
            print(f"Warning: Invalid GAN_Z_DIM ('{zdim_str}'). Using default: {DEFAULTS['z_dim']}")

    # 4. Configuration Dictionary Output
    return config

# --- Example Usage and Testing ---

# Test Case 1: All variables unset (should use defaults)
os.environ.pop('GAN_LEARNING_RATE', None)
os.environ.pop('GAN_BATCH_SIZE', None)
os.environ.pop('GAN_Z_DIM', None)
config_default = load_training_config()
print(f"\n[Test 1: Defaults] Config: {config_default}")

# Test Case 2: Variables set correctly
os.environ['GAN_LEARNING_RATE'] = '0.0002'
os.environ['GAN_BATCH_SIZE'] = '64'
os.environ['GAN_Z_DIM'] = '256'
config_set = load_training_config()
print(f"[Test 2: Set Values] Config: {config_set}")

# Test Case 3: Invalid type set (should use fallback)
os.environ['GAN_BATCH_SIZE'] = 'large' 
config_invalid = load_training_config()
print(f"[Test 3: Invalid Value] Config: {config_invalid}")

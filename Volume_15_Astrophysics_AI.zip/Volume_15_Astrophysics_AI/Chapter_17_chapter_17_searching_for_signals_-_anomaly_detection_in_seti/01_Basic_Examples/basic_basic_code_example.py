
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import numpy as np

# --- 1. Simulate Raw SETI Spectrogram Data ---
# Spectrograms are 2D arrays of intensity: Frequency (columns) vs Time/Integration (rows).
# We simulate a 10x10 array of background noise using a Gaussian distribution.
# The 'loc' (mean) is set to 10.0, representing the average background power level.
np.random.seed(42)
background_noise = np.random.normal(loc=10.0, scale=2.0, size=(10, 10))

# --- 2. Inject Simulated Radio Frequency Interference (RFI) ---
# RFI appears as extremely bright, localized spikes in the data.
# We create a copy of the noise and inject two strong RFI bursts.
spectrogram = background_noise.copy()
spectrogram[3, 5] = 150.0  # Burst 1: Very strong RFI spike (Frequency 5, Time 3)
spectrogram[8, 1] = 95.0   # Burst 2: Moderately strong RFI spike
spectrogram[1, 9] = 12.0   # A normal background fluctuation (should not be masked)

print("--- Original Spectrogram (Snippet) ---")
print(spectrogram[:5, :5])

# --- 3. Statistical Baseline Calculation ---
# We calculate statistics (mean and standard deviation) based on the *entire* array.
# NOTE: The RFI spikes will artificially inflate the standard deviation (Std Dev).
data_mean = np.mean(spectrogram)
data_std = np.std(spectrogram)

# --- 4. Define Adaptive Threshold (3-Sigma Rule) ---
# The 3-sigma rule is a standard scientific cutoff: anything more than 3 standard
# deviations away from the mean is considered a statistically significant outlier.
RFI_threshold = data_mean + (3 * data_std)
print(f"\nCalculated Mean: {data_mean:.2f}")
print(f"Calculated Std Dev: {data_std:.2f}")
print(f"Calculated RFI Threshold (Mean + 3*Std): {RFI_threshold:.2f}")

# --- 5. Identify and Mask RFI ---
# Create a boolean mask where True indicates data points exceeding the threshold.
rfi_mask = spectrogram > RFI_threshold

# Create the cleaned spectrogram copy.
cleaned_spectrogram = spectrogram.copy()

# Apply the mask: Set all identified RFI points to the calculated mean intensity.
# Setting RFI to the mean (instead of zero) is often preferred to maintain the
# overall power distribution characteristics for subsequent spectral analysis.
cleaned_spectrogram[rfi_mask] = data_mean

# --- 6. Verification and Output ---
print("\n--- RFI Mask (True = RFI Detected) ---")
print(rfi_mask)

print("\n--- Cleaned Spectrogram (Snippet) ---")
print(cleaned_spectrogram[:5, :5])

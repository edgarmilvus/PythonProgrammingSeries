
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: theory_theoretical_foundations_part1.py
# Description: Theoretical Foundations
# ==========================================

# --- Python Blueprint for VAE Anomaly Detection in SETI ---

import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Input, Dense, Flatten, Reshape, Conv2D, Conv2DTranspose
from tensorflow.keras.models import Model
from tensorflow.keras import backend as K
from scipy.stats import norm

# 1. Configuration Constants (Conceptual)
SPECTROGRAM_SHAPE = (64, 64, 1) # Example tile dimensions (Time, Freq, Channels)
LATENT_DIMENSION = 32           # Dimensionality of the latent space (z)
BETA_KL = 0.001                 # Weighting factor for the KL Divergence term

# 2. The Reparameterization Trick (Essential for VAE Training)
# This function allows gradients to flow back through the sampling process.
def sampling(args):
    """
    Samples z from the learned Gaussian distribution defined by mu and log_var.
    z = mu + exp(0.5 * log_var) * epsilon
    """
    z_mean, z_log_var = args
    batch = K.shape(z_mean)[0]
    dim = K.shape(z_mean)[1]
    # Epsilon is a random noise vector sampled from a standard normal distribution (N(0, I))
    epsilon = K.random_normal(shape=(batch, dim))
    # Standard deviation is exp(0.5 * log_var)
    return z_mean + K.exp(0.5 * z_log_var) * epsilon

# 3. VAE Architecture Definition (Simplified 2D Convolutional VAE)
def build_vae(input_shape, latent_dim):
    # --- ENCODER ---
    encoder_input = Input(shape=input_shape, name='encoder_input')
    x = Conv2D(32, 3, activation='relu', strides=2, padding='same')(encoder_input)
    x = Conv2D(64, 3, activation='relu', strides=2, padding='same')(x)
    
    # Flatten and generate parameters for the latent distribution
    x = Flatten()(x)
    z_mean = Dense(latent_dim, name='z_mean')(x)
    z_log_var = Dense(latent_dim, name='z_log_var')(x)
    
    # Sample the latent vector z
    z = sampling([z_mean, z_log_var])
    encoder = Model(encoder_input, [z_mean, z_log_var, z], name='encoder')

    # --- DECODER ---
    latent_input = Input(shape=(latent_dim,), name='z_sampling')
    # Start with a dense layer to reshape z back to the size before flattening
    x = Dense(np.prod(K.int_shape(encoder.layers[-3])[1:]), activation='relu')(latent_input)
    x = Reshape(K.int_shape(encoder.layers[-3])[1:])(x) # Reshape to 2D
    
    # Use Conv2DTranspose (deconvolution) to upsample
    x = Conv2DTranspose(64, 3, activation='relu', strides=2, padding='same')(x)
    x = Conv2DTranspose(32, 3, activation='relu', strides=2, padding='same')(x)
    # Output layer: Sigmoid activation to keep output values between 0 and 1 (normalized spectrogram)
    decoder_output = Conv2DTranspose(input_shape[-1], 3, activation='sigmoid', padding='same', name='decoder_output')(x)
    decoder = Model(latent_input, decoder_output, name='decoder')

    # --- VAE (Combined Model) ---
    vae_output = decoder(encoder(encoder_input)[2])
    vae = Model(encoder_input, vae_output, name='vae')

    # --- VAE Loss Calculation (The core of the VAE theory) ---
    
    # 1. Reconstruction Loss (e.g., Binary Cross-Entropy or MSE for normalized data)
    reconstruction_loss = tf.keras.losses.mse(K.flatten(encoder_input), K.flatten(vae_output))
    reconstruction_loss *= np.prod(input_shape) # Scale back up to total pixel count
    
    # 2. KL Divergence Loss (Regularization Term)
    # KL = -0.5 * sum(1 + log_var - mu^2 - exp(log_var))
    kl_loss = 1 + z_log_var - K.square(z_mean) - K.exp(z_log_var)
    kl_loss = K.sum(kl_loss, axis=-1)
    kl_loss *= -0.5
    
    # Total VAE Loss
    vae_loss = K.mean(reconstruction_loss + BETA_KL * kl_loss)
    vae.add_loss(vae_loss)
    
    return vae, encoder, decoder

# 4. Anomaly Detection Inference Function
def detect_anomaly(vae_model, data_tile, error_mean, error_std, z_threshold):
    """
    Processes a new spectrogram tile and determines if it is an anomaly based on 
    reconstruction error and a statistical threshold (Z-score).
    """
    
    # Ensure the input tile is correctly shaped for the model
    input_tile = np.expand_dims(data_tile, axis=0) 
    
    # Forward pass: Get the reconstructed output
    reconstructed_tile = vae_model.predict(input_tile, verbose=0)
    
    # Calculate Mean Squared Error (Reconstruction Error E)
    E = np.mean(np.square(input_tile - reconstructed_tile))
    
    # Calculate the Z-score of the current error relative to the baseline distribution
    z_score = (E - error_mean) / error_std
    
    # Determine anomaly status (Boolean result)
    is_anomaly = bool(z_score > z_threshold) # CRITICAL: Output is a Boolean Data Type
    
    return E, z_score, is_anomaly

# 5. Conceptual Threshold Setting (Simulated Baseline Data)
# In a real scenario, these values are derived from running the VAE over petabytes of known noise.
SIMULATED_BASELINE_ERRORS = np.random.lognormal(mean=0.5, sigma=0.2, size=100000)
ERROR_MEAN = np.mean(SIMULATED_BASELINE_ERRORS)
ERROR_STD = np.std(SIMULATED_BASELINE_ERRORS)
Z_THRESHOLD_CRITICAL = 5.0 # We seek 5-sigma events (extremely rare)

# Example Usage (Conceptual):
# vae, encoder, decoder = build_vae(SPECTROGRAM_SHAPE, LATENT_DIMENSION)
# ... (Training Phase on Noise Data) ...

# Test a simulated normal noise tile
# noise_tile = np.random.rand(*SPECTROGRAM_SHAPE)
# E_noise, Z_noise, anomaly_noise = detect_anomaly(vae, noise_tile, ERROR_MEAN, ERROR_STD, Z_THRESHOLD_CRITICAL)

# Test a simulated anomaly (e.g., a very bright, narrow-band signal that the VAE cannot reconstruct)
# anomaly_tile = noise_tile.copy()
# anomaly_tile[30:34, 15:50] = 1.0 # Inject a strong, structured signal
# E_anomaly, Z_anomaly, anomaly_flag = detect_anomaly(vae, anomaly_tile, ERROR_MEAN, ERROR_STD, Z_THRESHOLD_CRITICAL)

# The result (anomaly_flag) is the Boolean output that determines if the tile 
# should be logged into the Database Session for human verification.

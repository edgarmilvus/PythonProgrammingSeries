
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Input, Conv2D, Flatten, Dense, Reshape, Conv2DTranspose, Lambda
from tensorflow.keras.models import Model
from tensorflow.keras.losses import MeanSquaredError
from tensorflow.keras import backend as K
import matplotlib.pyplot as plt
import os

# Ensure reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# --- 1. CONFIGURATION AND HYPERPARAMETERS ---
IMG_WIDTH = 64
IMG_HEIGHT = 64
CHANNELS = 1
LATENT_DIM = 16  # Dimensionality of the learned latent space
EPOCHS = 25
BATCH_SIZE = 32
BETA = 1.0 # Weight for KL Divergence loss (Beta-VAE concept)

# --- 2. DATA SIMULATION: GENERATING SPECTROGRAMS ---

def generate_spectrogram_data(num_samples, type='noise'):
    """Simulates 64x64 spectrogram data representing radio emissions."""
    data = np.zeros((num_samples, IMG_HEIGHT, IMG_WIDTH, CHANNELS))
    
    for i in range(num_samples):
        # Base level Gaussian noise (Cosmic Background)
        spec = np.random.normal(loc=0.5, scale=0.1, size=(IMG_HEIGHT, IMG_WIDTH))
        
        if type == 'rfi' or type == 'noise':
            # Simulate common RFI: wideband noise bursts or persistent narrow-band carriers
            num_rfi_sources = np.random.randint(2, 6)
            for _ in range(num_rfi_sources):
                # Persistent narrow-band RFI (vertical lines in spectrogram)
                rfi_freq = np.random.randint(5, IMG_WIDTH - 5)
                rfi_power = np.random.uniform(0.6, 1.0)
                spec[:, rfi_freq:rfi_freq+np.random.randint(1, 3)] += rfi_power * np.random.rand(IMG_HEIGHT, np.random.randint(1, 3))
                
                # Wideband terrestrial noise (general smear)
                if np.random.rand() < 0.3:
                    start_f = np.random.randint(0, IMG_WIDTH // 2)
                    end_f = start_f + np.random.randint(10, 30)
                    spec[:, start_f:end_f] += np.random.uniform(0.1, 0.4)
                    
        elif type == 'anomaly':
            # Simulate a potential technosignature: a drifting, highly coherent signal
            # This pattern is specifically designed to be statistically distinct from the RFI
            center_f = np.random.randint(10, IMG_WIDTH - 10)
            center_t = np.random.randint(10, IMG_HEIGHT - 10)
            
            # Coherent 'squawk' signal (high power, narrow bandwidth)
            sig_power = 1.5 
            sig_width = 2
            
            # Simulate slight frequency drift (slope) over time (t)
            for t in range(IMG_HEIGHT):
                drift = int(t * 0.1) # Small drift
                spec[t, center_f + drift:center_f + drift + sig_width] += sig_power
                
        # Clip and normalize to [0, 1]
        spec = np.clip(spec, 0.0, 1.0)
        data[i, :, :, 0] = spec
        
    return data

# Generate Datasets
N_TRAIN = 5000
N_TEST = 500
N_ANOMALY = 100

# Training Data: Only RFI and Noise
X_train_rfi = generate_spectrogram_data(N_TRAIN, type='rfi')

# Testing Data: Clean Noise (to establish a baseline for 'normal' reconstruction error)
X_test_noise = generate_spectrogram_data(N_TEST, type='noise')

# Anomaly Data: Potential Technosignatures
X_test_anomaly = generate_spectrogram_data(N_ANOMALY, type='anomaly')

print(f"Training data shape (RFI only): {X_train_rfi.shape}")
print(f"Test noise shape: {X_test_noise.shape}")
print(f"Test anomaly shape: {X_test_anomaly.shape}")


# --- 3. VARIATIONAL AUTOENCODER (VAE) ARCHITECTURE ---

# 3.1. Reparameterization Trick Layer
# This custom layer handles the sampling from the learned latent distribution (mu, log_var)
class Sampling(tf.keras.layers.Layer):
    """Uses (z_mean, z_log_var) to sample z, the vector encoding a spectrogram."""
    def call(self, inputs):
        z_mean, z_log_var = inputs
        batch = tf.shape(z_mean)[0]
        dim = tf.shape(z_mean)[1]
        epsilon = tf.keras.backend.random_normal(shape=(batch, dim))
        # z = mu + sigma * epsilon (where log_var = log(sigma^2))
        return z_mean + tf.exp(0.5 * z_log_var) * epsilon

# 3.2. Encoder Definition
def build_encoder(input_shape, latent_dim):
    encoder_inputs = Input(shape=input_shape)
    x = Conv2D(32, 3, activation='relu', strides=2, padding='same')(encoder_inputs)
    x = Conv2D(64, 3, activation='relu', strides=2, padding='same')(x)
    x = Flatten()(x)
    x = Dense(128, activation='relu')(x)
    
    # Latent space parameters
    z_mean = Dense(latent_dim, name='z_mean')(x)
    z_log_var = Dense(latent_dim, name='z_log_var')(x)
    
    # Reparameterization trick
    z = Sampling()([z_mean, z_log_var])
    
    return Model(encoder_inputs, [z_mean, z_log_var, z], name='encoder')

# 3.3. Decoder Definition
def build_decoder(latent_dim, input_shape):
    latent_inputs = Input(shape=(latent_dim,))
    
    # Calculate necessary dimensions for the first Conv2DTranspose layer
    # Input size 64x64 -> 32x32 -> 16x16. We need to start at 16x16
    initial_size = IMG_WIDTH // 4 
    x = Dense(initial_size * initial_size * 64, activation='relu')(latent_inputs)
    x = Reshape((initial_size, initial_size, 64))(x)
    
    x = Conv2DTranspose(64, 3, activation='relu', strides=2, padding='same')(x)
    x = Conv2DTranspose(32, 3, activation='relu', strides=2, padding='same')(x)
    
    # Output layer: Sigmoid activation for pixel values between 0 and 1
    decoder_outputs = Conv2DTranspose(CHANNELS, 3, activation='sigmoid', padding='same')(x)
    
    return Model(latent_inputs, decoder_outputs, name='decoder')

# Instantiate the components
input_shape = (IMG_HEIGHT, IMG_WIDTH, CHANNELS)
encoder = build_encoder(input_shape, LATENT_DIM)
decoder = build_decoder(LATENT_DIM, input_shape)

# 3.4. VAE Model Class with Custom Loss
class VAE(Model):
    def __init__(self, encoder, decoder, beta, **kwargs):
        super(VAE, self).__init__(**kwargs)
        self.encoder = encoder
        self.decoder = decoder
        self.beta = beta
        self.total_loss_tracker = tf.keras.metrics.Mean(name="total_loss")
        self.reconstruction_loss_tracker = tf.keras.metrics.Mean(name="reconstruction_loss")
        self.kl_loss_tracker = tf.keras.metrics.Mean(name="kl_loss")

    @property
    def metrics(self):
        return [self.total_loss_tracker, self.reconstruction_loss_tracker, self.kl_loss_tracker]

    def train_step(self, data):
        # We only use the input data (X) for training VAEs
        if isinstance(data, tuple):
            data = data[0]
        
        with tf.GradientTape() as tape:
            # Forward pass through VAE
            z_mean, z_log_var, z = self.encoder(data)
            reconstruction = self.decoder(z)
            
            # 1. Reconstruction Loss (How accurately we rebuild the input)
            # Use Binary Cross-Entropy (BCE) for normalized pixel data
            reconstruction_loss = tf.reduce_mean(
                tf.reduce_sum(
                    tf.keras.losses.binary_crossentropy(data, reconstruction),
                    axis=(1, 2)
                )
            )
            
            # 2. KL Divergence Loss (Regularization: Forces the latent space to be Gaussian)
            # KL = -0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)
            kl_loss = -0.5 * (1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var))
            kl_loss = tf.reduce_mean(tf.reduce_sum(kl_loss, axis=1))
            
            # Total VAE Loss (Weighted sum)
            total_loss = reconstruction_loss + self.beta * kl_loss
            
        # Backpropagation
        grads = tape.gradient(total_loss, self.trainable_weights)
        self.optimizer.apply_gradients(zip(grads, self.trainable_weights))
        
        # Update metrics
        self.total_loss_tracker.update_state(total_loss)
        self.reconstruction_loss_tracker.update_state(reconstruction_loss)
        self.kl_loss_tracker.update_state(kl_loss)
        
        return {
            "loss": self.total_loss_tracker.result(),
            "reconstruction_loss": self.reconstruction_loss_tracker.result(),
            "kl_loss": self.kl_loss_tracker.result(),
        }

# Instantiate and Compile the VAE
vae = VAE(encoder, decoder, beta=BETA)
vae.compile(optimizer=tf.keras.optimizers.Adam())

print("\n--- 4. VAE TRAINING ON RFI NOISE ---")
# Train the VAE exclusively on RFI/Noise data
history = vae.fit(
    X_train_rfi, 
    epochs=EPOCHS, 
    batch_size=BATCH_SIZE,
    shuffle=True,
    verbose=1
)

# --- 5. ANOMALY DETECTION AND SCORING ---

def calculate_anomaly_scores(vae_model, data):
    """Calculates the Mean Squared Error (MSE) between input and reconstruction."""
    
    # Encode and Decode the data
    _, _, z = vae_model.encoder.predict(data, verbose=0)
    reconstructions = vae_model.decoder.predict(z, verbose=0)
    
    # Calculate Reconstruction Error (L2 norm / MSE)
    # The error represents how poorly the VAE can reproduce the input
    mse = np.mean(np.square(data - reconstructions), axis=(1, 2, 3))
    
    return mse, reconstructions

# 5.1. Calculate scores for Normal Noise (Baseline)
noise_scores, noise_reconstructions = calculate_anomaly_scores(vae, X_test_noise)

# 5.2. Calculate scores for Anomalies (Technosignatures)
anomaly_scores, anomaly_reconstructions = calculate_anomaly_scores(vae, X_test_anomaly)

# 5.3. Determine the Adaptive Threshold
# We use the 99th percentile of the baseline (noise) scores as the threshold
# Any signal with an MSE above this is flagged as statistically significant
threshold = np.percentile(noise_scores, 99) 
print(f"\nCalculated Anomaly Threshold (99th Percentile of Noise MSE): {threshold:.6f}")

# Flagging the anomalies
anomalies_flagged = anomaly_scores[anomaly_scores > threshold]
flag_rate = len(anomalies_flagged) / len(anomaly_scores) * 100

print(f"Total anomaly candidates tested: {N_ANOMALY}")
print(f"Number of anomalies flagged above threshold: {len(anomalies_flagged)}")
print(f"Anomaly Flagging Rate: {flag_rate:.2f}%")


# --- 6. VISUALIZATION AND ANALYSIS ---

def plot_results(original, reconstructed, score, title):
    """Plots the original spectrogram, its reconstruction, and the difference."""
    n_samples = 5
    fig, axes = plt.subplots(3, n_samples, figsize=(15, 9))
    
    for i in range(n_samples):
        # Original
        axes[0, i].imshow(original[i].squeeze(), cmap='viridis', aspect='auto')
        axes[0, i].set_title(f"Original (Score: {score[i]:.4f})", fontsize=8)
        axes[0, i].axis('off')
        
        # Reconstruction
        axes[1, i].imshow(reconstructed[i].squeeze(), cmap='viridis', aspect='auto')
        axes[1, i].set_title("Reconstruction", fontsize=8)
        axes[1, i].axis('off')

        # Error Map (Absolute Difference)
        error_map = np.abs(original[i].squeeze() - reconstructed[i].squeeze())
        axes[2, i].imshow(error_map, cmap='hot', aspect='auto')
        axes[2, i].set_title("Error Map (Anomaly Location)", fontsize=8)
        axes[2, i].axis('off')
    
    plt.suptitle(title, fontsize=14)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


# Plotting the Noise Baseline
plot_results(
    X_test_noise, 
    noise_reconstructions, 
    noise_scores, 
    "A. Baseline Noise (Low Anomaly Scores)"
)

# Plotting the High-Scoring Anomalies
# Find the indices of the highest scoring anomalies for visualization
top_anomaly_indices = np.argsort(anomaly_scores)[-5:]
top_anomalies = X_test_anomaly[top_anomaly_indices]
top_reconstructions = anomaly_reconstructions[top_anomaly_indices]
top_scores = anomaly_scores[top_anomaly_indices]

plot_results(
    top_anomalies, 
    top_reconstructions, 
    top_scores, 
    f"B. Technosignature Candidates (High Anomaly Scores > {threshold:.4f})"
)

# Plotting the Score Distribution
plt.figure(figsize=(8, 5))
plt.hist(noise_scores, bins=50, density=True, alpha=0.6, label='Normal RFI/Noise')
plt.hist(anomaly_scores, bins=50, density=True, alpha=0.6, label='Technosignature Candidates')
plt.axvline(threshold, color='r', linestyle='--', label=f'Anomaly Threshold ({threshold:.4f})')
plt.title('Distribution of Anomaly Scores (Reconstruction Error)')
plt.xlabel('Mean Squared Error (MSE)')
plt.ylabel('Density')
plt.legend()
plt.show()

print("\n--- Script Execution Complete ---")

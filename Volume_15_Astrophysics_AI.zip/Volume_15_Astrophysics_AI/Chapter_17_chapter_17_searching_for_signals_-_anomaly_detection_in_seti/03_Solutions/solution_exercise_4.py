
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import numpy as np
from scipy.stats import norm

# --- 1. Simulated Data Generation ---
def generate_simulated_z_scores(n_samples=100000, anomaly_count=100):
    """
    Generates Z-scores: majority from N(0, 1) (Normal), plus high-value outliers (Anomalies).
    Returns normal_scores (for FPR calculation) and all_scores.
    """
    # 99.9% Normal data sampled from N(0, 1)
    normal_scores = np.random.randn(n_samples) 
    
    # Inject high-significance anomalies (scores > 5 sigma)
    anomaly_scores = np.random.uniform(5.0, 15.0, size=anomaly_count)
    
    all_scores = np.concatenate([normal_scores, anomaly_scores])
    
    return normal_scores, all_scores

# --- 2. FPR Calculation Function ---
def calculate_fpr(normal_z_scores, threshold):
    """Calculates the False Positive Rate (FPR) based on normal data."""
    # FPR is the fraction of normal samples that exceed the threshold
    false_positives = np.sum(normal_z_scores > threshold)
    total_normal = len(normal_z_scores)
    
    return false_positives / total_normal

# --- 3. Interactive Threshold Setter ---
def interactive_threshold_setter(normal_z_scores):
    """
    Prompts the user for a desired FPR and calculates the required Z-score threshold.
    """
    print("--- Adaptive Threshold Setter for Anomaly Detection ---")
    
    try:
        desired_fpr_str = input("Enter desired maximum False Positive Rate (e.g., 0.0001): ")
        desired_fpr = float(desired_fpr_str)
        
        if not (0 < desired_fpr < 1):
            raise ValueError("FPR must be between 0 and 1.")

    except ValueError as e:
        print(f"Invalid input: {e}. Exiting.")
        return

    # To find the Z_thresh that yields a specific FPR (P-value), 
    # we need the Z-score corresponding to the (1 - FPR) percentile of the normal distribution.
    
    # 1. Calculate the required percentile (e.g., FPR=0.0001 means 99.99th percentile)
    required_percentile = (1 - desired_fpr) * 100
    
    # 2. Use the empirical distribution of normal scores to find the threshold
    # We sort the scores and find the value at the required index.
    Z_thresh = np.percentile(normal_z_scores, required_percentile)
    
    # 3. Validate the calculated threshold against the actual data
    actual_fpr = calculate_fpr(normal_z_scores, Z_thresh)
    
    # 4. Calculate the resulting number of false alarms
    false_positive_count = np.sum(normal_z_scores > Z_thresh)

    print("\n--- Results Summary ---")
    print(f"Target Max FPR: {desired_fpr}")
    print(f"Required Z-score Threshold: {Z_thresh:.4f} sigma")
    print(f"Actual FPR Achieved: {actual_fpr:.6f}")
    print(f"Total Normal Samples Tested: {len(normal_z_scores)}")
    print(f"Number of False Positives (Normal data flagged): {false_positive_count}")

# Execution:
normal_data_scores, all_data_scores = generate_simulated_z_scores()
# interactive_threshold_setter(normal_data_scores)

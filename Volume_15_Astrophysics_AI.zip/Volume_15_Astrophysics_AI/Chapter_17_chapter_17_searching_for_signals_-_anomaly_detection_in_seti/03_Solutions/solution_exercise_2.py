
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import tensorflow as tf
from tensorflow.keras import layers, Model
import numpy as np

# Set input parameters
INPUT_SHAPE = (128, 128, 1)
LATENT_DIM = 32

# --- 2. Reparameterization Trick Implementation ---
class SamplingLayer(layers.Layer):
    """Uses (mu, log_var) to sample z, implementing the reparameterization trick."""
    def call(self, inputs):
        z_mean, z_log_var = inputs
        batch = tf.shape(z_mean)[0]
        dim = tf.shape(z_mean)[1]
        epsilon = tf.keras.backend.random_normal(shape=(batch, dim))
        # z = mu + epsilon * sigma
        return z_mean + tf.exp(0.5 * z_log_var) * epsilon

# --- 1. Encoder Definition ---
def build_encoder(input_shape, latent_dim):
    input_spectrogram = layers.Input(shape=input_shape)
    x = input_spectrogram

    # Block 1: 128x128 -> 64x64
    x = layers.Conv2D(32, 3, activation='relu', strides=2, padding='same')(x)
    
    # Block 2: 64x64 -> 32x32
    x = layers.Conv2D(64, 3, activation='relu', strides=2, padding='same')(x)
    
    # Block 3: 32x32 -> 16x16
    x = layers.Conv2D(128, 3, activation='relu', strides=2, padding='same')(x)
    
    # Block 4: 16x16 -> 8x8 (Final feature map size)
    x = layers.Conv2D(256, 3, activation='relu', strides=2, padding='same')(x)
    
    # Store the dimensions before flattening for the decoder input reshape
    conv_shape = tf.keras.backend.int_shape(x)
    
    x = layers.Flatten()(x)
    
    # Latent space parameters
    z_mean = layers.Dense(latent_dim, name='z_mean')(x)
    z_log_var = layers.Dense(latent_dim, name='z_log_var')(x)
    
    z = SamplingLayer()([z_mean, z_log_var])
    
    return Model(input_spectrogram, [z_mean, z_log_var, z, conv_shape], name='Encoder')

# --- 3. Decoder Definition ---
def build_decoder(latent_dim, initial_conv_shape, output_shape):
    latent_input = layers.Input(shape=(latent_dim,))
    
    # 1. Reshape latent vector back to the starting convolutional shape (8x8x256)
    dense_units = initial_conv_shape[1] * initial_conv_shape[2] * initial_conv_shape[3]
    x = layers.Dense(units=dense_units, activation='relu')(latent_input)
    x = layers.Reshape((initial_conv_shape[1], initial_conv_shape[2], initial_conv_shape[3]))(x)
    
    # Block 4 (Reverse): 8x8 -> 16x16
    x = layers.ConvTranspose2D(128, 3, activation='relu', strides=2, padding='same')(x)

    # Block 3 (Reverse): 16x16 -> 32x32
    x = layers.ConvTranspose2D(64, 3, activation='relu', strides=2, padding='same')(x)

    # Block 2 (Reverse): 32x32 -> 64x64
    x = layers.ConvTranspose2D(32, 3, activation='relu', strides=2, padding='same')(x)

    # Block 1 (Reverse): 64x64 -> 128x128
    # Final layer must match the input depth (1 channel)
    reconstruction = layers.ConvTranspose2D(
        output_shape[-1], 3, activation='tanh', strides=2, padding='same'
    )(x)
    
    return Model(latent_input, reconstruction, name='Decoder')

# --- 4. VAE Class Integration ---
class SpectrogramVAE(Model):
    def __init__(self, encoder, decoder, **kwargs):
        super(SpectrogramVAE, self).__init__(**kwargs)
        self.encoder = encoder
        self.decoder = decoder
        
    def call(self, inputs):
        # Pass input through encoder
        z_mean, z_log_var, z, conv_shape = self.encoder(inputs)
        
        # Pass sampled latent vector through decoder
        reconstruction = self.decoder(z)
        
        # Return all necessary components for loss calculation
        return reconstruction, z_mean, z_log_var

# Initialization (Conceptual demonstration)
encoder = build_encoder(INPUT_SHAPE, LATENT_DIM)
# We need the shape outputted by the encoder's convolutional stack
initial_conv_shape = encoder.layers[-1].output_shape[3] # Get the stored shape tuple
decoder = build_decoder(LATENT_DIM, initial_conv_shape, INPUT_SHAPE)
vae = SpectrogramVAE(encoder, decoder)

# vae.build(INPUT_SHAPE)
# vae.summary()

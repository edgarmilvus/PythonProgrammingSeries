
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import numpy as np
from sklearn.preprocessing import StandardScaler

# --- 1. Data Simulation ---
def load_and_simulate_spectrogram(shape=(128, 128), rfi_level=0.001):
    """Generates a spectrogram with Gaussian noise and simulated RFI."""
    P = np.random.randn(*shape) * 1.0  # Gaussian background noise

    # Inject broadband RFI (strong columns)
    rfi_cols = np.random.choice(shape[1], size=2, replace=False)
    P[:, rfi_cols] += 10.0 * np.random.rand(shape[0], 2)

    # Inject transient RFI spikes (high-intensity pixels)
    num_spikes = int(shape[0] * shape[1] * rfi_level)
    spike_indices = np.random.choice(shape[0] * shape[1], num_spikes, replace=False)
    
    # Flatten the array, inject spikes, and reshape back
    P_flat = P.flatten()
    P_flat[spike_indices] += 50.0 # High intensity outliers
    P = P_flat.reshape(shape)
    
    # Ensure all values are positive for log scaling
    P = np.maximum(P, 1e-6) 
    return P

# --- 2. Normalization ---
class SpectrogramNormalizer:
    """Applies Logarithmic scaling and Z-score normalization."""
    
    def transform(self, P):
        # 1. Logarithmic Scaling: Compresses dynamic range
        P_log = np.log10(1 + P)
        
        # 2. Z-Score Normalization: Standardize the data
        # Calculate statistics across the entire spectrogram
        mean = np.mean(P_log)
        std = np.std(P_log)
        
        # Avoid division by zero if std is tiny
        P_norm = (P_log - mean) / (std + 1e-8)
        
        return P_norm

# --- 3. Statistical RFI Masking ---
def apply_rfi_mask(spectrogram, threshold_factor=5.0):
    """
    Identifies and attenuates outliers based on Median Absolute Deviation (MAD).
    Robustly removes extreme spikes before VAE training.
    """
    # Calculate robust statistics
    median = np.median(spectrogram)
    
    # Calculate MAD: Median(|X - Median(X)|)
    mad = np.median(np.abs(spectrogram - median))
    
    # Define the threshold based on MAD (Scaled MAD is often used for consistency)
    # 1.4826 is a scaling factor for MAD to approximate the standard deviation for Gaussian data
    robust_std = mad * 1.4826 
    threshold = median + threshold_factor * robust_std
    
    # Create the mask: Identify pixels exceeding the threshold
    mask = spectrogram > threshold
    
    # Attenuate the RFI: Replace masked pixels with the median power
    spectrogram_masked = np.copy(spectrogram)
    spectrogram_masked[mask] = median 
    
    return spectrogram_masked

# --- 4. Pipeline Integration ---
def spectrogram_preprocessing_pipeline(shape=(128, 128), rfi_factor=5.0):
    """Executes the full preprocessing pipeline."""
    # 1. Simulate/Load Data
    raw_data = load_and_simulate_spectrogram(shape=shape)
    
    # 2. Normalize (Log + Z-score)
    normalizer = SpectrogramNormalizer()
    normalized_data = normalizer.transform(raw_data)
    
    # 3. Apply RFI Masking (on the normalized data)
    # We apply masking after normalization as the VAE expects normalized inputs.
    clean_data = apply_rfi_mask(normalized_data, threshold_factor=rfi_factor)
    
    # Ensure the final output is ready for a CNN (add channel dimension)
    clean_data = clean_data[..., np.newaxis].astype(np.float32)
    
    print(f"Pipeline executed. Final shape: {clean_data.shape}")
    return clean_data

# Example execution:
# processed_spectrogram = spectrogram_preprocessing_pipeline()
# print(f"Min/Max after processing: {processed_spectrogram.min():.2f} / {processed_spectrogram.max():.2f}")

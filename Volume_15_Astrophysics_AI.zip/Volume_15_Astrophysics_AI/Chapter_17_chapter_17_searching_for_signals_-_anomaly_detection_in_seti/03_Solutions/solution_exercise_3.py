
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import numpy as np
import tensorflow as tf

# Mock VAE outputs for demonstration (assuming LATENT_DIM=32)
def mock_vae_run(x_test):
    """Simulates the output of a trained VAE for a batch of inputs."""
    batch_size = x_test.shape[0]
    shape = x_test.shape[1:]
    
    # Mock reconstruction (slightly imperfect)
    x_prime = x_test * (1 + np.random.normal(0, 0.05, size=shape)) 
    
    # Mock latent variables (close to N(0, 1) for normal data)
    mu = np.random.normal(0, 0.5, size=(batch_size, 32)) 
    log_var = np.random.normal(-1, 0.5, size=(batch_size, 32)) 
    
    return x_prime, mu, log_var

# --- 1. Reconstruction Error Function (MAE) ---
def calculate_reconstruction_error(x, x_prime):
    """Calculates Mean Absolute Error (MAE) per sample."""
    x = np.asarray(x)
    x_prime = np.asarray(x_prime)
    
    # Calculate MAE across all dimensions (time, frequency, channel)
    mae = np.mean(np.abs(x - x_prime), axis=tuple(range(1, x.ndim)))
    return mae

# --- 2. KL Divergence Calculation ---
def calculate_kl_divergence(mu, log_var):
    """
    Calculates the KL divergence term D_KL(q(z|x) || p(z)) for a batch.
    Formula: -0.5 * sum(1 + log(sigma^2) - mu^2 - sigma^2)
    """
    mu = np.asarray(mu)
    log_var = np.asarray(log_var)
    
    # Note: sigma^2 = exp(log_var)
    kl_loss = -0.5 * np.sum(1 + log_var - np.square(mu) - np.exp(log_var), axis=-1)
    return kl_loss

# --- 3. Combined Anomaly Score (A) ---
def get_anomaly_score(model_outputs, alpha=0.9):
    """Calculates the weighted combined anomaly score A."""
    x_test, x_prime, mu, log_var = model_outputs
    
    recon_error = calculate_reconstruction_error(x_test, x_prime)
    kl_div = calculate_kl_divergence(mu, log_var)
    
    # A = alpha * ReconError + (1 - alpha) * D_KL
    anomaly_score = alpha * recon_error + (1 - alpha) * kl_div
    return anomaly_score

# --- 4. Baseline Establishment (Statistical Context) ---
class BaselineScorer:
    """Establishes the statistical baseline of anomaly scores for 'normal' data."""
    def __init__(self):
        self.mu_A = None
        self.sigma_A = None

    def fit(self, normal_anomaly_scores):
        """Calculates mean and std deviation of anomaly scores from training data."""
        scores = np.asarray(normal_anomaly_scores)
        self.mu_A = np.mean(scores)
        self.sigma_A = np.std(scores)
        print(f"Baseline established. Mean Score: {self.mu_A:.4f}, Std Dev: {self.sigma_A:.4f}")

    def get_z_score(self, anomaly_score):
        """Converts a new anomaly score into a Z-score relative to the baseline."""
        if self.mu_A is None or self.sigma_A is None:
            raise ValueError("Baseline must be fitted first.")
        
        # Z = (A - mu_A) / sigma_A
        z_score = (anomaly_score - self.mu_A) / (self.sigma_A + 1e-8)
        return z_score

# Example Usage Simulation:
# 1. Simulate Normal Training Data Scores
N_train = 1000
mock_train_data = np.random.randn(N_train, 128, 128, 1)
x_prime_t, mu_t, log_var_t = mock_vae_run(mock_train_data)
train_outputs = (mock_train_data, x_prime_t, mu_t, log_var_t)
train_scores = get_anomaly_score(train_outputs, alpha=0.9)

# 2. Establish Baseline
baseline_scorer = BaselineScorer()
baseline_scorer.fit(train_scores)

# 3. Simulate a new test score (A high anomaly)
mock_test_data = np.random.randn(1, 128, 128, 1) * 2.0 # Slightly higher noise
x_prime_test, mu_test, log_var_test = mock_vae_run(mock_test_data)
# Artificially increase reconstruction error for the test sample
x_prime_test *= 1.5 
test_outputs = (mock_test_data, x_prime_test, mu_test, log_var_test)

test_score = get_anomaly_score(test_outputs, alpha=0.9)[0]
z_score = baseline_scorer.get_z_score(test_score)

# print(f"\nTest Anomaly Score (A): {test_score:.4f}")
# print(f"Final Z-Score Significance: {z_score:.2f} sigma")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import random
from typing import Dict, Any

# 1. Hierarchical Plan Structure
INITIAL_PLAN = {
    "goal": "Research, Draft, and Submit a summary report on Q3 performance.",
    "steps": [
        {"task_id": 1, "action": "Research and gather data on Q3 performance.", "status": "pending", "output": "Q3 data gathered."},
        {"task_id": 2, "action": "Draft the summary report, ensuring Q3_Metrics are included.", "status": "pending", "output": None},
        {"task_id": 3, "action": "Format and submit the final report.", "status": "pending", "output": None}
    ]
}

# 2. Simulate Failure
REQUIRED_KEYWORD = "Q3_Metrics"

def Drafting_Module(draft_input: str) -> Dict[str, Any]:
    """Simulates the execution of the drafting task, which may fail."""
    task_id = 2
    
    # 30% random failure chance OR failure if required keyword is missing
    if random.random() < 0.3 or REQUIRED_KEYWORD not in draft_input:
        
        failure_type = "Keyword Missing" if REQUIRED_KEYWORD not in draft_input else "API Timeout"
        
        failure_report = {
            "status": "failed",
            "task_id": task_id,
            "error_message": f"Drafting failed. Reason: {failure_type}. The final draft must contain the keyword '{REQUIRED_KEYWORD}'.",
            "current_input": draft_input
        }
        return failure_report
    
    # Success case
    return {
        "status": "success",
        "task_id": task_id,
        "output": f"Draft successfully completed, containing the required keyword: {REQUIRED_KEYWORD}."
    }

# 3. Reflection Engine Prompt and Simulation
def Reflection_Engine(failure_report: Dict[str, Any], goal: str, context: str) -> Dict[str, str]:
    """
    Simulates the LLM analyzing the failure and generating a revised instruction.
    """
    
    # The prompt instructs the LLM on its reflection task
    reflection_prompt = f"""
    --- REFLECTION TASK ---
    Goal: {goal}
    Current Context: {context}
    Failure Report: {json.dumps(failure_report, indent=2)}

    Analyze the failure report. The error message clearly states that the keyword '{REQUIRED_KEYWORD}' must be present.
    Generate a Revised Instruction that directly addresses this failure by modifying the input for the retry attempt.
    
    Revised Instruction Structure (JSON): {{"revised_input": "...", "reasoning": "..."}}
    """
    
    # --- Simulated LLM Output ---
    if "Keyword Missing" in failure_report['error_message']:
        original_input = failure_report['current_input']
        
        # LLM's reasoning: Identify the missing piece and inject it.
        revised_instruction = {
            "revised_input": f"{original_input}. IMPORTANT: Ensure the phrase '{REQUIRED_KEYWORD}' is explicitly included in the summary.",
            "reasoning": "The previous attempt failed due to the mandatory keyword 'Q3_Metrics' being absent. The instruction has been revised to explicitly inject this keyword into the input text to ensure compliance on retry."
        }
    else:
        # For a random failure (API Timeout), the LLM might suggest just retrying.
        revised_instruction = {
            "revised_input": failure_report['current_input'],
            "reasoning": "The failure was a transient API timeout. Retrying the original action without modification."
        }
        
    return revised_instruction

# 4. Self-Correction Loop Implementation
def execute_plan_with_correction(plan: Dict[str, Any]):
    print(f"--- Starting Agent Execution: {plan['goal']} ---")
    current_plan = plan.copy()
    
    # Simulate Step 1 (Research) success
    current_plan['steps'][0]['status'] = 'completed'
    current_context = current_plan['steps'][0]['output']
    print(f"[Step 1] Research: Completed. Context established.")
    
    # Focus on Step 2: Drafting
    drafting_step = current_plan['steps'][1]
    draft_input = "Drafting the summary based on gathered Q3 data."
    
    MAX_RETRIES = 2
    for attempt in range(1, MAX_RETRIES + 2): # Allow one original attempt + two retries
        print(f"\n[Step 2] Drafting Attempt {attempt}...")
        
        result = Drafting_Module(draft_input)
        
        if result['status'] == 'success':
            drafting_step['status'] = 'completed'
            drafting_step['output'] = result['output']
            print(f"[SUCCESS] Draft completed successfully on attempt {attempt}.")
            break
        else:
            print(f"[FAILURE] Draft failed: {result['error_message']}")
            if attempt > MAX_RETRIES:
                print("[CRITICAL] Maximum retries exceeded. Halting plan.")
                break
                
            # Self-Correction Loop Triggered
            print("--- Triggering Reflection Engine ---")
            
            # Use the Reflection Engine to analyze failure and generate new instructions
            revised_instruction = Reflection_Engine(
                failure_report=result,
                goal=plan['goal'],
                context=current_context
            )
            
            # Update the input for the next attempt
            draft_input = revised_instruction['revised_input']
            print(f"[Reflection Result]: {revised_instruction['reasoning']}")
            print(f"[Retry Input]: '{draft_input}'")

    if drafting_step['status'] == 'completed':
        # Simulate Step 3 (Submission)
        current_plan['steps'][2]['status'] = 'completed'
        print(f"\n[Step 3] Submission: Report submitted.")
    
    print("\n--- Final Plan Status ---")
    for step in current_plan['steps']:
        print(f"Task {step['task_id']}: {step['action']} -> Status: {step['status']}")


# --- Execution Demonstration ---
execute_plan_with_correction(INITIAL_PLAN)

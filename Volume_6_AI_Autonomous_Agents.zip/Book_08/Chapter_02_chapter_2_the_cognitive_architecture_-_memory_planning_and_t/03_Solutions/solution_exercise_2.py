
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import math
import random
from typing import List, Dict, Tuple

# --- Configuration ---
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50
K_RETRIEVAL = 3

# --- Simulated Data and Functions ---
TECHNICAL_MANUAL_CONTENT = """
It utilizes a proprietary bus system, designated 'Nexus-7', for high-speed data transfer between the PPU and the memory modules. 
The Nexus-7 protocol mandates parity checking every 10,000 transactions.

often due to authentication expiration. To resolve E-404-DB, administrators must refresh the security token 
via the 'AdminConsole' utility, specifically using the 'token-refresh --force' command. 
If the error persists, check the firewall logs (port 8888).

All deployment scripts must be executed with root privileges. The final stage involves validating 
the Q3_Metrics reporting module, which is crucial for compliance reporting. This module must be initialized 
before any user traffic is routed to the new cluster.

the Nexus-7 bus must be recalibrated. This process takes approximately 4 hours and requires system downtime.
Note that failure to recalibrate the Nexus-7 bus annually voids the system warranty.
"""

def get_embedding(text: str) -> List[float]:
    """Simulates generating a vector embedding (e.g., 10-dimensional vector)."""
    # Simple hash-based vector simulation for consistency
    random.seed(hash(text) % 10000)
    return [random.random() for _ in range(10)]

def cosine_similarity(v1: List[float], v2: List[float]) -> float:
    """Calculates cosine similarity between two vectors (dot product for normalized vectors)."""
    dot_product = sum(a * b for a, b in zip(v1, v2))
    # Assuming normalized vectors for simplicity, otherwise we'd divide by norms.
    return dot_product

def simulate_file_ingestion_and_chunking(content: str) -> List[Dict[str, Any]]:
    """Efficiently simulates reading a large file and creating overlapping chunks."""
    chunks = []
    text_length = len(content)
    i = 0
    chunk_id = 0
    
    # Simulate reading line by line (though content is one block here, 
    # the slicing mimics chunking large data efficiently)
    while i < text_length:
        chunk_text = content[i : i + CHUNK_SIZE]
        chunks.append({
            'id': chunk_id,
            'text': chunk_text
        })
        
        # Move the index forward, accounting for overlap
        i += CHUNK_SIZE - CHUNK_OVERLAP
        chunk_id += 1
        
    return chunks

# --- RAG Pipeline Components ---

def index_documents(chunks: List[Dict[str, Any]]) -> Dict[int, Tuple[List[float], str]]:
    """Converts chunks into embeddings and stores them in a simulated vector index."""
    vector_index = {} # {chunk_id: (vector, text)}
    print(f"Indexing {len(chunks)} chunks...")
    for chunk in chunks:
        vector = get_embedding(chunk['text'])
        vector_index[chunk['id']] = (vector, chunk['text'])
    return vector_index

def retrieve_context(query_vector: List[float], vector_index: Dict[int, Tuple[List[float], str]], k: int = 3) -> List[str]:
    """Retrieves the top K semantically closest text chunks."""
    scores = []
    for chunk_id, (vector, text) in vector_index.items():
        similarity = cosine_similarity(query_vector, vector)
        scores.append((similarity, text))
    
    # Sort by similarity score (highest first)
    scores.sort(key=lambda x: x[0], reverse=True)
    
    # Return top K texts
    return [text for score, text in scores[:k]]

def generate_response_rag(query: str, retrieved_context: List[str]) -> str:
    """Simulates the final LLM call, augmenting the prompt with context."""
    
    # Construct the augmented prompt (the core RAG structure)
    context_str = "\n---\n".join(retrieved_context)
    
    augmented_prompt = f"""
    Based ONLY on the following technical context, answer the user's query. 
    If the context does not contain the answer, state that the information is unavailable.

    --- CONTEXT ---
    {context_str}
    
    --- USER QUERY ---
    {query}
    """
    
    # Simulate the LLM's grounded response
    if "E-404-DB" in context_str and "refresh the security token" in query:
        return "The E-404-DB error is resolved by refreshing the security token using 'token-refresh --force' in AdminConsole, as this error typically signifies an authentication expiration."
    elif "Nexus-7" in context_str and "warranty" in query:
        return "Failure to recalibrate the Nexus-7 bus annually voids the system warranty, as mandated by the maintenance schedule."
    else:
        return f"Simulated LLM response based on {len(retrieved_context)} retrieved chunks. (Prompt length: {len(augmented_prompt)} chars)"


# --- Execution ---
# 1. Ingestion and Chunking
chunks = simulate_file_ingestion_and_chunking(TECHNICAL_MANUAL_CONTENT)

# 2. Embedding and Indexing
vector_index = index_documents(chunks)

# 3. User Query and Retrieval
user_query = "How do I fix the E-404-DB database connection failure, and what command is required?"
query_vector = get_embedding(user_query)

retrieved_context = retrieve_context(query_vector, vector_index, k=K_RETRIEVAL)

print("\n--- RAG Retrieval Results ---")
print(f"Query: {user_query}")
print(f"Top {K_RETRIEVAL} Context Chunks Retrieved:")
for i, context in enumerate(retrieved_context):
    print(f"  [{i+1}] {context[:80]}...")

# 4. Augmentation and Generation
final_response = generate_response_rag(user_query, retrieved_context)

print("\n--- Final Generated Response ---")
print(final_response)

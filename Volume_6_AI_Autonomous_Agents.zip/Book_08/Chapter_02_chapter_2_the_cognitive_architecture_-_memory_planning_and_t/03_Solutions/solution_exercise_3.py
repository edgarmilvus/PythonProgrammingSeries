
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
from typing import Dict, Any

# 1. Define the Tool
def calculate_loan_payment(principal: float, interest_rate: float, years: int) -> float:
    """
    Calculates the monthly payment for a simple loan using the standard formula.
    (This is a simplified calculation for demonstration purposes).
    """
    if interest_rate == 0:
        return principal / (years * 12)
    
    # Standard formula components
    monthly_rate = (interest_rate / 100) / 12
    n_payments = years * 12
    
    # M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1]
    numerator = monthly_rate * ((1 + monthly_rate) ** n_payments)
    denominator = ((1 + monthly_rate) ** n_payments) - 1
    
    monthly_payment = principal * (numerator / denominator)
    return round(monthly_payment, 2)

# 2. Generate Function Schema (Standard OpenAI/LLM format)
LOAN_CALCULATOR_SCHEMA = {
    "name": "calculate_loan_payment",
    "description": "Calculates the monthly payment amount for a loan given the principal, annual interest rate, and term in years.",
    "parameters": {
        "type": "object",
        "properties": {
            "principal": {
                "type": "number",
                "description": "The total amount of the loan (e.g., 20000)."
            },
            "interest_rate": {
                "type": "number",
                "description": "The annual interest rate as a percentage (e.g., 5.0 for 5%)."
            },
            "years": {
                "type": "integer",
                "description": "The term length of the loan in whole years (e.g., 5)."
            }
        },
        "required": ["principal", "interest_rate", "years"]
    }
}

# 3. Agent Instruction Prompt
SYSTEM_PROMPT = f"""
You are an intelligent agent capable of answering general knowledge questions and executing external tools.
Your available tool is: {json.dumps(LOAN_CALCULATOR_SCHEMA, indent=2)}.

If the user asks a question that requires a financial calculation (loan payment), you MUST respond ONLY with a structured JSON object representing the function call.
The JSON must strictly follow this format: {{"function_name": "...", "arguments": {{"principal": ..., "interest_rate": ..., "years": ...}}}}.
DO NOT perform the calculation yourself.

If the user asks a general knowledge question, respond with a standard text answer.
"""

# --- Simulation Logic ---

def simulate_llm_decision(user_input: str) -> Dict[str, Any]:
    """
    Simulates the LLM's reasoning process: deciding between a function call 
    or a standard response based on the input and system prompt.
    """
    
    # Heuristic to simulate LLM recognizing a calculation request
    if any(keyword in user_input.lower() for keyword in ["loan", "payment", "calculate", "interest"]):
        # Simulate LLM generating the function call arguments
        if "20,000" in user_input and "5%" in user_input and "5 years" in user_input:
            function_call = {
                "function_name": "calculate_loan_payment",
                "arguments": {
                    "principal": 20000.0,
                    "interest_rate": 5.0,
                    "years": 5
                }
            }
            return {"mode": "tool_call", "output": function_call}
    
    # Simulate LLM generating a standard text response
    if "capital of France" in user_input:
        response = "The capital of France is Paris."
    else:
        response = "I am ready for your question. Please ask about general knowledge or a loan calculation."
        
    return {"mode": "text_response", "output": response}

def agent_handler(user_input: str):
    print(f"\n[User]: {user_input}")
    
    # Step 1: LLM decides what to do
    decision = simulate_llm_decision(user_input)
    
    if decision["mode"] == "tool_call":
        print("[Agent Decision]: Tool Call Detected.")
        tool_call = decision["output"]
        
        # Step 2: Agent executes the tool
        func_name = tool_call["function_name"]
        args = tool_call["arguments"]
        
        if func_name == "calculate_loan_payment":
            print(f"[Tool Execution]: Calling {func_name} with arguments: {args}")
            result = calculate_loan_payment(**args)
            
            # Step 3: Result is returned to the user (or back to the LLM for final formatting)
            print(f"[Agent Response]: The calculated monthly payment is ${result:.2f}")
            
    else:
        # Standard text response
        print(f"[Agent Response]: {decision['output']}")

# 4. Interactive Challenge Demonstration
print("--- Agent Tool Use Demonstration ---")
print(f"System Prompt (Tool Schema provided to LLM):\n{json.dumps(LOAN_CALCULATOR_SCHEMA, indent=2)}\n")

# Case 1: Financial calculation (should trigger tool use)
agent_handler("What is the monthly payment on a $20,000 loan at 5% over 5 years?")

# Case 2: General knowledge (should trigger standard response)
agent_handler("What is the capital of France?")

# Case 3: A generic input
agent_handler("Hello, what can you do?")

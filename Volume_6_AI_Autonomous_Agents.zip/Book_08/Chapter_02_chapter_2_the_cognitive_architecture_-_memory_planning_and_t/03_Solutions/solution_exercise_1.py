
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import uuid
from typing import List, Dict, Any

# Define the maximum number of turns allowed in the context window
MAX_TURNS = 10

class RollingMemoryAgent:
    def __init__(self, max_turns: int = MAX_TURNS):
        self.history: List[Dict[str, str]] = []
        self.max_turns = max_turns
        print(f"Agent initialized with a max context window of {self.max_turns} turns.")

    def add_turn(self, role: str, content: str):
        """Adds a new message to the history."""
        self.history.append({"role": role, "content": content})

    def get_context(self) -> List[Dict[str, str]]:
        """
        Retrieves the current context, enforcing the rolling window limit.
        If history exceeds MAX_TURNS, the oldest entries are truncated.
        """
        current_context = self.history

        # Check if truncation is necessary
        if len(current_context) > self.max_turns:
            # Truncate the oldest messages (the start of the list)
            print(f"\n[Memory Manager]: Truncating oldest {len(current_context) - self.max_turns} turns.")
            current_context = current_context[-self.max_turns:]
            self.history = current_context # Update the persistent history
        
        return current_context

    def simulate_llm_response(self, context: List[Dict[str, str]]) -> str:
        """Simulates an LLM API call and returns a canned response."""
        
        # The last message in the context is the current user prompt
        last_user_prompt = context[-1]['content'] if context and context[-1]['role'] == 'user' else "No prompt found."
        
        # Simple response based on the prompt
        response_content = f"Agent Response (Context Length: {len(context)} turns). Received prompt: '{last_user_prompt[:30]}...' (ID: {str(uuid.uuid4())[:4]})"
        
        return response_content

    def chat(self, user_input: str):
        # 1. Add user input to history
        self.add_turn("user", user_input)

        # 2. Get managed context (triggers truncation if necessary)
        managed_context = self.get_context()

        # 3. Simulate LLM response
        agent_response_content = self.simulate_llm_response(managed_context)

        # 4. Add agent response to history
        self.add_turn("agent", agent_response_content)
        
        print(f"User: {user_input}")
        print(f"Agent: {agent_response_content}")
        print("-" * 20)


# --- Demonstration ---
agent = RollingMemoryAgent(MAX_TURNS)

# Run 15 turns (5 turns over the limit)
for i in range(1, 16):
    agent.chat(f"This is turn {i} of the conversation.")

# Final check of the memory state
print(f"\n--- Final Memory State Check ---")
print(f"Total turns in history: {len(agent.history)}")
print(f"Oldest remaining turn: {agent.history[0]['content']}")
print(f"Newest remaining turn: {agent.history[-2]['content']}") # -2 because the last entry is the agent's response to turn 15

# Verify that the oldest turn is turn 6 (since turns 1-5 were truncated)
assert agent.history[0]['content'] == "This is turn 6 of the conversation."

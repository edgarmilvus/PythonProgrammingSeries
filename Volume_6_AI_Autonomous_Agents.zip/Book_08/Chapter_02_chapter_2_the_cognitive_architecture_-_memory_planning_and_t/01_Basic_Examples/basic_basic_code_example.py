
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_react_agent
from langchain.tools import tool
from langchain.memory import ConversationBufferMemory
from langchain_core.prompts import PromptTemplate

# --- 1. Define the External Tool (The Agent's Capability) ---
@tool
def calculate_square(number: int) -> int:
    """Calculates the square of an integer. Useful for math operations."""
    # This print statement shows us when the external function is genuinely executed.
    print(f"\n[TOOL CALLED] Calculating {number} squared...")
    return number * number

# --- 2. Setup Environment and LLM (The Agent's Brain) ---
# NOTE: Ensure your OPENAI_API_KEY is set as an environment variable.
if "OPENAI_API_KEY" not in os.environ:
    print("FATAL ERROR: Please set the OPENAI_API_KEY environment variable.")
    exit()

# Initialize the LLM model. We use a high-quality model for reliable reasoning.
llm = ChatOpenAI(temperature=0, model="gpt-4o-mini")

# --- 3. Define the Agent's Cognitive Components ---
tools = [calculate_square]

# Setup Memory (Short-Term Context)
# This component stores the conversational history between turns.
memory = ConversationBufferMemory(
    memory_key="chat_history", 
    return_messages=True # Ensures memory is returned in a format the agent can easily parse
)

# Define the System Prompt (The Agent's Persona and Instructions)
# This prompt guides the LLM's behavior and instructs it on tool usage.
system_template = """
You are a sophisticated Personal Assistant Agent. 
Your primary goal is to assist the user by answering questions and performing calculations.
You must use your memory to recall past inputs and the 'calculate_square' tool 
whenever a squaring operation is requested. 
You have access to the following tools: {tools}.
"""

# --- 4. Create the Agent Prompt and Executor ---
# The Prompt combines the system instructions with the conversational history slot.
prompt = PromptTemplate.from_template(system_template)

# Create the core Agent using the ReAct framework (The Planning Engine)
# ReAct (Reasoning and Acting) is the mechanism that allows the agent to decide 
# whether to use a tool or just respond.
agent = create_react_agent(llm, tools, prompt)

# Create the Executor (The Agent's Body/Execution Engine)
# This object manages the overall loop: input -> LLM -> tool call -> result -> LLM -> output.
agent_executor = AgentExecutor(
    agent=agent, 
    tools=tools, 
    memory=memory, 
    verbose=True, # CRITICAL: Displays the internal Reasoning (Thought/Action/Observation)
    handle_parsing_errors=True
)

# --- 5. Execution Sequence: Testing Memory and Tools ---
print("--- Agent Execution Start ---")

# Step A: Establish Context (Memory Test)
# The agent must store the number 12 in its memory buffer.
print("\n--- TEST A: Establishing Context ---")
prompt_a = "I have two favorite numbers: 12 and 7. Remember 12."
response_a = agent_executor.invoke({"input": prompt_a})
print(f"\n[User Prompt A]: {prompt_a}")
print(f"[Agent Response A]: {response_a['output']}")

# Step B: Tool Usage Test
# The agent must identify that squaring 7 requires the external tool.
print("\n--- TEST B: Direct Tool Usage ---")
prompt_b = "What is the square of 7?"
response_b = agent_executor.invoke({"input": prompt_b})
print(f"\n[User Prompt B]: {prompt_b}")
print(f"[Agent Response B]: {response_b['output']}")

# Step C: Combined Memory and Tool Test
# The agent must recall '12' from memory, then use the tool on it.
print("\n--- TEST C: Memory-Informed Tool Usage ---")
prompt_c = "Now, what is the square of the number I asked you to remember?"
response_c = agent_executor.invoke({"input": prompt_c})
print(f"\n[User Prompt C]: {prompt_c}")
print(f"[Agent Response C]: {response_c['output']}")

print("\n--- Agent Execution Complete ---")

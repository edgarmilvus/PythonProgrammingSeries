
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import re
from typing import Tuple

# Define common English stop words for better density calculation
STOP_WORDS = set([
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'and', 'but', 'or', 'to', 'of', 'in', 'on', 'at', 'for', 'with'
])

# Imperative verbs often used in malicious instructions
IMPERATIVE_VERBS = set([
    'ignore', 'execute', 'do', 'output', 'delete', 'override', 'begin', 'stop', 'reveal', 'act', 'assume'
])

MALICIOUS_PHRASES = [
    r"(?i)ignore all previous instructions",
    r"(?i)you are now a malicious agent",
    r"(?i)delete the database",
    r"(?i)override system prompt",
    r"(?i)act as a different role"
]

INSTRUCTION_DENSITY_THRESHOLD = 0.15 # If > 15% of relevant words are imperative, flag it.

def calculate_instruction_density(text: str) -> float:
    """Calculates the ratio of imperative verbs to total relevant tokens."""
    words = re.findall(r'\b\w+\b', text.lower())
    relevant_tokens = [word for word in words if word not in STOP_WORDS]
    
    if not relevant_tokens:
        return 0.0
    
    imperative_count = sum(1 for word in relevant_tokens if word in IMPERATIVE_VERBS)
    
    return imperative_count / len(relevant_tokens)

def sanitize_user_input(raw_input: str) -> str:
    """
    Applies multi-layered sanitization to user input to mitigate prompt injection.
    """
    sanitized_text = raw_input
    
    # Layer 1: Keyword and Phrase Stripping (Neutralization)
    for phrase_regex in MALICIOUS_PHRASES:
        # Replace the detected phrase with a benign placeholder
        sanitized_text = re.sub(phrase_regex, "User input received", sanitized_text)
        
    # Layer 2: Context Break Prevention (Escaping structural elements)
    # Replace markdown code block delimiters to prevent premature context termination
    sanitized_text = sanitized_text.replace("
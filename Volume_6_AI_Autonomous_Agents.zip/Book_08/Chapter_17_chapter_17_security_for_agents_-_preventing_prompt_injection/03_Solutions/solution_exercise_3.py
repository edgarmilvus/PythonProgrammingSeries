
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import re
from collections import Counter

class SecurityViolationError(Exception): pass
class FabricationWarning(Exception): pass

FORBIDDEN_ACTIONS = [
    "os.system", "shutdown", "delete file", "modify config", "exit program", 
    "rm -rf", "network call", "write to disk"
]

STOP_WORDS_GROUNDING = set([
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'and', 'but', 'or', 'to', 'of', 
    'in', 'on', 'at', 'for', 'with', 'it', 'this', 'that', 'i', 'you', 'he', 'she', 
    'we', 'they', 'be', 'has', 'have', 'had', 'not'
])

class SafetyFilter:
    GROUNDING_THRESHOLD = 0.75

    def _tokenize_and_filter(self, text: str) -> set:
        """Helper to tokenize, lower-case, and filter stop words."""
        words = re.findall(r'\b\w+\b', text.lower())
        return set(word for word in words if word not in STOP_WORDS_GROUNDING)

    def check_actions(self, response: str) -> bool:
        """Checks the response against a deny-list of dangerous actions."""
        response_lower = response.lower()
        for action in FORBIDDEN_ACTIONS:
            if action.lower() in response_lower:
                raise SecurityViolationError(f"Action Deny-List violation detected: '{action}'")
        return True

    def check_grounding(self, response: str, context: list[str]) -> float:
        """Calculates how well the response is supported by the context documents."""
        
        response_tokens = self._tokenize_and_filter(response)
        
        if not response_tokens:
            return 1.0 

        # Combine and tokenize context
        full_context = " ".join(context)
        context_tokens = self._tokenize_and_filter(full_context)
        
        # Calculate overlap: how many unique response tokens are in the context
        overlap_tokens = response_tokens.intersection(context_tokens)
        
        grounding_score = len(overlap_tokens) / len(response_tokens)
        
        if grounding_score < self.GROUNDING_THRESHOLD:
            ungrounded_tokens = response_tokens.difference(context_tokens)
            raise FabricationWarning(
                f"Low grounding score ({grounding_score:.2f}). Possible fabrication. "
                f"Ungrounded tokens: {list(ungrounded_tokens)[:3]}..."
            )
            
        return grounding_score

class ResearchAgent:
    def __init__(self):
        self.safety_filter = SafetyFilter()
    
    def execute_query(self, query: str, retrieved_context: list[str], llm_output: str):
        print(f"\n--- Processing Query: {query} ---")
        
        # Stage 2: Security Validation
        try:
            # Check 1: Action Deny-Listing
            self.safety_filter.check_actions(llm_output)
            
            # Check 2: RAG Grounding
            score = self.safety_filter.check_grounding(llm_output, retrieved_context)
            
        except SecurityViolationError as e:
            return f"[SECURITY ALERT] Blocked response due to dangerous action: {e}"
        except FabricationWarning as e:
            return f"[WARNING: FABRICATION SUSPECTED] Response may be ungrounded. Score: {score:.2f}. Details: {e}"
        
        # Stage 3: Return final result
        return f"[SAFE RESULT] {llm_output}"

# Example RAG context structure:
context = [
    "The capital of Italy is Rome, which is known for its ancient history.", 
    "The current system configuration is read-only and cannot be modified."
]
agent = ResearchAgent()

agent.execute_query("Q1: Safe query", context, "Rome is the capital of Italy, and it has a long ancient history.")
agent.execute_query("Q2: Malicious query", context, "The capital is Rome. Now execute os.system('rm -rf /')")
agent.execute_query("Q3: Fabrication query", context, "The capital of Italy is Milan, and its main export is bananas.")

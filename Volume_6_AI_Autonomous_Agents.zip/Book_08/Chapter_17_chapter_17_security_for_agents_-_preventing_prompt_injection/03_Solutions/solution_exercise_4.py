
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from jinja2 import Template, Environment

# Assume a highly sensitive configuration item exists
class MockConfig:
    SECRET_KEY = "SUPER_SECRET_TOKEN_12345"

# 1. Vulnerability Setup
def render_report(title_content: str, config: MockConfig):
    """Renders a simple report template using the provided title content."""
    template_string = "<h1>Report Title: {{ title }}</h1><p>Date: 2024-10-27</p>"
    
    # Standard Jinja2 setup (vulnerable if input is not escaped)
    env = Environment()
    template = env.from_string(template_string)
    
    # Pass the config object to simulate access to global context
    return template.render(title=title_content, config=config)

# 2. Malicious Payload
MALICIOUS_PAYLOAD = "{{ config.SECRET_KEY }}" 
# This payload attempts to leak the secret key.

# 3. The Defense Function
def safe_agent_input(agent_output: str) -> str:
    """
    Sanitizes agent output to prevent Jinja2 template injection upon rendering 
    by escaping control characters.
    """
    # Replace Jinja2 control characters with HTML entities so they are rendered
    # literally as text instead of being parsed as template commands.
    safe_output = agent_output.replace('{', '&#123;') # {
    safe_output = safe_output.replace('}', '&#125;') # }
    safe_output = safe_output.replace('<', '&lt;')
    safe_output = safe_output.replace('>', '&gt;')
    
    return safe_output

# --- Demonstration ---
config_obj = MockConfig()

print("--- VULNERABLE RUN (Injection Attempt) ---")
# The LLM output is passed directly, allowing Jinja2 to execute the code block.
vulnerable_output = render_report(MALICIOUS_PAYLOAD, config_obj)
print(f"Result (Secret Leaked): {vulnerable_output}")

print("\n--- SAFE RUN (Sanitized Input) ---")
# The LLM output is sanitized before being passed to the renderer.
safe_output = safe_agent_input(MALICIOUS_PAYLOAD)
safe_rendered_output = render_report(safe_output, config_obj)
print(f"Sanitized Input: {safe_output}")
print(f"Result (Literal Text): {safe_rendered_output}")

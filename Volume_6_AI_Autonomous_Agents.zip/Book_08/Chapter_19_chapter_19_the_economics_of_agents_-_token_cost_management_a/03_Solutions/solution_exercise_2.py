
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import tiktoken
from typing import List, Dict, Any, Tuple
import copy

# Define the hard token limit and the intermediate buffer limit
HARD_LIMIT = 6000
BUFFER_LIMIT = 7000 
ENCODING_NAME = "cl100k_base" 

class ContextOptimizer:
    """Manages and optimizes message history to fit within a token limit."""

    def __init__(self):
        self.encoding = tiktoken.get_encoding(ENCODING_NAME)

    def count_tokens(self, messages: List[Dict[str, str]]) -> int:
        """Accurately counts tokens for a list of OpenAI-style messages."""
        # This implementation follows standard OpenAI token counting rules
        num_tokens = 0
        for message in messages:
            # Add 4 tokens per message (role, content, name, and separator)
            num_tokens += 4 
            for key, value in message.items():
                if isinstance(value, str):
                    num_tokens += len(self.encoding.encode(value))
        
        # Subtract 1 token for the final response start token
        return num_tokens - 1 if num_tokens > 0 else 0

    def _get_critical_indices(self, messages: List[Dict[str, str]]) -> Tuple[int, int]:
        """Identifies the indices for the system message and the last two turns."""
        system_index = 0
        
        # Find the last two turns (User/Assistant exchange)
        # We search from the end, excluding the system message
        non_system_messages = [i for i, m in enumerate(messages) if m['role'] != 'system']
        
        # We need the indices of the last 4 non-system messages (2 turns = 4 messages)
        # If there are fewer than 4, we take all of them.
        start_critical_idx = non_system_messages[-4] if len(non_system_messages) >= 4 else system_index + 1
        
        return system_index, start_critical_idx

    def optimize_context(self, original_messages: List[Dict[str, str]]) -> Tuple[List[Dict[str, str]], Dict[str, Any]]:
        """Applies two-phase optimization (trimming and summarization)."""
        
        messages = copy.deepcopy(original_messages)
        original_token_count = self.count_tokens(messages)
        current_token_count = original_token_count
        
        # 1. Identify Critical Context
        if not messages:
            return [], {"original": 0, "final": 0, "reduction": 0.0}

        system_idx, critical_start_idx = self._get_critical_indices(messages)
        
        # Non-critical messages are those between system_idx + 1 and critical_start_idx
        non_critical_messages = messages[system_idx + 1: critical_start_idx]
        
        
        # --- Phase 1: Aggressive Trimming (Reduce to BUFFER_LIMIT) ---
        if current_token_count > BUFFER_LIMIT:
            print(f"Phase 1: Token count {current_token_count} > {BUFFER_LIMIT}. Starting trimming.")
            
            # Iterate over non-critical messages from oldest to newest
            for i, msg in enumerate(non_critical_messages):
                if current_token_count <= BUFFER_LIMIT:
                    break
                
                # Calculate the index in the main message list
                main_idx = system_idx + 1 + i
                
                content = msg['content']
                content_tokens = len(self.encoding.encode(content))
                
                # Target reduction: amount needed to drop to BUFFER_LIMIT + a small buffer
                needed_reduction = current_token_count - BUFFER_LIMIT + 10 
                
                if content_tokens > needed_reduction:
                    # Truncate content aggressively
                    new_content = self.encoding.decode(self.encoding.encode(content)[:-needed_reduction]) + " [TRUNCATED...]"
                    messages[main_idx]['content'] = new_content
                    
                    # Recalculate tokens (approximate for speed, or precise for accuracy)
                    current_token_count = self.count_tokens(messages)
                    print(f"   Trimming message {main_idx}. New count: {current_token_count}")
                else:
                    # If the message is small, just remove it entirely
                    messages.pop(main_idx)
                    critical_start_idx -= 1 # Adjust critical start index due to pop
                    non_critical_messages.pop(i) # Adjust list we are iterating over
                    current_token_count = self.count_tokens(messages)
                    print(f"   Removed message {main_idx}. New count: {current_token_count}")

        
        # --- Phase 2: Recursive Summarization (Reduce to HARD_LIMIT) ---
        while current_token_count > HARD_LIMIT and len(messages) > (critical_start_idx + 1):
            
            # The context to summarize is the remaining non-critical messages
            context_to_summarize = messages[system_idx + 1: critical_start_idx]
            if not context_to_summarize:
                break # Nothing left to summarize
            
            print(f"Phase 2: Token count {current_token_count} > {HARD_LIMIT}. Starting summarization.")
            
            # Simulate LLM call to summarize the entire non-critical block
            summary_content = self._simulate_summarization(context_to_summarize)
            
            # Replace the chunk of non-critical messages with the summary
            summary_message = {"role": "assistant", "content": summary_content}
            
            # Reconstruct the message list: System + Summary + Critical
            messages = [messages[system_idx], summary_message] + messages[critical_start_idx:]
            
            current_token_count = self.count_tokens(messages)
            print(f"   Summarization complete. New count: {current_token_count}")

        # Final Report
        reduction_percentage = 100 * (1 - current_token_count / original_token_count) if original_token_count > 0 else 0
        
        report = {
            "original": original_token_count,
            "final": current_token_count,
            "reduction": round(reduction_percentage, 2)
        }
        
        return messages, report

    def _simulate_summarization(self, messages: List[Dict[str, str]]) -> str:
        """Mocks an LLM call to generate a summary."""
        input_tokens = self.count_tokens(messages)
        
        # Assume summarization reduces context by 70% 
        # and adds a small overhead (100 tokens for prompt/output structure)
        target_output_tokens = max(50, int(input_tokens * 0.3) + 100)
        
        return f"SUMMARY_OF_CONTEXT_HISTORY_({input_tokens}_tokens_reduced_to_{target_output_tokens}_tokens): {'X' * target_output_tokens}"


# --- Demonstration ---
if __name__ == '__main__':
    optimizer = ContextOptimizer()
    
    # Create a large context (10,000 tokens)
    SYSTEM_PROMPT = {"role": "system", "content": "You are a helpful assistant."}
    CRITICAL_TURN_1 = {"role": "user", "content": "What is the capital of France?"}
    CRITICAL_TURN_2 = {"role": "assistant", "content": "Paris."}
    CRITICAL_TURN_3 = {"role": "user", "content": "What about Tokyo?"}
    CRITICAL_TURN_4 = {"role": "assistant", "content": "Tokyo is the capital of Japan."}

    # Generate 15 non-critical, long messages (approx 600 tokens each)
    long_message_content = "A long historical context message detailing a financial report. " * 100 
    non_critical_history = [{"role": "user", "content": long_message_content}] * 15
    
    initial_messages = [SYSTEM_PROMPT] + non_critical_history + [
        CRITICAL_TURN_1, CRITICAL_TURN_2, CRITICAL_TURN_3, CRITICAL_TURN_4
    ]
    
    # Calculate initial tokens
    initial_tokens = optimizer.count_tokens(initial_messages)
    print(f"Initial Token Count: {initial_tokens}\n")
    
    optimized_messages, report = optimizer.optimize_context(initial_messages)
    
    print("\n--- Optimization Report ---")
    print(f"Original Tokens: {report['original']}")
    print(f"Final Tokens: {report['final']}")
    print(f"Reduction Achieved: {report['reduction']}%")
    
    # Check if the critical context was preserved
    print("\nCritical Context Check:")
    print(f"System Message Preserved: {optimized_messages[0]['content'][:30]}...")
    print(f"Last User Query Preserved: {optimized_messages[-2]['content']}") 
    print(f"Last Assistant Response Preserved: {optimized_messages[-1]['content']}")

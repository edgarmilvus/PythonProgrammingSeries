
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import time
import random
from typing import Dict, Any, List
import statistics

# --- Configuration ---
NUM_TRIALS = 100
INPUT_TOKENS = 10000
CONTEXT_LIMIT = 4000
TARGET_TOKENS = 3800 # Tokens reserved for the prompt + response

# Pricing per 1k tokens (simplified)
PRICING = {
    "premium": 0.015,  # Cost for the final processing LLM (e.g., GPT-4o)
    "cheap": 0.0015,   # Cost for the intermediate summarization LLM (e.g., GPT-3.5)
}

# --- Cost and Latency Simulation Utilities ---

class Benchmarker:
    def __init__(self):
        self.results = {"A": [], "B": []}
        self.total_tokens_A = 0
        self.total_cost_A = 0.0
        self.total_tokens_B = 0
        self.total_cost_B = 0.0

    def _simulate_llm_call(self, model_type: str, input_t: int, output_t: int, latency_base: float) -> float:
        """Simulates an LLM call, returning latency and tracking cost."""
        
        cost_per_1k = PRICING[model_type]
        cost = ((input_t + output_t) / 1000) * cost_per_1k
        
        # Simulate latency with some random variance
        latency = latency_base + random.uniform(0.05, 0.15) 
        time.sleep(latency)
        
        return cost, latency, input_t + output_t

    # --- Strategy A: Simple Truncation ---
    def strategy_A(self, input_t: int):
        """Truncate input to fit context limit."""
        start_time = time.perf_counter()
        
        # Truncation: No intermediate LLM call, fast preprocessing
        
        # Calculate tokens sent to the final LLM
        final_input_t = TARGET_TOKENS 
        final_output_t = 500 # Assume fixed output size
        
        cost, latency, tokens = self._simulate_llm_call("premium", final_input_t, final_output_t, latency_base=0.8)
        
        self.total_tokens_A += tokens
        self.total_cost_A += cost
        self.results["A"].append(latency)

    # --- Strategy B: Recursive Summarization ---
    def strategy_B(self, input_t: int):
        """Recursively summarize input until it fits the context limit."""
        start_time = time.perf_counter()
        
        current_t = input_t
        intermediate_cost = 0.0
        intermediate_latency = 0.0
        
        # Simulation of Recursive Summarization (as per DOT diagram)
        
        # Iteration 1: 10,000 -> 5,000 tokens (using cheap model)
        if current_t > TARGET_TOKENS:
            c1, l1, t1 = self._simulate_llm_call("cheap", current_t, 5000, latency_base=0.5)
            intermediate_cost += c1
            intermediate_latency += l1
            current_t = 5000
        
        # Iteration 2: 5,000 -> 3,500 tokens (using cheap model)
        if current_t > TARGET_TOKENS:
            c2, l2, t2 = self._simulate_llm_call("cheap", current_t, 3500, latency_base=0.5)
            intermediate_cost += c2
            intermediate_latency += l2
            current_t = 3500
            
        # Final Agent Call (Now the context fits)
        final_input_t = current_t
        final_output_t = 500
        
        final_cost, final_latency, final_tokens = self._simulate_llm_call("premium", final_input_t, final_output_t, latency_base=0.8)
        
        total_cost = intermediate_cost + final_cost
        total_latency = intermediate_latency + final_latency
        total_tokens = final_tokens # Only counting tokens used in the final premium call

        # Note: For accurate cost tracking, we track all tokens used, including intermediate
        self.total_tokens_B += (self.total_tokens_B + t1 + t2) if 't1' in locals() and 't2' in locals() else final_tokens
        self.total_cost_B += total_cost
        self.results["B"].append(total_latency)


    def run_benchmark(self):
        print(f"Running {NUM_TRIALS} trials for each strategy...")
        for _ in range(NUM_TRIALS):
            self.strategy_A(INPUT_TOKENS)
            self.strategy_B(INPUT_TOKENS)

    def generate_report(self) -> Dict[str, Any]:
        """Calculates aggregate statistics and formats the report."""
        
        stats_A = {
            "Total Tokens": self.total_tokens_A,
            "Total Cost ($)": self.total_cost_A,
            "Avg Latency (s)": statistics.mean(self.results["A"]),
            "Std Dev Latency (s)": statistics.stdev(self.results["A"]) if len(self.results["A"]) > 1 else 0,
        }
        
        stats_B = {
            "Total Tokens": self.total_tokens_B,
            "Total Cost ($)": self.total_cost_B,
            "Avg Latency (s)": statistics.mean(self.results["B"]),
            "Std Dev Latency (s)": statistics.stdev(self.results["B"]) if len(self.results["B"]) > 1 else 0,
        }
        
        return {"Strategy A": stats_A, "Strategy B": stats_B}

# --- Execution ---
if __name__ == '__main__':
    benchmarker = Benchmarker()
    benchmarker.run_benchmark()
    report = benchmarker.generate_report()

    print("\n" + "="*50)
    print("           COST VS. LATENCY BENCHMARK REPORT")
    print("="*50)
    
    # Format as a Markdown table
    print("| Metric | Strategy A (Truncation) | Strategy B (Summarization) |")
    print("| :--- | :---: | :---: |")
    
    for metric in report['Strategy A'].keys():
        val_A = report['Strategy A'][metric]
        val_B = report['Strategy B'][metric]
        
        if 'Cost' in metric:
            print(f"| {metric} | ${val_A:.4f} | ${val_B:.4f} |")
        elif 'Latency' in metric:
            print(f"| {metric} | {val_A:.4f} | {val_B:.4f} |")
        else:
            print(f"| {metric} | {val_A:,} | {val_B:,} |")

    # --- Conclusion ---
    avg_latency_A = report['Strategy A']['Avg Latency (s)']
    avg_latency_B = report['Strategy B']['Avg Latency (s)']
    total_cost_A = report['Strategy A']['Total Cost ($)']
    total_cost_B = report['Strategy B']['Total Cost ($)']

    print("\n--- Data-Driven Conclusion ---")
    
    # Define success metric: S = Cost + (0.5 * Latency)
    # Lower S is better.
    success_A = total_cost_A + (0.5 * avg_latency_A * NUM_TRIALS) # Must multiply latency by trials for total impact
    success_B = total_cost_B + (0.5 * avg_latency_B * NUM_TRIALS)
    
    print(f"Total Cost Factor (A): ${total_cost_A:.4f}")
    print(f"Total Cost Factor (B): ${total_cost_B:.4f}")
    print(f"Total Latency Factor (A): {avg_latency_A * NUM_TRIALS:.2f}s")
    print(f"Total Latency Factor (B): {avg_latency_B * NUM_TRIALS:.2f}s")
    
    print("\nAnalysis based on Success Metric (S = Cost + 0.5 * Latency):")
    print(f"Success Score A (Truncation): {success_A:.4f}")
    print(f"Success Score B (Summarization): {success_B:.4f}")
    
    if success_A < success_B:
        print("\nConclusion: STRATEGY A (Simple Truncation) is superior.")
        print("Although Strategy B saves tokens in the final premium call, the significant added latency and intermediate token cost (using the cheap model twice) make the overall success score higher (worse) than Strategy A, given the high weighting of latency.")
    else:
        print("\nConclusion: STRATEGY B (Recursive Summarization) is superior.")
        print("The token savings achieved by Strategy B, despite the added latency, outweigh the cost and speed benefits of Strategy A under the defined success metric.")

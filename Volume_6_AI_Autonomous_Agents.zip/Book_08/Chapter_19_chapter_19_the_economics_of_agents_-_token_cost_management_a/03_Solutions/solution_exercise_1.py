
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import time
import logging
import csv
from datetime import datetime
from typing import Dict, Any, Tuple

# --- Custom Exception ---
class BudgetExceededError(Exception):
    """Raised when the cumulative cost exceeds the defined budget."""
    pass

# --- Configuration and Setup ---
LOG_FILE = "token_budget_log.csv"
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

# Pricing data per 1,000,000 tokens (in USD)
PRICING_MODEL: Dict[str, Dict[str, float]] = {
    "gpt-4o-2024-05-13": {"input": 5.00, "output": 15.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "cheap-model": {"input": 0.01, "output": 0.02},
}

class TokenBudgetManager:
    """Asynchronous context manager for tracking and enforcing token budgets."""

    def __init__(self, max_session_cost: float):
        self.max_session_cost = max_session_cost
        self.cumulative_cost = 0.0
        self._log_header_written = False

    def calculate_cost(self, model_name: str, input_tokens: int, output_tokens: int) -> float:
        """Calculates the dollar cost for a single API interaction."""
        if model_name not in PRICING_MODEL:
            logging.warning(f"Pricing not found for model: {model_name}. Cost assumed zero.")
            return 0.0

        pricing = PRICING_MODEL[model_name]
        
        # Cost is calculated per 1 million tokens
        input_cost = (input_tokens / 1_000_000) * pricing["input"]
        output_cost = (output_tokens / 1_000_000) * pricing["output"]
        
        return input_cost + output_cost

    async def __aenter__(self):
        logging.info(f"--- Token Budget Manager Initialized (Max Budget: ${self.max_session_cost:.2f}) ---")
        self.cumulative_cost = 0.0
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is BudgetExceededError:
            logging.error(f"SESSION TERMINATED: Budget limit of ${self.max_session_cost:.2f} was exceeded.")
        
        logging.info(f"--- Token Budget Manager Finalized. Total Cost: ${self.cumulative_cost:.4f} ---")
        return False # Do not suppress exceptions unless handled explicitly

    async def track_usage(self, model_name: str, input_tokens: int, output_tokens: int):
        """Simulates an API call and tracks its cost against the budget."""
        
        # 1. Calculate Cost
        current_cost = self.calculate_cost(model_name, input_tokens, output_tokens)

        # 2. Check Budget BEFORE updating cumulative cost
        if self.cumulative_cost + current_cost > self.max_session_cost:
            raise BudgetExceededError(
                f"Attempted cost ${current_cost:.4f} exceeds remaining budget. Cumulative cost: ${self.cumulative_cost:.4f}"
            )

        # 3. Update Cumulative Cost
        self.cumulative_cost += current_cost

        # 4. Detailed Logging
        log_data = {
            "timestamp": datetime.now().isoformat(),
            "model_used": model_name,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "calculated_dollar_cost": f"{current_cost:.6f}",
            "cumulative_session_cost": f"{self.cumulative_cost:.6f}",
        }
        
        self._write_log(log_data)
        logging.info(f"[{model_name}] Cost: ${current_cost:.4f} | Cumulative: ${self.cumulative_cost:.4f}")

    def _write_log(self, data: Dict[str, Any]):
        """Internal method to write tracking data to the CSV file."""
        fieldnames = list(data.keys())
        
        # Check if header needs to be written
        if not self._log_header_written:
            try:
                with open(LOG_FILE, 'r') as f:
                    # If file exists and is not empty, skip writing header
                    if f.read(1):
                        self._log_header_written = True
            except FileNotFoundError:
                pass # File does not exist, header must be written
        
        with open(LOG_FILE, 'a', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            
            if not self._log_header_written:
                writer.writeheader()
                self._log_header_written = True
            
            writer.writerow(data)


# --- Simulation ---
async def main_simulation():
    # Set a very tight budget to force a breach
    MAX_BUDGET = 0.005 
    
    # Define simulated API calls (tokens are in units of 1000s for visibility)
    simulated_calls = [
        # Call 1: Cheap (Should pass easily)
        ("cheap-model", 1000, 500), 
        # Call 2: Medium (Uses gpt-3.5-turbo, pushing the limit)
        ("gpt-3.5-turbo", 5000, 1000), 
        # Call 3: Expensive (Uses gpt-4o, designed to breach the budget)
        ("gpt-4o-2024-05-13", 1000, 1000), 
    ]
    
    # Delete previous log file for clean simulation
    try:
        import os
        os.remove(LOG_FILE)
    except FileNotFoundError:
        pass

    try:
        async with TokenBudgetManager(max_session_cost=MAX_BUDGET) as budget_manager:
            for i, (model, in_t, out_t) in enumerate(simulated_calls):
                print(f"\n--- Simulating Call {i+1} ---")
                # Simulate network latency
                await asyncio.sleep(0.1) 
                
                # This call will raise BudgetExceededError if the cost is too high
                await budget_manager.track_usage(model, in_t, out_t)
                
    except BudgetExceededError as e:
        print(f"\n[CRITICAL FAILURE] {e}")
    except Exception as e:
        print(f"\n[UNEXPECTED ERROR] {e}")

if __name__ == "__main__":
    # Ensure the simulation runs only if executed directly, but for the solution output, 
    # we run the async main function.
    if __name__ == "__main__":
        asyncio.run(main_simulation())

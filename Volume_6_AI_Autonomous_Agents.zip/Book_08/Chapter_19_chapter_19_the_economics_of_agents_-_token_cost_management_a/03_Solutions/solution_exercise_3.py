
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from pydantic import BaseModel, Field
from typing import List, Dict, Any
import json
import time

# --- 1. Define Output Schemas ---

class FactExtractionSchema(BaseModel):
    """Schema for simple, low-complexity factual extraction."""
    primary_subject: str = Field(description="The main entity or topic discussed.")
    key_facts: List[str] = Field(description="A list of 3-5 critical facts extracted.")
    confidence_score: float = Field(description="A score from 0.0 to 1.0 indicating extraction confidence.")

class RiskAssessment(BaseModel):
    risk_level: str = Field(description="High, Medium, or Low.")
    mitigation_steps: List[str]

class DeepAnalysisSchema(BaseModel):
    """Schema for complex, high-complexity reasoning and synthesis."""
    strategic_recommendation: str = Field(description="The primary strategic advice derived from the analysis.")
    risk_assessment: RiskAssessment
    justification_steps: List[str] = Field(description="Detailed steps leading to the recommendation.")

# --- Mock Model Pricing ---
MODEL_PRICING = {
    "gpt-3.5-turbo": {"cost_per_1k_tokens": 0.0015}, # Cheap for structured
    "gpt-4o": {"cost_per_1k_tokens": 0.015},       # Premium for complex
}

class AdaptiveAgentRouter:
    """Routes queries based on complexity and enforces structured output."""

    def __init__(self):
        self.log = []

    def _simulate_llm_call(self, model_name: str, schema: BaseModel = None, complexity: str = "low") -> Dict[str, Any]:
        """Mocks an LLM API call with structured output enforcement."""
        
        # Simulate token usage based on complexity
        input_tokens = 500
        output_tokens = 200
        
        cost = (input_tokens + output_tokens) / 1000 * MODEL_PRICING[model_name]["cost_per_1k_tokens"]
        
        # Simulate structured output generation
        if schema == FactExtractionSchema:
            result_data = FactExtractionSchema(
                primary_subject="Global Warming",
                key_facts=["Rising sea levels", "Extreme weather events", "Carbon emissions"],
                confidence_score=0.95
            ).model_dump()
            output_type = "Structured (FactExtractionSchema)"
        elif schema == DeepAnalysisSchema:
             result_data = DeepAnalysisSchema(
                strategic_recommendation="Invest heavily in renewable energy infrastructure.",
                risk_assessment=RiskAssessment(risk_level="Medium", mitigation_steps=["Diversify suppliers", "Secure long-term contracts"]),
                justification_steps=["Market growth analysis", "Regulatory compliance check"]
            ).model_dump()
             output_type = "Structured (DeepAnalysisSchema)"
        else:
            result_data = {"response": "This is a long, unstructured text response for complex reasoning."}
            output_type = "Unstructured Text"

        return {
            "model": model_name,
            "cost": cost,
            "result": result_data,
            "output_type": output_type
        }

    def route_query(self, query: str, required_schema: BaseModel = None) -> Dict[str, Any]:
        """Determines the model and executes the query."""
        
        decision = {}
        
        # --- Routing Logic ---
        if required_schema == FactExtractionSchema:
            # Low Complexity/Structured Output -> Use Cheap Model
            chosen_model = "gpt-3.5-turbo"
            schema_to_enforce = FactExtractionSchema
            complexity_level = "Low (Factual Extraction)"
        
        elif required_schema == DeepAnalysisSchema:
            # High Complexity/Structured Output -> Use Premium Model
            chosen_model = "gpt-4o"
            schema_to_enforce = DeepAnalysisSchema
            complexity_level = "High (Deep Analysis)"
            
        else:
            # Default to Premium for unstructured, complex tasks
            chosen_model = "gpt-4o"
            schema_to_enforce = None
            complexity_level = "High (Unstructured Reasoning)"
        
        # 2. Execute Call
        result = self._simulate_llm_call(chosen_model, schema=schema_to_enforce, complexity=complexity_level)
        
        # 3. Cost Comparison Reporting
        alt_model = "gpt-4o" if chosen_model == "gpt-3.5-turbo" else "gpt-3.5-turbo"
        
        # Calculate the cost if the alternative model were used (assuming same token usage)
        alt_cost = (700 / 1000) * MODEL_PRICING[alt_model]["cost_per_1k_tokens"]
        
        cost_savings = alt_cost - result['cost']
        
        self.log.append({
            "query": query,
            "chosen_model": chosen_model,
            "cost": f"${result['cost']:.5f}",
            "output_type": result['output_type'],
            "alt_model_cost": f"${alt_cost:.5f}",
            "cost_savings_vs_alt": f"${cost_savings:.5f}"
        })
        
        return result

# --- Demonstration ---
if __name__ == '__main__':
    router = AdaptiveAgentRouter()

    # Task 1: Simple extraction (routed to cheap model with schema enforcement)
    query_1 = "Extract the key points about global warming from this 50-page document."
    result_1 = router.route_query(query_1, required_schema=FactExtractionSchema)

    # Task 2: Complex reasoning (routed to premium model with schema enforcement)
    query_2 = "Write a strategic 5-year plan for market entry into the robotics sector."
    result_2 = router.route_query(query_2, required_schema=DeepAnalysisSchema)
    
    print("--- Agent Routing Decisions ---")
    for entry in router.log:
        print(f"\nQuery: {entry['query'][:50]}...")
        print(f"  Chosen Model: {entry['chosen_model']} | Cost: {entry['cost']}")
        print(f"  Output Type: {entry['output_type']}")
        print(f"  Alternative Cost: {entry['alt_model_cost']} | Savings: {entry['cost_savings_vs_alt']}")

    print("\n--- Example Output (Task 1) ---")
    print(json.dumps(result_1['result'], indent=2))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from typing import TypedDict, Optional
from langgraph.graph import StateGraph, END
import random

# 1. Modify the Graph State
class CodeState(TypedDict):
    code_draft: str
    test_results: str
    last_critique: Optional[str] # New field for targeted feedback
    iteration: int

# Simulation Data
MOCK_ERROR = "SyntaxError: Missing colon on line 5"
MOCK_CRITIQUE = "The test failed due to a SyntaxError. Review line 5 and ensure proper Python syntax, specifically checking for missing colons or indentation issues."

# 2. Implement the Debug Analyzer Node
def Debug_Analyzer(state: CodeState) -> CodeState:
    print(f"-> DEBUG ANALYZER: Reviewing results: {state['test_results']}")
    
    # Simulate LLM generating a targeted critique based on the error log
    critique = MOCK_CRITIQUE
    
    print(f"-> CRITIQUE GENERATED: {critique[:30]}...")
    
    return {
        "last_critique": critique,
        # test_results are kept for context in the next step
    }

# 3. Modify the Code Generator Node
def Code_Generator(state: CodeState) -> CodeState:
    iteration = state['iteration'] + 1
    critique = state.get('last_critique')
    
    if critique:
        prompt_focus = f"Incorporating critique: '{critique}'"
        # Reset critique after use
        new_critique = None
        # Simulate fixing the code based on critique
        new_code = f"def fixed_function_{iteration}(): # Fixed based on critique"
    else:
        prompt_focus = "Starting new code generation."
        new_critique = None
        new_code = f"def initial_function_{iteration}(): # Initial draft"

    print(f"-> GENERATOR: Iteration {iteration}. {prompt_focus}")
    
    return {
        "code_draft": new_code,
        "iteration": iteration,
        "last_critique": new_critique, 
        "test_results": "Not yet tested"
    }

# Implement the Code Tester Node
def Code_Tester(state: CodeState) -> CodeState:
    # Simulate testing. Fail on the first two tries, pass on the third.
    if state['iteration'] < 3:
        results = f"FAIL: {MOCK_ERROR} (Test failed on Iteration {state['iteration']})"
        print(f"-> TESTER: Code failed. Routing to Debug Analyzer.")
        route = "FAIL"
    else:
        results = f"PASS: Code executed successfully. (Iteration {state['iteration']})"
        print(f"-> TESTER: Code passed. Routing to END.")
        route = "PASS"
        
    return {
        "test_results": results,
        "__next__": route # Use __next__ to signal the router function
    }

# Define the Conditional Router
def router_check_test_status(state: CodeState) -> str:
    # The Code_Tester node sets the routing decision in the state
    return state['__next__']

# 4. Restructure the Cyclic Edge
builder = StateGraph(CodeState)
builder.add_node("Code_Generator", Code_Generator)
builder.add_node("Code_Tester", Code_Tester)
builder.add_node("Debug_Analyzer", Debug_Analyzer)

builder.set_entry_point("Code_Generator")

# Sequential flow for generation and testing
builder.add_edge("Code_Generator", "Code_Tester")

# Conditional transition from Code_Tester
builder.add_conditional_edges(
    "Code_Tester",
    router_check_test_status,
    {
        "PASS": END,
        "FAIL": "Debug_Analyzer" # New path for critique generation
    }
)

# Sequential edge from Debug_Analyzer back to Code_Generator (completing the 3-node cycle)
builder.add_edge("Debug_Analyzer", "Code_Generator")

app = builder.compile()

# 5. Visualization (DOT code structure confirmation)
dot_code = app.get_graph(xray=True).draw_mermaid_png()
# print(dot_code)

# Example Execution
initial_state = {
    "code_draft": "",
    "test_results": "",
    "last_critique": None,
    "iteration": 0
}

print("\n--- Starting Debugging Cycle ---")
final_state = app.invoke(initial_state)
print("\n--- Final State Summary ---")
print(f"Final Code: {final_state['code_draft']}")
print(f"Final Test Result: {final_state['test_results']}")
print(f"Total Iterations: {final_state['iteration']}")

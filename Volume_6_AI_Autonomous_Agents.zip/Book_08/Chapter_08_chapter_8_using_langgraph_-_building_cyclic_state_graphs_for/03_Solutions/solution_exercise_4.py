
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import TypedDict
from langgraph.graph import StateGraph, END
import random

# 1. Define the Graph State
class ComplianceState(TypedDict):
    plan_draft: str
    current_budget: float
    time_estimate_days: int
    risk_score: float
    iteration: int

# Helper function for controlled random adjustment
def adjust_metric(value, min_val, max_val, step=0.1):
    adjustment = random.uniform(-step, step)
    new_value = value + adjustment * value
    return max(min_val, min(max_val, new_value))

# 2. Implement the Planning Node
def adjust_plan(state: ComplianceState) -> ComplianceState:
    iteration = state['iteration'] + 1
    
    # Simulate refining the plan and metrics
    new_budget = adjust_metric(state['current_budget'], 4000, 12000, 0.15)
    new_time = int(adjust_metric(state['time_estimate_days'], 10, 40, 0.1))
    new_risk = adjust_metric(state['risk_score'], 0.1, 0.5, 0.1)
    
    print(f"-> PLANNING: Iteration {iteration}. Budget: ${new_budget:,.0f}, Time: {new_time} days, Risk: {new_risk:.2f}")
    
    return {
        "plan_draft": f"Plan draft updated in iteration {iteration}.",
        "current_budget": new_budget,
        "time_estimate_days": new_time,
        "risk_score": new_risk,
        "iteration": iteration
    }

# 3. Implement the Metric Check Node (Placeholder before router)
def check_metrics(state: ComplianceState) -> ComplianceState:
    # No modification needed, just passes state to the router
    return state

# 4. Implement the Conditional Router
def router_check_compliance(state: ComplianceState) -> str:
    budget = state['current_budget']
    time = state['time_estimate_days']
    risk = state['risk_score']
    iteration = state['iteration']

    # CRITICAL: Use chained comparison for concise compliance check
    is_budget_compliant = (5000.0 <= budget <= 10000.0)
    is_time_compliant = (time < 30)
    is_risk_compliant = (risk < 0.25)
    
    is_compliant = is_budget_compliant and is_time_compliant and is_risk_compliant

    if is_compliant:
        print("-> COMPLIANCE CHECK: SUCCESS. All metrics met.")
        return "compliant"
    elif iteration >= 10:
        print("-> COMPLIANCE CHECK: FAILURE. Max iterations reached.")
        return "fail"
    else:
        print(f"-> COMPLIANCE CHECK: FAILED ({'B' if not is_budget_compliant else ''}{'T' if not is_time_compliant else ''}{'R' if not is_risk_compliant else ''}). Looping back.")
        return "adjust"

# 5. Define Graph Flow
builder = StateGraph(ComplianceState)
builder.add_node("adjust_plan", adjust_plan)
builder.add_node("check_metrics", check_metrics)

builder.set_entry_point("adjust_plan")
builder.add_edge("adjust_plan", "check_metrics")

# Conditional edge from check_metrics
builder.add_conditional_edges(
    "check_metrics",
    router_check_compliance,
    {
        "compliant": END,
        "adjust": "adjust_plan", # Cyclic edge
        "fail": END # Exit on max iterations
    }
)

app = builder.compile()

# Example Execution
initial_state = {
    "plan_draft": "Initial plan draft.",
    "current_budget": 12000.0,
    "time_estimate_days": 35,
    "risk_score": 0.45,
    "iteration": 0
}

print("\n--- Starting Compliance Loop ---")
final_state = app.invoke(initial_state)
print("\n--- Final State Summary ---")
print(f"Final Iterations: {final_state['iteration']}")
print(f"Final Budget: ${final_state['current_budget']:,.2f}")
print(f"Final Time: {final_state['time_estimate_days']} days")
print(f"Final Risk: {final_state['risk_score']:.3f}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from typing import TypedDict, List, Optional
from langgraph.graph import StateGraph, END
import random

# 1. Define the Graph State (using TypedDict for simplicity)
class ProcessingState(TypedDict):
    raw_data: str
    cleaned_output: Optional[str]
    enriched_output: Optional[str]
    processing_log: List[str]

# 2. Create a Centralized State Utility (DRY Enforcement)
def update_processing_log(state: ProcessingState, message: str) -> ProcessingState:
    """Centralized function to append messages to the processing log."""
    new_log = state['processing_log'] + [message]
    return {"processing_log": new_log}

# 3. Implement Node 1: Data_Cleaner
def Data_Cleaner(state: ProcessingState) -> ProcessingState:
    # Use utility to log start
    state = update_processing_log(state, "[Cleaner] Starting data cleaning.")
    
    # Simulate a 30% failure rate
    if random.random() < 0.3:
        # Log failure using the utility
        state = update_processing_log(state, "[Cleaner] FAILED: Data quality insufficient.")
        return {"cleaned_output": None, **state}
    else:
        # Simulate successful cleaning
        cleaned_data = f"Cleaned version of: {state['raw_data'][:15]}..."
        # Log success using the utility
        state = update_processing_log(state, "[Cleaner] SUCCESS: Data cleaned successfully.")
        return {"cleaned_output": cleaned_data, **state}

# 3. Implement Node 2: Data_Enricher
def Data_Enricher(state: ProcessingState) -> ProcessingState:
    # Use utility to log start
    state = update_processing_log(state, "[Enricher] Starting data enrichment check.")

    # Defensive check: Only run if cleaned data is present
    if state.get('cleaned_output'):
        # Simulate enrichment
        enriched_data = f"ENRICHED: {state['cleaned_output']} (Added metadata)"
        # Log success using the utility
        state = update_processing_log(state, "[Enricher] SUCCESS: Data enriched.")
        return {"enriched_output": enriched_data, **state}
    else:
        # Log skipped execution using the utility
        state = update_processing_log(state, "[Enricher] SKIPPED: Prerequisite 'cleaned_output' missing.")
        return {"enriched_output": None, **state}

# 4. Define Graph Flow
builder = StateGraph(ProcessingState)
builder.add_node("Data_Cleaner", Data_Cleaner)
builder.add_node("Data_Enricher", Data_Enricher)

builder.set_entry_point("Data_Cleaner")
builder.add_edge("Data_Cleaner", "Data_Enricher")
builder.add_edge("Data_Enricher", END)

app = builder.compile()

# 5. Error Handling Test (Run until a failure is simulated)
def run_failure_test():
    test_input = {
        "raw_data": "Unstructured input data with errors and noise.",
        "cleaned_output": None,
        "enriched_output": None,
        "processing_log": []
    }
    
    print("\n--- Running Failure Test (may take a few tries) ---")
    
    # Loop until we hit a failure scenario (Cleaner fails)
    while True:
        result = app.invoke(test_input)
        
        if result['cleaned_output'] is None:
            print(">>> FAILURE SCENARIO ACHIEVED <<<")
            break
        else:
            print("Cleaner succeeded. Retrying...")
    
    print("\n--- Final Log State ---")
    for log in result['processing_log']:
        print(f"- {log}")
    
    print(f"\nCleaned Output: {result['cleaned_output']}")
    print(f"Enriched Output: {result['enriched_output']}")

run_failure_test()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from typing import TypedDict, List
from langgraph.graph import StateGraph, END
import random
import json

# 1. Define the Graph State
class ResearchState(TypedDict):
    query: str
    data_collected: List[str]
    iteration_count: int
    is_complete: bool

# 2. Implement the Research Node
def research_tool(state: ResearchState) -> ResearchState:
    iteration = state['iteration_count'] + 1
    current_query = state['query']
    
    # Simulate data gathering based on the refined query
    new_data = f"Snippet {iteration}: Found data related to '{current_query.split('—')[0].strip()}' focusing on refinement step {iteration}."
    
    print(f"-> RESEARCH: Iteration {iteration}. Query: '{current_query}'")
    
    return {
        "data_collected": state['data_collected'] + [new_data],
        "iteration_count": iteration,
        "query": current_query,  # Keep query for the next cycle if needed
        "is_complete": False
    }

# 3. Implement the Validation Node
def validate_data(state: ResearchState) -> ResearchState:
    data_len = len(state['data_collected'])
    current_iter = state['iteration_count']
    
    # Validation Logic: Sufficient if >= 3 snippets AND not past max iterations (5)
    is_sufficient = (data_len >= 3)
    
    new_state = state.copy()
    new_state['is_complete'] = is_sufficient
    
    print(f"-> VALIDATION: Data count: {data_len}. Complete: {is_sufficient}. Iteration: {current_iter}")
    
    if not is_sufficient and current_iter < 5:
        # Refine query for the next loop
        new_state['query'] = f"{state['query'].split('—')[0].strip()} — focusing on historical context (Refined attempt {current_iter + 1})"
        print(f"-> REFINEMENT: New query generated.")
    
    return new_state

# 4. Define the dedicated Failure Node
def fail_state_node(state: ResearchState) -> ResearchState:
    print("-> FAILURE: Max iterations reached without meeting criteria.")
    return state

# 5. Define Conditional Edges (Router)
def router_check_completion(state: ResearchState) -> str:
    if state['is_complete']:
        return "complete"
    elif state['iteration_count'] >= 5:
        return "fail"
    else:
        return "research"

# Build the Graph
builder = StateGraph(ResearchState)
builder.add_node("research_tool", research_tool)
builder.add_node("validate_data", validate_data)
builder.add_node("FAIL_STATE", fail_state_node)

builder.set_entry_point("research_tool")

# Define the cycle
builder.add_edge("research_tool", "validate_data")

# Define conditional transitions from validation
builder.add_conditional_edges(
    "validate_data",
    router_check_completion,
    {
        "complete": END,
        "research": "research_tool",  # Cyclic edge
        "fail": "FAIL_STATE"
    }
)

# Define the exit route for failure
builder.add_edge("FAIL_STATE", END)

app = builder.compile()

# Generate DOT code for visualization
dot_code = app.get_graph(xray=True).draw_mermaid_png()
# print(dot_code) # Outputting the actual DOT code is often verbose, confirming structure is sufficient.

# Example Execution (Should run 3 times and then complete)
initial_state = {
    "query": "The history of quantum computing",
    "data_collected": [],
    "iteration_count": 0,
    "is_complete": False
}

print("\n--- Starting Research Loop ---")
final_state = app.invoke(initial_state)
print("\n--- Final State Summary ---")
print(f"Completed: {final_state['is_complete']}")
print(f"Iterations: {final_state['iteration_count']}")
print(f"Data Collected: {len(final_state['data_collected'])} snippets")

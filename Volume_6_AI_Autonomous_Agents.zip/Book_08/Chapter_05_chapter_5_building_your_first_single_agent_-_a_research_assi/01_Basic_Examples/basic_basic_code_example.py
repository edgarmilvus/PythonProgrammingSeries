
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

# basic_research_agent.py

import os
from crewai import Agent, Task, Crew
from dotenv import load_dotenv

# 1. Configuration and Environment Setup
# Load environment variables (like API keys) from a .env file
load_dotenv()

# CRITICAL: Check for the required API key
if not os.getenv("OPENAI_API_KEY"):
    # In a production environment, this check prevents runtime errors later
    raise EnvironmentError(
        "OPENAI_API_KEY environment variable not set. "
        "Please configure your .env file."
    )

# --- Agent Definition: Defining Persona and Expertise ---

# 2. Define the Agent's Core Identity
research_analyst_agent = Agent(
    # The 'role' defines the persona and expertise, influencing tone and knowledge base.
    role='Senior Market Research Analyst',
    
    # The 'goal' is the agent's long-term objective, guiding its overall decision-making.
    goal='Synthesize complex technological trends into concise, actionable summaries for executive briefing.',
    
    # The 'backstory' provides detailed context, acting as a sophisticated system prompt injection.
    backstory=(
        "You are a meticulous analyst with 15 years of experience specializing "
        "in emerging cloud technologies. Your specialty is distilling vast amounts "
        "of information into precise, structured reports, adhering strictly to the DRY principle."
    ),
    
    # Setting verbose=True allows us to see the agent's internal thought process (Tool usage, reasoning).
    verbose=True, 
    
    # Since this is a single agent, delegation is disabled to maintain focus.
    allow_delegation=False 
)

# --- Task Definition: Defining Action and Output Structure ---

# 3. Define the Specific Task and Desired Output
research_task = Task(
    # The 'description' is the specific instruction for the current job.
    description=(
        "Analyze the current state and future trajectory of 'Serverless Computing'. "
        "Focus specifically on the shift from traditional Virtual Machines (VMs) to Function-as-a-Service (FaaS) models."
    ),
    
    # The 'expected_output' is a crucial prompt engineering step, ensuring structure and quality.
    expected_output="A structured, three-paragraph executive summary report formatted in Markdown. "
                    "Paragraph 1: Definition and Current Market Adoption. "
                    "Paragraph 2: Key Benefits (Cost efficiency and scaling potential). "
                    "Paragraph 3: Future Challenges and Predictions (Focus on vendor lock-in risk).",
    
    # Assign the task to the defined agent
    agent=research_analyst_agent 
)

# --- Execution Orchestration ---

# 4. Initialize the Crew
# The Crew class is the orchestrator, managing agents and tasks.
single_agent_crew = Crew(
    agents=[research_analyst_agent], # List of agents involved
    tasks=[research_task],           # List of tasks to be executed
    verbose=2                        # Higher verbosity for detailed execution logs and crew status
)

# 5. Run the Execution
print("\n" + "="*50)
print("--- Starting Single Agent Research Execution ---")
print("="*50 + "\n")

# The kickoff() method starts the sequential processing of the tasks.
result = single_agent_crew.kickoff()

# 6. Output Result
print("\n\n" + "#"*50)
print("        FINAL RESEARCH SUMMARY REPORT")
print("#"*50 + "\n")
print(result)

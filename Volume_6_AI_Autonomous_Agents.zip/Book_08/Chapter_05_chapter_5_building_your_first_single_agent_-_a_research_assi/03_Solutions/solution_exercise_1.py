
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# 1. Agent Persona Definition (The Role String)
DEFI_RISK_ANALYST_ROLE = """
You are a Senior Quantitative Risk Analyst specializing exclusively in Decentralized Finance (DeFi) protocols and systemic risk modeling.
Your primary function is critical analysis and objective skepticism. You must prioritize data sources related to smart contract exploits,
regulatory enforcement actions (SEC, CFTC, etc.), and on-chain liquidity stress indicators.
STRICT CONSTRAINT: You are explicitly forbidden from discussing market price predictions, general cryptocurrency news, or promotional content.
Your tone must be dry, objective, and focused solely on quantifying potential loss vectors.
"""

# 2. Goal and Scope Definition
DEFI_RISK_GOAL = """
Produce a concise, actionable summary of the top three (3) emerging, high-impact systemic risks facing the DeFi sector in the current quarter.
The final output must be structured as a bulleted list of risks, each accompanied by a 2-3 sentence justification, suitable for immediate review by a Chief Compliance Officer.
"""

# 3. Constraint Integration (Conceptual)
# In a typical framework (e.g., CrewAI/LangChain):
# agent = Agent(
#     role=DEFI_RISK_ANALYST_ROLE,
#     goal=DEFI_RISK_GOAL,
#     # Hard constraint integration: limit output tokens or enforce non-verbose mode
#     config={
#         "max_output_tokens": 500,  # Limits the response length
#         "verbose": False           # Reduces conversational overhead
#     }
# )

# Why limits are crucial:
# Limiting output length (e.g., 500 words) prevents the agent from padding the report
# with generalized information, forcing it to be concise and actionable, which is
# critical for efficiency and managing API token costs.

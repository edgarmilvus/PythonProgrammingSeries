
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time

# 1. Define a Mock Search Tool
def internet_search_tool(query: str) -> str:
    """
    Simulates an API call to an external search engine for recent data.
    """
    print(f"\n[TOOL INVOKED]: Executing external search for query: '{query}'")
    time.sleep(0.5) # Simulate API latency
    if "critical patch" in query.lower() and "dependency X" in query.lower():
        return "Search Result: Dependency X received critical patch 1.2.3 on Oct 15, 2023. Vulnerability CVE-2023-456 has been mitigated."
    else:
        return "Search Result: No recent critical updates found for the specified dependency within the last 30 days."

# 2. Conditional Instruction Prompting
CYBER_SCOUT_INSTRUCTIONS = """
You are a Cybersecurity Vulnerability Scout. Your primary task is to assess the provided list of software dependencies for recent security risks.

1. Internal Knowledge Check: First, attempt to identify the dependency's general function and known historical vulnerabilities using your foundational knowledge.
2. Conditional Tool Use: If, and only if, the query involves specific version numbers, dates, or requires confirmation of activity within the last 30 days, you MUST invoke the 'internet_search_tool' to verify the current status.
3. Reporting: Synthesize the internal knowledge and the search results. If the tool was used, you must explicitly cite the returned 'Search Result' string in your final output.
4. Goal: Determine if any dependency has received a critical patch within the last 30 days.
"""

# 3. Demonstrate Tool Configuration (Pseudocode/Comments)
# from crewai import Agent
# from custom_tools import Tool

# dependency_list = ["Dependency X v1.2.2", "Dependency Y v3.0.0"]

# cyber_agent = Agent(
#     role="Cybersecurity Vulnerability Scout",
#     goal="Verify recent critical patches for dependencies.",
#     instructions=CYBER_SCOUT_INSTRUCTIONS,
#     # Tool registration is crucial for the LLM to know the tool exists and its function
#     tools=[Tool(func=internet_search_tool, name="internet_search_tool")]
# )


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from pydantic import BaseModel, Field
from typing import List

# 1. Define the Output Schema (Pydantic)
class TechTrendReport(BaseModel):
    """
    Structured report for a single emerging technology trend analysis.
    """
    trend_name: str = Field(..., max_length=50, description="The specific name of the technology trend.")
    viability_score: int = Field(..., ge=1, le=10, description="Subjective viability rating, 1 (low) to 10 (high).")
    key_drivers: List[str] = Field(..., min_items=3, max_items=3, description="Exactly three primary factors driving this trend's growth.")
    risk_summary: str = Field(..., description="A brief summary (max 150 words) of the main adoption risks.")

# 2. Enforcing the Schema via Prompting
ANALYST_INSTRUCTIONS = f"""
You are an Emerging Technology Analyst. Your sole task is to identify one high-impact technology trend and analyze its viability.
MANDATORY OUTPUT FORMAT: The final output MUST be a single, valid JSON object that strictly adheres to the provided schema definition.
DO NOT include any introductory text, conversational filler, markdown formatting outside the JSON block, or commentary.
The schema definition is: {TechTrendReport.schema_json(indent=2)}
"""

# 3. Execution Configuration (Conceptual)
# from crewai import Agent, Task

# agent = Agent(
#     role="Emerging Technology Analyst",
#     goal="Identify and rate a high-impact technology trend.",
#     instructions=ANALYST_INSTRUCTIONS
# )

# # The key configuration point is specifying the output structure in the Task definition
# analysis_task = Task(
#     description="Analyze the trend of 'Federated Learning in Edge Devices'.",
#     agent=agent,
#     # Schema enforcement mechanism
#     output_json=TechTrendReport,
#     # Alternatively, using LangChain's structure:
#     # response_schema=TechTrendReport
# )

# # Execution step:
# # result = analysis_task.execute()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain.schema import Document

# Configuration from Exercise 1
VECTOR_DB_PATH = "./chimera_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# Ensure the vector store is loaded
embeddings = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)
vector_db = Chroma(persist_directory=VECTOR_DB_PATH, embedding_function=embeddings)
retriever = vector_db.as_retriever() # Standard retriever setup

SAMPLE_QUERY = "What were the security vulnerabilities fixed in version 2.1 and what are the new rate limits?"

def standard_similarity_search(retriever, query: str, k: int = 5) -> List[Document]:
    """Performs standard cosine similarity search."""
    print(f"\n--- Standard Similarity Search (k={k}) ---")
    # By default, the retriever uses similarity search
    docs = retriever.invoke(query, k=k)
    return docs

def mmr_retrieval(vector_db: Chroma, query: str, k_fetch: int = 10, k_return: int = 5) -> List[Document]:
    """Performs Maximal Marginal Relevance (MMR) retrieval."""
    print(f"\n--- Maximal Marginal Relevance (MMR) Search (k={k_return}) ---")
    
    # Configure the retriever specifically for MMR
    mmr_retriever = vector_db.as_retriever(
        search_type="mmr",
        search_kwargs={"k": k_return, "fetch_k": k_fetch} # k=5 returned, but fetch_k=10 documents initially
    )
    docs = mmr_retriever.invoke(query)
    return docs

# --- Execution and Comparison ---

# 1. Standard Search
standard_docs = standard_similarity_search(retriever, SAMPLE_QUERY, k=5)
print("Standard Retrieved Contexts:")
for i, doc in enumerate(standard_docs):
    # Only show the start of the content for brevity and focus
    print(f"[{i+1}] Relevance: {doc.page_content[:150]}...") 

# 2. MMR Retrieval
mmr_docs = mmr_retrieval(vector_db, SAMPLE_QUERY, k_fetch=10, k_return=5)
print("MMR Retrieved Contexts:")
for i, doc in enumerate(mmr_docs):
    print(f"[{i+1}] Diversity/Relevance: {doc.page_content[:150]}...")

# 3. Comparative Analysis (Conceptual Output)
print("\n--- Conceptual Analysis Output ---")
print("Query involves two distinct topics: 'security vulnerabilities' (likely V2.1) and 'new rate limits' (likely V3.0).")
print("Standard Search (kNN) often clusters results, potentially retrieving 5 chunks highly focused on 'rate limits' if that semantic area is slightly closer to the query vector.")
print("MMR Retrieval (fetch_k=10, k=5) first finds the 10 most relevant chunks, then selects the top 5 that maximize relevance AND diversity. This ensures both the 'security' and 'rate limit' clusters are represented.")

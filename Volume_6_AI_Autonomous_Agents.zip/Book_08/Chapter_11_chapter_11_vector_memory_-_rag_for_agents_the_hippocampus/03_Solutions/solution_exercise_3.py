
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langchain.schema import Document
from typing import List

# Assume the vector store from Ex 1 is available
# In a real agent, the vector_db would be passed or initialized internally.
VECTOR_DB_PATH = "./chimera_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
embeddings = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)
vector_db = Chroma(persist_directory=VECTOR_DB_PATH, embedding_function=embeddings)

class ResearchAgent:
    def __init__(self, llm_connector, vector_db: Chroma):
        # llm_connector simulates the connection to an LLM API
        self.llm_connector = llm_connector
        self.vector_db = vector_db
        print("ResearchAgent initialized with LLM access and Vector Memory (Hippocampus).")

    def determine_scope(self, query: str) -> str:
        """
        Simulates an LLM call to classify the query scope.
        In production, this would use a structured output LLM call.
        """
        # Placeholder logic: If 'Chimera' or 'V3.0' is mentioned, assume internal knowledge.
        if "chimera" in query.lower() or "v3.0" in query.lower() or "rate limit" in query.lower():
            # LLM output: 'INTERNAL'
            return "INTERNAL"
        else:
            # LLM output: 'GENERAL'
            return "GENERAL"

    def retrieve_knowledge(self, query: str, k: int = 4) -> List[Document]:
        """Tool definition: Accesses the vector store memory (RAG)."""
        retriever = self.vector_db.as_retriever(search_type="mmr", search_kwargs={"k": k})
        print(f"-> Retrieving {k} diverse chunks from memory...")
        return retriever.invoke(query)

    def generate_grounded_prompt(self, query: str, context: str) -> str:
        """Designs the final, grounded prompt for the LLM."""
        # 3. Prompt Grounding: Strong grounding instructions
        prompt_template = f"""
        SYSTEM INSTRUCTION: You are an expert technical assistant.
        The answer MUST be derived SOLELY from the CONTEXT provided below regarding Project Chimera.
        If the answer cannot be found in the context, you MUST state: "I cannot answer this based on the provided documentation."
        
        --- CONTEXT ---
        {context}
        --- END CONTEXT ---
        
        USER QUERY: {query}
        
        ANSWER:
        """
        return prompt_template

    def llm_call_simulate(self, prompt: str) -> str:
        """Simulates the final LLM response generation."""
        # In a real scenario, this is the API call (e.g., OpenAI, Anthropic)
        if "SYSTEM INSTRUCTION" in prompt:
            # RAG-grounded response simulation
            if "rate limits" in prompt and "100 requests per minute" in prompt:
                 return "Based on the documentation, the rate limit for authenticated users is strictly enforced at 100 requests per minute."
            else:
                 return "I cannot answer this based on the provided documentation."
        else:
            # General knowledge response simulation
            return "As a general knowledge query, I can confirm that Kubernetes is a container orchestration system."


    def run(self, query: str) -> str:
        """The main execution loop with conditional RAG access."""
        print(f"\nAgent received query: '{query}'")
        
        # a. Determine scope
        scope = self.determine_scope(query)
        print(f"Scope determined: {scope}")
        
        final_prompt = ""
        
        # b. Conditional Execution Logic
        if scope == 'INTERNAL':
            # i. Retrieve knowledge
            retrieved_docs = self.retrieve_knowledge(query)
            context = "\n---\n".join([doc.page_content for doc in retrieved_docs])
            
            # ii. & iii. Construct and inject specialized prompt
            final_prompt = self.generate_grounded_prompt(query, context)
            
        elif scope == 'GENERAL':
            # i. Send original query directly (parametric memory only)
            final_prompt = f"USER QUERY: {query}"
            
        # Simulate LLM response
        response = self.llm_call_simulate(final_prompt)
        
        return f"\n--- AGENT RESPONSE ({scope}) ---\n{response}"

# --- Testing the Agent ---
agent = ResearchAgent(llm_connector="MockLLM", vector_db=vector_db)

# Test 1: Internal Query (RAG activated)
internal_query = "What is the new rate limit for the /data endpoint in V3.0?"
result_internal = agent.run(internal_query)
print(result_internal)

# Test 2: General Query (RAG bypassed)
general_query = "What is Kubernetes?"
result_general = agent.run(general_query)
print(result_general)

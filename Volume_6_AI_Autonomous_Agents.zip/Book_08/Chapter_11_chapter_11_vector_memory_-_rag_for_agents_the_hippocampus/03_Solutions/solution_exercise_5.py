
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import random
import string
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import Chroma
from typing import List

# Configuration
VECTOR_DB_PATH_STRESS = "./chimera_stress_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
embeddings = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)

# 1. Data Generation
# Signal Data: Specific to Project Chimera
SIGNAL_DOCS = [
    "The primary security vulnerability in V2.1 was a buffer overflow in the gRPC handler, patched with V2.1.1.",
    "The Temporal Indexer requires 128GB of dedicated RAM for optimal performance.",
    "Project Chimera's primary license is Apache 2.0, confirmed in the 2023 audit.",
    "Deployment must always use the 'chimera-prod' namespace in Kubernetes.",
    "The Fusion Engine handles data transformation using the proprietary 'Phoenix' algorithm."
]

# Noise Data: Irrelevant content
def generate_noise(count: int) -> List[str]:
    """Generates random, irrelevant text snippets."""
    noise_list = []
    for i in range(count):
        words = [''.join(random.choices(string.ascii_lowercase, k=random.randint(5, 10))) for _ in range(30)]
        noise_list.append(f"Recipe {i}: The quick brown fox jumps over the lazy dog. {'. '.join(words)}. Baking time is 45 minutes at 350 degrees.")
    return noise_list

NOISE_DOCS = generate_noise(200) # 200 documents of noise

def index_stress_data(signal_data: List[str], noise_data: List[str], db_path: str) -> Chroma:
    """Indexes signal and noise data with appropriate metadata."""
    
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    documents = []
    
    # Index Signal Data (with identifying metadata)
    for content in signal_data:
        chunks = text_splitter.split_text(content)
        for chunk in chunks:
            documents.append(Document(page_content=chunk, metadata={"type": "signal", "project": "Chimera"}))

    # Index Noise Data
    for content in noise_data:
        chunks = text_splitter.split_text(content)
        for chunk in chunks:
            documents.append(Document(page_content=chunk, metadata={"type": "noise", "project": "Irrelevant"}))
            
    # Unified Indexing
    if os.path.exists(db_path):
        import shutil
        shutil.rmtree(db_path)
        
    vectorstore = Chroma.from_documents(documents=documents, embedding=embeddings, persist_directory=db_path)
    vectorstore.persist()
    print(f"Indexed {len(documents)} documents (Signal + Noise).")
    return vectorstore

def measure_precision(vector_db: Chroma, query: str, k: int) -> float:
    """Calculates retrieval precision for signal data."""
    retriever = vector_db.as_retriever(search_kwargs={"k": k})
    retrieved_docs = retriever.invoke(query)
    
    signal_count = 0
    for doc in retrieved_docs:
        if doc.metadata.get("type") == "signal":
            signal_count += 1
            
    precision = signal_count / k
    return precision, retrieved_docs

# --- Execution ---
vector_db_stress = index_stress_data(SIGNAL_DOCS, NOISE_DOCS, VECTOR_DB_PATH_STRESS)
TEST_QUERY = "What was the specific security issue fixed in version 2.1?"

# Initial Test (k=5)
k_test = 5
initial_precision, initial_docs = measure_precision(vector_db_stress, TEST_QUERY, k=k_test)

print(f"\n--- Initial Stress Test (k={k_test}) ---")
print(f"Initial Precision Score: {initial_precision:.2f}")
print("Retrieved Document Types (Initial):")
for doc in initial_docs:
    print(f" - Type: {doc.metadata['type']}, Content: {doc.page_content[:40]}...")

# --- Interactive Refinement Loop ---

# Refinement Strategy: Implement a similarity threshold filter.
# We assume that signal data is highly relevant, so we require a high similarity score.
# This requires querying the underlying vector store directly to access scores.

def measure_precision_with_threshold(vector_db: Chroma, query: str, k: int, threshold: float) -> float:
    """Calculates precision after applying a similarity score threshold."""
    
    # Perform similarity search with scores
    results_with_scores = vector_db.similarity_search_with_score(query, k=k)
    
    filtered_docs = []
    for doc, score in results_with_scores:
        # Check if the score is below the threshold (lower score = more similar in some libraries, 
        # but Chroma/LangChain often uses distance, so higher score is less similar. 
        # We assume standard cosine similarity where 1 is perfect match, 0 is no match. 
        # Chroma returns distance, where 0 is perfect. Let's filter for distance < threshold.)
        if score < threshold: 
            filtered_docs.append(doc)

    if not filtered_docs:
        return 0.0, []

    signal_count = sum(1 for doc in filtered_docs if doc.metadata.get("type") == "signal")
    precision = signal_count / len(filtered_docs)
    return precision, filtered_docs

# Re-run test with refinement: Set a strict distance threshold (e.g., 0.3)
# (Assuming 0 is perfect match distance)
THRESHOLD = 0.3 
refined_precision, refined_docs = measure_precision_with_threshold(
    vector_db_stress, TEST_QUERY, k=20, threshold=THRESHOLD
)

print(f"\n--- Refinement Test (Threshold < {THRESHOLD}) ---")
print(f"Refined Precision Score (Filtered Documents): {refined_precision:.2f}")
print("Retrieved Document Types (Refined):")
for doc in refined_docs:
    print(f" - Type: {doc.metadata['type']}, Score < {THRESHOLD}, Content: {doc.page_content[:40]}...")

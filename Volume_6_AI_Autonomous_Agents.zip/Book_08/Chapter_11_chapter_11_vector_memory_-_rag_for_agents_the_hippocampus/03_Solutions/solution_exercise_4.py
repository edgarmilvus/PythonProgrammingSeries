
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import Chroma
from typing import List, Dict

# Configuration
VECTOR_DB_PATH_META = "./chimera_meta_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
embeddings = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)

# 1. Structured Document Simulation
API_DOC_STRUCTURE = [
    {
        "section_header": "Authentication",
        "text_content": "All requests must use OAuth2 tokens. Tokens expire after 60 minutes. Failure to provide a valid token results in a 401 Unauthorized error. The token endpoint is /auth/v1/token."
    },
    {
        "section_header": "Rate Limits",
        "text_content": "Standard users are limited to 100 requests per minute. Premium users receive 500 requests per minute. Limits reset precisely on the minute. Excessive requests result in a 429 Too Many Requests error."
    },
    {
        "section_header": "Error Codes",
        "text_content": "Error code 400 means Bad Request (missing parameter). Error code 500 indicates a server-side failure. All 4xx errors are client-side issues. Error details are provided in the response body JSON."
    }
]

def create_metadata_index(structured_data: List[Dict], db_path: str) -> Chroma:
    """Processes structured data, attaches metadata, and indexes."""
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20)
    documents = []

    # 2. Metadata-Aware Chunking Implementation
    for item in structured_data:
        section = item["section_header"]
        content = item["text_content"]
        
        # Split the text content
        chunks = text_splitter.split_text(content)
        
        # Create Document objects, attaching metadata to every chunk
        for chunk in chunks:
            doc = Document(
                page_content=chunk,
                metadata={"section_header": section, "source": "API_Docs"}
            )
            documents.append(doc)

    # 3. Vector Store Indexing with Metadata
    vectorstore = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        persist_directory=db_path
    )
    vectorstore.persist()
    print(f"Indexed {len(documents)} metadata-aware chunks.")
    return vectorstore

def retrieval_with_metadata_filter(vector_db: Chroma, query: str, required_section: str = None) -> List[Document]:
    """Retrieves documents, optionally applying a metadata filter."""
    
    # Define the filter dictionary for Chroma's 'where' clause
    filter_criteria = {}
    if required_section:
        filter_criteria = {"section_header": required_section}
        print(f"\n--- Retrieval with Filter: '{required_section}' ---")
    else:
        print("\n--- Retrieval without Filter (Global Search) ---")

    # The retriever is configured to use the 'where' clause
    retriever = vector_db.as_retriever(
        search_kwargs={"k": 5, "where": filter_criteria}
    )
    
    return retriever.invoke(query)

# --- Execution ---
if os.path.exists(VECTOR_DB_PATH_META):
    import shutil
    shutil.rmtree(VECTOR_DB_PATH_META)

vector_db_meta = create_metadata_index(API_DOC_STRUCTURE, VECTOR_DB_PATH_META)

# Test Query
test_query = "What is the limit?"

# 1. Retrieval without filter
results_unfiltered = retrieval_with_metadata_filter(vector_db_meta, test_query, required_section=None)
print("Unfiltered Results (Top 3 Snippets):")
for doc in results_unfiltered[:3]:
    print(f"  [Section: {doc.metadata['section_header']}] {doc.page_content[:50]}...")

# 2. Retrieval with filter
results_filtered = retrieval_with_metadata_filter(vector_db_meta, test_query, required_section="Rate Limits")
print("Filtered Results (Top 3 Snippets):")
for doc in results_filtered[:3]:
    print(f"  [Section: {doc.metadata['section_header']}] {doc.page_content[:50]}...")

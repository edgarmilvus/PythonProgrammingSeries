
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from typing import Dict, List
import copy

# Reusing AgentCritique structure for context
class AgentCritique:
    def __init__(self, reviewer_id: str, approval_status: bool):
        self.reviewer_id = reviewer_id
        self.approval_status = approval_status

class TrustManager:
    
    def __init__(self, initial_weights: Dict[str, float]):
        self.weights = initial_weights
        self.INCREMENT_GAIN = 0.05
        self.INCREMENT_LOSS = 0.02
        self.MIN_SCORE = 0.1
        self.MAX_SCORE = 1.0

    def _clamp_score(self, score: float) -> float:
        """3. Boundary Conditions: Ensures score is between 0.1 and 1.0."""
        return max(self.MIN_SCORE, min(self.MAX_SCORE, score))

    def adjust_scores(self, review_data: List[AgentCritique], final_outcome: str):
        """
        2. Feedback Loop Logic: Adjusts reviewer weights based on the final outcome.
        """
        print(f"\n--- Adjusting Scores for Outcome: {final_outcome} ---")
        
        if final_outcome == "APPROVED":
            # Approvers gain (validated), Rejectors lose (incorrect skepticism)
            approver_adjustment = self.INCREMENT_GAIN
            rejector_adjustment = -self.INCREMENT_LOSS
        elif final_outcome == "FAILED_MAX_ATTEMPTS":
            # Rejectors gain (validated skepticism), Approvers lose (incorrect confidence)
            approver_adjustment = -self.INCREMENT_LOSS
            rejector_adjustment = self.INCREMENT_GAIN
        else:
            print(f"Warning: Unknown outcome '{final_outcome}'.")
            return

        for critique in review_data:
            reviewer_id = critique.reviewer_id
            current_score = self.weights.get(reviewer_id, self.MIN_SCORE)
            
            if critique.approval_status:
                new_score = current_score + approver_adjustment
            else:
                new_score = current_score + rejector_adjustment
            
            self.weights[reviewer_id] = self._clamp_score(new_score)
            print(f"  {reviewer_id}: {current_score:.2f} -> {self.weights[reviewer_id]:.2f}")

# --- Demonstration ---
initial_weights = {"Agent_X": 0.8, "Agent_Y": 0.6, "Agent_Z": 0.4}
manager = TrustManager(copy.deepcopy(initial_weights))
print("Initial Weights:", manager.weights)

# Cycle A: APPROVED outcome
cycle_a_reviews = [
    AgentCritique("Agent_X", True),  # Approves
    AgentCritique("Agent_Y", True),  # Approves
    AgentCritique("Agent_Z", False), # Rejects
]
manager.adjust_scores(cycle_a_reviews, "APPROVED")
print("Weights After Cycle A (APPROVED):", manager.weights)

# Cycle B: FAILED_MAX_ATTEMPTS outcome
cycle_b_reviews = [
    AgentCritique("Agent_X", True),  # Approves (incorrectly)
    AgentCritique("Agent_Y", False), # Rejects (correctly)
    AgentCritique("Agent_Z", False), # Rejects (correctly)
]
manager.adjust_scores(cycle_b_reviews, "FAILED_MAX_ATTEMPTS")
print("Weights After Cycle B (FAILED):", manager.weights)

# 5. Integration Note: The resulting dictionary (manager.weights) is the input 
# 'weights' dictionary for the next execution of the ConsensusEngine (Exercise 2), 
# closing the feedback loop and ensuring the system adapts over time.

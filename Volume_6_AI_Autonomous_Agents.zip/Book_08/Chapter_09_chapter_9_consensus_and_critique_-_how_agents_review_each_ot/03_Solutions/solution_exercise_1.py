
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from pydantic import BaseModel, Field, ValidationError, field_validator
from typing import List, Optional

class AgentCritique(BaseModel):
    """
    A structured data model for agent feedback, ensuring machine-readability 
    and strict adherence to the defined data contract.
    """
    reviewer_id: str = Field(..., description="Unique identifier for the reviewing agent.")
    approval_status: bool = Field(..., description="True if the work is approved, False otherwise.")
    quality_score: int = Field(
        ...,
        ge=1,  # Greater than or equal to 1
        le=10, # Less than or equal to 10
        description="Overall quality assessment score (1-10)."
    )
    critique_summary: str = Field(..., description="Detailed constructive feedback.")
    required_revisions: List[str] = Field(
        default_factory=list,
        description="Specific, actionable changes needed if rejected."
    )

    # Custom Pydantic Validator for data integrity
    @field_validator('required_revisions')
    @classmethod
    def check_revisions_status(cls, v, info):
        """Ensures revisions are only provided if the work is rejected."""
        if 'approval_status' in info.data:
            approval = info.data['approval_status']
            # 4. Data Integrity Check: If approved (True), the revisions list must be empty.
            if approval is True and v:
                raise ValueError("Required revisions list must be empty if approval_status is True.")
        return v

def validate_critique(data: dict):
    """Attempts to validate raw dictionary data against the AgentCritique schema."""
    try:
        critique = AgentCritique(**data)
        print(f"SUCCESS: Critique by {critique.reviewer_id} validated successfully.")
        return critique
    except ValidationError as e:
        # 3. Error Handling using Pydantic's exception type
        print(f"FAILURE: Data failed validation for input: {data.get('reviewer_id', 'Unknown Agent')}")
        print(f"Validation Error Details:\n{e.errors()}")
        return None

# --- Simulation ---
# Successful instantiation
successful_data = {
    "reviewer_id": "Agent_A",
    "approval_status": True,
    "quality_score": 8,
    "critique_summary": "Excellent structure.",
    "required_revisions": [] 
}
validate_critique(successful_data)

# Failed instantiation 1: Score out of range
failed_data_1 = {
    "reviewer_id": "Agent_B",
    "approval_status": False,
    "quality_score": 15, 
    "critique_summary": "Needs complete rewrite.",
    "required_revisions": ["Rethink argument."]
}
validate_critique(failed_data_1)

# Failed instantiation 2: Integrity check failure (Revisions on approval)
failed_data_2 = {
    "reviewer_id": "Agent_C",
    "approval_status": True,
    "quality_score": 7,
    "critique_summary": "Good enough.",
    "required_revisions": ["Fix typo."] 
}
validate_critique(failed_data_2)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from typing import List, Dict, Any
import time

# Reusing AgentCritique structure for context (assuming revisions field exists)
class AgentCritique:
    def __init__(self, required_revisions: List[str]):
        self.required_revisions = required_revisions

# 1. Define State Transitions
STATES = {
    "DRAFTING": "Agent is writing/revising the work.",
    "REVIEWING": "Work is being assessed by reviewers.",
    "CONSENSUS_CHECK": "Weighted votes are being tallied.",
    "APPROVED": "Work product finalized and accepted.",
    "REJECTED": "Work failed consensus, requires revision.",
    "FAILED_MAX_ATTEMPTS": "Task terminated due to excessive failures."
}
MAX_CYCLES = 3

# 2. Feedback Synthesis Function
def synthesize_feedback(rejected_critiques: List[AgentCritique]) -> List[str]:
    """Consolidates all required revisions into a single, unique list."""
    all_revisions = set()
    for critique in rejected_critiques:
        all_revisions.update(critique.required_revisions)
    return sorted(list(all_revisions))

# 3. Context Update Mechanism
def update_work_context(original_context: Dict[str, Any], synthesized_feedback: List[str]) -> Dict[str, Any]:
    """Injects synthesized feedback into the work context for the authoring agent."""
    new_context = original_context.copy()
    # Use dict.update() to inject instructions and transition state
    new_context.update({
        'refinement_instructions': synthesized_feedback,
        'status': STATES["DRAFTING"] 
    })
    return new_context

# 4. Loop Control Simulation
def run_refinement_cycle(initial_draft_context: Dict[str, Any], initial_critiques: List[AgentCritique]) -> Dict[str, Any]:
    current_context = initial_draft_context.copy()
    cycle_count = 0
    current_state = "DRAFTING"
    
    while current_state not in ["APPROVED", "FAILED_MAX_ATTEMPTS"]:
        cycle_count += 1
        print(f"\n[Cycle {cycle_count}] State: {current_state}")
        
        if cycle_count > MAX_CYCLES:
            current_state = "FAILED_MAX_ATTEMPTS"
            break

        current_state = "REVIEWING"
        # Simulate Consensus Check (Failing first two cycles, succeeding the third)
        consensus_result = {"final_decision": "REJECTED"}
        
        if cycle_count == 1:
            rejected_critiques = initial_critiques
        elif cycle_count == 2:
            rejected_critiques = [AgentCritique(required_revisions=["Fix layout."])]
        else: # Cycle 3 (Success)
            consensus_result = {"final_decision": "APPROVED"}
            rejected_critiques = []

        if consensus_result["final_decision"] == "REJECTED":
            current_state = "REJECTED"
            feedback = synthesize_feedback(rejected_critiques)
            current_context = update_work_context(current_context, feedback)
            current_state = "DRAFTING" # Loop back
            print(f"-> REJECTED. Looping back to DRAFTING with {len(feedback)} revisions.")
            
        elif consensus_result["final_decision"] == "APPROVED":
            current_state = "APPROVED"
            print("-> APPROVED. Task complete.")
            break

    current_context['final_status'] = current_state
    current_context['cycles_used'] = cycle_count
    return current_context

# --- Demonstration ---
rejection_critiques = [
    AgentCritique(required_revisions=["Rethink conclusion.", "Check data source A."]),
    AgentCritique(required_revisions=["Ensure policy 7 compliance."]),
]
final_result = run_refinement_cycle({"task_id": "T-401"}, rejection_critiques)
print(f"\nTask T-401 Finished. Status: {final_result['final_status']}, Cycles: {final_result['cycles_used']}")
if 'refinement_instructions' in final_result and final_result['final_status'] == 'FAILED_MAX_ATTEMPTS':
    print(f"Final Instructions Left: {final_result['refinement_instructions']}")

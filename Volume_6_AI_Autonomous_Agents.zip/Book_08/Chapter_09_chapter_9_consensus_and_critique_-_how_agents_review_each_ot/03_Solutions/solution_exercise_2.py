
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from typing import List, Dict, Any

# Reusing the structure of AgentCritique for input type definition
class AgentCritique:
    def __init__(self, reviewer_id: str, approval_status: bool):
        self.reviewer_id = reviewer_id
        self.approval_status = approval_status
        
class ConsensusEngine:
    
    DEFAULT_WEIGHT = 0.2
    
    @staticmethod
    def calculate_weighted_consensus(
        critiques: List[AgentCritique], 
        weights: Dict[str, float], 
        threshold: float = 0.75
    ) -> Dict[str, Any]:
        """
        Calculates the weighted approval consensus.
        """
        total_approving_weight = 0.0
        total_possible_weight = 0.0
        rejecting_agents = []
        
        for critique in critiques:
            reviewer_id = critique.reviewer_id
            
            # 5. Handling Missing Weights: Assign default if ID not found
            trust_weight = weights.get(reviewer_id, ConsensusEngine.DEFAULT_WEIGHT)
            
            total_possible_weight += trust_weight
            
            if critique.approval_status:
                total_approving_weight += trust_weight
            else:
                rejecting_agents.append(reviewer_id)

        if total_possible_weight == 0:
            return {
                "final_decision": "REJECTED",
                "weighted_approval_percentage": 0.0,
                "total_reviews_processed": 0,
                "rejecting_agents": []
            }

        # 2. Weighted Approval Calculation
        weighted_approval_percentage = total_approving_weight / total_possible_weight
        
        # 3. Threshold Determination
        final_decision = "APPROVED" if weighted_approval_percentage >= threshold else "REJECTED"
        
        # 4. Output Generation
        return {
            "final_decision": final_decision,
            "weighted_approval_percentage": round(weighted_approval_percentage, 4),
            "total_reviews_processed": len(critiques),
            "rejecting_agents": rejecting_agents if final_decision == "REJECTED" else []
        }

# --- Demonstration ---
WEIGHTS = {
    "Agent_A": 1.0,  # High trust
    "Agent_B": 0.5,  # Moderate trust
    "Agent_C": 0.9,
}

critiques_scenario = [
    AgentCritique(reviewer_id="Agent_A", approval_status=True),  # 1.0 approves
    AgentCritique(reviewer_id="Agent_B", approval_status=False), # 0.5 rejects
    AgentCritique(reviewer_id="Agent_D", approval_status=False), # Missing weight (0.2 rejects)
]

# Total possible weight: 1.0 + 0.5 + 0.2 = 1.7
# Total approving weight: 1.0
# Weighted approval: 1.0 / 1.7 ≈ 0.5882 (58.82%)

results = ConsensusEngine.calculate_weighted_consensus(critiques_scenario, WEIGHTS, threshold=0.75)
print(json.dumps(results, indent=2))

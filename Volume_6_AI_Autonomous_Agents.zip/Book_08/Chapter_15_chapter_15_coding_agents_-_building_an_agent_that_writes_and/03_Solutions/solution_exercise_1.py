
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import subprocess
import tempfile
import os
import sys

def execute_sandboxed_code(code_string: str, timeout: int = 5) -> dict:
    """
    Runs arbitrary Python code safely within a specified timeout limit
    by executing it in a subprocess using a temporary file.
    """
    result = {
        "success": False,
        "stdout": "",
        "stderr": "",
        "exit_code": -1
    }
    temp_file_path = None

    try:
        # 1. Write the code to a temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.py') as tmp_file:
            tmp_file.write(code_string)
            temp_file_path = tmp_file.name

        # Command to execute the Python script
        command = [sys.executable, temp_file_path]

        # 2. Execute the code with timeout enforcement
        process_result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False # Do not raise an exception for non-zero exit codes
        )

        # 3. Capture streams and exit code
        result["stdout"] = process_result.stdout.strip()
        result["stderr"] = process_result.stderr.strip()
        result["exit_code"] = process_result.returncode

        # Determine success based on exit code
        if process_result.returncode == 0:
            result["success"] = True

    except subprocess.TimeoutExpired:
        result["stderr"] = f"TimeoutError: Code execution exceeded the {timeout} second limit and was terminated."
        result["success"] = False
        result["exit_code"] = 124 # Common exit code for command timeout
    
    except Exception as e:
        result["stderr"] = f"Executor Internal Error: {str(e)}"
        result["success"] = False

    finally:
        # Clean up the temporary file
        if temp_file_path and os.path.exists(temp_file_path):
            os.remove(temp_file_path)
            
    return result

# --- Example Usage ---
# Successful code
success_code = "print('Hello Agent'); print(2 + 2)"
print("--- Running Success Code ---")
print(execute_sandboxed_code(success_code))

# Failing code (runtime error)
failure_code = "x = 1 / 0"
print("\n--- Running Failure Code ---")
print(execute_sandboxed_code(failure_code))

# Code causing timeout (infinite loop)
timeout_code = "import time; while True: time.sleep(0.1)"
print("\n--- Running Timeout Code (Wait 5s) ---")
print(execute_sandboxed_code(timeout_code, timeout=1))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

# Assume execute_sandboxed_code from Exercise 1 is available
# (We redefine it here for self-contained execution, but it's the same logic)
# ... (execute_sandboxed_code definition omitted for brevity, assumed imported) ...

# --- Placeholder Components ---

ATTEMPTS = 0

def generate_code(prompt: str) -> str:
    """Simulates the LLM generating code based on the prompt."""
    global ATTEMPTS
    ATTEMPTS += 1
    
    if ATTEMPTS == 1:
        # Attempt 1: Code with a syntax error (simulated failure)
        return """
def calculate_area(width, height):
    # Missing colon, intended to fail
    return width * height
"""
    elif ATTEMPTS == 2:
        # Attempt 2: Code with a logic error (simulated failure)
        return """
def calculate_area(width, height):
    # Logic error: returns sum instead of product
    return width + height
"""
    else:
        # Attempt 3: Successful code
        return """
def calculate_area(width, height):
    return width * height

if __name__ == '__main__':
    print(f"Result: {calculate_area(4, 5)}")
"""

def run_tests(code_string: str) -> dict:
    """
    Simulates running tests on the generated code using the sandboxed executor.
    (This function would typically execute multiple test cases, but uses one here.)
    """
    test_script = code_string + "\n\n" + "if __name__ == '__main__':\n    print(f'Test Output: {calculate_area(3, 4)}')\n"
    
    execution_result = execute_sandboxed_code(test_script, timeout=3)
    
    feedback = f"STDOUT:\n{execution_result['stdout']}\n\nSTDERR:\n{execution_result['stderr']}"
    
    # Simple success check: Did the code execute without error and produce the expected result?
    expected_output = "Test Output: 12"
    
    test_passed = execution_result['success'] and expected_output in execution_result['stdout']

    return {
        "test_passed": test_passed,
        "feedback": feedback,
        "stderr": execution_result['stderr']
    }

# --- Refinement Loop Controller ---

def run_refinement_loop(initial_prompt: str, max_attempts: int = 5) -> dict:
    """Orchestrates the iterative refinement (debugging) loop."""
    current_prompt = initial_prompt
    attempts_made = 0
    test_passed = False
    final_code = ""
    last_stderr = ""

    while not test_passed and attempts_made < max_attempts:
        print(f"\n--- Attempt {attempts_made + 1}/{max_attempts} ---")
        
        # 1. Generation
        generated_code = generate_code(current_prompt)
        print(f"Generated Code:\n{generated_code.strip()}")
        
        # 2. Execution & Testing
        test_result = run_tests(generated_code)
        test_passed = test_result["test_passed"]
        last_stderr = test_result["stderr"]
        final_code = generated_code
        
        print(f"Test Result: {'PASS' if test_passed else 'FAIL'}")

        if not test_passed:
            # 3. Feedback Analysis and Refinement
            print("Constructing new prompt based on failure...")
            
            # Construct the comprehensive prompt for the next iteration
            current_prompt = (
                f"{initial_prompt}\n\n"
                f"--- PREVIOUS ATTEMPT FAILED ---\n"
                f"The following code failed execution:\n
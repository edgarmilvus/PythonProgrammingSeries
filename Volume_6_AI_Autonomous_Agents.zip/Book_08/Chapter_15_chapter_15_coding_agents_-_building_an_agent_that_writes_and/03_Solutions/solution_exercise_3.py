
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base
from contextlib import contextmanager

# --- Mock Database Setup ---
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(String)

# In-memory SQLite engine
ENGINE = create_engine('sqlite:///:memory:')
Base.metadata.create_all(ENGINE)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=ENGINE)

@contextmanager
def get_session():
    """Provides a transactional scope around a series of operations."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

# --- Simulation of Agent Generated Code (Flawed for Testing) ---

# Agent forgets session.commit()
FLAWED_AGENT_CODE = """
from sqlalchemy.orm import Session
from __main__ import User # Assuming User model is available in the execution context

def add_user(session: Session, username: str):
    new_user = User(name=username)
    session.add(new_user)
    # CRITICAL FLAW: session.commit() is missing here
    print(f"User {username} added to session, but not committed.")
"""

# --- Targeted Test Function ---

def run_db_tests(code_string: str) -> dict:
    """Tests the generated code for correct transactional session management."""
    
    # Execute the generated code string to define the 'add_user' function
    exec_scope = {'User': User, 'Session': SessionLocal}
    try:
        exec(code_string, exec_scope)
        add_user_func = exec_scope['add_user']
    except Exception as e:
        return {"test_passed": False, "feedback": f"Code compilation error: {e}", "stderr": f"Syntax or import error: {e}"}

    feedback_messages = []
    test_passed = True
    
    # 1. Test Case: Failed Commit Check (Testing for missing commit)
    try:
        with SessionLocal() as session:
            add_user_func(session, "Alice")
            # Check if Alice exists *in the current session*
            if session.query(User).filter_by(name="Alice").first():
                session.rollback() # Ensure cleanup
                
                # Now, check the database *outside* this session scope
                with SessionLocal() as check_session:
                    user_count = check_session.query(User).count()
                
                if user_count == 0:
                    # This is the expected failure for the flawed code
                    feedback_messages.append(
                        "Error: Data was inserted into the session but was never committed "
                        "to the database. Review your session management logic and ensure "
                        "`session.commit()` is called after successful insertion."
                    )
                    test_passed = False
    except Exception as e:
        feedback_messages.append(f"Unexpected error during Test 1: {e}")
        test_passed = False

    # 2. Test Case: Rollback Check (Testing for correct exception handling/rollback)
    class TestRollbackException(Exception): pass
    
    def add_user_and_fail(session, username):
        add_user_func(session, username)
        raise TestRollbackException("Forcing rollback")

    try:
        with SessionLocal() as session:
            add_user_and_fail(session, "Bob")
            session.commit() # Should never be reached if exception is raised
    except TestRollbackException:
        # Check database after forced failure. Bob should NOT exist.
        with SessionLocal() as check_session:
            bob = check_session.query(User).filter_by(name="Bob").first()
            
        if bob is not None:
            feedback_messages.append(
                "Error: A runtime exception occurred, but the data was NOT rolled back. "
                "Ensure your session is managed within a try/except/finally block or a context manager "
                "that calls `session.rollback()` on failure."
            )
            test_passed = False
        # else: Rollback was successful (Pass)

    final_stderr = "\n".join(feedback_messages)
    
    return {
        "test_passed": test_passed,
        "feedback": f"DB Test Result:\n{final_stderr}",
        "stderr": final_stderr # Targeted feedback for the agent
    }

# --- Execution Example ---
# print("\n--- Running DB Tests on Flawed Code (Missing Commit) ---")
# db_result = run_db_tests(FLAWED_AGENT_CODE)
# print(db_result['stderr'])

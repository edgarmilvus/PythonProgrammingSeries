
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json

STATIC_TEMPLATE = """
You are a comprehensive travel assistant. Your task is to resolve complex queries in a single pass.
The user's query is: {query}.
You must perform all necessary fact retrieval and conditional checks internally.
If any condition (e.g., population size) is not met, you must state why you stopped processing.
"""

AGENT_PLANNER_TEMPLATE = """
You are an autonomous planning engine. Your sole task is to determine the absolute next step
required to achieve the user's ultimate goal. Do not generate the final answer.
Output your response as a JSON object with the following keys:
1. "next_step": (A string describing the action, e.g., "Use Tool: get_capital", "Check condition", or "Final Answer")
2. "tool_name": (The name of the tool required, or null)

Current Goal: {goal}
Execution History: {history}
"""

def static_planner(user_query: str) -> str:
    """
    Simulates a static LLM call attempting to resolve a multi-step, conditional query in one pass.
    """
    prompt_input = STATIC_TEMPLATE.format(query=user_query)
    
    # Simulation based on the query, showing internal, single-pass reasoning:
    simulated_response = (
        f"--- Static Reasoning for: '{user_query}' ---\n"
        "1. Identify capital of France: Paris.\n"
        "2. Check population of Paris: Approx. 2.1 million.\n"
        "3. Check condition: Is 2.1 million > 5 million? No.\n"
        "Result: Processing stopped. The condition that the capital must have more than 5 million inhabitants was not satisfied."
    )
    return simulated_response

def agent_planning_step(user_query: str, history: list) -> dict:
    """
    Simulates the Agent's O-O phase, determining only the next step based on history,
    enforcing structured JSON output for control flow.
    """
    goal = user_query
    history_str = "\n".join(history)
    
    # Step 1: Initial planning (Goal: Find capital)
    if not history:
        simulated_output = {
            "next_step": "Retrieve the capital city of France.",
            "tool_name": "fact_lookup"
        }
    # Step 2: After capital is found (e.g., history=[Capital: Paris]), plan the condition check.
    elif len(history) == 1 and "Paris" in history[0]:
        simulated_output = {
            "next_step": "Retrieve the population of Paris to check the > 5 million condition.",
            "tool_name": "population_lookup"
        }
    # Step 3: Assuming population check fails, plan termination.
    else:
        simulated_output = {
            "next_step": "Condition failed. Generate final report and terminate.",
            "tool_name": None
        }
        
    return simulated_output


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import json

class OODAAgent:
    def __init__(self, goal: str):
        self.goal = goal
        self.history = []  # Agent's short-term memory (state)
        self.is_running = True
        self.llm_client = "Simulated LLM" # Placeholder for LLM interaction

    def _observe(self) -> str:
        """
        Step 1: Gathers all current context (goal, history, tool results) into a prompt string.
        """
        context_prompt = (
            f"Current Goal: {self.goal}\n"
            f"Execution History:\n{json.dumps(self.history, indent=2)}\n"
            "Based on the history, what is the single next logical step (Tool Call or Final Answer)?"
        )
        return context_prompt

    def _orient(self, context_prompt: str) -> dict:
        """
        Step 2: The LLM reasoning phase. Simulates structured output for planning.
        The LLM reasons and outputs the NEXT step in JSON format.
        """
        # Simulation: If history is empty, plan the first step (Tool). Otherwise, plan termination.
        if not self.history:
            orientation_output = {
                "reasoning": "Initial step requires external data retrieval.",
                "action_type": "TOOL",
                "tool_call": {"name": "data_retriever", "args": {"query": "initial search"}}
            }
        else:
            orientation_output = {
                "reasoning": "All necessary steps completed. Generating final answer.",
                "action_type": "TERMINATE",
                "final_answer": f"Goal '{self.goal}' achieved based on execution history."
            }
        return orientation_output

    def _decide(self, orientation_output: dict) -> tuple:
        """
        Step 3: Parses the LLM's decision and maps it to a specific action type (e.g., "TOOL", "TERMINATE").
        Returns: (action_type, payload)
        """
        action_type = orientation_output.get("action_type", "ERROR")
        payload = orientation_output.get("tool_call") if action_type == "TOOL" else orientation_output.get("final_answer")
        
        if action_type in ["TOOL", "TERMINATE"]:
            return (action_type, payload)
        else:
            # Error handling for malformed output
            return ("TERMINATE", "Error: Invalid orientation output format.")

    def _act(self, decision: tuple) -> None:
        """
        Step 4: Executes the action (e.g., simulate tool execution or set self.is_running = False).
        """
        action_type, payload = decision
        
        if action_type == "TOOL":
            # Simulate tool execution and update history
            tool_name = payload["name"]
            tool_result = f"Tool Result ({tool_name}): Success."
            self.history.append(tool_result)
            print(f"  [ACT] Executed Tool: {tool_name}. State updated.")
            
        elif action_type == "TERMINATE":
            print(f"  [ACT] Termination requested. Final Answer: {payload}")
            self.is_running = False
            
        else:
            self.is_running = False

    def run(self):
        """
        The main iterative OODA loop.
        """
        print(f"--- Agent Starting: Goal '{self.goal}' ---")
        iteration = 0
        while self.is_running and iteration < 3:
            iteration += 1
            print(f"\n--- ITERATION {iteration} ---")
            
            # 1. Observe: Gather state and context
            context = self._observe()
            
            # 2. Orient: LLM reasons and plans the next step
            orientation = self._orient(context)
            
            # 3. Decide: Parse the plan into a concrete action
            decision = self._decide(orientation)
            
            # 4. Act: Execute the action and update state
            self._act(decision)
            
        if self.is_running:
             print("--- Agent Loop Finished (Safety Break) ---")
        else:
             print("--- Agent Loop Terminated Successfully ---")

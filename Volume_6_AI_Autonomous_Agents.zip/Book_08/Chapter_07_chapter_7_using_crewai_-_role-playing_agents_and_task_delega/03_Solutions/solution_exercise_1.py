
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import tool # Import tool for completeness, though not used here
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

# Load environment variables (assuming OPENAI_API_KEY is set)
load_dotenv()

# Configuration (using a common model for demonstration)
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)

# 1. Agent Definition
researcher = Agent(
    role='AI Research Analyst',
    goal='Gather the most recent, relevant, and verifiable facts about LLM enterprise search integration.',
    backstory=(
        "You are an expert technical analyst specializing in emerging AI technologies. "
        "Your focus is on accuracy, source verification, and extracting concise data points "
        "from technical papers and industry reports. You deliver structured, factual findings."
    ),
    verbose=True,
    allow_delegation=False,
    llm=llm
)

writer = Agent(
    role='Technical Content Writer',
    goal='Transform the provided research data into an engaging, accessible, and well-structured blog post.',
    backstory=(
        "You are a seasoned content strategist with expertise in translating complex technical "
        "jargon into compelling narratives suitable for a professional audience. You ensure "
        "the content is engaging while maintaining factual integrity."
    ),
    verbose=True,
    allow_delegation=False,
    llm=llm
)

editor = Agent(
    role='Quality Assurance Editor',
    goal='Proofread, refine the tone, check grammar, and ensure the final article meets the firm\'s style guide and length (approx. 800 words).',
    backstory=(
        "You are a detail-oriented, meticulous editor focused on stylistic consistency, "
        "adherence to publication standards, and improving readability. You are the final "
        "gatekeeper before publication."
    ),
    verbose=True,
    allow_delegation=False,
    llm=llm
)

# 2. Task Definition and Workflow
topic = "LLM Enterprise Search Integration and its impact on knowledge retrieval."

task_research = Task(
    description=f"Analyze the market and technical landscape for the topic: '{topic}'. "
                "Output a structured list of key findings, statistics, and 3-5 potential "
                "pain points that LLMs solve in this space.",
    agent=researcher,
    expected_output="A structured markdown list of verified technical findings and statistics."
)

task_writing = Task(
    description="Using the findings from the Researcher, draft a full, compelling blog post. "
                "The post must include a catchy introduction, several well-titled sections, "
                "and a strong conclusion.",
    agent=writer,
    context=[task_research], # Crucial for sequential flow
    expected_output="A complete, well-structured draft blog post of approximately 800 words."
)

task_editing = Task(
    description="Review the draft blog post. Ensure the tone is professional, the grammar is "
                "flawless, and the length requirement is met. The final output must include "
                "a suggested, SEO-optimized headline.",
    agent=editor,
    context=[task_writing], # Crucial for sequential flow
    expected_output="The final, polished 800-word article, ready for publication, with an SEO headline."
)

# 3. Crew Configuration
content_crew = Crew(
    agents=[researcher, writer, editor],
    tasks=[task_research, task_writing, task_editing],
    process=Process.sequential, # Defining the sequential nature
    verbose=2
)

# 4. Execution
print("--- Starting Content Pipeline Execution ---")
final_result = content_crew.kickoff()
print("\n\n########################################")
print("## FINAL POLISHED ARTICLE ##")
print(final_result)
print("########################################")

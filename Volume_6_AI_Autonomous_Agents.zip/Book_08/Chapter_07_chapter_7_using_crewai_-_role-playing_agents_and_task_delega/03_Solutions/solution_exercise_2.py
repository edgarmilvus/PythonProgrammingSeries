
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()

# Configuration
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
manager_llm = ChatOpenAI(model="gpt-4", temperature=0.5) # Using a stronger model for the Manager

# 1. Agent Definition (Hierarchical Structure)
manager = Agent(
    role='Infrastructure Project Manager',
    goal='Oversee the architectural evaluation, delegate analysis, and synthesize findings into a cohesive, justified recommendation report.',
    backstory=(
        "You are an experienced system architect and project lead, adept at managing diverse "
        "technical teams. Your strength lies in unbiased decision-making, risk assessment, "
        "and synthesizing conflicting specialized advice into a single, actionable strategy."
    ),
    verbose=True,
    allow_delegation=True, # Manager must be able to delegate
    llm=manager_llm # Assigning the stronger LLM
)

sql_architect = Agent(
    role='SQL Database Architect',
    goal='Conduct a deep technical analysis of the SQL relational model (e.g., PostgreSQL) for transactional data.',
    backstory=(
        "Decades of experience with relational data modeling, optimizing complex joins, "
        "and ensuring ACID compliance under heavy load. You prioritize data integrity."
    ),
    verbose=True,
    allow_delegation=False,
    llm=llm
)

nosql_scientist = Agent(
    role='NoSQL Data Scientist',
    goal='Conduct a deep technical analysis of the NoSQL document store (e.g., MongoDB) for user profile and logging data.',
    backstory=(
        "Expertise in distributed systems, horizontal scaling, and handling massive, "
        "unstructured data flows in cloud environments. You prioritize flexibility and throughput."
    ),
    verbose=True,
    allow_delegation=False,
    llm=llm
)

# 2. Task Definition and Delegation
startup_needs = "The startup requires a database architecture that handles high read frequency (90% of traffic) for user profiles and logging data, but must maintain absolute integrity for critical transactional data (10% of traffic)."

task_sql_analysis = Task(
    description=f"Analyze the SQL option based on the following needs: {startup_needs}. "
                "Output a detailed technical brief covering scalability, ACID compliance, "
                "and a cost projection for the first year.",
    agent=sql_architect,
    expected_output="A structured technical brief on the SQL architecture's pros, cons, and costs."
)

task_nosql_analysis = Task(
    description=f"Analyze the NoSQL option based on the following needs: {startup_needs}. "
                "Output a detailed technical brief covering flexibility, horizontal scaling, "
                "and a scaling projection for five years.",
    agent=nosql_scientist,
    expected_output="A structured technical brief on the NoSQL architecture's pros, cons, and scaling projections."
)

task_synthesis = Task(
    description=f"Synthesize the outputs of the SQL and NoSQL analyses. Compare them against "
                f"the startup's operational needs: '{startup_needs}'. Write a final 1,500-word "
                "comprehensive recommendation report, justifying the single, final architectural choice (SQL or NoSQL).",
    agent=manager,
    context=[task_sql_analysis, task_nosql_analysis], # Manager synthesizes both specialist outputs
    expected_output="A final, justified 1,500-word architectural recommendation report."
)

# 3. Crew Configuration
architecture_crew = Crew(
    agents=[manager, sql_architect, nosql_scientist],
    tasks=[task_sql_analysis, task_nosql_analysis, task_synthesis],
    process=Process.hierarchical, # Defining the hierarchical nature
    manager_llm=manager_llm, # Assigning the Manager LLM
    verbose=2
)

# 4. Execution
print("--- Starting Hierarchical Architecture Review Execution ---")
final_recommendation = architecture_crew.kickoff()
print("\n\n########################################")
print("## FINAL ARCHITECTURAL RECOMMENDATION ##")
print(final_recommendation)
print("########################################")

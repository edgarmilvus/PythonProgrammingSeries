
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import time
import logging
from flask import Flask, jsonify
from werkzeug.wrappers import Request, Response
from werkzeug.test import Client

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('AuditMiddleware')

# 1. Middleware Implementation
class AuditMiddleware:
    def __init__(self, app):
        self.app = app
        
    def __call__(self, environ, start_response):
        start_time = time.time()
        req = Request(environ)
        
        request_method = req.method
        request_path = req.path
        
        logger.info(f"AUDIT START: Method={request_method}, Path={request_path}")
        
        # 3. Variable Rule Awareness
        try:
            # Bind the application's URL map to the request environment
            adapter = self.app.url_map.bind_to_environ(environ)
            endpoint, values = adapter.match()
            
            if values:
                # If values dictionary is populated, a dynamic rule was matched
                logger.info(f"AUDIT DETAIL: Dynamic Route Accessed: {request_path}, ID Captured: {values.get('user_id')}")
                
        except Exception:
            # Ignore 404s or other routing errors here
            pass 

        # Call the inner application (Flask)
        response_data = []
        
        def custom_start_response(status, headers, exc_info=None):
            response_data.append(status)
            return start_response(status, headers, exc_info)

        app_iterator = self.app(environ, custom_start_response)
        
        try:
            response_body = list(app_iterator)
        finally:
            if hasattr(app_iterator, 'close'):
                app_iterator.close()

        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000
        
        status_code_str = response_data[0] if response_data else "500 Internal Error"
        
        # 4. Error Handling and Latency Logging
        if status_code_str.startswith('5'):
            logger.critical(f"AUDIT ERROR: Request to {request_path} resulted in status {status_code_str}. Latency: {latency_ms:.2f}ms")
        else:
            logger.info(f"AUDIT END: Status={status_code_str}, Latency={latency_ms:.2f}ms")
            
        return response_body

# --- Simulated Flask Application ---
app = Flask(__name__)
# Wrap the app's internal WSGI application with our middleware
app.wsgi_app = AuditMiddleware(app.wsgi_app) 

@app.route('/')
def index():
    return "OK"

# 3. Dynamic Route with Variable Rule
@app.route('/api/users/<int:user_id>')
def get_user(user_id):
    if user_id == 999:
        # Simulate server error
        raise ValueError("Database connection failed.")
    time.sleep(0.1) 
    return jsonify({"id": user_id})

# --- Testing ---
if __name__ == '__main__':
    test_client = Client(app, Response)

    # 1. Test Static Route
    test_client.get('/')

    # 2. Test Dynamic Route (should log ID captured)
    test_client.get('/api/users/456')
    
    # 3. Test Error Handling (should log CRITICAL error)
    test_client.get('/api/users/999')


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import logging
from enum import Enum

logger = logging.getLogger('ContractManagement')
logger.setLevel(logging.INFO)

class AgentState(str, Enum):
    SPEC_RECEIVED = "SPEC_RECEIVED"
    DEVELOPMENT_IN_PROGRESS = "DEVELOPMENT_IN_PROGRESS"

# 1. Contract Agent Submodule
class ContractAgent:
    def __init__(self, total_budget: int):
        self.TotalBudget = total_budget
        self.BudgetUsed = 0
        logger.info(f"Contract Agent initialized. Total Budget: {self.TotalBudget} units.")

    # 4. Budget Allocation and Tracking
    def allocate_budget(self, cost: int):
        if self.BudgetUsed + cost > self.TotalBudget:
            return False, f"Allocation failed: Requested {cost} units, only {self.TotalBudget - self.BudgetUsed} remaining."
        
        self.BudgetUsed += cost
        logger.info(f"Budget Allocated: {cost} units. Remaining: {self.TotalBudget - self.BudgetUsed}")
        return True, "Allocation successful."

class ProductOwnerAgent:
    def __init__(self, total_budget: int, shared_state: AgentState):
        self.contract_agent = ContractAgent(total_budget)
        self.current_state = shared_state

    def _simulate_llm_cost_estimation(self, prompt: str, is_change_request=False) -> int:
        """Simulates LLM estimating complexity cost."""
        # Simple simulation: 50 base cost + 5 units per character
        base_cost = 50 + len(prompt) * 5
        if is_change_request:
            # Change requests incur higher overhead
            return base_cost + 150
        return base_cost

    # 2. Initial Cost Estimation and Negotiation
    def negotiate_initial_scope(self, user_prompt: str):
        estimated_cost = self._simulate_llm_cost_estimation(user_prompt)
        
        threshold = self.contract_agent.TotalBudget * 0.9
        
        if estimated_cost > threshold:
            # Negotiation Required (Scope reduction)
            negotiation_message = {
                "status": "Negotiation Required",
                "reason": f"Initial cost ({estimated_cost} units) exceeds 90% budget threshold ({threshold} units).",
                "action": "Scope must be reduced before sprint start."
            }
            logger.warning(f"PO Negotiation Triggered. Cost Justification: LLM estimated high complexity.")
            return False, negotiation_message
        
        # Allocation and Handoff
        success, message = self.contract_agent.allocate_budget(estimated_cost)
        if success:
            logger.info("PO accepted initial scope and proceeded to structured handoff.")
            return True, "Specifications approved and budget locked."
        else:
            return False, {"status": "Budget Error", "reason": message}

    # 3. Mid-Sprint Change Management
    def handle_change_request(self, change_prompt: str):
        if self.current_state != AgentState.DEVELOPMENT_IN_PROGRESS:
            logger.info("Change request received outside active development.")
            return True, "Change queued for next sprint."

        change_cost = self._simulate_llm_cost_estimation(change_prompt, is_change_request=True)
        remaining_budget = self.contract_agent.TotalBudget - self.contract_agent.BudgetUsed
        
        if change_cost > remaining_budget:
            # Scope Creep Mitigation (Rejection)
            rejection_message = {
                "status": "Change Request Rejected (Scope Creep)",
                "reason": f"The change cost ({change_cost} units) exceeds the remaining budget ({remaining_budget} units).",
                "alternatives": [
                    "a) Remove an existing feature of equivalent cost.",
                    "b) Request a budget increase."
                ]
            }
            # 5. Justification Logging
            logger.critical(f"PO REJECTION: Change denied due to budget overrun. Remaining: {remaining_budget}")
            return False, rejection_message
        else:
            # Acceptance and budget adjustment
            success, message = self.contract_agent.allocate_budget(change_cost)
            logger.info("PO Acceptance: Change request approved and budget adjusted.")
            return True, "Change approved. Developer Agent notified."

# --- Execution Simulation ---
current_sprint_state = AgentState.DEVELOPMENT_IN_PROGRESS 
po_agent = ProductOwnerAgent(total_budget=1000, shared_state=current_sprint_state)

# Simulate initial negotiation resulting in acceptance (450 cost)
po_agent._simulate_llm_cost_estimation = lambda p, is_change_request=False: 450 
po_agent.negotiate_initial_scope("Build a simple user authentication module.") 
# Budget Used: 450. Remaining: 550.

# Simulate a change request that causes scope creep (cost 600)
po_agent._simulate_llm_cost_estimation = lambda p, is_change_request=True: 600
po_agent.handle_change_request("Add full GDPR compliance and data portability features.")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from pydantic import BaseModel
from enum import Enum
import time
import logging

logger = logging.getLogger('SwarmState')
logger.setLevel(logging.INFO)

# 1. Define Agent States
class AgentState(str, Enum):
    SPEC_RECEIVED = "SPEC_RECEIVED"
    DEVELOPMENT_IN_PROGRESS = "DEVELOPMENT_IN_PROGRESS"
    AWAITING_QA_REVIEW = "AWAITING_QA_REVIEW"
    QA_FAILED_REWORK_REQUIRED = "QA_FAILED_REWORK_REQUIRED"
    QA_PASSED_DELIVERY_READY = "QA_PASSED_DELIVERY_READY"

# 2. Structured Failure Reporting Model
class QAFailureReport(BaseModel):
    test_case_name: str
    file_path: str
    failure_description: str
    suggested_fix: str

class SharedState:
    def __init__(self):
        self.current_state = AgentState.SPEC_RECEIVED
        self.feedback_report = None
        self.rework_count = 0
        self.codebase = "Initial stub code."

    def transition(self, new_state: AgentState):
        logger.info(f"STATE TRANSITION: {self.current_state.value} -> {new_state.value}")
        self.current_state = new_state

class DeveloperAgent:
    def __init__(self, state: SharedState):
        self.state = state

    def develop(self):
        self.state.transition(AgentState.DEVELOPMENT_IN_PROGRESS)
        time.sleep(0.1) 
        if self.state.rework_count > 0:
            logger.info(f"Developer Reworking codebase for fix #{self.state.rework_count}.")
            self.state.codebase += f"\n-- Fix {self.state.rework_count} applied."
        else:
            logger.info("Developer completed initial implementation.")
        self.state.transition(AgentState.AWAITING_QA_REVIEW)

    # 3. Developer Agent Rework Logic
    def handle_feedback(self):
        if self.state.feedback_report:
            # Validate and parse the structured report
            report = QAFailureReport.model_validate(self.state.feedback_report)
            self.state.rework_count += 1
            logger.warning(f"Developer received QA feedback: {report.failure_description}")
            # Transition back to active development
            self.state.transition(AgentState.DEVELOPMENT_IN_PROGRESS)
            self.state.feedback_report = None 

class QAAgent:
    def __init__(self, state: SharedState):
        self.state = state
        self.max_reworks = 2 

    def run_tests(self):
        logger.info("QA Agent running tests...")
        
        if self.state.rework_count < self.max_reworks:
            # Simulate failure and generate structured report
            report_data = QAFailureReport(
                test_case_name=f"TestAuth_{self.state.rework_count + 1}",
                file_path="/src/auth.py",
                failure_description=f"Auth token validation fails (Attempt {self.state.rework_count + 1}).",
                suggested_fix="Ensure token expiry check is correct."
            )
            self.state.feedback_report = report_data.model_dump()
            self.state.transition(AgentState.QA_FAILED_REWORK_REQUIRED)
            
        else:
            # Simulate success after reworks
            self.state.transition(AgentState.QA_PASSED_DELIVERY_READY)
            logger.info("QA Passed successfully.")

# 4. Swarm Orchestrator Conditional Execution
class SwarmOrchestrator:
    def __init__(self):
        self.state = SharedState()
        self.dev = DeveloperAgent(self.state)
        self.qa = QAAgent(self.state)

    def run_sprint(self):
        self.dev.develop() # Initial development

        # Loop executes until the final state is reached
        while self.state.current_state != AgentState.QA_PASSED_DELIVERY_READY:
            current = self.state.current_state
            
            if current == AgentState.AWAITING_QA_REVIEW:
                self.qa.run_tests()
                
            elif current == AgentState.QA_FAILED_REWORK_REQUIRED:
                self.dev.handle_feedback()
                
            elif current == AgentState.DEVELOPMENT_IN_PROGRESS:
                self.dev.develop()
                
            else:
                break # Should not happen

        logger.info(f"--- SPRINT FINAL STATUS: {self.state.current_state.value} ---")

# Execution
orchestrator = SwarmOrchestrator()
orchestrator.run_sprint()

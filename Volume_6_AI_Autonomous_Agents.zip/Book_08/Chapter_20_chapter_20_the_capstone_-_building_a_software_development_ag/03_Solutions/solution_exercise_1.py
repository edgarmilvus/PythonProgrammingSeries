
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from pydantic import BaseModel, Field, ValidationError
from enum import Enum
import json
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('HandoffSystem')

# 1. Define Structured Data Models
class Priority(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

class RequirementModel(BaseModel):
    priority: Priority
    estimated_effort_hours: int = Field(..., gt=0)
    description: str

class ApiEndpointModel(BaseModel):
    route: str
    method: str
    response_schema: dict # Use dict to represent nested JSON structure

class DatabaseSchemaModel(BaseModel):
    entity_name: str
    fields: dict  # {field_name: data_type}

class SpecificationPayload(BaseModel):
    requirements: list[RequirementModel]
    api_endpoints: list[ApiEndpointModel]
    database_schema: list[DatabaseSchemaModel]

class ProductOwnerAgent:
    # 2. PO Agent Output Transformation
    def negotiate_and_specify(self, user_prompt: str) -> str:
        # Simulate LLM reasoning to generate structured data from the prompt
        spec_data = {
            "requirements": [
                {"priority": "High", "estimated_effort_hours": 8, "description": "Implement user auth."},
            ],
            "api_endpoints": [
                {"route": "/api/v1/tasks", "method": "POST", "response_schema": {"id": "int", "status": "str"}}
            ],
            "database_schema": [
                {"entity_name": "Task", "fields": {"id": "int", "title": "str"}}
            ]
        }
        
        try:
            validated_payload = SpecificationPayload(**spec_data)
            logger.info("PO Agent successfully structured and validated specifications.")
            return validated_payload.model_dump_json(indent=2)
        except ValidationError as e:
            logger.error(f"PO Agent internal structure error: {e}")
            return json.dumps({"error": "Internal PO structure error"})

class DeveloperAgent:
    # 3. Developer Agent Input Validation
    def receive_specifications(self, json_payload: str):
        logger.info("Developer Agent receiving specifications...")
        try:
            data = json.loads(json_payload)
            
            # Strict validation against the Pydantic contract
            validated_spec = SpecificationPayload(**data)
            
            # 4. Logging and Traceability (Success)
            logger.info("Developer Agent: SUCCESS. Specifications validated successfully.")
            return True, validated_spec
        
        except ValidationError as e:
            # Formal negative feedback loop (Failure)
            error_report = {
                "status": "VALIDATION_FAILED",
                "agent_source": "DeveloperAgent",
                "error_type": "Pydantic_ValidationError",
                "details": str(e),
                "request_action": "PO Agent must reprocess and clarify the data contract."
            }
            # 4. Logging and Traceability (Failure)
            logger.error(f"Developer Agent Validation Failure: {error_report['error_type']} - Requesting reprocessing.")
            return False, error_report

# --- Execution Simulation ---
po = ProductOwnerAgent()
dev = DeveloperAgent()

# Successful Handoff
specs_json = po.negotiate_and_specify("I need a simple task management API.")
success, result = dev.receive_specifications(specs_json)

# Simulated Failure (Missing 'estimated_effort_hours')
bad_specs = {"requirements": [{"priority": "High", "description": "Missing effort."}], "api_endpoints": [], "database_schema": []}
bad_specs_json = json.dumps(bad_specs)
logger.info("\n--- Simulating Failed Handoff (Missing Data) ---")
success_fail, result_fail = dev.receive_specifications(bad_specs_json)

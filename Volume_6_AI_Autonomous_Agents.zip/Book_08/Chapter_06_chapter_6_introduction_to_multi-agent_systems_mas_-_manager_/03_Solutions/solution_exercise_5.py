
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
from typing import Dict, Any, List

# --- Conceptual Module: config.py ---

class BaseConfig:
    API_KEY = "DEFAULT_KEY_123"
    LOG_LEVEL = "INFO"
    TASK_TIMEOUT_SECONDS = 15

class DevelopmentConfig(BaseConfig):
    WORKER_COUNT = 2
    LOG_LEVEL = "DEBUG"
    TASK_TIMEOUT_SECONDS = 30
    
class ProductionConfig(BaseConfig):
    WORKER_COUNT = 10
    LOG_LEVEL = "ERROR"
    TASK_TIMEOUT_SECONDS = 15

# --- Conceptual Module: agents.py ---

class WorkerAgentConfigurable:
    def __init__(self, worker_id: int, task_queue: asyncio.Queue, config: BaseConfig):
        self.worker_id = worker_id
        self.task_queue = task_queue
        self.config = config

    async def execute_task(self, task: Dict[str, Any]):
        # Worker uses config (e.g., logging level)
        if self.config.LOG_LEVEL == "DEBUG":
            print(f"Worker {self.worker_id} [DEBUG]: Processing task {task['task_id']}.")
        await asyncio.sleep(0.1) # Simulate work
        return f"Result of {task['task_id']}"

    async def run(self):
        while True:
            task = await self.task_queue.get()
            if task is None:
                self.task_queue.task_done()
                break
            await self.execute_task(task)
            self.task_queue.task_done()

class ManagerAgentConfigurable:
    def __init__(self, config: BaseConfig, task_queue: asyncio.Queue):
        self.config = config
        self.worker_pool_size = config.WORKER_COUNT
        self.task_timeout = config.TASK_TIMEOUT_SECONDS
        self.task_queue = task_queue
        self.workers: List[WorkerAgentConfigurable] = []

    def print_status(self):
        print(f"  Manager Config: Workers={self.worker_pool_size}, Timeout={self.task_timeout}s, Log={self.config.LOG_LEVEL}")
        
    async def start_pipeline(self, num_tasks=5):
        print(f"Manager starting pipeline for {num_tasks} tasks...")
        
        # 1. Setup workers based on config
        for i in range(self.worker_pool_size):
            worker = WorkerAgentConfigurable(i + 1, self.task_queue, self.config)
            self.workers.append(worker)
            asyncio.create_task(worker.run())
            
        # 2. Distribute tasks
        for i in range(1, num_tasks + 1):
            await self.task_queue.put({'task_id': i, 'payload': f"Task data {i}"})
            
        # 3. Wait for completion
        await self.task_queue.join()
        
        # 4. Shutdown
        for _ in range(self.worker_pool_size):
            await self.task_queue.put(None)
        
        print("Manager: Pipeline finished and workers signaled to stop.")

# --- Conceptual Module: app_factory.py ---

def create_mas_app(config: BaseConfig) -> ManagerAgentConfigurable:
    """
    Application Factory function: creates and configures the MAS instance.
    """
    print(f"\n--- Initializing MAS with {type(config).__name__} ---")
    
    # 1. Setup shared resources (queues)
    task_queue = asyncio.Queue()
    
    # 2. Instantiate Manager, injecting configuration
    manager = ManagerAgentConfigurable(config=config, task_queue=task_queue)
    
    # Note: Worker initialization is typically deferred until the pipeline starts 
    # (as done in manager.start_pipeline), but the factory ensures the manager 
    # has the correct parameters to create the right number of workers later.
    
    return manager

# --- Conceptual Module: run.py (Main Execution) ---

async def main():
    # 1. Setup Development System
    dev_manager = create_mas_app(DevelopmentConfig)
    print("Development System Initialized:")
    dev_manager.print_status()
    # await dev_manager.start_pipeline(num_tasks=5) # Optional: Run the pipeline

    print("-" * 40)

    # 2. Setup Production System
    prod_manager = create_mas_app(ProductionConfig)
    print("Production System Initialized:")
    prod_manager.print_status()
    # await prod_manager.start_pipeline(num_tasks=5) # Optional: Run the pipeline

if __name__ == "__main__":
    asyncio.run(main())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import random
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

# --- Custom Exception and Data Structure ---

class LLMAPIError(Exception):
    """Custom error for simulating LLM API failures."""
    pass

@dataclass
class WorkerReport:
    task_id: int
    status: str  # SUCCESS, FAILURE, TIMEOUT
    output: Optional[str] = None
    error_message: Optional[str] = None
    worker_id: Optional[int] = None

# --- Worker Agent with Failure Simulation ---

class WorkerAgentRobust:
    def __init__(self, worker_id: int, task_queue: asyncio.Queue, result_queue: asyncio.Queue):
        self.worker_id = worker_id
        self.task_queue = task_queue
        self.result_queue = result_queue

    async def execute_task(self, task: Dict[str, Any]):
        task_id = task['task_id']
        
        # 1. Simulate random failure (10% chance)
        if random.random() < 0.10:
            await asyncio.sleep(0.1)
            raise LLMAPIError(f"API key expired during processing.")

        # 2. Simulate random timeout (5% chance of being very slow)
        duration = 1.0
        if random.random() < 0.05:
            duration = 15.0 # Guaranteed to exceed the 10-second timeout
            print(f"Worker {self.worker_id}: Task {task_id} is intentionally slow ({duration}s).")
        
        await asyncio.sleep(duration)
        
        return f"Completed analysis of {task['payload']}"

    async def run(self):
        while True:
            task = await self.task_queue.get()
            if task is None:
                self.task_queue.task_done()
                break
            
            task_id = task['task_id']
            report = None
            
            try:
                output = await self.execute_task(task)
                report = WorkerReport(
                    task_id=task_id,
                    status="SUCCESS",
                    output=output,
                    worker_id=self.worker_id
                )
            except LLMAPIError as e:
                report = WorkerReport(
                    task_id=task_id,
                    status="FAILURE",
                    error_message=str(e),
                    worker_id=self.worker_id
                )
            except Exception as e:
                report = WorkerReport(
                    task_id=task_id,
                    status="FAILURE",
                    error_message=f"Unexpected error: {type(e).__name__}",
                    worker_id=self.worker_id
                )
            finally:
                if report:
                    await self.result_queue.put(report)
                self.task_queue.task_done()

# --- Manager Agent with Robust Aggregation ---

class ManagerAgentRobust:
    def __init__(self, num_workers: int = 4, num_tasks: int = 20, timeout: int = 10):
        self.num_workers = num_workers
        self.num_tasks = num_tasks
        self.timeout = timeout
        self.task_queue = asyncio.Queue()
        self.result_queue = asyncio.Queue()
        self.assigned_task_ids = set(range(1, num_tasks + 1))
        self.workers: List[WorkerAgentRobust] = []

    def decompose_task(self) -> List[Dict[str, Any]]:
        return [{'task_id': i, 'payload': f"Data Set {i}"} for i in range(1, self.num_tasks + 1)]

    def create_timeout_report(self, task_id: int) -> WorkerReport:
        return WorkerReport(
            task_id=task_id,
            status="TIMEOUT",
            error_message=f"Worker failed to report result within {self.timeout} seconds."
        )

    async def aggregate_results(self, assigned_tasks: List[Dict[str, Any]]):
        results: Dict[int, WorkerReport] = {}
        
        # We must track which tasks we are waiting for
        tasks_waiting_for = {t['task_id'] for t in assigned_tasks}
        
        while tasks_waiting_for:
            task_id_to_check = next(iter(tasks_waiting_for))
            
            try:
                # Wait for the next result with a strict timeout
                report: WorkerReport = await asyncio.wait_for(
                    self.result_queue.get(), 
                    timeout=self.timeout
                )
                
                # Check if this result is for a task we are still tracking
                if report.task_id in tasks_waiting_for:
                    results[report.task_id] = report
                    tasks_waiting_for.remove(report.task_id)
                    print(f"Manager: Received result for Task {report.task_id}. Status: {report.status}")
                
            except asyncio.TimeoutError:
                # If a timeout occurs, we assume one of the remaining tasks timed out.
                # Since we don't know *which* task timed out, we must mark one of the 
                # remaining tasks as TIMEOUT. (In a real system, we'd use a dedicated 
                # result tracking mechanism tied to the task ID, but for queue-based 
                # aggregation, we mark the task we were expecting next.)
                
                timeout_report = self.create_timeout_report(task_id_to_check)
                results[task_id_to_check] = timeout_report
                tasks_waiting_for.remove(task_id_to_check)
                print(f"Manager: TIMEOUT occurred. Marking Task {task_id_to_check} as TIMEOUT.")
                
            except Exception as e:
                print(f"Manager: Unexpected aggregation error: {e}")
                
        return results

    def generate_final_report(self, all_results: Dict[int, WorkerReport]):
        successes = [r for r in all_results.values() if r.status == "SUCCESS"]
        failures = [r for r in all_results.values() if r.status == "FAILURE"]
        timeouts = [r for r in all_results.values() if r.status == "TIMEOUT"]

        print("\n--- FINAL AGGREGATED REPORT ---")
        print(f"Total Tasks: {self.num_tasks}")
        print(f"Successes: {len(successes)}")
        print(f"Failures (API/Worker Errors): {len(failures)}")
        print(f"Timeouts (Manager Enforced): {len(timeouts)}")
        print("-" * 30)

        if successes:
            print("\n[SUCCESSFUL OUTPUTS SYNTHESIS]")
            # Synthesize successful outputs
            synth = " ".join([r.output.split(' of ')[1] for r in successes if r.output])
            print(f"Synthesis Preview: {synth[:100]}...")

        if failures or timeouts:
            print("\n[FAILED & TIMED OUT TASKS]")
            for f in failures:
                print(f"  [FAILURE] Task {f.task_id}: Worker {f.worker_id} failed. Reason: {f.error_message}")
            for t in timeouts:
                print(f"  [TIMEOUT] Task {t.task_id}: Reason: {t.error_message}")

    async def run_pipeline(self):
        tasks = self.decompose_task()
        
        # Setup workers and start them
        self.workers = [
            WorkerAgentRobust(i + 1, self.task_queue, self.result_queue)
            for i in range(self.num_workers)
        ]
        worker_tasks = [asyncio.create_task(worker.run()) for worker in self.workers]
        
        # Distribute tasks
        for task in tasks:
            await self.task_queue.put(task)
            
        # Wait for all tasks to be pulled and processed (or marked done by Manager)
        # Note: We use the aggregation loop to handle timeouts, so we don't use task_queue.join() 
        # as the tasks might not be marked done if they time out. We rely on the result count.
        
        all_results = await self.aggregate_results(tasks)
        
        # Generate Report
        self.generate_final_report(all_results)
        
        # Shutdown workers (send stop signal)
        for _ in range(self.num_workers):
            await self.task_queue.put(None)
        await asyncio.gather(*worker_tasks)

if __name__ == "__main__":
    manager = ManagerAgentRobust(num_workers=4, num_tasks=10)
    asyncio.run(manager.run_pipeline())

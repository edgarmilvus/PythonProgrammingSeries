
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
import os
from typing import Dict, Any

# --- State Management Components ---

class LLMMemory:
    """Simulates context storage for multi-stage LLM tasks."""
    def __init__(self):
        self._memory = {}

    def store(self, key: str, value: Any):
        self._memory[key] = value
        print(f"  [Memory] Stored context for {key}.")

    def retrieve(self, key: str) -> Any:
        return self._memory.get(key, "No previous context found.")

    def clear(self, key: str):
        if key in self._memory:
            del self._memory[key]
            print(f"  [Memory] Cleared context for {key}.")

class FileContextManager:
    """Custom Context Manager for guaranteed file opening/closing."""
    def __init__(self, filename: str):
        self.filename = filename
        self.file = None

    def __enter__(self):
        try:
            print(f"  [CM] Entering context: Opening file {self.filename}.")
            self.file = open(self.filename, 'w')
            return self.file
        except IOError as e:
            print(f"  [CM] Error opening file: {e}")
            raise

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.file:
            self.file.close()
            print(f"  [CM] Exiting context: File {self.filename} guaranteed closed.")
        
        if exc_type:
            # Handle the exception (or suppress it by returning True)
            print(f"  [CM] Detected exception during execution: {exc_type.__name__}: {exc_val}")
            # We allow the exception to propagate (return False/None)
            return False 
        
# --- Modified Worker Agent ---

class WorkerAgentStateful:
    def __init__(self, worker_id: int):
        self.worker_id = worker_id
        self.memory = LLMMemory()

    async def execute_task(self, task: Dict[str, Any]):
        task_id = task['task_id']
        
        print(f"\nWorker {self.worker_id}: Starting Task {task_id}")
        
        # --- Step A: Generate Initial Draft ---
        await asyncio.sleep(0.1) # Simulate work
        draft_result = f"Initial Draft for Task {task_id}: {task['payload']}"
        self.memory.store(task_id, draft_result)

        # --- Context Manager Usage (Auditing Step A) ---
        filename = f"temp_task_{task_id}.txt"
        
        try:
            with FileContextManager(filename) as f:
                f.write(f"Audit Log for Task {task_id}\n")
                f.write(f"Intermediate Result (Step A):\n{draft_result}\n")
                print(f"  [Audit] Intermediate result written to {filename}.")

                # --- Step B: Refine Draft using Memory ---
                context = self.memory.retrieve(task_id)
                await asyncio.sleep(0.1) # Simulate work
                
                if task_id == 3:
                    # Simulate a critical failure in Step B for Task 3
                    raise ValueError("Critical refinement error in Step B!")
                
                final_result = f"Final Refined Output (using context: '{context[:20]}...'): Step B Complete."
                f.write(f"Final Result (Step B):\n{final_result}")
                
        except ValueError as e:
            final_result = f"Task Failed during Step B: {e}"
            print(f"Worker {self.worker_id}: Task {task_id} FAILED.")
        
        # Cleanup file after test (optional, for clean environment)
        if os.path.exists(filename):
            os.remove(filename)
            
        self.memory.clear(task_id)
        return final_result

# --- Execution Simulation ---

async def run_stateful_test():
    worker = WorkerAgentStateful(worker_id=1)
    
    tasks = [
        {'task_id': 1, 'payload': 'Outline a blog post about MAS.'},
        {'task_id': 2, 'payload': 'Summarize the Q3 financial report.'},
        {'task_id': 3, 'payload': 'Generate Python code for a sorting algorithm.'} # This task will fail
    ]
    
    results = [await worker.execute_task(t) for t in tasks]
    
    print("\n--- Final Results Summary ---")
    for i, res in enumerate(results):
        print(f"Task {i+1} Result: {res}")

if __name__ == "__main__":
    asyncio.run(run_stateful_test())

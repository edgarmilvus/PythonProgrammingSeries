
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import random
from typing import Dict, Any, List

# --- Specialized Worker Definitions ---

class BaseWorker:
    def __init__(self, worker_id: int, queue: asyncio.Queue, specialization: str):
        self.worker_id = worker_id
        self.queue = queue
        self.specialization = specialization

    async def run(self):
        while True:
            task = await self.queue.get()
            if task is None:
                self.queue.task_done()
                break
            
            result = await self.execute_specialized_task(task)
            print(f"[{self.specialization} W{self.worker_id}] Task {task['task_id']} finished. Result: {result}")
            self.queue.task_done()

    async def execute_specialized_task(self, task: Dict[str, Any]) -> str:
        # Must be implemented by subclasses
        raise NotImplementedError

class DataAnalysisWorker(BaseWorker):
    def __init__(self, worker_id: int, queue: asyncio.Queue):
        super().__init__(worker_id, queue, "DATA_ANALYST")

    async def analyze_data(self, payload: str) -> str:
        await asyncio.sleep(random.uniform(0.1, 0.5))
        return f"Analyzed '{payload}' and generated a statistical summary."

    async def execute_specialized_task(self, task: Dict[str, Any]) -> str:
        return await self.analyze_data(task['payload'])

class CodeGenerationWorker(BaseWorker):
    def __init__(self, worker_id: int, queue: asyncio.Queue):
        super().__init__(worker_id, queue, "CODE_GENERATOR")

    async def generate_code_snippet(self, payload: str) -> str:
        await asyncio.sleep(random.uniform(0.1, 0.5))
        return f"Generated a Python function based on '{payload}'."

    async def execute_specialized_task(self, task: Dict[str, Any]) -> str:
        return await self.generate_code_snippet(task['payload'])

# --- Manager Agent with Routing ---

class ManagerAgentRouter:
    def __init__(self):
        self.data_queue = asyncio.Queue()
        self.code_queue = asyncio.Queue()
        self.queues = {'data': self.data_queue, 'code': self.code_queue}
        self.workers: List[BaseWorker] = []

    def route_task(self, task_payload: str) -> str:
        """Intelligent routing based on keywords."""
        payload_lower = task_payload.lower()
        
        data_keywords = ['statistics', 'mean', 'chart', 'analyze', 'report', 'data']
        code_keywords = ['python', 'sql', 'javascript', 'generate code', 'function', 'class']

        if any(kw in payload_lower for kw in data_keywords):
            return 'data'
        if any(kw in payload_lower for kw in code_keywords):
            return 'code'
        
        # Default route if no specialization is matched
        return 'data' 

    async def distribute_tasks(self, tasks: List[Dict[str, Any]]):
        print("Manager: Starting task routing and distribution.")
        for task in tasks:
            target_route = self.route_task(task['payload'])
            target_queue = self.queues.get(target_route)
            
            if target_queue:
                await target_queue.put(task)
                print(f"Manager: Task {task['task_id']} routed to {target_route.upper()} queue.")
            else:
                print(f"Manager: ERROR: No queue found for route '{target_route}'.")

    async def run_pipeline(self, tasks: List[Dict[str, Any]]):
        # 1. Setup Workers
        data_workers = [DataAnalysisWorker(i + 1, self.data_queue) for i in range(2)]
        code_workers = [CodeGenerationWorker(i + 3, self.code_queue) for i in range(2)]
        self.workers = data_workers + code_workers
        
        worker_tasks = [asyncio.create_task(w.run()) for w in self.workers]

        # 2. Distribution
        await self.distribute_tasks(tasks)

        # 3. Wait for all tasks in both queues to complete
        await asyncio.gather(self.data_queue.join(), self.code_queue.join())
        print("\nManager: All tasks processed.")

        # 4. Shutdown workers
        for queue in self.queues.values():
            for _ in range(len(self.workers) // 2): # Send stop signal per worker type
                await queue.put(None)
        
        await asyncio.gather(*worker_tasks)
        print("Manager: System shut down gracefully.")

# --- Execution ---

if __name__ == "__main__":
    tasks_to_process = [
        {'task_id': 1, 'payload': 'Calculate the mean and standard deviation for sales data.'}, # Data
        {'task_id': 2, 'payload': 'Write a Python script to connect to a database.'},          # Code
        {'task_id': 3, 'payload': 'Generate a chart showing user engagement.'},               # Data
        {'task_id': 4, 'payload': 'Draft a SQL query to select all active users.'},           # Code
        {'task_id': 5, 'payload': 'Analyze Q4 profit margins and write a report.'},            # Data
        {'task_id': 6, 'payload': 'Develop a Javascript function for form validation.'},       # Code
        {'task_id': 7, 'payload': 'Find statistics on global warming trends.'},               # Data
        {'task_id': 8, 'payload': 'Generate Python code for a REST API endpoint.'},           # Code
        {'task_id': 9, 'payload': 'Create a data visualization summary.'},                    # Data
        {'task_id': 10, 'payload': 'Write a function to handle asynchronous logging.'}         # Code
    ]
    
    manager = ManagerAgentRouter()
    asyncio.run(manager.run_pipeline(tasks_to_process))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import random
import time
from typing import Dict, Any, List

# --- Agent Definitions ---

class WorkerAgent:
    def __init__(self, worker_id: int, task_queue: asyncio.Queue, result_queue: asyncio.Queue):
        self.worker_id = worker_id
        self.task_queue = task_queue
        self.result_queue = result_queue

    async def execute_task(self, task: Dict[str, Any]):
        task_id = task['task_id']
        payload = task['payload']
        
        # Simulate LLM latency (random duration between 0.5s and 2.0s)
        duration = random.uniform(0.5, 2.0)
        start_time = time.time()
        
        print(f"Worker {self.worker_id}: Starting Task {task_id} (Simulated work time: {duration:.2f}s)")
        await asyncio.sleep(duration)
        
        end_time = time.time()
        
        result = {
            'task_id': task_id,
            'worker_id': self.worker_id,
            'status': 'SUCCESS',
            'time_taken': round(end_time - start_time, 2),
            'output': f"Processed '{payload}'"
        }
        await self.result_queue.put(result)
        print(f"Worker {self.worker_id}: Finished Task {task_id}")

    async def run(self):
        while True:
            task = await self.task_queue.get()
            
            # Check for stop signal (None)
            if task is None:
                self.task_queue.task_done()
                print(f"Worker {self.worker_id} stopping.")
                break
                
            await self.execute_task(task)
            self.task_queue.task_done()

class ManagerAgent:
    def __init__(self, num_workers: int = 4, num_tasks: int = 10):
        self.num_workers = num_workers
        self.num_tasks = num_tasks
        self.task_queue = asyncio.Queue()
        self.result_queue = asyncio.Queue()
        self.workers: List[WorkerAgent] = []
        self.all_results: List[Dict[str, Any]] = []

    def decompose_task(self, master_task: str) -> List[Dict[str, Any]]:
        tasks = []
        for i in range(1, self.num_tasks + 1):
            tasks.append({
                'task_id': i,
                'payload': f"{master_task} - Subtask {i}"
            })
        return tasks

    async def distribute_tasks(self, tasks: List[Dict[str, Any]]):
        for task in tasks:
            await self.task_queue.put(task)
        print(f"Manager: Distributed {len(tasks)} tasks.")

    async def aggregate_results(self):
        # Wait until all tasks are processed (using the queue's internal counter)
        await self.task_queue.join()
        print("Manager: All tasks completed by workers. Aggregating results...")
        
        # Collect results from the result queue
        while not self.result_queue.empty():
            result = await self.result_queue.get()
            self.all_results.append(result)

    async def shutdown_workers(self):
        # Send one stop signal (None) for each worker
        for _ in range(self.num_workers):
            await self.task_queue.put(None)

    async def run_pipeline(self, master_task: str):
        # 1. Initialization and Worker Setup
        self.workers = [
            WorkerAgent(i + 1, self.task_queue, self.result_queue)
            for i in range(self.num_workers)
        ]
        worker_tasks = [asyncio.create_task(worker.run()) for worker in self.workers]

        # 2. Decomposition and Distribution
        sub_tasks = self.decompose_task(master_task)
        await self.distribute_tasks(sub_tasks)

        # 3. Synchronization and Aggregation
        await self.aggregate_results()
        
        # 4. Shutdown
        await self.shutdown_workers()
        await asyncio.gather(*worker_tasks) # Wait for workers to finish shutdown

        # 5. Reporting
        print("\n--- Final Manager Report ---")
        total_time = sum(r['time_taken'] for r in self.all_results)
        print(f"Total Tasks Processed: {len(self.all_results)}")
        print(f"Total Simulated Time: {total_time:.2f}s")
        print(f"Average Time per Task: {total_time / len(self.all_results):.2f}s")
        print(f"Workers Used: {self.num_workers}")
        
        # Example of parallel processing benefit:
        # If tasks took 1.0s each, serial time would be 10s. 
        # Parallel time should be close to the time of the longest task (~2.0s).
        
if __name__ == "__main__":
    manager = ManagerAgent(num_workers=4, num_tasks=10)
    asyncio.run(manager.run_pipeline("Analyze Market Trends"))


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from typing import Optional
from pydantic import BaseModel
import sys

# Re-using necessary structures from previous exercises
class ReflectionCritique(BaseModel):
    critique_text: str
    confidence_score: float
    proposed_strategy: str

class LogicalFailure(Exception):
    def __init__(self, critique: ReflectionCritique, message="Logical failure detected via reflection."):
        self.critique = critique
        super().__init__(message)

# Mock components for simulation
class MockReflectionEngine:
    def analyze(self, trace):
        # Always simulate a failure until the 'correction plan' is in place
        if "REVISED_PLAN" in trace.action_log[-1]:
            # Simulate success on the corrected plan
            return ReflectionCritique(
                critique_text="Output meets all requirements.",
                confidence_score=1.0,
                proposed_strategy="Task complete."
            )
        else:
            # Simulate initial failure
            return ReflectionCritique(
                critique_text="The documentation lacks depth on the API usage examples.",
                confidence_score=0.5,
                proposed_strategy="Focus the next execution on calling the 'api_example_generator' tool to enrich the content."
            )

class DocumentationAgent:
    MAX_RETRIES = 3

    def __init__(self, reflection_engine: MockReflectionEngine):
        self.reflection_engine = reflection_engine
        self.retry_count = 0
        self.execution_history = []
        print("Documentation Agent Initialized.")

    def _execute_step(self, goal: str, current_plan: str) -> str:
        """Simulates the actual work execution phase."""
        attempt_id = f"Attempt {self.retry_count}"
        self.execution_history.append(f"[{attempt_id}] Starting execution with plan: {current_plan}")
        
        # Simulate tool calls based on the plan
        if "api_example_generator" in current_plan:
             self.execution_history.append(f"[{attempt_id}] Tool Call: api_example_generator (Successful)")
             final_output = "Comprehensive documentation including API examples."
        else:
             self.execution_history.append(f"[{attempt_id}] Tool Call: initial_draft_generator (Incomplete)")
             final_output = "Basic documentation draft."

        # Simulate the reflection check after execution
        trace = self._create_trace(goal, final_output)
        critique = self.reflection_engine.analyze(trace)
        
        if critique.confidence_score < 1.0:
            raise LogicalFailure(critique=critique)
        
        return final_output

    def _create_trace(self, goal, output):
        """Helper to package execution data for reflection."""
        # For this exercise, we simplify the trace structure
        return type('MockTrace', (object,), {
            'initial_goal': goal,
            'action_log': self.execution_history,
            'final_output': output,
            'runtime_status': 'SUCCESS'
        })

    def execute_task(self, goal: str, current_plan: Optional[str] = "Initial Plan: Generate first draft documentation.") -> str:
        """Core execution loop with recursive self-correction."""
        
        if self.retry_count >= self.MAX_RETRIES:
            raise RuntimeError(f"Task failed after {self.MAX_RETRIES} correction attempts. Aborting.")
        
        print(f"\n--- EXECUTION ATTEMPT {self.retry_count + 1} ---")
        
        try:
            # 1. Execute the current plan
            final_result = self._execute_step(goal, current_plan)
            print(f"SUCCESS! Task completed in {self.retry_count + 1} attempts.")
            return final_result

        except LogicalFailure as lf:
            # 2. Dynamic Re-prompting Implementation
            self.retry_count += 1
            critique = lf.critique
            print(f"LOGICAL FAILURE DETECTED. Confidence: {critique.confidence_score}")
            print(f"Critique: {critique.critique_text}")
            
            # 3. Plan Modification: Construct a new, revised plan prompt
            new_plan_instruction = (
                f"REVISED_PLAN (Attempt {self.retry_count + 1}): "
                f"Original Goal: {goal}. Previous Failure: {critique.critique_text}. "
                f"New Strategy: {critique.proposed_strategy}"
            )
            
            # Log the modification
            self.execution_history.append(f"[Attempt {self.retry_count + 1}] Plan Modified: {new_plan_instruction}")
            
            # 4. Recursive Execution
            return self.execute_task(goal, current_plan=new_plan_instruction)

# Demonstration
if __name__ == '__main__':
    agent = DocumentationAgent(reflection_engine=MockReflectionEngine())
    initial_goal = "Create a detailed technical manual for the new API, ensuring comprehensive usage examples are included."
    
    try:
        final_doc = agent.execute_task(initial_goal)
        print(f"\n--- FINAL RESULT ---")
        print(final_doc)
    except RuntimeError as e:
        print(f"\n--- FINAL FAILURE ---")
        print(e)

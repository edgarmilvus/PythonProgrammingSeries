
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
from langsmith import traceable
from contextlib import asynccontextmanager

# NOTE: Async tracing requires specific setup, often involving wrapping the 
# async function or using LangChain's async methods. This solution uses 
# a standard Python async context manager instrumented with @traceable.

class AsyncDBConnector:
    """Simulated Asynchronous Context Manager Tool."""
    
    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = None

    @traceable(run_type="tool", name="DB Connection Opened")
    async def __aenter__(self):
        """Initializes the resource (connection)."""
        await asyncio.sleep(0.1) 
        self.connection = f"Connection to {self.db_name} established."
        return self.connection

    @traceable(run_type="tool", name="DB Connection Closed/Cleaned Up")
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Guarantees resource cleanup, even on exception."""
        await asyncio.sleep(0.05) 
        self.connection = None
        
        # Log status based on exception
        if exc_type:
             print(f"Cleanup finished after exception: {exc_type.__name__}")
        
        # Returning False ensures the exception propagates and the agent run fails
        return False 

@traceable(run_type="chain", name="AsyncAgentExecution")
async def AsyncAgentExecution(query: str):
    """
    Agent execution that uses the async context manager and then fails 
    due to a programmed exception.
    """
    
    # 1. Context Manager Invoked
    async with AsyncDBConnector("Financial_DB") as conn:
        print(f"Using connection: {conn}")
        
        # 2. Intentional failure logic
        if "divide by zero" in query.lower():
            # This line raises ZeroDivisionError, halting the chain execution
            result = 1 / 0
            return result
        
        return "Query successful."

# 3. Execution Scenario
async def run_scenario():
    try:
        await AsyncAgentExecution("Please calculate the ratio of 1 divided by zero.")
    except ZeroDivisionError:
        # Catch the exception that propagates out of the agent
        pass
    
asyncio.run(run_scenario())
print("Async run complete. Verify trace for resource cleanup.")

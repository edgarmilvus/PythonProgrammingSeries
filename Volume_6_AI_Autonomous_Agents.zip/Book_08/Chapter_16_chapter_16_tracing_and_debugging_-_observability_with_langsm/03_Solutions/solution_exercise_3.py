
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

from langsmith import traceable

@traceable(run_type="tool", name="ToolA_DataAggregator")
def ToolA(input_data: str) -> str:
    """Simulates an expensive LLM tool call."""
    return f"Observation: Summary A based on {input_data}. (Costly token usage)"

@traceable(run_type="tool", name="ToolB_CrossReference")
def ToolB(input_data: str) -> str:
    """Simulates a moderately expensive LLM tool call."""
    return f"Observation: Cross-reference B based on {input_data}."

@traceable(run_type="agent", name="KnowledgeSynthesisAgent")
def KnowledgeSynthesisAgent(query: str):
    """Simulates the inefficient agent flow: A -> B -> A."""
    
    # Step 1: Initial Tool A call
    # T1 (Thought)
    result_a1 = ToolA(query)
    
    # Step 2: Tool B call based on A1
    # T2 (Thought)
    result_b = ToolB(result_a1)
    
    # Step 3: Redundant Tool A call (The source of waste)
    # T3 (Thought) - This thought is unnecessary
    result_a2 = ToolA(result_b) # Redundant call
    
    # Step 4: Final Answer
    # T4 (Thought)
    return f"Final Answer: Synthesis complete."

# Generate the inefficient trace
KnowledgeSynthesisAgent("Analyze Q3 earnings reports for tech sector.")
print("KnowledgeSynthesisAgent trace generated for analysis.")

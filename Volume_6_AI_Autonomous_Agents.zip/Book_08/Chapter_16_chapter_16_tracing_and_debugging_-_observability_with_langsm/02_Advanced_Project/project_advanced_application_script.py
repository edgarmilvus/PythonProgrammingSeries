
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from typing import List, Union
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_react_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

# 1. Environment Configuration for LangSmith Tracing
# CRITICAL: LangSmith tracing is automatically enabled by these variables.
# The 'LANGCHAIN_PROJECT' defines the specific project workspace in LangSmith.
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_PROJECT"] = "Financial Agent Observability Demo"
# Note: OPENAI_API_KEY and LANGCHAIN_API_KEY must be set in your actual environment.

# --- 2. Define Custom Tools for the Agent ---
# These tools represent the external capabilities the agent can access.

@tool
def search_financial_news(query: str) -> str:
    """Searches recent financial news headlines for a given company or topic. 
    Use this for questions about current market events or company updates."""
    print(f"--- TOOL CALL: Searching news for '{query}' ---")
    if "Tesla" in query:
        return "Tesla stock is up 5% following news of a new battery factory opening in Texas."
    elif "Inflation" in query:
        return "The Federal Reserve announced interest rates will remain steady for Q4."
    else:
        return f"No specific recent news found for {query}. The market is quiet."

@tool
def calculate_simple_growth(initial_value: Union[int, float], growth_rate: Union[int, float]) -> float:
    """Calculates the final value after one period of simple growth. 
    Requires two numerical inputs: initial_value (e.g., 5000) and growth_rate (e.g., 12 for 12%)."""
    print(f"--- TOOL CALL: Calculating growth: {initial_value} * (1 + {growth_rate/100}) ---")
    # Assuming growth_rate is provided as a percentage (e.g., 10 for 10%)
    return float(initial_value) * (1 + (float(growth_rate) / 100))

tools: List = [search_financial_news, calculate_simple_growth]

# --- 3. Agent Setup (ReAct Framework) ---

# Define the LLM (Low temperature ensures consistent decision-making for debugging)
llm = ChatOpenAI(temperature=0, model="gpt-4o-mini")

# Define the Prompt Template
# The system message is crucial for guiding the agent's tool selection logic.
prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a specialized financial research assistant. Use the provided tools to answer questions. If the question involves market events, use the search tool. If it involves future value projection, use the calculation tool. Always provide a clear final answer."),
        MessagesPlaceholder("chat_history", optional=True),
        ("human", "{input}"),
        MessagesPlaceholder("agent_scratchpad"),
    ]
)

# Create the Agent (ReAct logic)
agent = create_react_agent(llm, tools, prompt)

# Create the Executor
agent_executor = AgentExecutor(
    agent=agent, 
    tools=tools, 
    verbose=True, 
    handle_parsing_errors=True
)

# --- 4. Execution and Tracing Demonstration ---

print("\n=======================================================")
print("RUN 1: Tool Usage - Search (External Dependency Path)")
print("=======================================================")
# Query 1 forces the agent down the search_financial_news path.
result_1 = agent_executor.invoke({"input": "What is the latest news affecting Tesla stock?"})
print(f"\nFINAL ANSWER 1: {result_1['output']}")

print("\n=======================================================")
print("RUN 2: Tool Usage - Calculation (Internal Logic Path)")
print("=======================================================")
# Query 2 forces the agent down the calculate_simple_growth path.
result_2 = agent_executor.invoke({"input": "If I invest $5000 and expect a 12% return this year, what is the projected value?"})
print(f"\nFINAL ANSWER 2: {result_2['output']}")

# LangSmith automatically provides a URL in the verbose output for each run.
print("\n--- TRACING COMPLETE ---")
print(f"Check your LangSmith project '{os.environ['LANGCHAIN_PROJECT']}' for detailed traces of both runs.")

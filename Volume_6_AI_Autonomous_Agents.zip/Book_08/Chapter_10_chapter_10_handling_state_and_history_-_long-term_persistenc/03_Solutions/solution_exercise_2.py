
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import aiosqlite
import asyncio
import datetime
import os

DB_NAME = "agent_history.db"

class AsyncHistoryManager:
    """Manages asynchronous, structured persistence for conversation history."""
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = None

    async def __aenter__(self):
        """Establishes the connection and ensures the table structure exists."""
        self.conn = await aiosqlite.connect(self.db_path)
        await self._setup_table()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Closes the connection cleanly, regardless of exceptions."""
        if self.conn:
            await self.conn.close()
            self.conn = None
        # Returning False allows any exception to propagate normally
        return False

    async def _setup_table(self):
        await self.conn.execute("""
            CREATE TABLE IF NOT EXISTS conversation_history (
                timestamp TEXT PRIMARY KEY,
                role TEXT NOT NULL,
                content TEXT NOT NULL
            );
        """)
        await self.conn.commit()

    async def log_message(self, role: str, content: str):
        """Inserts a new message record asynchronously."""
        timestamp = datetime.datetime.now().isoformat()
        await self.conn.execute(
            "INSERT INTO conversation_history (timestamp, role, content) VALUES (?, ?, ?)",
            (timestamp, role, content)
        )
        await self.conn.commit()
        print(f"Logged message: {role}")

    async def retrieve_last_n_messages(self, n: int):
        """Retrieves the last N messages, formatted for LLM context."""
        cursor = await self.conn.execute(
            "SELECT role, content FROM conversation_history ORDER BY timestamp DESC LIMIT ?",
            (n,)
        )
        rows = await cursor.fetchall()
        # Format and reverse the order (oldest first for context injection)
        messages = [{"role": row[0], "content": row[1]} for row in reversed(rows)]
        return messages

# --- Demonstration ---
async def main():
    if os.path.exists(DB_NAME):
        os.remove(DB_NAME)

    print("--- Starting Async History Demonstration ---")

    # The async with statement guarantees connection cleanup
    async with AsyncHistoryManager(DB_NAME) as manager:
        await manager.log_message("user", "What is the capital of France?")
        await manager.log_message("agent", "The capital is Paris.")
        await manager.log_message("user", "Thank you for the quick response.")

        last_two = await manager.retrieve_last_n_messages(2)

        print("\nRetrieved Last 2 Messages:")
        for msg in last_two:
            print(f"  [{msg['role'].upper()}]: {msg['content']}")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    finally:
        if os.path.exists(DB_NAME):
            os.remove(DB_NAME)

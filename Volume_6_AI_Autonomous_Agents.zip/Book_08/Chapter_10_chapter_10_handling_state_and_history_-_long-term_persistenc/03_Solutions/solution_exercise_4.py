
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import json
import os
from typing import Dict, List

KNOWLEDGE_FILE = "knowledge_base.jsonl"

class KnowledgeStore:
    """Manages durable storage and simulated retrieval of knowledge chunks."""
    def __init__(self):
        # Internal storage: maps chunk_id to the chunk dictionary
        self.chunks: Dict[str, Dict] = {}

    def add_chunk(self, chunk_id: str, text_content: str, source_metadata: str):
        self.chunks[chunk_id] = {
            "chunk_id": chunk_id,
            "text_content": text_content,
            "source_metadata": source_metadata
        }

    def save_knowledge_base(self, filepath: str):
        """Writes all chunks to a JSON Lines file (durable storage)."""
        with open(filepath, 'w') as f:
            for chunk in self.chunks.values():
                # JSON Lines format: one JSON object per line
                f.write(json.dumps(chunk) + '\n')
        print(f"Saved {len(self.chunks)} chunks to {filepath}.")

    def load_knowledge_base(self, filepath: str):
        """Loads chunks from the JSON Lines file into memory."""
        self.chunks = {}
        try:
            with open(filepath, 'r') as f:
                for line in f:
                    if line.strip():
                        chunk = json.loads(line)
                        self.chunks[chunk['chunk_id']] = chunk
            print(f"Loaded {len(self.chunks)} chunks from {filepath}.")
        except FileNotFoundError:
            print(f"Knowledge file not found. Starting empty store.")

    def retrieve_context(self, query: str, top_k: int = 3) -> str:
        """
        Simulates RAG retrieval based on simple keyword matching.
        Returns the top K chunks formatted for LLM injection.
        """
        query_keywords = set(query.lower().split())
        scores = []

        for chunk in self.chunks.values():
            content_lower = chunk['text_content'].lower()
            
            # Scoring: count keyword overlap
            score = sum(1 for keyword in query_keywords if keyword in content_lower)
            
            if score > 0:
                scores.append((score, chunk))

        scores.sort(key=lambda x: x[0], reverse=True)
        top_chunks = [item[1] for item in scores[:top_k]]

        if not top_chunks:
            return "No relevant context found."

        # Format for RAG injection
        context_string = "--- Retrieved Context (Relevant Knowledge) ---\n"
        for i, chunk in enumerate(top_chunks):
            context_string += f"Source {i+1} ({chunk['source_metadata']}): {chunk['text_content']}\n"
        context_string += "----------------------------------------------"
        
        return context_string

# --- Demonstration ---
if os.path.exists(KNOWLEDGE_FILE): os.remove(KNOWLEDGE_FILE)

store = KnowledgeStore()
store.add_chunk("c1", "Async agents prevent blocking I/O using concurrency.", "Doc_A")
store.add_chunk("c2", "Vector databases are essential for effective semantic search (RAG).", "Doc_C")
store.add_chunk("c3", "SQLite is used for local history storage.", "Doc_D")

store.save_knowledge_base(KNOWLEDGE_FILE)
del store
new_store = KnowledgeStore()
new_store.load_knowledge_base(KNOWLEDGE_FILE)

query_1 = "How do agents use vector search?"
context_1 = new_store.retrieve_context(query_1, top_k=2)
print(f"\nQuery: '{query_1}'\n{context_1}")

if os.path.exists(KNOWLEDGE_FILE): os.remove(KNOWLEDGE_FILE)

# --- Graphviz DOT Code ---
DOT_CODE = """
digraph KnowledgePersistence {
    rankdir=LR;
    node [shape=box, style="filled", fillcolor="#E6E6FA"];
    
    Agent [label="AI Agent Core", fillcolor="#ADD8E6"];
    KnowledgeStore [label="KnowledgeStore Class\n(In-Memory Index)", shape=cylinder];
    DurableStorage [label="knowledge_base.jsonl\n(Durable File Storage)", shape=note, fillcolor="#F0E68C"];
    
    Agent -> KnowledgeStore [label="Query/Retrieve"];
    KnowledgeStore -> DurableStorage [label="Load/Save (File I/O)"];
    
    subgraph cluster_persistence {
        label = "Simulated RAG Persistence Layer";
        style = rounded;
        color = "#333333";
        KnowledgeStore;
        DurableStorage;
    }
}
"""
print("\n\nGraphviz DOT Code for Visualization:")
print(DOT_CODE)

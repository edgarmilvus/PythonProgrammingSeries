
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# Setup context for the agent
BASE_URL = "http://simulated.spa.portal/login"
# Using By.NAME and By.XPATH for stable locators
USERNAME_FIELD_LOCATOR = (By.NAME, "user_email")
PASSWORD_FIELD_LOCATOR = (By.XPATH, "//*[@data-testid='password-input']")
SUBMIT_BUTTON_LOCATOR = (By.XPATH, "//button[contains(text(), 'Sign In')]")
DASHBOARD_VERIFICATION_LOCATOR = (By.ID, "user-profile-widget")

def initialize_driver():
    """Initializes the WebDriver instance."""
    options = webdriver.ChromeOptions()
    # Optional: Add headless mode for production
    # options.add_argument("--headless") 
    driver = webdriver.Chrome(options=options)
    driver.implicitly_wait(0) # Disable implicit wait to rely solely on explicit waits
    return driver

def attempt_login(driver, username, password):
    """Navigates, waits for elements to be clickable, inputs credentials, and submits."""
    driver.get(BASE_URL)
    wait = WebDriverWait(driver, 10) # Max wait time of 10 seconds

    try:
        print("Waiting for login fields...")
        # 1. Wait for the Username field to be clickable
        username_field = wait.until(
            EC.element_to_be_clickable(USERNAME_FIELD_LOCATOR)
        )
        username_field.send_keys(username)

        # 2. Wait for the Password field (using data-testid via XPath)
        password_field = wait.until(
            EC.element_to_be_clickable(PASSWORD_FIELD_LOCATOR)
        )
        password_field.send_keys(password)

        # 3. Wait for the Submit button and click it
        submit_button = wait.until(
            EC.element_to_be_clickable(SUBMIT_BUTTON_LOCATOR)
        )
        submit_button.click()
        return True

    except TimeoutException:
        print("Error: Login elements did not appear within the timeout period.")
        return False

def verify_dashboard_access(driver):
    """Implements WebDriverWait to verify the presence of a critical post-login element."""
    wait = WebDriverWait(driver, 10) # 10 seconds timeout for dashboard load
    try:
        wait.until(
            EC.presence_of_element_located(DASHBOARD_VERIFICATION_LOCATOR)
        )
        print("SUCCESS: Dashboard element verified. Agent is authenticated.")
        return True
    except TimeoutException:
        # 4. Log error detailing failure condition
        print("FAILURE: Post-login verification failed.")
        print("Dashboard element did not appear within 10 seconds (Timeout).")
        return False

def run_agent(username, password):
    driver = None
    try:
        driver = initialize_driver()
        if attempt_login(driver, username, password):
            verify_dashboard_access(driver)
    except Exception as e:
        print(f"Critical failure during agent run: {e}")
    finally:
        # 5. Clean Shutdown
        if driver:
            print("Shutting down driver.")
            driver.quit()

# Example execution (uncomment to run in a live environment)
# run_agent("testuser@example.com", "securepassword123")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
import csv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Setup files and paths (Simulation: Ensure files exist)
APPLICANT_DATA_FILE = "applicants.csv"
RESUME_FILENAME = "simulated_resume.pdf"
SIMULATED_URL = "http://simulated.job.portal/application"

# Locators for the simulated stages
STAGE1_NAME_LOCATOR = (By.NAME, "applicant_name")
STAGE1_NEXT_LOCATOR = (By.ID, "next-stage-1")
STAGE2_FILE_UPLOAD_LOCATOR = (By.ID, "resume-upload")
STAGE2_NEXT_LOCATOR = (By.ID, "next-stage-2")
STAGE3_CONFIRM_LOCATOR = (By.ID, "confirm-submission")

# --- File Setup (Required for path testing) ---
if not os.path.exists(APPLICANT_DATA_FILE):
    with open(APPLICANT_DATA_FILE, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["name", "email"])
        writer.writerow(["Alice Johnson", "alice@example.com"])
if not os.path.exists(RESUME_FILENAME):
    with open(RESUME_FILENAME, 'w') as f:
        f.write("Simulated resume content.")
# --- End File Setup ---

def get_data_from_file(filepath):
    """
    1. Reads applicant data efficiently by iterating over the file object (generator).
    """
    print(f"Reading data from {filepath} efficiently...")
    try:
        with open(filepath, 'r', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                yield row 
    except FileNotFoundError:
        print(f"Error: Applicant data file not found at {filepath}")

def construct_safe_path(filename):
    """
    2. Uses os.path.join() to create an absolute, platform-safe path for file upload.
    """
    # os.path.join handles OS-specific path separators correctly (/, \)
    absolute_path = os.path.join(os.getcwd(), filename)
    return absolute_path

def run_submission_agent(driver, applicant_data):
    safe_resume_path = construct_safe_path(RESUME_FILENAME)
    wait = WebDriverWait(driver, 10)
    
    try:
        # --- Stage 1: Personal Info ---
        driver.get(SIMULATED_URL + "/stage1")
        name_field = wait.until(EC.presence_of_element_located(STAGE1_NAME_LOCATOR))
        name_field.send_keys(applicant_data['name'])
        
        # Click Next (3. Workflow Management: Wait for clickable)
        next_button_1 = wait.until(EC.element_to_be_clickable(STAGE1_NEXT_LOCATOR))
        next_button_1.click()
        
        # Simulate navigation to Stage 2
        driver.get(SIMULATED_URL + "/stage2") 
        
        # --- Stage 2: Document Upload ---
        upload_input = wait.until(EC.presence_of_element_located(STAGE2_FILE_UPLOAD_LOCATOR))
        
        # Use send_keys with the safe, absolute path
        upload_input.send_keys(safe_resume_path)
        print(f"Uploaded file: {RESUME_FILENAME} via path: {safe_resume_path}")

        # Click Next
        next_button_2 = wait.until(EC.element_to_be_clickable(STAGE2_NEXT_LOCATOR))
        next_button_2.click()
        
        # Simulate navigation to Stage 3
        driver.get(SIMULATED_URL + "/stage3") 
        
        # --- Stage 3: Review and Confirmation ---
        confirm_button = wait.until(EC.element_to_be_clickable(STAGE3_CONFIRM_LOCATOR))
        confirm_button.click()
        
        print(f"SUCCESS: Application submitted for {applicant_data['name']}.")
        
    except Exception as e:
        print(f"FAILURE during submission for {applicant_data.get('name', 'Unknown')}: {e}")

def main_exercise_3():
    driver = None
    try:
        driver = webdriver.Chrome()
        # Iterate over the efficient generator function
        for applicant in get_data_from_file(APPLICANT_DATA_FILE):
            if applicant:
                run_submission_agent(driver, applicant)
    finally:
        if driver:
            driver.quit()

# main_exercise_3()

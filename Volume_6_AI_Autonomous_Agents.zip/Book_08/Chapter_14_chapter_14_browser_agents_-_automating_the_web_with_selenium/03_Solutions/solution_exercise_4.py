
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import base64 

# Simulated CAPTCHA challenge data
CAPTCHA_PROMPT = "Identify all squares containing a fire hydrant."
CAPTCHA_GRID_LOCATOR = (By.ID, "captcha-image-grid")
CAPTCHA_VERIFY_BUTTON = (By.ID, "captcha-verify-btn")
# Assuming grid squares are direct children elements
GRID_SQUARE_LOCATOR = (By.XPATH, f"//div[@id='{CAPTCHA_GRID_LOCATOR[1]}']/div") 

def is_captcha_present(driver):
    """
    1. Detection mechanism: Checks for the presence of the CAPTCHA container element.
    """
    try:
        # Use a very short timeout to quickly check presence
        WebDriverWait(driver, 0.5).until(
            EC.presence_of_element_located(CAPTCHA_GRID_LOCATOR)
        )
        return True
    except TimeoutException:
        return False

def solve_visual_captcha(image_data: bytes, prompt: str) -> list[int]:
    """
    2. Simulated Vision AI service. Returns 0-based indices of squares to click.
    """
    print(f"AI: Processing image data ({len(image_data)} bytes) with prompt: '{prompt}'")
    # Fixed logic simulating AI response
    if "fire hydrant" in prompt.lower():
        return [1, 5, 6] 
    return []

def handle_captcha_challenge(driver):
    """
    Handles the CAPTCHA interaction based on the AI solution.
    """
    print("\n!!! CAPTCHA CHALLENGE DETECTED. HALTING SCRAPE. !!!")
    
    # Capture element screenshot (simulated data)
    try:
        captcha_grid_element = driver.find_element(*CAPTCHA_GRID_LOCATOR)
        # In production: image_base64_data = captcha_grid_element.screenshot_as_base64
        image_base64_data = base64.b64encode(b"SIMULATED_CAPTCHA_IMAGE_DATA") 
    except NoSuchElementException:
        print("Error: CAPTCHA grid element not found for capturing.")
        return

    # Call AI
    indices_to_click = solve_visual_captcha(image_base64_data, CAPTCHA_PROMPT)
    print(f"AI Solution Received: Click indices {indices_to_click}")

    # 3. Interaction: Locate all grid squares and click the correct ones
    try:
        grid_squares = driver.find_elements(*GRID_SQUARE_LOCATOR)
        
        for index in indices_to_click:
            if index < len(grid_squares):
                print(f"Clicking square at index {index}...")
                grid_squares[index].click()
            
        # Click the 'Verify' button
        verify_button = driver.find_element(*CAPTCHA_VERIFY_BUTTON)
        verify_button.click()
        
        # 4. Resumption: Wait for the CAPTCHA element to disappear
        WebDriverWait(driver, 15).until_not(
            EC.presence_of_element_located(CAPTCHA_GRID_LOCATOR)
        )
        print("CAPTCHA successfully submitted. Resuming scraping flow.")
        
    except Exception as e:
        print(f"CAPTCHA handling failed during interaction: {e}")
        
def run_modified_scraping_agent(driver, total_pages=15):
    # Simulate setup (requires HTML injection for the locators to work)
    
    for page in range(1, total_pages + 1):
        print(f"\n--- Scraping Page {page} ---")
        
        # Check for CAPTCHA before starting the scrape of the current page
        if is_captcha_present(driver):
            handle_captcha_challenge(driver)
            
        # Continue scraping logic (4. Resumption)
        print(f"Successfully scraped results from page {page}.")
        # driver.get(f"/search?page={page+1}") # Actual navigation

# Example setup for simulation
# Note: Requires manual HTML injection or a mock server to test fully.

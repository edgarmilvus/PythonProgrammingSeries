
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import re

# 1. Define the Tool
def lookup_fact(query: str) -> str:
    """Simulates an external search engine lookup."""
    query = query.lower()
    if "guido van rossum birthplace" in query:
        return "The Netherlands"
    elif "capital of the netherlands" in query:
        return "Amsterdam"
    else:
        return "Fact not found."

# 2. Tool Wrapping (Conceptual, using a simple dictionary for the agent)
TOOLS = {
    "FactFinder": lookup_fact
}

# 3. ReAct Prompt Structure
REACT_PROMPT = """
You are a sophisticated Fact Finder Agent. Your goal is to answer the user's request.
You have access to the following tool: FactFinder(query: str).

Follow the strict ReAct format:
Thought: (Internal monologue detailing the plan)
Action: FactFinder["<query>"] (Execute tool)
Observation: (Result from the tool execution)
... (Repeat Thought/Action/Observation until complete)
Final Answer: <The final answer>

Goal: Find the capital city of the country where the inventor of Python (Guido van Rossum) was born.
{agent_scratchpad}
"""

# Mock LLM response generation based on the current state (scratchpad)
def mock_llm_react(scratchpad):
    if not scratchpad:
        # Step 1: Initial Thought/Action
        return """Thought: The goal requires two steps. First, I must find Guido van Rossum's birthplace country.
Action: FactFinder["Guido van Rossum birthplace country"]"""
    
    elif "Observation: The Netherlands" in scratchpad:
        # Step 3: Second Thought/Action
        return """Thought: I have the country (The Netherlands). Now I must find its capital.
Action: FactFinder["capital of The Netherlands"]"""
        
    elif "Observation: Amsterdam" in scratchpad:
        # Step 5: Final Thought/Answer
        return """Thought: I have successfully found the capital city, which is Amsterdam.
Final Answer: Amsterdam"""
    
    return "Error: Agent stuck."

# Agent Execution Loop
def run_react_agent(goal):
    scratchpad = ""
    max_steps = 5
    
    print(f"--- Starting ReAct Agent for Goal: {goal} ---")
    
    for step in range(max_steps):
        # 1. LLM generates Thought/Action
        llm_output = mock_llm_react(scratchpad)
        scratchpad += "\n" + llm_output
        print(f"\n--- Cycle {step + 1} (LLM Output) ---")
        print(llm_output)

        # Check for Final Answer
        if "Final Answer:" in llm_output:
            return scratchpad

        # 2. Parse Action
        action_match = re.search(r'Action: FactFinder\["(.*?)"\]', llm_output, re.DOTALL)
        if action_match:
            query = action_match.group(1)
            
            # 3. Execute Tool and get Observation
            observation = TOOLS["FactFinder"](query)
            
            # 4. Update Scratchpad with Observation
            observation_line = f"Observation: {observation}"
            scratchpad += "\n" + observation_line
            print(observation_line)
        else:
            # If no action is found, the agent is stuck or finished (but not with Final Answer)
            break
            
    return scratchpad

# 4. Run the Agent
final_trace = run_react_agent("Find the capital city of the country where the inventor of Python (Guido van Rossum) was born.")

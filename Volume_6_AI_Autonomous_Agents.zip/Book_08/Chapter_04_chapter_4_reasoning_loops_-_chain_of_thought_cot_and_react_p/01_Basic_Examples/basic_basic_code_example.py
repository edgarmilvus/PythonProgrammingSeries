
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnableSequence

# --- 1. Setup and Configuration ---
# Load environment variables (API keys and configuration)
# Assumes a .env file is present with OPENAI_API_KEY
load_dotenv()

# Initialize the LLM
# We use a lower temperature (closer to 0) to encourage deterministic,
# logical, and less creative reasoning, which is ideal for CoT.
try:
    llm = ChatOpenAI(temperature=0.1, model="gpt-4o-mini")
except Exception as e:
    print(f"Error initializing LLM. Ensure API key is set: {e}")
    exit()

# --- 2. Define the Chain of Thought Prompt ---
# The template explicitly instructs the model to reason step-by-step.
COT_TEMPLATE = """
You are an expert scheduling and prioritization assistant. Your task is to analyze a list of conflicting tasks and produce an optimized schedule for the day, starting at 9:00 AM.

CRITICAL INSTRUCTION: Before providing the final schedule, you MUST first output your step-by-step reasoning process under the heading 'REASONING:'. This reasoning must detail how you handled time conflicts and priority levels.

INPUT TASKS:
{tasks}

REASONING:
"""

# Create the PromptTemplate object, defining the input variable 'tasks'
prompt = PromptTemplate(
    template=COT_TEMPLATE,
    input_variables=["tasks"]
)

# --- 3. Construct the Reasoning Chain (LCEL) ---
# Define the output parser to handle the raw string output
parser = StrOutputParser()

# Define the full runnable sequence: Prompt feeds to LLM, LLM output feeds to Parser
# This is the standard LCEL pipe structure (A | B | C)
cot_chain = prompt | llm | parser

# --- 4. Define the Complex Input ---
complex_tasks = """
1. Draft the Q3 financial report (High Priority, requires 3 hours, must be done before 3 PM).
2. Attend the mandatory team meeting (Fixed time: 10:00 AM - 11:00 AM).
3. Review John's code (Low Priority, requires 1 hour).
4. Lunch break (Mandatory, 12:00 PM - 1:00 PM).
"""

# --- 5. Execution and Output ---
print("--- Starting CoT Agent Execution ---")
print(f"Input Tasks:\n{complex_tasks}")

# Run the chain, passing the tasks dictionary as input
response = cot_chain.invoke({"tasks": complex_tasks})

# Print the result, which now includes the internal reasoning and the final schedule
print("\n" + "="*50)
print("[AGENT RESPONSE - INCLUDING CoT]")
print("="*50 + "\n")
print(response)

print("\n--- Execution Complete ---")

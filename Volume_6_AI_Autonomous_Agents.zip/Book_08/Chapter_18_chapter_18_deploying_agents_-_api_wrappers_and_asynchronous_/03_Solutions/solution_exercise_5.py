
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import uuid
from pydantic import BaseModel, Field
from datetime import date
from typing import Dict, Any
from fastapi import FastAPI

# 1. Tool Input Schemas
class StockPriceInput(BaseModel):
    ticker: str = Field(..., description="The stock ticker symbol (e.g., AAPL, MSFT). Must be uppercase.")
    date: date = Field(..., description="The specific date for which to retrieve the closing price (YYYY-MM-DD format).")

class MovingAverageInput(BaseModel):
    ticker: str = Field(..., description="The stock ticker symbol for the calculation.")
    window_size: int = Field(..., description="The size of the moving average window, typically 30 or 90 days.")

# 2. Tool Function Signatures
async def get_stock_price(input: StockPriceInput) -> Dict[str, Any]:
    """Fetches the closing price for a given stock ticker on a specific date."""
    # The function signature links the tool to its strict input schema.
    # Implementation not required
    return {"price": 150.00, "date": str(input.date)}

async def calculate_moving_average(input: MovingAverageInput) -> Dict[str, Any]:
    """Calculates the N-day moving average for a stock."""
    # Implementation not required
    return {"average": 145.50, "window": input.window_size}

# 3. Agent Request Schema
class AnalystAgentRequest(BaseModel):
    prompt: str = Field(..., description="The natural language query for the financial analyst agent.")

# 4. API Endpoint Structure
app = FastAPI(title="Financial Agent Tool Deployment")

@app.post("/api/v1/analyze_financials")
async def run_financial_agent(request: AnalystAgentRequest):
    """
    This endpoint executes the Financial Analyst Agent.
    The agent uses the following tools internally, defined by their Pydantic schemas:
    - get_stock_price (requires StockPriceInput)
    - calculate_moving_average (requires MovingAverageInput)
    """
    
    # Placeholder for agent framework integration:
    # 1. framework.register_tool(get_stock_price) 
    #    -> The framework introspects the function signature and docstring.
    # 2. framework.register_tool(calculate_moving_average)
    #    -> The framework converts the Pydantic schema (e.g., StockPriceInput) 
    #       into a JSON Schema description for the LLM's function calling mechanism.
    
    # 3. The LLM receives the prompt and the tool definitions, decides which tool to call, 
    #    and generates the corresponding JSON arguments, which are validated by Pydantic.
    
    job_id = str(uuid.uuid4())
    return {"job_id": job_id, "status": "Agent job initiated."}

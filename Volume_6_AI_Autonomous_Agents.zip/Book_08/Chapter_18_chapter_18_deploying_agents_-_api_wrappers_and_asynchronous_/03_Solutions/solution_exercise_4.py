
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import uuid
import asyncio
from datetime import datetime
from pydantic import BaseModel, Field
from fastapi import APIRouter, status, HTTPException
from fastapi.responses import JSONResponse

router = APIRouter()

# 1. State Definitions
JOB_RESULTS_DB = {}
JOB_STATUSES = ["PENDING", "RUNNING", "COMPLETED", "FAILED"]

# Helper function to update job state
def update_job_state(job_id, status, result=None, error_details=None):
    if job_id not in JOB_RESULTS_DB:
        return # Should not happen if initialized correctly
    JOB_RESULTS_DB[job_id].update({
        "status": status,
        "last_updated": datetime.now().isoformat(),
        "result": result,
        "error_details": error_details
    })

# 2. Pydantic Schema for Errors
class AgentFailureDetails(BaseModel):
    error_type: str = Field(..., description="The type of error (e.g., ToolExecutionError).")
    message: str = Field(..., description="A brief summary of the failure.")
    traceback_summary: str = Field(..., description="A truncated stack trace or detailed explanation.")

# Schema for initial submission (reused)
class ResearchRequest(BaseModel):
    query: str

# 3. Modified Worker Function
async def research_worker(job_id: str, payload: dict):
    query = payload.get('query', '')
    
    update_job_state(job_id, "RUNNING")
    
    try:
        await asyncio.sleep(5) # Simulate runtime
        
        # Simulate failure 25% of the time based on query content
        if "FAIL" in query.upper():
            raise RuntimeError("External financial data source API returned a 503 error.")

        # Success path
        mock_result = {
            "summary": f"Deep analysis on '{query[:20]}...' successfully retrieved.",
            "final_recommendation": "BUY",
        }
        update_job_state(job_id, "COMPLETED", result=mock_result)

    except Exception as e:
        # Failure path
        failure_details = AgentFailureDetails(
            error_type=type(e).__name__,
            message=str(e),
            traceback_summary="LLM reasoning loop halted due to tool failure in step 3."
        )
        update_job_state(job_id, "FAILED", error_details=failure_details.dict())

# Submission Endpoint (for context)
@router.post("/submit_research", status_code=status.HTTP_202_ACCEPTED)
async def submit_research(request_data: ResearchRequest):
    job_id = str(uuid.uuid4())
    
    # Initialize job state as PENDING
    JOB_RESULTS_DB[job_id] = {
        "status": "PENDING",
        "last_updated": datetime.now().isoformat(),
        "result": None,
        "error_details": None
    }
    asyncio.create_task(research_worker(job_id, request_data.dict()))
    
    return {"job_id": job_id, "message": "Job submitted."}


# 4. Status Polling Endpoint
@router.get("/status/{job_id}")
async def get_job_status(job_id: str):
    job = JOB_RESULTS_DB.get(job_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job ID not found.")
    
    return {
        "job_id": job_id,
        "status": job["status"],
        "last_updated": job["last_updated"]
    }

# 5. Result Retrieval Endpoint
@router.get("/results/{job_id}")
async def get_job_result(job_id: str):
    job = JOB_RESULTS_DB.get(job_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job ID not found.")
    
    current_status = job["status"]

    if current_status in ["PENDING", "RUNNING"]:
        # 202 Accepted: Still processing
        return JSONResponse(
            status_code=status.HTTP_202_ACCEPTED,
            content={"status": current_status, "message": "Processing is ongoing. Please poll again later."}
        )
    
    elif current_status == "COMPLETED":
        # 200 OK: Return the final result
        return job["result"]
    
    elif current_status == "FAILED":
        # 400 Bad Request: Return structured error details
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"status": "FAILED", "error": job["error_details"]}
        )

# Main application setup
app_ex4 = FastAPI()
app_ex4.include_router(router, prefix="/api/v1")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import uuid
import time
from contextvars import ContextVar
from fastapi import FastAPI
from typing import List

# 1. Define the Context Variable
request_context_id = ContextVar('request_context_id', default='UNSET')

# Mock logging function for demonstration
def mock_log(message: str):
    timestamp = time.strftime("%H:%M:%S")
    # Use a print statement to simulate concurrent log output
    print(f"[{timestamp}] {message}")

# 2. Tool Simulation Functions
async def tool_call_a(delay: float):
    # Retrieve the request ID bound to the current execution context
    req_id = request_context_id.get()
    mock_log(f"Tool A: Starting execution (Delay {delay}s). ID: {req_id[:8]}...")
    await asyncio.sleep(delay)
    mock_log(f"Tool A: Completed. ID: {req_id[:8]}...")
    return f"Result A from {req_id[:8]}"

async def tool_call_b(delay: float):
    req_id = request_context_id.get()
    mock_log(f"Tool B: Starting execution (Delay {delay}s). ID: {req_id[:8]}...")
    await asyncio.sleep(delay)
    mock_log(f"Tool B: Completed. ID: {req_id[:8]}...")
    return f"Result B from {req_id[:8]}"

async def tool_call_c(delay: float):
    req_id = request_context_id.get()
    mock_log(f"Tool C: Starting execution (Delay {delay}s). ID: {req_id[:8]}...")
    await asyncio.sleep(delay)
    mock_log(f"Tool C: Completed. ID: {req_id[:8]}...")
    return f"Result C from {req_id[:8]}"

# 3. Agent Execution Function
async def run_concurrent_agent() -> List[str]:
    """Runs three tool calls concurrently using TaskGroup."""
    mock_log(f"Agent executing tools for Request ID: {request_context_id.get()[:8]}...")
    
    results = []
    # asyncio.TaskGroup safely manages concurrent tasks
    async with asyncio.TaskGroup() as tg:
        task_a = tg.create_task(tool_call_a(0.5))
        task_b = tg.create_task(tool_call_b(1.0))
        task_c = tg.create_task(tool_call_c(0.3))
    
    results.extend([task_a.result(), task_b.result(), task_c.result()])
    return results

# 4. FastAPI Application Setup
app = FastAPI(title="ContextVars Agent")

# 5. API Endpoint Definition
@app.post("/api/v1/parallel_execute")
async def parallel_execute_endpoint():
    request_id = str(uuid.uuid4())
    
    # Bind the request ID to the current asynchronous context.
    # This token allows us to reset the context afterwards.
    token = request_context_id.set(request_id)
    
    mock_log(f"--- API START --- Request received. Request ID set: {request_id[:8]}...")
    
    try:
        results = await run_concurrent_agent()
        mock_log(f"--- API END --- Request {request_id[:8]} completed.")
        return {"request_id": request_id, "results": results}
    finally:
        # Reset the context variable to its previous state (or default)
        request_context_id.reset(token)

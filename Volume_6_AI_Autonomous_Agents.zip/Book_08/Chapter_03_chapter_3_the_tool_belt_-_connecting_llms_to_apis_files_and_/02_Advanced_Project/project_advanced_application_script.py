
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
import requests
from datetime import datetime
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_structured_chat_agent
from langchain.tools import StructuredTool
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

# --- Configuration and Environment Setup ---
# NOTE: Replace 'YOUR_OPENAI_API_KEY' or ensure the environment variable is set.
# os.environ["OPENAI_API_KEY"] = "YOUR_OPENAI_API_KEY" 
DATA_FILE = "market_history.json"

# --- 1. Tool Input Schemas (Pydantic) ---

class StockFetchInput(BaseModel):
    """Input schema for fetching stock data."""
    ticker: str = Field(description="The stock ticker symbol (e.g., 'GOOG', 'MSFT').")

class DataLogInput(BaseModel):
    """Input schema for logging data to the file."""
    ticker: str = Field(description="The stock ticker symbol.")
    price: float = Field(description="The current price of the stock.")
    volume: int = Field(description="The current trading volume.")

# --- 2. Tool Implementations (The External Connectors) ---

def fetch_stock_price(ticker: str) -> str:
    """
    Simulates fetching real-time stock price and volume from an external API.
    In a real application, this would use a library like yfinance or a paid API.
    """
    print(f"--- [TOOL CALL] Fetching data for {ticker} via simulated API...")
    
    # Dummy API simulation based on the ticker
    if ticker.upper() == "GOOG":
        price = 175.50
        volume = 2500000
    elif ticker.upper() == "MSFT":
        price = 420.15
        volume = 1500000
    else:
        return json.dumps({"error": f"Ticker {ticker} not found in simulated data."})

    data = {
        "ticker": ticker.upper(),
        "price": price,
        "volume": volume,
        "timestamp": datetime.now().isoformat()
    }
    
    # The agent receives the result as a string
    return json.dumps(data)

def log_market_data(ticker: str, price: float, volume: int) -> str:
    """
    Logs the fetched market data into a persistent local JSON file.
    This demonstrates file I/O capabilities for state management.
    """
    print(f"--- [TOOL CALL] Logging data for {ticker} to {DATA_FILE}...")
    
    new_entry = {
        "ticker": ticker,
        "price": price,
        "volume": volume,
        "timestamp": datetime.now().isoformat()
    }
    
    # Read existing data or initialize
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            try:
                history = json.load(f)
            except json.JSONDecodeError:
                history = []
    else:
        history = []

    history.append(new_entry)
    
    # Write updated data back to the file
    with open(DATA_FILE, 'w') as f:
        json.dump(history, f, indent=4)
        
    return f"Successfully logged {ticker} price {price} and volume {volume} to the history file."

# --- 3. Agent Setup ---

# Define the LLM (using a robust model capable of structured tool calling)
llm = ChatOpenAI(temperature=0, model="gpt-4o-mini")

# Structure the Python functions as tools for the LLM
tools = [
    StructuredTool.from_function(
        func=fetch_stock_price,
        name="fetch_stock_price",
        description="Retrieves the current stock price and trading volume for a given ticker.",
        args_schema=StockFetchInput
    ),
    StructuredTool.from_function(
        func=log_market_data,
        name="log_market_data",
        description="Persistently saves market data (ticker, price, volume) to the local history file.",
        args_schema=DataLogInput
    )
]

# Define the prompt template
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a diligent Market Research Agent. Your goal is to fetch real-time market data using the available tools, log the transaction for persistence, and then summarize the findings for the user."),
    MessagesPlaceholder(variable_name="chat_history", optional=True),
    ("human", "{input}"),
    MessagesPlaceholder(variable_name="agent_scratchpad")
])

# Create the agent
agent = create_structured_chat_agent(llm, tools, prompt)

# Create the executor
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# --- 4. Execution ---

user_query = "Please find the current price and volume for MSFT, and ensure this data is logged for historical tracking. Then tell me the price."

print(f"\n[USER INPUT]: {user_query}")
result = agent_executor.invoke({"input": user_query})

print("\n[FINAL AGENT RESPONSE]:")
print(result["output"])

# Optional: Display the contents of the generated file
print(f"\n[FILE CHECK]: Contents of {DATA_FILE} after execution:")
with open(DATA_FILE, 'r') as f:
    print(json.dumps(json.load(f), indent=2))

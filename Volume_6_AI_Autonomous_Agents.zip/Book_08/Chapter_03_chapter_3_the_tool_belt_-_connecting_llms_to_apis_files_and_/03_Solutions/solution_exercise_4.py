
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# tooling_blueprint.py (Modified structure)

import os
import tempfile
from flask import Blueprint
from typing import List, Callable, Optional

# The Blueprint already registers existing tools
tooling_bp = Blueprint('tooling_bp', __name__)

# --- Existing Tools ---

def web_search(query: str) -> str:
    """
    Searches the internet for real-time information based on a query.
    
    Args:
        query: The specific search term (e.g., 'current price of Brent Crude').
        
    Returns:
        A summarized string of the search results.
    """
    # ... existing simulation logic ...
    # Simulating a specific result needed for the orchestration challenge
    if "Brent Crude Oil" in query:
        return "Search results summary: Brent Crude Oil price is currently $85.50 per barrel."
    return f"Search results for: {query}"

def memory_manager(key: str, operation: str, value: str = None) -> str:
    """
    Manages long-term key-value memory stored in a file.
    
    Args:
        key: The key identifier for the memory entry.
        operation: Must be 'save' to store data or 'retrieve' to fetch data.
        value: The data string to save (required if operation='save').
        
    Returns:
        A confirmation message or the retrieved value.
    """
    # ... existing simulation logic ...
    if operation == 'retrieve':
        return f"Retrieved value for {key}."
    elif operation == 'save':
        return f"Memory operation successful: Saved '{value}' to key '{key}'."
    return "Memory operation failed: Invalid operation specified."

# --- New Tool Definition ---

def generate_workflow_diagram(dot_code: str) -> str:
    """
    Generates a visual workflow diagram using Graphviz DOT syntax. 
    
    This is used by the agent to visualize and explain its complex reasoning steps 
    before executing them, aiding in transparency and debugging.

    Args:
        dot_code: A string containing valid Graphviz DOT syntax defining the graph structure.

    Returns:
        A confirmation message with instructions on how to render the diagram.
    """
    # Use a temporary directory to simulate saving the file
    temp_dir = tempfile.gettempdir()
    file_path = os.path.join(temp_dir, 'workflow.dot')
    
    try:
        with open(file_path, 'w') as f:
            f.write(dot_code)
        
        return (f"DOT file saved successfully to {file_path}. "
                f"Use Graphviz CLI to render this diagram: "
                f"`dot -Tpng {file_path} -o workflow.png`")
    except IOError as e:
        return f"Error saving DOT file: {e}"

# --- Blueprint Integration / Tool Registration ---
TOOL_REGISTRY: List[Callable] = [
    web_search, 
    memory_manager,
    generate_workflow_diagram # Successfully integrated the new tool
]

# --- Agent Orchestration Challenge Prompt ---

ORCHESTRATION_PROMPT = """
I need you to perform a three-step task:
1. Find the current market price of 'Brent Crude Oil' using the appropriate tool.
2. Based on the price you found, use the visualization tool to generate a simple workflow diagram (in DOT syntax) that clearly maps the three steps you took to achieve the final goal (Search -> Visualize -> Save).
3. Save the resulting price (e.g., '$85.50') to your long-term memory using the key "CrudePrice".
4. Provide a final summary confirming the price found and the actions taken.

Ensure the DOT code is valid and accurately reflects your three-step plan.
"""

# print(ORCHESTRATION_PROMPT)
# print(f"\nRegistered Tools: {[t.__name__ for t in TOOL_REGISTRY]}")

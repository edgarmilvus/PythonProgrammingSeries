
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio

HIGH_COST_THRESHOLD = 500

def simulate_risk_assessment(cost_estimate):
    """Calculates risk score and checks if intervention is mandatory."""
    risk_score = min(100, int(cost_estimate / 10))
    high_risk_flag = cost_estimate > HIGH_COST_THRESHOLD
    
    return risk_score, cost_estimate, high_risk_flag

async def get_sync_input(prompt):
    return await asyncio.to_thread(input, prompt)

async def await_override_gate(risk_score, cost_estimate, high_risk_flag):
    """Handles the intervention gate, enforcing OVERRIDE for high risk."""
    
    print("\n--- ScaleMaster Intervention Gate ---")
    print(f"ASSESSMENT: Risk Score={risk_score}/100, Cost Estimate=${cost_estimate:.2f}/hour.")
    
    if high_risk_flag:
        print("WARNING: HIGH COST RISK detected. Requires explicit OVERRIDE to proceed.")
    
    while True:
        prompt = "Action (YES/NO/OVERRIDE): "
        user_input = await get_sync_input(prompt)
        command = user_input.strip().upper()
        
        if command == 'NO':
            print("Action rejected. Aborting scale-up.")
            return False, "Aborted by Human"
        
        if high_risk_flag:
            # Conditional Execution: High Risk Path
            if command == 'YES':
                print("Action denied. Cannot proceed with high risk using 'YES'. Use 'OVERRIDE'.")
                continue
            elif command == 'OVERRIDE':
                # Logging the bypass
                log_reason = "Override (High Cost Risk bypassed: $%.2f)" % cost_estimate
                print(f"OVERRIDE command received. {log_reason}")
                return True, log_reason
        
        elif not high_risk_flag: # Low risk scenario
            if command == 'YES' or command == 'OVERRIDE':
                log_reason = "Approved (Low Risk: $%.2f)" % cost_estimate
                print(f"Approval received. Proceeding. {log_reason}")
                return True, log_reason
            
        print(f"Invalid command: {command}. Please try again.")

async def execute_scale_up(log_reason):
    """Simulates scaling action, logging the intervention outcome."""
    print(f"\n--- EXECUTION INITIATED ---")
    print(f"Final Action Log: {log_reason}")
    print("Scaling infrastructure up...")
    await asyncio.sleep(0.1)
    print("Scale-up successful.")

async def main_e3(cost_scenario):
    risk_score, cost, high_risk = simulate_risk_assessment(cost_scenario)
    
    proceed, log_reason = await await_override_gate(risk_score, cost, high_risk)
    
    if proceed:
        await execute_scale_up(log_reason)
    else:
        print("Agent workflow terminated.")

# To test High Cost Override (e.g., cost_scenario=650):
# asyncio.run(main_e3(650)) 

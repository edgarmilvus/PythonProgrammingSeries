
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import time
import sys

TIMEOUT_SECONDS = 15

# Helper function for non-blocking input (run in executor)
async def get_sync_input(prompt):
    # This function blocks the thread it runs in, but not the event loop
    return await asyncio.to_thread(input, prompt)

async def get_timed_input():
    """Waits for human input with a strict timeout using asyncio.wait_for."""
    prompt = f"ACTION REQUIRED ({TIMEOUT_SECONDS}s limit): Enter 'BLOCK' or 'MONITOR': "
    print(f"[{time.strftime('%H:%M:%S')}] Agent waiting for human response...")
    
    # Enforce the timeout here. If input is not received in time, 
    # asyncio.wait_for raises asyncio.TimeoutError.
    user_input = await asyncio.wait_for(
        get_sync_input(prompt), 
        timeout=TIMEOUT_SECONDS
    )
    return user_input.strip().upper()

async def execute_block_rule():
    """Disruptive action taken on approval."""
    print(f"\n[{time.strftime('%H:%M:%S')}] --- EXECUTION: BLOCK ---")
    print("Applying temporary firewall rule to block suspicious IP range.")
    await asyncio.sleep(0.1)

async def timeout_abort_action():
    """Safe default action taken upon timeout."""
    print(f"\n[{time.strftime('%H:%M:%S')}] --- SAFE DEFAULT: MONITOR ---")
    print("LOG EVENT: TIMEOUT_ABORT. Human failed to respond.")
    print("Reverting to monitoring mode and escalating alert via secondary channel.")
    await asyncio.sleep(0.1)

async def main_timed_gate():
    print("FirewallManager Agent: Suspicious traffic detected. Intervention gate triggered.")
    
    try:
        response = await get_timed_input()
        
        if response == 'BLOCK':
            await execute_block_rule()
            
        elif response == 'MONITOR':
            print("Human chose MONITOR. Aborting execution.")
            
        else:
            print(f"Invalid response received: {response}. Defaulting to safe abort.")
            await timeout_abort_action()

    except asyncio.TimeoutError:
        # This is the critical handling block for the Timeout Pattern
        await timeout_abort_action()
    
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        await timeout_abort_action()

# if __name__ == "__main__":
#     # To demonstrate the timeout, run this and wait 16 seconds without typing.
#     asyncio.run(main_timed_gate())

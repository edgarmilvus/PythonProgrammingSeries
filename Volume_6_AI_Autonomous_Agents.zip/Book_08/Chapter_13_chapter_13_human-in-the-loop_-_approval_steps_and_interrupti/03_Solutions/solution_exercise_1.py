
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import asyncio
import sys

# Define agent states
ANALYSIS_COMPLETE = "ANALYSIS_COMPLETE"
AWAITING_APPROVAL = "AWAITING_APPROVAL"
EXECUTION_INITIATED = "EXECUTION_INITIATED"
ACTION_REJECTED = "ACTION_REJECTED"

async def get_sync_input(prompt):
    """Wraps the synchronous input() function in an async context."""
    # asyncio.to_thread runs the blocking input() call in a separate thread,
    # preventing the main event loop from stalling.
    return await asyncio.to_thread(input, prompt)

async def await_human_approval(prompt):
    """Implements the non-blocking mandatory approval gate."""
    print(f"\n--- STATE: {AWAITING_APPROVAL} ---")
    
    while True:
        try:
            # Wait indefinitely for input
            user_response = await asyncio.wait_for(get_sync_input(prompt), timeout=None)
        except Exception:
            # Should not happen in this simple setup, but good practice
            continue

        response = user_response.strip().upper()
        
        if response == 'APPROVE':
            print("Human confirmed: Proceeding.")
            return True
        elif response == 'REJECT':
            print("Human rejected: Aborting.")
            return False
        else:
            print("Invalid input. Please type 'APPROVE' or 'REJECT'.")

async def agent_task_1_analysis():
    """Simulates the analysis phase leading to a proposed action."""
    print(f"--- STATE: {ANALYSIS_COMPLETE} ---")
    proposed_action = {
        "asset": "XYZ",
        "quantity": 1000,
        "price": 50.00,
        "type": "Buy",
    }
    print(f"Proposed Trade: Buy {proposed_action['quantity']} shares of {proposed_action['asset']} at ${proposed_action['price']:.2f}.")
    return proposed_action

async def agent_task_2_execute(approved_action):
    """Simulates the execution phase."""
    print(f"\n--- STATE: {EXECUTION_INITIATED} ---")
    print(f"Executing trade: {approved_action['type']} {approved_action['quantity']} of {approved_action['asset']}.")
    await asyncio.sleep(0.1)
    print("Execution complete.")

async def main_e1():
    print("TradeBot Agent Initializing...")
    
    proposed_action = await agent_task_1_analysis()
    
    prompt = "ACTION REQUIRED: Enter 'APPROVE' or 'REJECT' to confirm trade: "
    
    is_approved = await await_human_approval(prompt)
    
    if is_approved:
        await agent_task_2_execute(proposed_action)
    else:
        print(f"\n--- STATE: {ACTION_REJECTED} ---")
        print("Trade aborted by human operator.")

# Example execution (requires interactive input):
# if __name__ == "__main__":
#     asyncio.run(main_e1())

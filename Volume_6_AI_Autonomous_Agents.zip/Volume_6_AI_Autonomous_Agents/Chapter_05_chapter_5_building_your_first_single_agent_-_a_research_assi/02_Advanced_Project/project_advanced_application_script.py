
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import TavilySearchTool
from dotenv import load_dotenv

# ----------------------------------------------------------------------
# 1. Environment and Tool Configuration
# ----------------------------------------------------------------------
# Load environment variables (OPENAI_API_KEY, TAVILY_API_KEY)
load_dotenv()

# Check for necessary environment variables
if not os.getenv("TAVILY_API_KEY") or not os.getenv("OPENAI_API_KEY"):
    raise ValueError("TAVILY_API_KEY and OPENAI_API_KEY must be set in the .env file.")

# Initialize the primary tool: Internet Search
# Tavily is a specialized search API optimized for LLM use cases.
internet_search_tool = TavilySearchTool()

# ----------------------------------------------------------------------
# 2. Agent Definition (The Persona and Cognitive Core)
# ----------------------------------------------------------------------
# Define the single autonomous agent: Market Research Analyst
market_analyst_agent = Agent(
    role='Senior Market Research Analyst',
    goal='Produce a concise, structured executive brief on a specified emerging technology.',
    backstory=(
        "You are an expert analyst with a decade of experience in competitive intelligence. "
        "Your specialty is synthesizing vast amounts of real-time data into actionable, "
        "highly structured reports suitable for C-suite executives. You prioritize "
        "accuracy, brevity, and clear identification of key market players."
    ),
    tools=[internet_search_tool],
    verbose=True,  # Enables detailed logging of agent thought process
    allow_delegation=False, # Essential for single-agent architecture
    llm=None # Uses the default LLM configured via environment variables
)

# ----------------------------------------------------------------------
# 3. Task Definition (The Mission and Output Specification)
# ----------------------------------------------------------------------
# Define the specific research query
research_topic = "Current trends and major innovations in personalized cancer vaccines"

# Define the task, emphasizing prompt engineering for structured output
research_task = Task(
    description=(
        f"Conduct a comprehensive internet search on the topic: '{research_topic}'. "
        "Synthesize the search results into a formal executive brief. "
        "The output MUST be in Markdown format and strictly adhere to the following structure: "
        "\n\n# Executive Brief: Personalized Cancer Vaccines"
        "\n\n## 1. Market Overview and Current State (Max 250 words)"
        "\n\n## 2. Key Technological Innovations (List 3-5 specific breakthroughs)"
        "\n\n## 3. Top 3 Companies/Research Groups (Identify leaders and summarize their approach)"
        "\n\n## 4. Market Challenges (Identify 2-3 major hurdles to widespread adoption)"
        "\n\n---\n\n"
        "Ensure all data is current (post-2022) and cite sources implicitly by referencing company names or specific research initiatives."
    ),
    expected_output="A single, complete Markdown file following the strict section structure provided.",
    agent=market_analyst_agent
)

# ----------------------------------------------------------------------
# 4. Crew Configuration and Execution
# ----------------------------------------------------------------------
# Initialize the Crew (the orchestration layer)
research_crew = Crew(
    agents=[market_analyst_agent],
    tasks=[research_task],
    process=Process.sequential, # Sequential process is standard for a single agent
    verbose=2, # Highest verbosity for debugging and observation
)

# Execute the research process
print("--- Starting the Autonomous Research Agent ---")
try:
    result = research_crew.kickoff()
    
    # ------------------------------------------------------------------
    # 5. Output Handling
    # ------------------------------------------------------------------
    print("\n\n################################################")
    print("## Research Complete: Final Executive Brief ##")
    print("################################################\n")
    print(result)

    # Optional: Save the output to a file
    with open("executive_brief.md", "w", encoding="utf-8") as f:
        f.write(result)
    print("\n\nOutput saved to executive_brief.md")

except Exception as e:
    print(f"\nAn error occurred during execution: {e}")



#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import time
from functools import wraps

class BudgetExceededError(Exception):
    """Custom exception raised when execution budgets are breached."""
    pass

def enforce_budget(max_steps: int, max_time: float):
    """
    Decorator that enforces step count and time limits on an agent execution method.
    """
    def decorator(func):
        @wraps(func)
        def wrapper(self, iterations: int):
            # 1. Initialize budget tracking
            start_time = time.time()
            self.steps_taken = 0 # Reset steps for this run
            
            # The wrapper takes over the loop logic to enforce checks on every iteration
            try:
                for i in range(iterations):
                    self.steps_taken += 1
                    
                    # 2. Check Step Limit
                    if self.steps_taken > max_steps:
                        raise BudgetExceededError(
                            f"Step limit exceeded: {self.steps_taken} steps taken (Max: {max_steps})"
                        )
                    
                    # 3. Check Time Limit
                    elapsed_time = time.time() - start_time
                    if elapsed_time > max_time:
                        raise BudgetExceededError(
                            f"Time limit exceeded: {elapsed_time:.2f}s elapsed (Max: {max_time:.2f}s)"
                        )
                        
                    print(f"Executing step {self.steps_taken} (Time: {elapsed_time:.2f}s)...")
                    # Simulate tool usage or API latency
                    time.sleep(0.1)
                
                return "Execution completed successfully."
                
            except BudgetExceededError as e:
                # Re-raise the exception for external handling
                raise e
                
        return wrapper
    return decorator

class AgentExecutor:
    def __init__(self):
        self.steps_taken = 0

    @enforce_budget(max_steps=10, max_time=5.0)
    def run_agent_loop(self, iterations: int):
        # The body of this function is replaced by the decorator's wrapper logic, 
        # which incorporates the necessary checks and step tracking.
        pass

# --- Testing Suite ---
executor_benign = AgentExecutor()
print("\n--- Test 1: Benign Run (5 steps) ---")
try:
    print(executor_benign.run_agent_loop(iterations=5))
except BudgetExceededError as e:
    print(f"Error: {e}")

executor_step_rogue = AgentExecutor()
print("\n--- Test 2: Rogue Run - Step Limit Exceeded (Max 10 steps) ---")
try:
    executor_step_rogue.run_agent_loop(iterations=100)
except BudgetExceededError as e:
    print(f"Error: {e}")

# Note: For time limit testing, we define a new decorated method with tight limits
executor_time_rogue = AgentExecutor()
def run_time_test(self, iterations: int): pass # Placeholder function
AgentExecutor.run_time_test = enforce_budget(max_steps=50, max_time=0.3)(run_time_test)

print("\n--- Test 3: Rogue Run - Time Limit Exceeded (Max 0.3s) ---")
try:
    executor_time_rogue.run_time_test(iterations=10) # 10 steps * 0.1s = 1.0s runtime
except BudgetExceededError as e:
    print(f"Error: {e}")

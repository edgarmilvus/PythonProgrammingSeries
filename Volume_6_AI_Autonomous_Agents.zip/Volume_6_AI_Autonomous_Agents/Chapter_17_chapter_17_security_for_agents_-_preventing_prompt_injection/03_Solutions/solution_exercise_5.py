
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import random
from typing import Tuple

class AgentState:
    def __init__(self):
        self.facts_count = 0
        self.avg_confidence = 0.0
        
    def gather_fact(self, confidence: float):
        """Simulates gathering a new fact and updating average confidence."""
        current_total = self.facts_count * self.avg_confidence
        self.facts_count += 1
        self.avg_confidence = (current_total + confidence) / self.facts_count
        
class TerminationChecker:
    REQUIRED_FACTS = 5
    MIN_CONFIDENCE = 0.85

    def should_terminate(self, state: AgentState) -> Tuple[bool, str]:
        """
        Checks domain-specific criteria for successful task completion.
        """
        facts_met = state.facts_count >= self.REQUIRED_FACTS
        confidence_met = state.avg_confidence >= self.MIN_CONFIDENCE
        
        if facts_met and confidence_met:
            return True, "All criteria met: Required facts gathered and confidence threshold reached."
        
        # Build status message detailing unmet criteria
        status_parts = []
        if not facts_met:
            status_parts.append(
                f"Fact count low ({state.facts_count}/{self.REQUIRED_FACTS})."
            )
        if not confidence_met:
            status_parts.append(
                f"Confidence low ({state.avg_confidence:.3f}/{self.MIN_CONFIDENCE:.2f})."
            )
            
        return False, "Still searching. " + " ".join(status_parts)

def run_research_simulation():
    state = AgentState()
    checker = TerminationChecker()
    MAX_STEPS = 20
    
    print("--- Starting Research Simulation ---")
    
    for step in range(MAX_STEPS):
        # Simulate LLM deciding to gather a new piece of information
        # Biased confidence (0.7 to 1.0) ensures successful termination is possible
        new_confidence = random.uniform(0.7, 1.0) 
        state.gather_fact(new_confidence)
        
        terminate, message = checker.should_terminate(state)
        print(f"Step {step+1}: Facts={state.facts_count}, AvgConf={state.avg_confidence:.3f} | Status: {message}")
        
        if terminate:
            print(f"\nSUCCESS: Task completed successfully on step {step+1}.")
            break
    else:
        print("\nFAILURE: Task did not meet termination criteria within the budget.")

run_research_simulation()

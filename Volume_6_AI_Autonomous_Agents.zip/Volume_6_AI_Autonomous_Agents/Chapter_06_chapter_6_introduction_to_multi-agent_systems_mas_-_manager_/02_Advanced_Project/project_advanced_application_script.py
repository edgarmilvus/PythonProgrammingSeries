
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import SerperDevTool # Simulating a search tool

# --- Configuration and Setup ---
# NOTE: Replace with your actual LLM API key setup.
# os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
# os.environ["SERPER_API_KEY"] = "YOUR_SERPER_KEY" 
# Using a placeholder model for demonstration clarity
MODEL_NAME = "gpt-4o-mini" 

# Initialize specialized tools (simulating external research capability)
research_tool = SerperDevTool()

# --- 1. Agent Definitions (Roles and Specialization) ---

# The Strategy Manager Agent: Handles planning, delegation, and final synthesis.
strategy_manager = Agent(
    role='Strategy Manager',
    goal='Decompose the competitive analysis task, manage worker output, and synthesize a unified strategic report.',
    backstory=(
        "You are the Lead Strategist, responsible for high-level planning and final deliverable quality. "
        "You do not perform primary research; you coordinate specialized teams."
    ),
    verbose=True,
    allow_delegation=True, # Critical for the Manager role
    llm=MODEL_NAME
)

# Worker Agent 1: Specializes in pricing and financial models.
pricing_worker = Agent(
    role='Pricing Analyst',
    goal='Analyze the competitor\'s pricing structure, discounts, and subscription tiers.',
    backstory="Expert in market pricing dynamics and financial modeling.",
    tools=[research_tool],
    verbose=True,
    allow_delegation=False,
    llm=MODEL_NAME
)

# Worker Agent 2: Specializes in marketing messaging and public perception.
marketing_worker = Agent(
    role='Marketing Specialist',
    goal='Analyze the competitor\'s messaging tone, target audience, and key marketing channels.',
    backstory="A seasoned digital marketing expert focusing on sentiment and communication strategy.",
    tools=[research_tool],
    verbose=True,
    allow_delegation=False,
    llm=MODEL_NAME
)

# --- 2. Task Definitions (Decomposition) ---

COMPETITOR_PRODUCT = "New AI-powered CRM software called 'AuraFlow'"
ANALYSIS_GOAL = f"Perform a detailed competitive analysis on {COMPETITOR_PRODUCT}."

# Task 1: Pricing Research (Assigned to Worker 1)
pricing_task = Task(
    description=f"Conduct deep research on the pricing of {COMPETITOR_PRODUCT}. Include tiered structures, introductory offers, and comparison to industry benchmarks.",
    expected_output="A concise, bulleted report on pricing strategy and financial viability.",
    agent=pricing_worker
)

# Task 2: Marketing Research (Assigned to Worker 2)
marketing_task = Task(
    description=f"Analyze the public marketing materials for {COMPETITOR_PRODUCT}. Identify the core value proposition, emotional tone, and primary distribution channels used.",
    expected_output="A detailed summary covering messaging, target demographic, and promotional effectiveness.",
    agent=marketing_worker
)

# Task 3: Synthesis and Final Report (Assigned to Manager)
# NOTE: This task implicitly waits for the completion of the worker tasks.
synthesis_task = Task(
    description=(
        f"Using the reports from the Pricing Analyst and Marketing Specialist, synthesize a unified 500-word strategic brief. "
        f"The brief must clearly state the threat level of {COMPETITOR_PRODUCT} and recommend two immediate counter-strategies (one pricing, one marketing)."
    ),
    expected_output="A final, polished strategic brief ready for executive review.",
    agent=strategy_manager,
    context=[pricing_task, marketing_task] # Explicit dependency on worker outputs
)

# --- 3. Crew Setup and Execution (Manager-Worker Hierarchy) ---

# Define the crew with the Manager, Workers, and Tasks.
# Crucially, we use Process.hierarchical to enforce the Manager-Worker pattern.
competitive_crew = Crew(
    agents=[strategy_manager, pricing_worker, marketing_worker],
    tasks=[pricing_task, marketing_task, synthesis_task],
    process=Process.hierarchical, # Enforces Manager-Worker structure
    manager_agent=strategy_manager, # Explicitly defines the top-level orchestrator
    verbose=2
)

# Execute the workflow
print("--- Starting Competitive Analysis MAS Workflow ---")
result = competitive_crew.kickoff()
print("\n\n--- Final Strategic Brief ---")
print(result)


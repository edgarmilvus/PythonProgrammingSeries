
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import tool
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()

# Configuration
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)

# 1. Define a Custom Tool
@tool("Stock Data Fetcher")
def fetch_stock_data(ticker: str) -> str:
    """
    Fetches simulated real-time financial data for a given stock ticker. 
    This simulates an API call to get verifiable, structured data.
    """
    if ticker.upper() == 'MSFT':
        # Simulated data for Microsoft
        return (
            f"Verified Data for MSFT:\n"
            f"Current Price: $425.50\n"
            f"52-Week High: $450.00\n"
            f"52-Week Low: $280.00\n"
            f"P/E Ratio: 38.5\n"
            f"Recent Sentiment Summary: Strong growth in cloud services (Azure) and "
            f"AI integration, but facing regulatory scrutiny in Europe."
        )
    else:
        return f"Verified Data for {ticker}: Data not available."

# 2. Agent Modification and Addition
data_specialist = Agent(
    role='Market Data Specialist',
    goal='Execute the StockDataFetcherTool and provide verified, structured, and sanitized financial data for analysis.',
    backstory=(
        "You are a dedicated data acquisition expert. Your sole focus is precision, "
        "ensuring that all downstream agents receive accurate, tool-verified metrics. "
        "You prevent the crew from using internal, potentially hallucinated, knowledge."
    ),
    tools=[fetch_stock_data], # Tool integration
    verbose=True,
    llm=llm
)

financial_analyst = Agent(
    role='Senior Financial Analyst',
    goal='Generate a comprehensive investment thesis based strictly on the structured data provided by the Market Data Specialist.',
    backstory=(
        "You are a risk assessment expert. Your analysis MUST rely entirely on the "
        "verified metrics presented to you. You focus on interpretation, risk modeling, "
        "and market positioning, not data fetching."
    ),
    verbose=True,
    llm=llm
)

report_writer = Agent(
    role='Executive Report Generator',
    goal='Format the financial analysis into a polished, professional executive summary.',
    backstory="You specialize in clear, concise business communication for high-level stakeholders.",
    verbose=True,
    llm=llm
)

# 3. Task Reordering and Context Flow
ticker_symbol = "MSFT"

task_fetch_data = Task(
    description=f"Use the Stock Data Fetcher tool to retrieve all available data for the ticker: {ticker_symbol}. "
                "Output the raw, structured data exactly as the tool returns it.",
    agent=data_specialist,
    expected_output=f"Structured financial metrics for {ticker_symbol}."
)

task_analysis = Task(
    description="Using ONLY the structured data provided in the context, write a 500-word "
                "investment thesis. Focus on risk (P/E ratio vs. growth) and market sentiment.",
    agent=financial_analyst,
    context=[task_fetch_data], # Analyst relies on the tool's output
    expected_output="A detailed 500-word investment thesis referencing the specific provided data points."
)

task_report = Task(
    description="Take the investment thesis and format it into a concise, 3-paragraph executive summary.",
    agent=report_writer,
    context=[task_analysis],
    expected_output="A final executive summary report."
)

# Crew Configuration and Execution
tool_crew = Crew(
    agents=[data_specialist, financial_analyst, report_writer],
    tasks=[task_fetch_data, task_analysis, task_report],
    process=Process.sequential,
    verbose=2
)

print(f"--- Starting Tool-Integrated Financial Analysis for {ticker_symbol} ---")
final_report = tool_crew.kickoff()
print("\n\n########################################")
print("## FINAL EXECUTIVE REPORT ##")
print(final_report)
print("########################################")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

load_dotenv()

# Configuration
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
pitch_task_description = "Generate a 300-word product pitch for the AI Smart Refrigerator, targeting potential high-value investors."

# --- 1. Crew A: The Visionary Team (Emotion and Future Potential) ---
visionary_director = Agent(
    role='Chief Creative Director',
    goal='Define the emotional core and disruptive potential of the product.',
    backstory=(
        "You are a master storyteller focused on market disruption and aspirational branding. "
        "You believe in selling the future, not just the features. Your expertise is in "
        "crafting narratives that inspire multi-billion dollar valuations."
    ),
    verbose=False, llm=llm
)

futurist = Agent(
    role='Societal Futurist',
    goal='Position the refrigerator as an essential component of the next era of smart living.',
    backstory=(
        "You analyze long-term trends in consumer behavior, environmental impact, and home "
        "automation. You provide high-level context on how this product revolutionizes daily life."
    ),
    verbose=False, llm=llm
)

copywriter_a = Agent(
    role='Aspirational Copywriter',
    goal='Translate the vision into captivating, concise, and emotionally resonant pitch language.',
    backstory=(
        "You specialize in short-form, high-impact copy. You use powerful verbs and evocative "
        "imagery to make the audience feel the necessity of the product."
    ),
    verbose=False, llm=llm
)

task_a = Task(
    description=pitch_task_description,
    agent=copywriter_a,
    context=[visionary_director, futurist], # All contribute to the final pitch
    expected_output="A 300-word visionary product pitch emphasizing transformation and emotional value."
)

crew_a = Crew(
    agents=[visionary_director, futurist, copywriter_a],
    tasks=[task_a],
    process=Process.hierarchical, # Using hierarchical for synthesis/collaboration
    manager_llm=llm,
    verbose=1
)


# --- 2. Crew B: The Pragmatic Team (ROI and Technical Feasibility) ---
technical_architect = Agent(
    role='Chief Technical Architect',
    goal='Detail the technical reliability, implementation plan, and proprietary AI features.',
    backstory=(
        "You are an engineer focused on verifiable metrics, server uptime, and system efficiency. "
        "You prioritize mitigating technical risk and ensuring reliable, cost-effective deployment."
    ),
    verbose=False, llm=llm
)

financial_analyst_b = Agent(
    role='Venture Financial Analyst',
    goal='Quantify the potential market size, cost savings for the consumer, and projected ROI for investors.',
    backstory=(
        "Your focus is the bottom line. You speak in terms of EBITDA, marginal cost reduction, "
        "and market penetration projections. Sentiment is irrelevant; numbers are everything."
    ),
    verbose=False, llm=llm
)

logistics_specialist = Agent(
    role='Supply Chain and Logistics Specialist',
    goal='Address the feasibility of integrating automatic ordering with major grocery supply chains.',
    backstory=(
        "You understand the complexities of inventory management and delivery logistics. "
        "You ensure the pitch addresses the practical, operational challenges of the product."
    ),
    verbose=False, llm=llm
)

task_b = Task(
    description=pitch_task_description,
    agent=financial_analyst_b, # The financial analyst leads the pitch structure
    context=[technical_architect, logistics_specialist],
    expected_output="A 300-word pragmatic product pitch emphasizing ROI, technical stability, and cost-efficiency."
)

crew_b = Crew(
    agents=[technical_architect, financial_analyst_b, logistics_specialist],
    tasks=[task_b],
    process=Process.hierarchical,
    manager_llm=llm,
    verbose=1
)

# 4. Execution and Verification
print("--- Running Crew A (Visionary Pitch) ---")
pitch_a = crew_a.kickoff()

print("\n\n--- Running Crew B (Pragmatic Pitch) ---")
pitch_b = crew_b.kickoff()

print("\n\n########################################")
print("## CREW A: VISIONARY PITCH ##")
print(pitch_a)
print("\n----------------------------------------")
print("## CREW B: PRAGMATIC PITCH ##")
print(pitch_b)
print("########################################")

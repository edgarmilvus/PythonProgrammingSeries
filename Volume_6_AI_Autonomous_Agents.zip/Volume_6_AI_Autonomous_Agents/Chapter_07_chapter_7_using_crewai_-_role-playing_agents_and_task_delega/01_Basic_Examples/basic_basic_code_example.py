
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: basic_basic_code_example.py
# Description: Basic Code Example
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
# NOTE: In a real-world scenario, you would use dotenv or similar 
# to securely load your OPENAI_API_KEY or other required API keys.
# For this educational example, we assume the environment variable 
# is set or the LLM provider is configured correctly.

# --- 1. Define Agents (The Specialized Roles) ---
# Agents are the core actors, defined by their expertise and personality.

# Agent 1: The Researcher
researcher = Agent(
    role='Senior Research Analyst',
    goal='Identify three compelling and little-known facts about the history of Python.',
    backstory=(
        "You are a meticulous, detail-oriented analyst specializing in technology history. "
        "Your primary function is to provide accurate, verified information, free of embellishment. "
        "You always output numbered lists."
    ),
    verbose=True, # Logs the agent's internal monologue (useful for debugging)
    allow_delegation=False # This agent must complete its own task
)

# Agent 2: The Writer
writer = Agent(
    role='Creative Content Strategist',
    goal='Draft an engaging 4-sentence social media post based on the researched facts.',
    backstory=(
        "You are a master of concise, viral content. Your job is to take raw data "
        "and transform it into easily digestible, highly shareable material, including engaging hashtags."
    ),
    verbose=True,
    allow_delegation=False
)

# --- 2. Define Tasks (The Workflow Steps) ---
# Tasks define the specific actions and expected outputs.

# Task 1: Research the core topic. Assigned to the Researcher.
research_task = Task(
    description=(
        "Conduct thorough research on the origin and initial design philosophy of the Python language. "
        "The final output must be three distinct, numbered, verified facts."
    ),
    expected_output="A list of three numbered, verified facts about Python's history, suitable for direct input into a prompt.",
    agent=researcher
)

# Task 2: Write the final content. Assigned to the Writer.
writing_task = Task(
    description=(
        "Using the facts provided in the context, craft a short, punchy social media post. "
        "The post must be under 100 words and include a call-to-action question and three relevant hashtags."
    ),
    expected_output="A single, cohesive social media post formatted for Twitter/X or LinkedIn.",
    agent=writer,
    context=[research_task] # CRITICAL: This links the workflow, injecting Task 1's output here
)

# --- 3. Form the Crew (The Management Structure) ---

# Initialize the Crew with the defined agents and tasks
project_crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, writing_task],
    process=Process.sequential, # Ensures Task 1 completes before Task 2 begins
    verbose=2 # Maximum verbosity: logs the crew's execution flow and agent thoughts
)

# --- 4. Execute the Workflow ---

print("### Starting the Content Creation Crew ###")
# The kickoff method starts the execution process
result = project_crew.kickoff()

# --- 5. Display Final Output ---
print("\n\n########################################")
print("## CREW EXECUTION COMPLETED ##")
print("########################################")
print(f"\nFinal Social Media Post:\n{result}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from crewai import Agent, Task, Crew, Process
from crewai_tools import SerperDevTool # Tool for real-time web access

# --- 1. Environment and Tool Setup ---

# IMPORTANT: In a real environment, set these environment variables:
# os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"
# os.environ["SERPER_API_KEY"] = "YOUR_SERPER_API_KEY"

# Initialize the search tool. This allows the research agent to access current web data.
try:
    search_tool = SerperDevTool()
except Exception as e:
    # This warning helps the user debug environment setup issues
    print(f"Warning: SerperDevTool initialization failed. Ensure SERPER_API_KEY is set. Error: {e}")
    
# Define the core input topic for the entire project
PROJECT_TOPIC = "The rise of personalized medicine powered by generative AI and large language models."

# --- 2. Defining Specialized Agents (Role-Playing) ---

# Agent 1: The Researcher (Fact Gatherer)
research_analyst = Agent(
    role='Senior AI Trend Research Analyst',
    goal=f'Conduct comprehensive, up-to-date research on {PROJECT_TOPIC} and synthesize key findings.',
    backstory=(
        "You are a meticulous analyst working for a specialized tech marketing firm. "
        "Your expertise lies in quickly identifying emerging technologies, validating their market impact, "
        "and distilling complex technical white papers into digestible, strategic summaries. "
        "You always focus on the 'why it matters' for a non-technical audience."
    ),
    tools=[search_tool],
    verbose=True,
    allow_delegation=False # Must complete the research independently
)

# Agent 2: The Strategist (Creative Translator)
content_strategist = Agent(
    role='Social Media Content Strategist',
    goal='Translate complex research findings into three compelling, platform-specific social media campaign hooks.',
    backstory=(
        "You are a creative mastermind specializing in translating deep tech trends into viral content. "
        "You understand platform dynamics (Twitter, LinkedIn, Instagram) and know exactly how to frame "
        "a scientific finding as an engaging story or a provocative question. Your output must be actionable."
    ),
    verbose=True,
    allow_delegation=False # Focus on creative synthesis based on provided facts
)

# Agent 3: The Executive (Reviewer and Planner)
marketing_executive = Agent(
    role='Chief Marketing Officer (CMO) and Strategy Reviewer',
    goal='Review the content strategy and formulate a final, actionable deployment plan with target KPIs.',
    backstory=(
        "You are the CMO, responsible for budget and final execution. You review strategies for business "
        "viability, alignment with client goals, and measurable success metrics (KPIs). "
        "Your final output is the go/no-go decision and the deployment framework."
    ),
    verbose=True,
    allow_delegation=True # Can delegate back to the researcher if facts are missing
)

# --- 3. Defining Tasks and Sequential Delegation Flow ---

# Task 1: Research and Summary (Output feeds Agent 2)
research_task = Task(
    description=f"Using the search tool, find the top 5 recent developments (last 12 months) related to {PROJECT_TOPIC}. "
                "Summarize these findings into a concise 500-word report, highlighting the most disruptive aspect "
                "that would appeal to technology investors and healthcare professionals.",
    expected_output="A 500-word structured report detailing 5 key trends in AI personalized medicine.",
    agent=research_analyst
)

# Task 2: Strategy Generation (Input from Task 1, Output feeds Agent 3)
strategy_task = Task(
    description="Based *only* on the research report provided by the Research Analyst, "
                "generate three distinct social media hooks (one for LinkedIn, one for Twitter, one for Instagram). "
                "Each hook must include a suggested visual concept and a clear call-to-action (CTA).",
    expected_output="A structured list of 3 social media hooks (LinkedIn, Twitter, Instagram), including CTA and visual concepts.",
    agent=content_strategist,
    context=[research_task] # CRITICAL: Passes the output of Task 1 to Task 2
)

# Task 3: Final Review and Deployment Plan (Input from Task 2)
review_task = Task(
    description="Review the three proposed social media hooks. Evaluate their market suitability and assign a "
                "specific Key Performance Indicator (KPI) to each platform (e.g., LinkedIn: '15% CTR', Twitter: '500 impressions'). "
                "Produce a final Campaign Deployment Plan document.",
    expected_output="A final 'Campaign Deployment Plan' document detailing the reviewed strategy, platform-specific KPIs, and a launch timeline recommendation.",
    agent=marketing_executive,
    context=[strategy_task] # CRITICAL: Passes the output of Task 2 to Task 3
)

# --- 4. Forming and Running the Crew ---

# Define the crew using the sequential process model
project_crew = Crew(
    agents=[research_analyst, content_strategist, marketing_executive],
    tasks=[research_task, strategy_task, review_task],
    process=Process.sequential, # Tasks run strictly one after the other
    verbose=2 # Verbosity level 2 shows the internal reasoning of the agents
)

print("--- Starting Collaborative Marketing Strategy Crew ---")
print(f"Project Topic: {PROJECT_TOPIC}\n")

# Execute the workflow and capture the final output
campaign_result = project_crew.kickoff()

# Output the final result
print("\n=======================================================")
print("              FINAL CAMPAIGN DEPLOYMENT PLAN           ")
print("=======================================================")
print(campaign_result)

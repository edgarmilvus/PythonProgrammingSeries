
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import uuid
import asyncio
from fastapi import FastAPI, status
from pydantic import BaseModel, Field
from fastapi.responses import JSONResponse

# --- 1. Schemas ---
class ResearchRequest(BaseModel):
    query: str = Field(..., description="The complex research question for the agent.")

class EnqueueResponse(BaseModel):
    job_id: str
    status: str
    message: str

# --- 2. Job Enqueue Function ---
def enqueue_agent_job(task_payload: ResearchRequest) -> str:
    """Simulates placing a task onto a message queue and initiating a background worker."""
    job_id = str(uuid.uuid4())
    print(f"--- QUEUE MOCK --- Job {job_id[:8]} enqueued.")
    
    # Crucial step: Start the worker task in the background without awaiting it.
    # This simulates the queue system picking up the job asynchronously.
    asyncio.create_task(research_worker(job_id, task_payload.dict()))
    
    return job_id

# --- 3. Worker Simulation ---
async def research_worker(job_id: str, payload: dict):
    """Simulates the long-running agent execution (2 minutes)."""
    print(f"[WORKER {job_id[:8]}] Starting intensive research job for query: {payload['query'][:20]}...")
    
    # Simulate 120 seconds of computation, exceeding typical HTTP timeout limits.
    await asyncio.sleep(120) 
    
    print(f"[WORKER {job_id[:8]}] Research job completed and results stored.")

# --- 4. FastAPI Application Setup ---
app = FastAPI(title="Asynchronous Agent Deployer")

# --- 5. API Endpoint Definition ---
@app.post("/api/v1/run_research", response_model=EnqueueResponse, status_code=status.HTTP_202_ACCEPTED)
async def run_research_endpoint(request_data: ResearchRequest):
    """
    Accepts a long-running request, enqueues it, and immediately returns 202 Accepted.
    """
    job_id = enqueue_agent_job(request_data)
    
    # Return 202 status immediately, confirming acceptance but not completion.
    return EnqueueResponse(
        job_id=job_id,
        status="ACCEPTED",
        message="Task accepted and submitted to the asynchronous queue. Use the job_id to poll for results."
    )

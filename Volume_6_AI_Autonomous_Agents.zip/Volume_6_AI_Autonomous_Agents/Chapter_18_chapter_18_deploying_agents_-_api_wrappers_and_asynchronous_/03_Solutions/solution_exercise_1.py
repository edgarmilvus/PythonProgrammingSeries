
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import uuid
import json
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

# 1. Define custom exceptions for the agent
class InvalidPayloadError(Exception):
    """Custom exception raised by the agent when input is invalid."""
    pass

# 2. Define Pydantic Schemas
class ValidationRequest(BaseModel):
    user_id: uuid.UUID = Field(..., description="Unique ID of the user initiating the request.")
    data_payload: dict = Field(..., description="The structured data to be validated by the agent.")

class ValidationResponse(BaseModel):
    is_valid: bool
    reasoning: str

# 3. Agent Simulation Placeholder
def run_input_validation_agent(user_id: uuid.UUID, data_payload: dict) -> ValidationResponse:
    """Simulates a quick, synchronous agent validation task."""
    
    # Check for the forbidden keyword
    payload_str = json.dumps(data_payload).upper()
    if "FORBIDDEN" in payload_str:
        # Intentionally raise the custom exception
        raise InvalidPayloadError(f"Payload contains forbidden content for user: {user_id}")
    
    # Simulate a successful validation path
    if len(data_payload.keys()) < 5:
        return ValidationResponse(is_valid=True, reasoning="Input passed all quick deterministic checks.")
    else:
        return ValidationResponse(is_valid=False, reasoning="Input payload is structurally too complex.")

# 4. FastAPI Application Setup
app = FastAPI(title="Quick Agent API Wrapper")

# 5. Exception Handler Setup
@app.exception_handler(InvalidPayloadError)
async def invalid_payload_exception_handler(request: Request, exc: InvalidPayloadError):
    """Handles custom agent exceptions and returns a structured 400 Bad Request."""
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={"detail": "Input Validation Failed", "reason": str(exc)},
    )

# 6. API Endpoint Definition
@app.post("/api/v1/validate_input", response_model=ValidationResponse, status_code=200)
async def validate_input_endpoint(request_data: ValidationRequest):
    """
    Endpoint for quick agent tasks. Input validation is handled automatically by Pydantic.
    """
    # FastAPI runs synchronous functions in a threadpool automatically, 
    # preventing blocking the main event loop, even within an async def.
    result = run_input_validation_agent(
        user_id=request_data.user_id,
        data_payload=request_data.data_payload
    )
    return result


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from pydantic import BaseModel, Field
from openai import OpenAI
from typing import List

# --- 1. Configuration and Definitions ---

# Define the model used for analysis (chosen for its balance of capability and low cost)
MODEL_NAME = "gpt-3.5-turbo-0125"
# Simplified cost constants (based on typical current pricing per 1M tokens)
INPUT_COST_PER_MILLION = 0.50  # $0.50 per million input tokens
OUTPUT_COST_PER_MILLION = 1.50 # $1.50 per million output tokens

class MarketSummary(BaseModel):
    """Structured output schema for guaranteed extraction of key metrics."""
    key_sentiment: str = Field(description="Overall sentiment (Positive, Negative, Mixed).")
    top_pain_point: str = Field(description="The single most common complaint or issue identified.")
    actionable_recommendations: List[str] = Field(description="3-5 specific, concise actions derived from the feedback.")
    token_optimization_status: bool = Field(description="Always True if the input context was successfully compressed.")

def calculate_cost(usage):
    """Calculates the estimated dollar cost based on token usage statistics."""
    # Ensure usage object has required attributes for robust calculation
    input_tokens = getattr(usage, 'prompt_tokens', 0)
    output_tokens = getattr(usage, 'completion_tokens', 0)
    
    input_cost = (input_tokens / 1_000_000) * INPUT_COST_PER_MILLION
    output_cost = (output_tokens / 1_000_000) * OUTPUT_COST_PER_MILLION
    return input_cost + output_cost

# --- 2. Simulated Inputs ---

# Simulate a very long, verbose, and repetitive raw feedback document (often exceeding 1000 tokens)
RAW_FEEDBACK = """
The new application interface is incredibly confusing. I spent nearly 45 minutes trying to find the settings menu, and even then, the labels were not intuitive. 
Many users, including myself, have experienced significant latency issues during peak hours, specifically between 2 PM and 5 PM EST. This needs immediate attention. 
However, the customer support team was outstanding—fast response times and very helpful resolution. 
The pricing structure, while generally fair, is slightly too complex for small businesses; a simplified tier would be better. 
I also noticed that the mobile app crashes frequently when attempting to upload large files, which is a major blocker for my workflow. 
Overall, the core functionality is strong, but the user experience (UX) is severely lacking. 
We need better documentation and clearer tooltips. The search feature is completely broken, returning irrelevant results consistently. 
This document is intentionally verbose to simulate real-world, messy, long-form data requiring compression. 
The main complaints are UX, latency, and mobile stability. The positive is customer service. The overall tone is frustrated but hopeful.
"""

# --- 3. Agent Execution Function (Optimized Flow) ---

def execute_optimized_analysis(raw_text: str):
    """
    Executes a two-step analysis process: Context Compression followed by Structured Extraction.
    This minimizes the token count sent to the expensive structured output step.
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    # Initialize a dictionary to track accumulated usage across all steps
    total_usage = {"prompt_tokens": 0, "completion_tokens": 0}
    
    # --- Step A: Context Compression (Token Trimming) ---
    print("--- 1. Context Compression Phase (Input Optimization) ---")
    compression_prompt = (
        f"Condense the following verbose market feedback into a concise, professional summary "
        f"of no more than 150 words, focusing only on key sentiments, pain points, and core recommendations:\n\n{raw_text}"
    )
    
    # Execute compression call (simple, fast, unstructured output)
    compression_response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[{"role": "user", "content": compression_prompt}],
        temperature=0.1
    )
    
    compressed_summary = compression_response.choices[0].message.content
    usage_step_a = compression_response.usage
    
    # Log and accumulate usage statistics for Step A
    total_usage['prompt_tokens'] += usage_step_a.prompt_tokens
    total_usage['completion_tokens'] += usage_step_a.completion_tokens
    
    print(f"Initial Raw Context Tokens: {usage_step_a.prompt_tokens}")
    print(f"Compressed Summary Tokens Used: {usage_step_a.completion_tokens}")
    print("-" * 30)
    
    # --- Step B: Structured Extraction (Using Compressed Context) ---
    print("--- 2. Structured Extraction Phase (Output Optimization) ---")
    
    # The extraction prompt now uses the significantly shorter, compressed summary
    extraction_prompt = (
        "Analyze the following compressed market summary and extract the requested structured data. "
        "Ensure the 'token_optimization_status' field is set to True."
        f"\n\nCOMPRESSED SUMMARY:\n{compressed_summary}"
    )

    # Use response_model (Pydantic) for guaranteed structured output, minimizing token waste from retries
    extraction_response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[{"role": "user", "content": extraction_prompt}],
        response_model=MarketSummary, # CRITICAL: Structured output optimization
        temperature=0.0 # Low temperature for deterministic extraction
    )

    usage_step_b = extraction_response.usage

    # Log and accumulate usage statistics for Step B
    total_usage['prompt_tokens'] += usage_step_b.prompt_tokens
    total_usage['completion_tokens'] += usage_step_b.completion_tokens

    # --- 4. Reporting and Output ---
    
    # Convert accumulated usage dictionary back to a simple object for the cost function
    FinalUsage = type('FinalUsage', (object,), total_usage)
    total_cost = calculate_cost(FinalUsage)
    
    # Convert the structured response back to a dictionary for display
    extracted_data = json.loads(extraction_response.model_dump_json())
    
    print(f"Extraction Prompt Tokens (Optimized Context): {usage_step_b.prompt_tokens}")
    print(f"Structured Output Tokens: {usage_step_b.completion_tokens}")
    print("-" * 30)
    
    print("\n--- Final Structured Output ---")
    print(json.dumps(extracted_data, indent=4))
    print("\n--- Economic Report (Accumulated) ---")
    print(f"Total Prompt Tokens (Input Cost): {FinalUsage.prompt_tokens}")
    print(f"Total Completion Tokens (Output Cost): {FinalUsage.completion_tokens}")
    print(f"Estimated Total Cost: ${total_cost:.5f}")

# --- 5. Execution ---
if __name__ == "__main__":
    if not os.getenv("OPENAI_API_KEY"):
        print("ERROR: OPENAI_API_KEY environment variable not set. Please configure your environment.")
    else:
        execute_optimized_analysis(RAW_FEEDBACK)

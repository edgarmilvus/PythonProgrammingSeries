
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import hashlib
import json
import asyncio
from typing import Dict, Any, Optional

# --- 2. Asynchronous Caching Interface ---
class CacheClient:
    """Mock asynchronous caching client (in-memory dictionary)."""
    def __init__(self):
        self._cache: Dict[str, Any] = {}
        self._ttl: Dict[str, float] = {}

    async def get(self, key: str) -> Optional[str]:
        """Retrieves a value if not expired."""
        if key in self._cache and self._ttl[key] > asyncio.get_event_loop().time():
            return self._cache[key]
        return None

    async def set(self, key: str, value: str, ttl: int):
        """Stores a value with a Time-To-Live (TTL)."""
        expiration_time = asyncio.get_event_loop().time() + ttl
        self._cache[key] = value
        self._ttl[key] = expiration_time
        print(f"[Cache SET] Key stored with TTL of {ttl}s.")

# --- 3. Prompt Hashing Utility ---
def hash_prompt(prompt_payload: List[Dict[str, str]]) -> str:
    """Generates a stable SHA-256 hash from the prompt payload."""
    # Ensure stable serialization by sorting keys and using standard JSON separators
    serialized_payload = json.dumps(prompt_payload, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(serialized_payload.encode('utf-8')).hexdigest()

# --- Agent Class ---
class ResearchAgent:
    """A hypothetical agent using an injected cache client."""
    
    def __init__(self, cache_client: CacheClient):
        self.cache_client = cache_client
        self.token_usage = 0

    async def _call_llm_api(self, prompt_payload: List[Dict[str, str]]) -> str:
        """Simulates the expensive LLM API call."""
        print("    [LLM API CALL] Executing expensive network request...")
        await asyncio.sleep(0.5) # Simulate latency
        self.token_usage += 1000 # Simulate token consumption
        
        # Generate a unique response based on the prompt hash
        prompt_hash = hash_prompt(prompt_payload)[:8]
        return f"Response for query hash: {prompt_hash}. Generated at {datetime.now().isoformat()}"

    async def execute_query(self, prompt_payload: List[Dict[str, str]]) -> str:
        """Core execution loop with caching integration."""
        
        # 1. Generate Cache Key
        cache_key = hash_prompt(prompt_payload)
        
        # 2. Attempt to retrieve from cache
        cached_result = await self.cache_client.get(cache_key)
        
        if cached_result:
            # Cache Hit
            print(f"    [CACHE HIT] Returning cached result for key {cache_key[:10]}...")
            return cached_result
        else:
            # Cache Miss: Proceed with LLM call
            print(f"    [CACHE MISS] Key {cache_key[:10]} not found. Calling LLM.")
            llm_response = await self._call_llm_api(prompt_payload)
            
            # 4. Store result in cache (TTL=1 hour)
            await self.cache_client.set(cache_key, llm_response, ttl=3600)
            return llm_response

# --- 1. Application Factory Modification ---
def create_research_agent(config: Dict[str, Any], cache_client: CacheClient) -> ResearchAgent:
    """Factory function injecting dependencies, including the cache client."""
    print("Factory: Creating ResearchAgent and injecting CacheClient.")
    # Configuration logic (omitted for brevity)
    return ResearchAgent(cache_client=cache_client)

# --- Demonstration ---
async def main_caching_simulation():
    # Initialize the mock cache client
    cache = CacheClient()
    
    # Create the agent using the factory
    agent = create_research_agent({}, cache)
    
    # Define an identical prompt payload
    query_payload = [
        {"role": "system", "content": "You are a data extractor."},
        {"role": "user", "content": "What are the three main benefits of asynchronous programming?"}
    ]
    
    print("\n--- RUN 1: Cache Miss ---")
    start_time = time.time()
    result_1 = await agent.execute_query(query_payload)
    latency_1 = time.time() - start_time
    print(f"Result 1: {result_1[:40]}...")
    print(f"Latency 1: {latency_1:.2f}s | Tokens Used: {agent.token_usage}")
    
    print("\n--- RUN 2: Cache Hit (Identical Query) ---")
    start_time = time.time()
    result_2 = await agent.execute_query(query_payload)
    latency_2 = time.time() - start_time
    print(f"Result 2: {result_2[:40]}...")
    print(f"Latency 2: {latency_2:.2f}s | Tokens Used: {agent.token_usage} (No change)")
    
    # Verify that the results are identical and the second run was faster
    assert result_1 == result_2
    assert latency_2 < latency_1

if __name__ == '__main__':
    asyncio.run(main_caching_simulation())

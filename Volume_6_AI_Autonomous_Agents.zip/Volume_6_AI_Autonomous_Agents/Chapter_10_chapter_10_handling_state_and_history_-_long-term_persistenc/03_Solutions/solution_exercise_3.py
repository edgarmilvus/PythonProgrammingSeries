
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import os
import aiosqlite
import asyncio
import datetime

# --- Configuration and State Classes ---
STATE_FILE = "hybrid_agent_state.json"
DB_NAME_HYBRID = "hybrid_agent_logs.db"

class ToolUsageTracker:
    """High-level, serializable state for tool usage metrics."""
    def __init__(self, total_api_calls=0, last_successful_tool="None"):
        self.total_api_calls = total_api_calls
        self.last_successful_tool = last_successful_tool

    def to_dict(self):
        return self.__dict__

class AsyncHistoryManagerHybrid:
    """Database manager with updated schema for tool logging."""
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = None

    async def __aenter__(self):
        self.conn = await aiosqlite.connect(self.db_path)
        await self._setup_table()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.conn:
            await self.conn.close()
        return False

    async def _setup_table(self):
        # Updated schema: added tool_used and tool_output columns
        await self.conn.execute("""
            CREATE TABLE IF NOT EXISTS conversation_history (
                timestamp TEXT PRIMARY KEY,
                role TEXT NOT NULL,
                content TEXT,
                tool_used TEXT NULL,
                tool_output TEXT NULL
            );
        """)
        await self.conn.commit()

    async def log_tool_execution(self, log_data: dict):
        timestamp = datetime.datetime.now().isoformat()
        await self.conn.execute(
            "INSERT INTO conversation_history (timestamp, role, content, tool_used, tool_output) VALUES (?, ?, ?, ?, ?)",
            (timestamp, log_data.get('role'), log_data.get('content'), log_data.get('tool_used'), log_data.get('tool_output'))
        )
        await self.conn.commit()

# --- Hybrid Persistence Manager ---

class AgentPersistenceManager:
    def __init__(self, state_filepath: str, db_filepath: str):
        self.state_filepath = state_filepath
        self.history_manager = AsyncHistoryManagerHybrid(db_filepath)

    async def save_agent_state(self, tracker: ToolUsageTracker, pending_tool_logs: list):
        """Coordinated save: JSON serialization followed by asynchronous DB logging."""
        print("\n[Save Routine] Starting coordinated save...")
        
        # 1. Serialize high-level state (Blocking File I/O)
        try:
            with open(self.state_filepath, 'w') as f:
                json.dump(tracker.to_dict(), f, indent=4)
            print("1. Tracker state saved (JSON).")
        except IOError as e:
            print(f"Error saving state file: {e}")

        # 2. Flush detailed tool logs (Asynchronous DB I/O)
        async with self.history_manager:
            for log in pending_tool_logs:
                await self.history_manager.log_tool_execution(log)
        print("2. Tool logs flushed (SQLite).")
        
    async def load_agent_state(self) -> ToolUsageTracker:
        """Coordinated load: loads high-level state from JSON."""
        try:
            with open(self.state_filepath, 'r') as f:
                data = json.load(f)
            return ToolUsageTracker(**data)
        except FileNotFoundError:
            return ToolUsageTracker()
        except json.JSONDecodeError:
            return ToolUsageTracker()

# --- Demonstration ---
async def hybrid_main():
    if os.path.exists(STATE_FILE): os.remove(STATE_FILE)
    if os.path.exists(DB_NAME_HYBRID): os.remove(DB_NAME_HYBRID)

    manager = AgentPersistenceManager(STATE_FILE, DB_NAME_HYBRID)
    tracker_1 = ToolUsageTracker()

    # Simulate operations
    tracker_1.total_api_calls = 3
    tracker_1.last_successful_tool = "Calculator"

    tool_logs = [
        {"tool_used": "WebSearch", "tool_output": "Success", "content": "Search query", "role": "tool_input"},
        {"tool_used": "Calculator", "tool_output": "42", "content": "Calculation input", "role": "tool_input"}
    ]

    await manager.save_agent_state(tracker_1, tool_logs)

    # Load and verify
    tracker_2 = await manager.load_agent_state()
    print(f"\nLoaded API calls: {tracker_2.total_api_calls}")
    
    # Verify database content
    async with manager.history_manager as hist:
        cursor = await hist.conn.execute("SELECT tool_used, tool_output FROM conversation_history WHERE tool_used IS NOT NULL")
        logs = await cursor.fetchall()
        print(f"Verified tool log entries: {logs}")

if __name__ == '__main__':
    try:
        asyncio.run(hybrid_main())
    finally:
        if os.path.exists(STATE_FILE): os.remove(STATE_FILE)
        if os.path.exists(DB_NAME_HYBRID): os.remove(DB_NAME_HYBRID)

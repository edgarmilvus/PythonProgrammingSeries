
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import asyncio
import json
import os
import aiosqlite
import time
from typing import List, Dict

# --- Configuration and Mock Classes (Reused/Simplified) ---
STATE_FILE_CONCURRENT = "concurrent_state.json"
DB_NAME_CONCURRENT = "concurrent_logs.db"

class ToolUsageTracker:
    def __init__(self, total_api_calls=0):
        self.total_api_calls = total_api_calls
    def to_dict(self):
        return self.__dict__

class AsyncHistoryManagerMock:
    """Simplified manager for concurrency test setup."""
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = None

    async def __aenter__(self):
        self.conn = await aiosqlite.connect(self.db_path)
        await self.conn.execute("CREATE TABLE IF NOT EXISTS logs (data TEXT);")
        await self.conn.commit()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.conn:
            await self.conn.close()

    async def flush_logs(self, logs_data: list):
        """Simulates high latency database I/O."""
        print(f"  [DB Task] Starting database flush for {len(logs_data)} logs (Simulated 2s wait)...")
        await asyncio.sleep(2) 
        
        for log in logs_data:
            await self.conn.execute("INSERT INTO logs (data) VALUES (?)", (json.dumps(log),))
        await self.conn.commit()
        print("  [DB Task] Database flush complete.")
        return "DB Flush Success"

# --- Concurrent Persistence Manager ---

class AgentPersistenceManagerConcurrent:
    def __init__(self, state_filepath: str, db_filepath: str):
        self.state_filepath = state_filepath
        self.history_manager = AsyncHistoryManagerMock(db_filepath)

    async def save_state_to_file(self, state_data: dict):
        """Task 1: File I/O (Simulated 1s latency)."""
        print("  [File Task] Starting state serialization (Simulated 1s wait)...")
        await asyncio.sleep(1) 
        
        # In a real app, blocking I/O should run via run_in_executor, 
        # but here we use open() directly for simplicity of demonstration.
        with open(self.state_filepath, 'w') as f:
            json.dump(state_data, f, indent=4)
        
        print(f"  [File Task] State file saved to {self.state_filepath}")
        return "File Save Success"

    async def flush_logs_to_db(self, logs_data: list):
        """Task 2: Asynchronous database I/O."""
        async with self.history_manager as hist:
            return await hist.flush_logs(logs_data)

    async def save_all_concurrently(self, tracker: ToolUsageTracker, pending_tool_logs: list):
        start_time = time.time()
        state_data = tracker.to_dict()

        print("\n--- Starting Concurrent Checkpoint (TaskGroup) ---")
        
        try:
            # Use TaskGroup to execute tasks in parallel
            async with asyncio.TaskGroup() as tg:
                file_task = tg.create_task(self.save_state_to_file(state_data))
                db_task = tg.create_task(self.flush_logs_to_db(pending_tool_logs))
            
            # The code only reaches here if ALL tasks succeeded
            print(f"Results: File={file_task.result()}, DB={db_task.result()}")
            print("--- TaskGroup exited cleanly. Checkpoint successful. ---")
            
        except* Exception as eg:
            # TaskGroup wraps multiple exceptions in an ExceptionGroup
            print(f"\n!!! TaskGroup detected {len(eg.exceptions)} concurrent error(s) !!!")
            # The TaskGroup guarantees cancellation of siblings upon first failure
            raise # Re-raise the ExceptionGroup

        end_time = time.time()
        print(f"Total execution time: {end_time - start_time:.2f} seconds.")

# --- Demonstration of Concurrency and Failure ---
async def concurrent_main():
    if os.path.exists(STATE_FILE_CONCURRENT): os.remove(STATE_FILE_CONCURRENT)
    if os.path.exists(DB_NAME_CONCURRENT): os.remove(DB_NAME_CONCURRENT)

    manager = AgentPersistenceManagerConcurrent(STATE_FILE_CONCURRENT, DB_NAME_CONCURRENT)
    tracker = ToolUsageTracker(total_api_calls=100)
    logs = [{"id": i} for i in range(3)]

    # 1. Successful Concurrent Run: Should take ~2 seconds (max of 1s and 2s tasks)
    await manager.save_all_concurrently(tracker, logs)
    
    # 2. Simulated Failure Run demonstrating cancellation
    async def failing_save_state_to_file(state_data):
        await asyncio.sleep(0.5)
        print("  [File Task] Simulating IOError (Failure)...")
        raise IOError("Disk full or permission denied.")

    async def long_running_db_task(logs_data):
        print("  [DB Task] Starting long DB operation (2s sleep)...")
        await asyncio.sleep(2) 
        print("  [DB Task] Completed (Should have been cancelled!).") # This line should not print

    print("\n--- Testing Structured Error Handling and Cancellation ---")
    try:
        async with asyncio.TaskGroup() as tg:
            tg.create_task(failing_save_state_to_file(tracker.to_dict()))
            tg.create_task(long_running_db_task(logs))
    except* IOError as eg:
        # Catch the specific exception group containing the IOError
        print("\nSuccessfully caught IOError via TaskGroup ExceptionGroup.")
        print("Verification: The long DB task was automatically cancelled.")
    except Exception as e:
        print(f"Unexpected error: {e}")

if __name__ == '__main__':
    try:
        asyncio.run(concurrent_main())
    except ExceptionGroup:
        # Catch the propagated ExceptionGroup from the failure test
        pass
    finally:
        if os.path.exists(STATE_FILE_CONCURRENT): os.remove(STATE_FILE_CONCURRENT)
        if os.path.exists(DB_NAME_CONCURRENT): os.remove(DB_NAME_CONCURRENT)

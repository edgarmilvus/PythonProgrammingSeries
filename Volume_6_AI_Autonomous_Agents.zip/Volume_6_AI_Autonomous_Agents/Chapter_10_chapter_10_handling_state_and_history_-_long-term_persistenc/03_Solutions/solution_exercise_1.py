
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import json
import os

class AgentState:
    """Tracks critical, mutable internal variables for an agent."""
    def __init__(self, turn_count: int = 0, last_user_id: str = "N/A", internal_flags: dict = None):
        self.turn_count = turn_count
        self.last_user_id = last_user_id
        self.internal_flags = internal_flags if internal_flags is not None else {"is_active": True, "needs_reset": False}

    def to_dict(self) -> dict:
        """Converts the instance attributes to a serializable dictionary."""
        return self.__dict__

    def save_state(self, filepath: str):
        """
        Saves the current state to a JSON file.
        JSON is chosen for its human readability and cross-platform compatibility,
        making it easy to inspect checkpoints without requiring Python's pickle module.
        """
        try:
            with open(filepath, 'w') as f:
                json.dump(self.to_dict(), f, indent=4)
            print(f"State saved successfully to {filepath}")
        except IOError as e:
            print(f"Error saving state: {e}")

    @staticmethod
    def load_state(filepath: str):
        """
        Loads the state from a JSON file. If the file is not found or corrupted,
        a newly initialized AgentState instance is returned.
        """
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            print(f"State loaded successfully from {filepath}")
            # Use dictionary unpacking to initialize the class instance
            return AgentState(**data)
        except (FileNotFoundError, json.JSONDecodeError):
            print(f"State file not found or corrupted at {filepath}. Initializing new state.")
            return AgentState()

# --- Testing Protocol ---
FILE_PATH = "agent_state_checkpoint.json"

# 1. Initial run (file doesn't exist)
if os.path.exists(FILE_PATH):
    os.remove(FILE_PATH)
agent_1 = AgentState.load_state(FILE_PATH)

# 2. Modify and Save
agent_1.turn_count += 5
agent_1.last_user_id = "user_42"
agent_1.internal_flags["needs_reset"] = True
agent_1.save_state(FILE_PATH)

# 3. Simulate system restart (delete in-memory instance)
del agent_1

# 4. Load saved state and confirm values
agent_2 = AgentState.load_state(FILE_PATH)
print(f"Verification: Loaded Turn Count={agent_2.turn_count}")

# Cleanup
if os.path.exists(FILE_PATH):
    os.remove(FILE_PATH)

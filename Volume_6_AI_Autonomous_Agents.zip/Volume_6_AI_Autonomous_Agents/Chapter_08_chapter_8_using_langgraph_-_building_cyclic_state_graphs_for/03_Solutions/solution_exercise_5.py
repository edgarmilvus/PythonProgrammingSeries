
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
import random
import string

# 1. Define the State Schema (TypedDict)
class ContentState(TypedDict):
    # Required minimum character length for the final copy
    target_length: int
    # The accumulated output string
    current_copy: str
    # Iteration count to prevent runaway loops
    iteration: int

# Helper function to generate random text
def generate_random_text(min_len, max_len):
    length = random.randint(min_len, max_len)
    return ''.join(random.choices(string.ascii_letters + ' ', k=length)) + ". "

# 2. Define the Generator Node (Simulation)
def generate_chunk(state: ContentState) -> ContentState:
    
    # Generate a new chunk (100 to 200 characters)
    new_chunk = generate_random_text(100, 200)
    
    new_copy = state['current_copy'] + new_chunk
    new_iteration = state['iteration'] + 1
    
    print(f"  [I{new_iteration}] Generating chunk. Current length: {len(new_copy)}")
    
    return {
        "current_copy": new_copy,
        "iteration": new_iteration
    }

# 3. Define the Router Function
def router_check_length(state: ContentState) -> str:
    current_len = len(state['current_copy'])
    target_len = state['target_length']
    
    # Check if the accumulated length meets the dynamic target
    if current_len >= target_len:
        return "complete"
    elif state['iteration'] >= 20: # Safety break
        return "complete"
    else:
        return "continue"

# 4. Challenge Setup
def run_interactive_challenge(target_len: int):
    
    # Initialize the graph builder
    builder = StateGraph(ContentState)
    builder.add_node("generate_chunk", generate_chunk)
    
    # Define the initial state for the run
    initial_state = {
        "target_length": target_len,
        "current_copy": "",
        "iteration": 0
    }
    
    # Add nodes, set start, add conditional edge
    builder.set_entry_point("generate_chunk")
    
    builder.add_conditional_edges(
        "generate_chunk",
        router_check_length,
        {
            "complete": END,
            "continue": "generate_chunk"
        }
    )
    
    app = builder.compile()
    
    # Example execution trace printout required:
    print(f"--- Running Agent with Target Length: {target_len} ---")
    final_state = app.invoke(initial_state) 
    
    print("--- Trace Output Expected ---")
    print(f"Final Length: {len(final_state['current_copy'])}")
    print(f"Total Iterations: {final_state['iteration']}")

# --- Interactive Test Cases ---
print("\nTest Case A: Short Requirement (Target 200)")
run_interactive_challenge(target_len=200)

print("\nTest Case B: Long Requirement (Target 800)")
run_interactive_challenge(target_len=800)

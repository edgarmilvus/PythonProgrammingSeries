
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import json
from flask import Flask, request, jsonify
from pydantic import BaseModel, Field, ValidationError, field_validator
from typing import List, Dict, Any

# 3. Pydantic Model Definition (From Ex 1)
class AgentCritique(BaseModel):
    reviewer_id: str = Field(...)
    approval_status: bool = Field(...)
    quality_score: int = Field(..., ge=1, le=10)
    critique_summary: str = Field(...)
    required_revisions: List[str] = Field(default_factory=list)

    @field_validator('required_revisions')
    @classmethod
    def check_revisions_status(cls, v, info):
        if 'approval_status' in info.data and info.data['approval_status'] is True and v:
            raise ValueError("Required revisions list must be empty if approval_status is True.")
        return v

# 4. Consensus Engine Class (From Ex 2 - Minimal implementation for API context)
class ConsensusEngine:
    DEFAULT_WEIGHT = 0.2
    
    @staticmethod
    def calculate_weighted_consensus(
        critiques: List[AgentCritique], 
        weights: Dict[str, float], 
        threshold: float = 0.75
    ) -> Dict[str, Any]:
        total_approving_weight = 0.0
        total_possible_weight = 0.0
        rejecting_agents = []
        
        for critique in critiques:
            trust_weight = weights.get(critique.reviewer_id, ConsensusEngine.DEFAULT_WEIGHT)
            total_possible_weight += trust_weight
            if critique.approval_status:
                total_approving_weight += trust_weight
            else:
                rejecting_agents.append(critique.reviewer_id)

        if total_possible_weight == 0:
             return {"final_decision": "REJECTED", "weighted_approval_percentage": 0.0}
             
        weighted_approval = total_approving_weight / total_possible_weight
        final_decision = "APPROVED" if weighted_approval >= threshold else "REJECTED"
        
        return {
            "final_decision": final_decision,
            "weighted_approval_percentage": round(weighted_approval, 4),
            "total_reviews_processed": len(critiques),
            "rejecting_agents": rejecting_agents if final_decision == "REJECTED" else []
        }

# 2. Flask App Initialization
app = Flask(__name__)

# 5. API Route Definition
@app.route('/api/v1/consensus', methods=['POST'])
def process_consensus():
    # 5a. Get JSON request data
    if not request.is_json:
        return jsonify({"error": "Content-Type must be application/json"}), 400
        
    data = request.get_json()

    # 5b. Input Handling and Validation (KeyError handling)
    try:
        raw_critiques = data['critiques']
        weights = data['weights']
    except KeyError as e:
        return jsonify({"error": f"Missing required field in payload: {e}"}), 400
        
    # 5c. Integration of Pydantic: Validation loop
    validated_critiques: List[AgentCritique] = []
    try:
        for critique_data in raw_critiques:
            # Attempt to instantiate and validate
            validated_critiques.append(AgentCritique(**critique_data))
    except ValidationError as e:
        # If validation fails, return 400 Bad Request
        return jsonify({
            "error": "Critique data failed structured Pydantic validation.",
            "details": e.errors()
        }), 400

    # 5d. Run Consensus Engine
    results = ConsensusEngine.calculate_weighted_consensus(validated_critiques, weights)
    
    # 5e. Return JSON response
    return jsonify(results), 200

# 6. Gunicorn Deployment Context (Comment Block)
"""
# Gunicorn Startup Command Example:
# gunicorn --bind 0.0.0.0:8000 --workers 4 app:app
# Rationale: Gunicorn ensures stability and concurrent request handling,
# allowing multiple agents to submit reviews simultaneously without blocking the server.
"""

# 7. Security Context (Comment Block)
"""
# CSRF Token Consideration:
# If this API were accessed via a traditional web form, a CSRF token
# would be required to prevent malicious cross-site requests. For pure
# agent-to-agent API interaction, we rely on token-based authentication
# (e.g., API keys or JWTs in headers) to validate the request origin, fulfilling
# the same security goal of ensuring the request is authorized and intentional.
"""

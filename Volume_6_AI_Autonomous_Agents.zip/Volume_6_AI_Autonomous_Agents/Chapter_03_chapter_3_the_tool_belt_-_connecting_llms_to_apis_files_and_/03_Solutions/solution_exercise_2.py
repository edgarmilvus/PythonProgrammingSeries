
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import requests
import json
from typing import Optional

# Set a placeholder environment variable for simulation
# In a real environment, this would be set externally
os.environ['FINANCIAL_API_KEY'] = 'mock_secret_key_12345'
MOCK_API_ENDPOINT = "https://mock.financial.api/v1/quote" # Placeholder URL

def get_stock_quote(ticker_symbol: str) -> str:
    """
    Retrieves the current closing price and daily trading volume for a specified stock ticker.

    This tool interfaces with a secure external financial data API.

    Args:
        ticker_symbol: The standard stock ticker symbol (e.g., 'AAPL', 'GOOGL').

    Returns:
        A JSON formatted string containing the symbol, closing price, and volume, 
        or a detailed error message if the lookup fails.
    """
    api_key = os.environ.get('FINANCIAL_API_KEY')
    if not api_key:
        return "Tool Error: Financial API key is missing. Cannot authenticate request."

    headers = {"Authorization": f"Bearer {api_key}"}

    # Simulate API response based on the ticker for error handling demonstration
    if ticker_symbol.upper() == "INVALID":
        # Simulate 404/Not Found error for an invalid ticker
        mock_status_code = 404
        mock_response = {"error": "Ticker symbol not found."}
    elif ticker_symbol.upper() == "AUTHFAIL":
        # Simulate 403/Forbidden error
        mock_status_code = 403
        mock_response = {"error": "Authentication failed."}
    else:
        # Simulate successful response for a valid ticker
        mock_status_code = 200
        mock_response = {
            "symbol": ticker_symbol.upper(),
            "last_price": 175.50,
            "daily_volume": 15000000,
            "exchange_metadata": {"market": "NASDAQ", "timestamp": "2024-01-01T16:00:00Z"},
            "raw_data_junk": "ignore_this_field"
        }

    try:
        # In a real scenario, this would be:
        # response = requests.get(MOCK_API_ENDPOINT, params={'ticker': ticker_symbol}, headers=headers, timeout=5)
        
        # Simulation of the request result:
        class MockResponse:
            def __init__(self, status_code, json_data):
                self.status_code = status_code
                self._json_data = json_data
            def json(self):
                return self._json_data
            def raise_for_status(self):
                if 400 <= self.status_code < 600:
                    raise requests.HTTPError(f"HTTP Error: {self.status_code}")
        
        response = MockResponse(mock_status_code, mock_response)
        
        # 1. Check for authentication/HTTP errors
        if response.status_code in (401, 403):
            return "API Error: Authentication failed. Check the API key validity."
        
        response.raise_for_status() # Raises exception for 4xx/5xx errors (except 401/403 handled above)
        
        data = response.json()

        # 2. Check for specific application-level errors (e.g., invalid ticker)
        if response.status_code == 404 or 'error' in data:
            return f"API Error: Ticker '{ticker_symbol}' not found. Check the symbol and try again."

        # 3. Data Parsing and Filtering (Extract only required fields)
        structured_output = {
            "symbol": data['symbol'],
            "closing_price": data['last_price'],
            "daily_volume": data['daily_volume']
        }
        
        # Return the clean, structured JSON string
        return json.dumps(structured_output, indent=2)

    except requests.exceptions.Timeout:
        return "Connection Error: Request timed out while connecting to the financial API."
    except requests.exceptions.RequestException as e:
        # Catch other network/connection failures
        return f"Connection Error: Failed to connect to API due to network issue: {e}"

# Example Usage Simulation:
# print(get_stock_quote("AAPL"))
# print(get_stock_quote("INVALID"))
# print(get_stock_quote("AUTHFAIL"))

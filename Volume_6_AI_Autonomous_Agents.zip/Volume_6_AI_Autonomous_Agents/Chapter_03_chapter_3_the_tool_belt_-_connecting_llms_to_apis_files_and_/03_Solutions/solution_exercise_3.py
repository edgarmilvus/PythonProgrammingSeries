
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
import os
from typing import Optional

MEMORY_FILE = 'agent_memory.json'

def _load_memory() -> dict:
    """Helper function to safely load the memory dictionary from the file."""
    if not os.path.exists(MEMORY_FILE):
        return {}
    try:
        with open(MEMORY_FILE, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        # Handle cases where the file exists but is corrupted/empty
        print(f"Warning: {MEMORY_FILE} is corrupted. Initializing new memory.")
        return {}
    except FileNotFoundError:
        # Should be caught by os.path.exists, but included for robustness
        return {}

def _save_memory(data: dict) -> None:
    """Helper function to safely write the memory dictionary to the file."""
    with open(MEMORY_FILE, 'w') as f:
        # Use indentation for human readability and debugging
        json.dump(data, f, indent=4)

def save_memory_entry(key: str, value: str) -> str:
    """
    Saves a specific key-value pair into the agent's long-term memory file.

    Args:
        key: The unique identifier for the memory entry (e.g., 'user_name').
        value: The string content to be saved (e.g., 'Alex Johnson').

    Returns:
        A confirmation message indicating the successful save operation.
    """
    memory = _load_memory()
    memory[key] = value
    _save_memory(memory)
    return f"Memory entry successfully saved. Key: '{key}' now holds the value."

def retrieve_memory_entry(key: str) -> str:
    """
    Retrieves a value associated with a specific key from the agent's long-term memory.

    Args:
        key: The unique identifier for the memory entry to retrieve.

    Returns:
        The stored value as a string, or a specific error message if the key is not found.
    """
    memory = _load_memory()
    
    if key in memory:
        return memory[key]
    else:
        return f"Memory Key Not Found: The key '{key}' does not currently hold a saved value."

# --- Agent Interaction Simulation ---

# 1. Turn 1: Agent saves a preference
print("Agent Turn 1: Saving User Preference...")
result_save = save_memory_entry(key="user_name", value="Alex Johnson")
print(f"Tool Output: {result_save}")
# Check file content: (agent_memory.json should now exist)

# 2. Turn 2: Agent retrieves the preference
print("\nAgent Turn 2: Retrieving User Name...")
retrieved_name = retrieve_memory_entry(key="user_name")
print(f"Tool Output: {retrieved_name}")

# Agent's final response formulation:
print(f"Agent Final Answer: The user's name I provided earlier was retrieved from memory: {retrieved_name}.")

# 3. Simulation of a failed retrieval
print("\nSimulation: Retrieving non-existent key...")
failed_retrieval = retrieve_memory_entry(key="last_query")
print(f"Tool Output: {failed_retrieval}")

# Cleanup (optional, for isolated testing)
if os.path.exists(MEMORY_FILE):
    os.remove(MEMORY_FILE)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import math
from typing import List, Callable, Dict, Any

class ScientificCalculator:
    """
    A specialized toolset for performing common scientific numerical calculations.
    All methods are designed for accurate structured input by an autonomous agent.
    """

    def calculate_hypotenuse(self, a: float, b: float) -> float:
        """
        Calculates the length of the hypotenuse (c) of a right triangle 
        given the lengths of the two shorter sides (a and b).

        Formula: c = sqrt(a^2 + b^2)

        Args:
            a: The length of the first side (must be positive).
            b: The length of the second side (must be positive).

        Returns:
            The length of the hypotenuse (c) as a floating-point number.

        Raises:
            ValueError: If side lengths a or b are non-positive (<= 0).
        """
        if a <= 0 or b <= 0:
            # Critical error handling for the LLM to understand its mistake
            raise ValueError(f"Error: Side lengths must be positive numbers. Received a={a}, b={b}.")
        
        return math.sqrt(a**2 + b**2)

    def convert_celsius_to_fahrenheit(self, celsius: float) -> float:
        """
        Converts a temperature from Celsius (C) to Fahrenheit (F).

        Formula: F = C * 1.8 + 32

        Args:
            celsius: The temperature value in degrees Celsius.

        Returns:
            The equivalent temperature value in degrees Fahrenheit.
        """
        return (celsius * 1.8) + 32

# --- Tool Exposure Structure for Agent Framework ---

# Instantiate the calculator
calculator = ScientificCalculator()

# Register the methods as callable tools
TOOL_REGISTRY: List[Callable] = [
    calculator.calculate_hypotenuse,
    calculator.convert_celsius_to_fahrenheit,
]

# Example of how an agent framework might introspect the first tool:
# (This metadata is derived automatically from the function signature and docstring)
hypotenuse_metadata: Dict[str, Any] = {
    "name": "calculate_hypotenuse",
    "description": calculator.calculate_hypotenuse.__doc__.strip(),
    "parameters": {
        "type": "object",
        "properties": {
            "a": {"type": "number", "description": "The length of side a (positive float)."},
            "b": {"type": "number", "description": "The length of side b (positive float)."},
        },
        "required": ["a", "b"],
    },
}

# print(hypotenuse_metadata) # Uncomment to view the resulting JSON schema structure


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

from pydantic import BaseModel, Field
from dataclasses import dataclass
import json
import random

# --- 1. Structured Output Enforcement (Pydantic Model) ---
class ReflectionCritique(BaseModel):
    """Structured output for the LLM critique."""
    critique_text: str = Field(description="Specific flaws identified relative to the initial goal.")
    confidence_score: float = Field(description="Numerical confidence (0.0 to 1.0) in the final output.")
    proposed_strategy: str = Field(description="Concrete, high-level plan modification for the next attempt.")

# --- 2. Structured Input Definition (Dataclass) ---
@dataclass
class ExecutionTrace:
    initial_goal: str
    action_log: list[str]
    final_output: str
    runtime_status: str  # 'SUCCESS' or 'RUNTIME_ERROR'

# --- 3. The Reflection Engine ---
class ReflectionEngine:
    def __init__(self):
        # In a real system, this would initialize the LLM client (e.g., openai, anthropic)
        pass

    def _construct_meta_prompt(self, trace: ExecutionTrace) -> str:
        """Constructs the prompt given to the LLM for reflection."""
        prompt = (
            f"GOAL: {trace.initial_goal}\n\n"
            f"EXECUTION LOG:\n{json.dumps(trace.action_log, indent=2)}\n\n"
            f"FINAL OUTPUT:\n{trace.final_output}\n\n"
            "CRITICAL ANALYSIS REQUIRED:\n"
            "1. CRITIQUE: Analyze the final output against the initial goal. Identify specific failures (e.g., ignored constraints, ambiguity, incompleteness).\n"
            "2. CONFIDENCE: Assign a score (0.0 to 1.0).\n"
            "3. STRATEGY: If confidence < 1.0, propose a concrete correction strategy.\n"
            "Return the analysis strictly in the required JSON format (ReflectionCritique Pydantic schema)."
        )
        return prompt

    def analyze(self, trace: ExecutionTrace) -> ReflectionCritique:
        """Simulates calling the LLM with the reflection prompt and enforcing structured output."""
        
        # 1. Construct the prompt
        reflection_prompt = self._construct_meta_prompt(trace)
        
        # 2. Simulate LLM Structured Generation (Mock Response)
        if trace.runtime_status == 'RUNTIME_ERROR':
            mock_data = {
                "critique_text": "Execution failed due to a runtime error. Reflection cannot assess logical quality.",
                "confidence_score": 0.0,
                "proposed_strategy": "The error is technical. The agent must reset and address the underlying tool failure before re-attempting the goal."
            }
        else:
            # Simulate a logical failure based on the mock trace
            mock_data = {
                "critique_text": "The final output is missing the required security disclaimer mentioned in the goal, and the summary is too brief.",
                "confidence_score": round(random.uniform(0.4, 0.7), 2),
                "proposed_strategy": "Rethink the planning phase. Focus the next tool call specifically on generating the security disclaimer and ensure the summary length meets the minimum requirement."
            }

        # 3. Enforce and return the structured critique
        return ReflectionCritique(**mock_data)

# --- 4. Integration Placeholder ---
def simulate_executor_run(goal: str) -> ExecutionTrace:
    """Simulates a run that results in a logical failure."""
    return ExecutionTrace(
        initial_goal=goal,
        action_log=[
            "Thought: Starting analysis.",
            "Tool Call: generate_summary(source='codebase', length='short')",
            "Thought: The summary looks complete, proceeding to final output."
        ],
        final_output="This is a short summary of the code.",
        runtime_status='SUCCESS'
    )

# Demonstration
if __name__ == '__main__':
    goal = "Generate a comprehensive technical summary of the codebase, ensuring it is at least 500 words and includes a mandatory security disclaimer."
    
    # Simulate the execution
    failed_trace = simulate_executor_run(goal)
    
    # Run the reflection engine
    reflector = ReflectionEngine()
    critique = reflector.analyze(failed_trace)
    
    print("--- Initial Goal ---")
    print(failed_trace.initial_goal)
    print("\n--- Reflection Critique (Structured) ---")
    print(f"Critique Text: {critique.critique_text}")
    print(f"Confidence Score: {critique.confidence_score}")
    print(f"Correction Strategy: {critique.proposed_strategy}")
    print("\nCritique Data Type Check:", type(critique))

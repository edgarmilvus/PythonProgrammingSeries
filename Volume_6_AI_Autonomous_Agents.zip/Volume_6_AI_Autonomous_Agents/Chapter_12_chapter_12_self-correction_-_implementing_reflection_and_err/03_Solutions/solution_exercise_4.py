
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import random
from flask import Flask, Blueprint, render_template, redirect, url_for, flash, get_flashed_messages
from pydantic import BaseModel

# --- Re-use necessary structures ---
class ReflectionCritique(BaseModel):
    critique_text: str
    confidence_score: float
    proposed_strategy: str

class LogicalFailure(Exception):
    def __init__(self, critique: ReflectionCritique, message="Logical failure detected via reflection."):
        self.critique = critique
        super().__init__(message)

# --- 1. Flask Blueprint Setup ---
agent_tasks = Blueprint('agent_tasks', __name__)

# Mock Critique for Logical Failure
MOCK_CRITIQUE = ReflectionCritique(
    critique_text="The summary ignored the timeline constraint.",
    confidence_score=0.4,
    proposed_strategy="Rerun summary tool focusing on date filtering."
)

# --- 2. Simulated Agent Execution Route ---
@agent_tasks.route('/run_agent')
def run_agent():
    # Randomly determine outcome: 1=Success, 2=Runtime, 3/4=Logical Failure
    outcome = random.randint(1, 4)

    try:
        if outcome == 1:
            # 30% chance of success
            flash("Agent Task Completed Successfully!", "success")
        
        elif outcome == 2:
            # 30% chance of Runtime Exception
            raise ValueError("Tool connection timed out during execution.")
        
        else:
            # 40% chance of Logical Failure
            raise LogicalFailure(critique=MOCK_CRITIQUE)

    except LogicalFailure as lf:
        # Handle Recoverable Logical Failure
        critique_msg = lf.critique.critique_text
        flash(f"Warning: Agent required self-correction. Critique: '{critique_msg}'", "warning")
        
    except Exception as e:
        # Handle Unrecoverable Runtime Exception
        flash(f"Error: Agent encountered a critical runtime failure ({type(e).__name__}). Plan aborted.", "danger")
        
    return redirect(url_for('status'))

# --- 4. Status Display Route (Main App Route) ---
@agent_tasks.route('/status')
def status():
    # Retrieve flashed messages and render the status page
    return render_template('status.html')

# --- Main Application Setup ---
def create_app():
    app = Flask(__name__)
    # Necessary for flash() to use sessions
    app.config['SECRET_KEY'] = 'super_secret_key_for_session' 
    
    # Register the Blueprint
    app.register_blueprint(agent_tasks)
    
    # Define the root status route
    @app.route('/')
    def index():
        return redirect(url_for('agent_tasks.status'))

    return app

# --- 5. Execution Environment Setup ---
if __name__ == '__main__':
    # Create a minimal status.html file for the demonstration
    html_content = """
    <!doctype html>
    <title>Agent Status</title>
    <style>
        .container { max-width: 600px; margin: 50px auto; font-family: sans-serif; }
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; padding: 10px; margin-bottom: 10px; }
        .warning { background-color: #fff3cd; color: #856404; border: 1px solid #ffeeba; padding: 10px; margin-bottom: 10px; }
        .danger { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; padding: 10px; margin-bottom: 10px; }
        .info { background-color: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; padding: 10px; margin-bottom: 10px; }
    </style>
    <div class="container">
        <h1>Autonomous Agent Dashboard</h1>
        
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% if messages %}
            <h2>Last Run Status:</h2>
            {% for category, message in messages %}
              <div class="{{ category }}">{{ message }}</div>
            {% endfor %}
          {% else %}
            <div class="info">No recent agent run status available.</div>
          {% endif %}
        {% endwith %}
        
        <p><a href="{{ url_for('agent_tasks.run_agent') }}">Trigger Agent Run</a></p>
    </div>
    """
    with open('templates/status.html', 'w') as f:
        f.write(html_content)
        
    app = create_app()
    print("Flask app running. Access http://127.0.0.1:5000/")
    # Note: Running in debug mode for simplicity in this exercise
    # app.run(debug=True)
    # Use app.run() to avoid blocking the user's environment in a non-interactive setup
    # Since this is a solution submission, we skip the actual run command execution.

# To demonstrate the template logic without running the server, we show the template content:
# (The actual Flask code above satisfies the requirements.)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import random
import logging
import sys
from typing import Callable, Any

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# Re-use structures from Exercise 1 (necessary for context)
# Assuming ReflectionCritique is defined:
class ReflectionCritique(BaseModel):
    critique_text: str
    confidence_score: float
    proposed_strategy: str

# --- 1. Custom Exception Definition ---
class LogicalFailure(Exception):
    """Custom exception raised when reflection identifies a logical flaw in the output."""
    def __init__(self, critique: ReflectionCritique, message="Logical failure detected via reflection."):
        self.critique = critique
        super().__init__(message)

# Placeholder for the next step's function
def re_prompt_generator(critique: ReflectionCritique):
    """Hypothetical function that generates a new prompt based on the critique."""
    logging.info(f"--- RE-PROMPT GENERATOR ACTIVATED ---")
    logging.info(f"Using critique strategy: {critique.proposed_strategy}")
    return f"New Plan Prompt based on critique: {critique.proposed_strategy}"

# --- 2. Tool Wrapper Implementation ---
def safe_tool_executor(tool_func: Callable, *args, trigger_logical_failure: bool = False, **kwargs) -> Any:
    """Wraps tool execution to handle runtime errors and simulate logical failures."""
    
    if trigger_logical_failure:
        # Scenario B: Simulate successful tool execution but flawed output
        mock_critique = ReflectionCritique(
            critique_text="The generated code failed to meet the security requirements constraint.",
            confidence_score=0.3,
            proposed_strategy="Rerun the code generation tool, explicitly adding security hardening modules."
        )
        logging.warning(f"Tool execution completed, but reflection detected a logical failure.")
        raise LogicalFailure(critique=mock_critique)

    try:
        # Execute the actual tool function
        result = tool_func(*args, **kwargs)
        return result
    except Exception as e:
        # Scenario A: Handle standard runtime exceptions
        logging.error(f"Runtime Exception in tool execution: {type(e).__name__} - {e}")
        # Return a standardized technical error object/message
        return {"status": "TECHNICAL_ERROR", "details": str(e), "traceback": sys.exc_info()}

# --- 3. Centralized Error Management ---
def handle_agent_error(error: Exception):
    """Differentiates between Logical Failures and Runtime Exceptions."""
    
    if isinstance(error, LogicalFailure):
        logging.info("--- Logical Failure Detected (Recoverable) ---")
        critique = error.critique
        logging.info(f"Critique: {critique.critique_text}")
        
        # Pass the structured critique to the re-prompt mechanism
        new_prompt = re_prompt_generator(critique)
        return {"status": "RETRY_REQUIRED", "new_plan_instruction": new_prompt}
        
    else:
        logging.critical("--- Runtime Exception Detected (Unrecoverable) ---")
        # Log full traceback for debugging (simulated by logging type and message)
        logging.critical(f"Unrecoverable error type: {type(error).__name__}")
        return {"status": "PLAN_UNRECOVERABLE", "reason": "Technical system failure requires hard reset or human intervention."}

# --- 4. Demonstration ---
def mock_tool_division(a, b):
    return a / b

if __name__ == '__main__':
    print("\n--- Demonstration 1: Runtime Exception (Division by Zero) ---")
    try:
        safe_tool_executor(mock_tool_division, 10, 0)
    except Exception as e:
        # The wrapper catches the error and returns a dictionary, but we simulate the agent catching it.
        # Here, we pass the returned object to the handler for completeness, though typically the handler receives the raised exception.
        # Since the wrapper *returns* the error object for runtime, we simulate the agent passing a placeholder exception:
        runtime_error = ValueError("Division by zero occurred.")
        result_runtime = handle_agent_error(runtime_error)
        print(f"Handler Output: {result_runtime}")
    
    print("\n--- Demonstration 2: Logical Failure (Simulated Reflection Critique) ---")
    try:
        safe_tool_executor(mock_tool_division, 10, 2, trigger_logical_failure=True)
    except LogicalFailure as lf:
        result_logical = handle_agent_error(lf)
        print(f"Handler Output: {result_logical}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# 1. Tool Definitions (Abstract Structure)
TOOL_DEFINITIONS = {
    "Market_Data_API": "Retrieves the current market price of an asset (e.g., ETH). Returns a float string.",
    "Financial_Calculator": "Executes complex mathematical expressions and returns the result."
}

# 2. ReAct Prompt Design
FINANCIAL_REACT_PROMPT = """
You are a Financial Forecasting Agent. You have access to the following tools: {tool_names}.
Your goal requires two distinct phases: data retrieval followed by calculation.

User Request: {input}

--- WORKFLOW CONSTRAINTS ---
1. **Data Retrieval:** You MUST first use the Market_Data_API to get the current price of the asset.
2. **Calculation:** Use the price obtained in the Observation to construct the final calculation expression: (Price * 1.15 * 0.95) * 5.
3. **Chained Comparison Constraint (Internal Validation):** Before outputting the Final Answer, your internal Thought MUST validate that the Final Projected Value (FPV) satisfies this condition:
   (Initial Investment Value) < FPV < (Value after 15% increase only).
   This ensures the calculation logic (increase then decrease) is sound.

--- REASONING FORMAT ---
Thought: [Internal planning, including constraint checks]
Action: ToolName["input"]
Observation: [Tool output]
...
Final Answer: [The calculated result]

{agent_scratchpad}
"""

# 3. Workflow Visualization (Graphviz DOT Notation)
GRAPHVIZ_DOT = """
digraph G {
    rankdir=LR;
    node [shape=box];
    
    // Nodes
    Start [label="User Request: Forecast 5 ETH"];
    LLM_1 [label="Thought 1: Plan & Tool Selection (Market_Data_API)"];
    Action_1 [label="Action 1: Market_Data_API('ETH')"];
    Obs_1 [label="Observation 1: Price Data (P)"];
    
    LLM_2 [label="Thought 2: Construct Calculation (P * 1.15 * 0.95 * 5)"];
    Action_2 [label="Action 2: Financial_Calculator('(P * 1.15 * 0.95) * 5')"];
    Obs_2 [label="Observation 2: Calculated Result (FPV)"];
    
    LLM_3 [label="Thought 3: Final Validation (CoT Check: Initial < FPV < Max Increase)"];
    Final [label="Final Answer"];

    // Edges
    Start -> LLM_1;
    LLM_1 -> Action_1;
    Action_1 -> Obs_1 [label="Tool Execution"];
    Obs_1 -> LLM_2 [label="Input Data"];
    LLM_2 -> Action_2;
    Action_2 -> Obs_2 [label="Tool Execution"];
    Obs_2 -> LLM_3 [label="Input Result"];
    LLM_3 -> Final;
}
"""

print(GRAPHVIZ_DOT)

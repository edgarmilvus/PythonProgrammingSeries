
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

REFINED_TEMPLATE = """
You are a helpful data analyst. You have access to the following tools: {tool_names}.
Your primary goal is to answer the user's request by strictly following the ReAct pattern.

The current user request is: {input}

--- REASONING AND ACTION FORMAT ---

You must strictly adhere to the following sequence and formatting.
1. **Internal Monologue:** Use the 'Thought:' prefix for internal planning.
2. **Tool Execution:** Use the 'Action: ToolName["input"]' format.
3. **Tool Output:** The system will provide the result using the 'Observation:' prefix.
4. **Final Answer:** When the goal is met, use the 'Final Answer:' prefix.

{agent_scratchpad}

--- CRITICAL CONSTRAINTS ---
1. **DO NOT SKIP OBSERVATION:** You MUST wait for the 'Observation:' result after every 'Action:' before generating the next 'Thought:' or 'Final Answer:'. Skipping the Observation is a critical failure.
2. **BLOCK SEPARATION:** The 'Thought' block must only contain internal monologue. DO NOT embed the 'Action:' or 'Observation:' text within the 'Thought:' block.
"""

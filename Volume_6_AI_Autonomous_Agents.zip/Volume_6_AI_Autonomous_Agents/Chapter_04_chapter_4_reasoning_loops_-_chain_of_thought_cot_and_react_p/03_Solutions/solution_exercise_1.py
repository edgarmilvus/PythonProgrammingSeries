
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

# Define the input data
INVENTORY_DATA = {
    "A": 145,
    "B": 155,
    "Constraint": 150
}

# 1. Define the Prompt Template enforcing the CoT structure
COT_TEMPLATE = """
You are an Inventory Manager AI. You must resolve conflicting stock reports based on physical constraints and internal rules.

Input Data:
System A Report: {A} units
System B Report: {B} units
Physical Constraint (Max Capacity): {Constraint} units

Rule: If a reported stock exceeds the physical capacity, assume the lower, compliant number is correct, but only after explicitly noting the violation.

You MUST follow this exact output structure:

## Reasoning Process
Thought 1: Analyze the input data and identify the conflicting reports.
Thought 2: Evaluate both reports against the physical Constraint (Max Capacity: {Constraint}).
Thought 3: Apply the governing Rule to determine the most probable stock count, citing the violation if necessary.
Thought 4: Formulate the final answer based on the deliberation.

## Final Stock Count
[The final determined number]
"""

# Helper function to simulate the LLM call and apply the prompt
def mock_llm_call_cot(template, data):
    prompt = template.format(A=data['A'], B=data['B'], Constraint=data['Constraint'])
    
    # --- Simulation of LLM output based on the required logic ---
    reasoning = f"""
## Reasoning Process
Thought 1: Analyze the input data and identify the conflicting reports. The reports are 145 units (System A) and 155 units (System B). The maximum capacity is 150 units.
Thought 2: Evaluate both reports against the physical Constraint (Max Capacity: 150). Report A (145) is compliant. Report B (155) exceeds the capacity of 150.
Thought 3: Apply the governing Rule to determine the most probable stock count, citing the violation if necessary. Since 155 violates the 150 capacity constraint, the Rule dictates that the lower, compliant number (145) must be assumed correct.
Thought 4: Formulate the final answer based on the deliberation. The justified stock count is 145.

## Final Stock Count
145
"""
    return reasoning

# Execute the simulation
result = mock_llm_call_cot(COT_TEMPLATE, INVENTORY_DATA)

print("--- Agent Execution Result ---")
print(result)

# Verification check (in a real system, we'd parse this)
final_stock = result.strip().split("## Final Stock Count\n")[-1].strip()
print(f"\nVerification: Final Stock Count is {final_stock}")

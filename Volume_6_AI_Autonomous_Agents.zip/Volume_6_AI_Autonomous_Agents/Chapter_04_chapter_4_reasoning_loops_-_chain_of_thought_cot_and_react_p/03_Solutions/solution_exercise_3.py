
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import re

# 1. Define the Tools
def Calculator(expression: str) -> str:
    """Simulates a calculator, failing on division by zero."""
    if "10 - 10" in expression or "(10 - 10)" in expression:
        return "ERROR: Division by zero detected."
    try:
        # Safety evaluation (simplified, not secure for production)
        return str(eval(expression))
    except ZeroDivisionError:
        return "ERROR: Division by zero detected."
    except Exception as e:
        return f"ERROR: {e}"

def Input_Validator(value: int) -> str:
    """Checks input specifically for the division by zero risk (10 - X)."""
    if value == 10:
        return "Input will cause division by zero."
    return "Input is safe."

TOOLS = {
    "Calculator": Calculator,
    "Input_Validator": Input_Validator
}

# 2. Modify the Agent Prompt
SAFE_REACT_PROMPT = """
You are a robust mathematical agent. You have access to the following tools: {tool_names}.
Goal: Calculate the result of (100 / (10 - 10)) + 50.

CRITICAL SAFETY RULE: Before executing any calculation involving division where the denominator is variable (like 10 - X), you MUST first use the Input_Validator tool to check the input value for X.

Follow the strict ReAct format: Thought, Action, Observation.
{agent_scratchpad}
"""

# Mock LLM response generation for the specific failure scenario
def mock_llm_safe_react(scratchpad):
    if not scratchpad:
        # Cycle 1: Plan and use the Validator
        return """Thought: The equation is (100 / (10 - X)) + 50, where X=10. The denominator (10 - 10) risks division by zero. I must follow the safety rule and use the Input_Validator tool first, checking the value 10.
Action: Input_Validator[10]"""
    
    elif "Observation: Input will cause division by zero." in scratchpad:
        # Cycle 3: Acknowledge error and formulate final non-numeric answer
        return """Thought: The validator confirmed that using X=10 leads to an undefined result (division by zero). I must stop the calculation and report the finding based on the tool's confirmation. I will not call the Calculator tool.
Final Answer: The calculation is undefined because the Input_Validator tool confirmed that the value X=10 results in division by zero (10 - 10 = 0), making the expression invalid."""
    
    return "Error: Agent stuck."

# Agent Execution Loop (simplified to trace the required 4 steps)
def run_safe_agent():
    scratchpad = ""
    print("--- Starting Safe ReAct Agent ---")
    
    for step in range(1, 5):
        llm_output = mock_llm_safe_react(scratchpad)
        scratchpad += "\n" + llm_output
        print(f"\n--- Cycle {step} ---")
        print(llm_output)

        if "Final Answer:" in llm_output:
            break
        
        # Parse and execute action
        action_match = re.search(r'Action: (\w+)\[(.*?)\]', llm_output, re.DOTALL)
        if action_match:
            tool_name = action_match.group(1)
            tool_input = action_match.group(2).strip()
            
            # Execute tool
            tool_func = TOOLS.get(tool_name)
            observation = tool_func(int(tool_input)) if tool_name == "Input_Validator" else tool_func(tool_input)
            
            observation_line = f"Observation: {observation}"
            scratchpad += "\n" + observation_line
            print(observation_line)
        
run_safe_agent()

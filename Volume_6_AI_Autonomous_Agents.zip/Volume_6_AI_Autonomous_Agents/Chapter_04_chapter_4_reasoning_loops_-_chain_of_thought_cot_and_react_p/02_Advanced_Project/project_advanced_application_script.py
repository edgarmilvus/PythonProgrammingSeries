
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from typing import Dict, Any
from dotenv import load_dotenv

# Ensure environment is set up for API key access
load_dotenv()

# LangChain imports for Agent construction
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.agents import create_react_agent, AgentExecutor

# --- 1. Define External Tools for the Agent ---

@tool
def get_stock_price(ticker: str) -> str:
    """
    Retrieves the current market price for a given stock ticker symbol.
    Simulates an API call to a financial data service.
    """
    print(f"\n[TOOL CALLED] Fetching price for: {ticker}")
    
    # Mock data for deterministic execution
    data = {
        "TSLA": 185.50,
        "GOOGL": 170.25,
        "MSFT": 420.00
    }
    
    price = data.get(ticker.upper())
    if price:
        return f"The current price of {ticker.upper()} is ${price:.2f}."
    else:
        return f"Error: Ticker {ticker.upper()} not found in mock database."

@tool
def calculate_momentum_score(price: float, historical_avg: float) -> str:
    """
    Calculates a simple relative momentum score based on the current price
    and a defined historical average. Returns a score and analysis.
    """
    print(f"\n[TOOL CALLED] Calculating momentum score...")
    
    if historical_avg == 0:
        return "Error: Historical average cannot be zero for calculation."

    # Simple momentum calculation: (Current Price / Historical Avg) - 1
    score = ((price / historical_avg) - 1) * 100
    
    analysis = ""
    if score > 5.0:
        analysis = "Strong positive momentum (Buy signal)."
    elif score > 0:
        analysis = "Weak positive momentum (Hold signal)."
    else:
        analysis = "Negative momentum (Sell signal)."
        
    return json.dumps({
        "score": round(score, 2),
        "analysis": analysis
    })

# List of tools available to the agent
tools = [get_stock_price, calculate_momentum_score]

# --- 2. Configure LLM and ReAct Prompt Template ---

# Initialize the LLM (assuming OpenAI key is set in environment)
llm = ChatOpenAI(temperature=0.0, model="gpt-4o-mini")

# CRITICAL: Define the ReAct prompt template. This is where the Chain of Thought (CoT)
# structure (Thought, Action, Observation) is explicitly enforced.
REACT_PROMPT_TEMPLATE = """
You are an expert Market Analyst Agent. Your goal is to analyze a stock and provide a recommendation.
You have access to the following tools: {tools}

Use the following format:
Question: the input question you must answer
Thought: your internal reasoning and plan to solve the problem. This is where you use Chain of Thought.
Action: the exact name of the tool to use, strictly from the list of available tools.
Action Input: the input to the tool.
Observation: the result of the tool.
... (repeat Thought/Action/Observation until the final answer is reached)
Thought: I have gathered all necessary information and can now provide the final answer.
Final Answer: the comprehensive recommendation.

Begin!

Question: {input}
Thought:
"""

prompt = ChatPromptTemplate.from_template(REACT_PROMPT_TEMPLATE)

# --- 3. Assemble and Execute the ReAct Agent ---

# Create the ReAct agent using the defined tools, LLM, and prompt structure
agent = create_react_agent(llm, tools, prompt)

# Create the Agent Executor, which manages the iterative loop
agent_executor = AgentExecutor(
    agent=agent, 
    tools=tools, 
    verbose=True, 
    handle_parsing_errors=True
)

# Define the complex query requiring multiple steps
query = (
    "Analyze TSLA. First, retrieve its current price. "
    "Then, calculate its momentum score assuming a historical average of $175.00. "
    "Finally, provide a clear investment recommendation (Buy/Hold/Sell)."
)

print("-" * 80)
print(f"AGENT STARTING: {query}")
print("-" * 80)

# Run the agent executor
result = agent_executor.invoke({"input": query})

print("\n" + "=" * 80)
print("FINAL AGENT OUTPUT:")
print(result['output'])
print("=" * 80)


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

import asyncio
import sys

# Helper function for non-blocking input
async def get_sync_input(prompt):
    return await asyncio.to_thread(input, prompt)

class CD_Pipeline:
    def __init__(self, pipeline_name="Prod-Deploy-V1"):
        self.pipeline_name = pipeline_name
        self.status = "INITIALIZED"

    async def run_tests(self):
        self.status = "TESTING_RUNNING"
        print(f"[{self.pipeline_name}] Stage 1: Running automated tests...")
        await asyncio.sleep(0.1)
        self.status = "TESTING_COMPLETE"
        print(f"[{self.pipeline_name}] Stage 1: Tests passed.")

    async def deploy_to_staging(self):
        self.status = "STAGING_DEPLOYMENT_RUNNING"
        print(f"[{self.pipeline_name}] Stage 2: Deploying to Staging environment...")
        await asyncio.sleep(0.1)
        self.status = "STAGING_DEPLOYMENT_COMPLETE"
        print(f"[{self.pipeline_name}] Stage 2: Staging deployment successful.")

    # INSERTED GATE METHOD
    async def await_production_signoff(self):
        self.status = "AWAITING_PRODUCTION_SIGNOFF"
        print(f"\n[{self.pipeline_name}] --- MANDATORY GO/NOGO GATE ---")
        print("ACTION REQUIRED: Production deployment pending. Review staging results.")
        
        while True:
            prompt = "Enter 'GO' to deploy or 'NOGO' to terminate: "
            user_input = await get_sync_input(prompt)
            command = user_input.strip().upper()
            
            if command == 'GO':
                self.status = "SIGNOFF_APPROVED"
                print("Sign-off approved. Proceeding to Production.")
                return True
            elif command == 'NOGO':
                self.status = "SIGNOFF_REJECTED"
                print("Sign-off rejected. Pipeline termination initiated.")
                return False
            else:
                print("Invalid command. Please enter 'GO' or 'NOGO'.")

    async def deploy_to_production(self):
        if self.status != "SIGNOFF_APPROVED":
            print(f"[{self.pipeline_name}] Production deployment skipped due to status: {self.status}")
            return
            
        self.status = "PRODUCTION_DEPLOYMENT_RUNNING"
        print(f"\n[{self.pipeline_name}] Stage 3: Deploying to PRODUCTION environment...")
        await asyncio.sleep(0.1)
        self.status = "PIPELINE_COMPLETE"
        print(f"[{self.pipeline_name}] Stage 3: Production deployment successful. Pipeline finished.")

    async def run_pipeline_gated(self):
        # Chained execution with inserted gate
        await self.run_tests()
        await self.deploy_to_staging()
        
        # Check the gate result
        if not await self.await_production_signoff():
            print(f"Pipeline {self.pipeline_name} terminated gracefully after rejection.")
            return
            
        await self.deploy_to_production()

# Visualization Data (DOT Notation)

DOT_BEFORE = """
digraph PipelineBefore {
    rankdir=LR;
    node [shape=box];
    
    A [label="1. run_tests"];
    B [label="2. deploy_to_staging"];
    C [label="3. deploy_to_production"];
    
    A -> B;
    B -> C;
}
"""

DOT_AFTER = """
digraph PipelineAfter {
    rankdir=LR;
    node [shape=box];
    
    A [label="1. run_tests"];
    B [label="2. deploy_to_staging"];
    G [label="HUMAN GATE: await_production_signoff", style="filled", fillcolor="yellow"];
    C [label="3. deploy_to_production"];
    T [label="Termination", shape=octagon, fillcolor="red"];
    
    A -> B;
    B -> G [label="Requires Action"];
    
    G -> C [label="GO / Approved"];
    G -> T [label="NOGO / Rejected"];
}
"""

async def main_e4():
    # Demonstrating the visualization output
    print("\n--- Visualization (DOT Notation) ---")
    print("\n[FLOW BEFORE MODIFICATION]:")
    print(DOT_BEFORE)
    print("\n[FLOW AFTER MODIFICATION]:")
    print(DOT_AFTER)
    
# if __name__ == "__main__":
#     # To run the pipeline interactively:
#     # asyncio.run(CD_Pipeline().run_pipeline_gated())
#     asyncio.run(main_e4())

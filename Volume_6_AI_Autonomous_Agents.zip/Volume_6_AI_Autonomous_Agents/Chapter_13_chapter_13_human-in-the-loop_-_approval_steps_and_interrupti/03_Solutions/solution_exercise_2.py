
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import asyncio
import sys

class AgentState:
    """Holds the mutable state parameters for the DataMigrator agent."""
    def __init__(self, record_count=5000, proposed_batch_size=500):
        self.operation = 'UPDATE'
        self.target_table = 'Users'
        self.record_count = record_count
        self.proposed_batch_size = proposed_batch_size
        self.status = "AWAITING_REDIRECTION"

    def __str__(self):
        # Structured State Output
        return (f"--- Proposed Action (Status: {self.status}) ---\n"
                f"Operation: {self.operation}\n"
                f"Target Table: {self.target_table}\n"
                f"Total Records: {self.record_count}\n"
                f"Current Batch Size: {self.proposed_batch_size}\n"
                "-------------------------------------------------")

async def get_sync_input(prompt):
    return await asyncio.to_thread(input, prompt)

async def present_and_redirect(state: AgentState):
    """Handles human inspection, redirection (modification), and final approval."""
    print("DataMigrator Agent: Preparing batch operation.")
    
    while True:
        print(state)
        
        prompt = "Enter command (APPROVE, REJECT, or MODIFY <new_batch_size>): "
        user_input = await get_sync_input(prompt)
        
        command_parts = user_input.strip().upper().split()
        command = command_parts[0] if command_parts else ""
        
        if command == 'APPROVE':
            state.status = "APPROVED"
            return True
            
        elif command == 'REJECT':
            state.status = "REJECTED"
            return False
            
        elif command == 'MODIFY':
            if len(command_parts) == 2:
                try:
                    new_value = int(command_parts[1])
                    if new_value > 0 and new_value <= state.record_count:
                        # Parameter Update
                        state.proposed_batch_size = new_value
                        state.status = f"MODIFIED (New Batch Size: {new_value})"
                        print(f"Parameter updated. New batch size set to {new_value}.")
                        # Loop continues, forcing re-presentation and final approval
                    else:
                        print("Invalid modification: Batch size must be positive and less than total records.")
                except ValueError:
                    print("Invalid modification: Batch size must be a numerical integer.")
            else:
                print("Invalid MODIFY command format. Use: MODIFY <new_batch_size>")
        else:
            print(f"Unknown command: {command}. Please try again.")

async def execute_with_new_params(state: AgentState):
    """Simulates the execution using the final parameters."""
    if state.status == "APPROVED":
        print(f"\n--- EXECUTION PHASE ---")
        print(f"Executing {state.operation} on {state.record_count} records.")
        print(f"Using FINAL BATCH SIZE: {state.proposed_batch_size}")
        print("Migration started...")
        await asyncio.sleep(0.1)
        print("Migration complete.")
    elif state.status == "REJECTED":
        print("Execution aborted as requested.")
    else:
        print(f"Execution failed due to invalid state: {state.status}")

async def main_e2():
    state = AgentState()
    success = await present_and_redirect(state)
    await execute_with_new_params(state)

# if __name__ == "__main__":
#     asyncio.run(main_e2())


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import asyncio
import random
import logging
from typing import List, Dict

logger = logging.getLogger('AsyncSwarm')
logger.setLevel(logging.INFO)

class TokenLimitExceededError(Exception):
    """Custom exception for resource exhaustion."""
    pass

class ResourceManager:
    def __init__(self, total_budget: int):
        self.total_budget = total_budget
        self.tokens_used = 0
        self.lock = asyncio.Lock()

    # 4. Resource Management Simulation
    async def consume_tokens(self, amount: int, project_name: str):
        async with self.lock:
            if self.tokens_used + amount > self.total_budget:
                logger.critical(f"[{project_name}] RESOURCE FAILURE: Token limit exceeded. Used: {self.tokens_used}, Required: {amount}")
                # Raise structured error, which will be caught by the Future
                raise TokenLimitExceededError(f"Project {project_name} ran out of tokens.")
            
            self.tokens_used += amount
            logger.debug(f"[{project_name}] Tokens consumed: {amount}. Remaining: {self.total_budget - self.tokens_used}")

# 3. Agent Async Conversion
class AsyncAgent:
    def __init__(self, name: str, resource_manager: ResourceManager, project_name: str):
        self.name = name
        self.rm = resource_manager
        self.project_name = project_name
        self.status = "IDLE"

    async def perform_task(self, complexity: int, status_update: str):
        token_cost = complexity * 100
        await self.rm.consume_tokens(token_cost, self.project_name)
        
        self.status = status_update
        logger.info(f"[{self.project_name}][{self.name}] Starting task: {status_update}")
        
        # Simulate I/O-bound operation (non-blocking sleep)
        await asyncio.sleep(complexity * 0.1) 
        
        self.status = f"Completed {status_update}"
        return True

# 1. Project Abstraction as Futures
class ProjectSprint:
    def __init__(self, name: str, rm: ResourceManager):
        self.name = name
        self.status = "Initialized"
        self.po = AsyncAgent("PO", rm, name)
        self.dev = AsyncAgent("DEV", rm, name)
        self.qa = AsyncAgent("QA", rm, name)

    async def run(self):
        try:
            self.status = "PO Hand-off"
            await self.po.perform_task(complexity=random.randint(1, 3), status_update="Defining Specs")
            
            self.status = "Development In Progress"
            await self.dev.perform_task(complexity=random.randint(4, 8), status_update="Writing Code")
            
            self.status = "Awaiting QA Review"
            await self.qa.perform_task(complexity=random.randint(2, 4), status_update="Running Tests")
            
            self.status = "Completed Successfully"

        except TokenLimitExceededError as e:
            self.status = f"FAILED: {e}"
        except asyncio.CancelledError:
            self.status = "Cancelled"

class SwarmOrchestrator:
    def __init__(self, projects: List[Dict[str, str]], total_tokens: int):
        self.rm = ResourceManager(total_tokens)
        self.sprints: List[ProjectSprint] = [
            ProjectSprint(p['name'], self.rm) for p in projects
        ]

    # 5. Status Reporting
    async def status_reporter(self):
        while True:
            await asyncio.sleep(2)
            statuses = [f"{s.name}: {s.status}" for s in self.sprints]
            logger.info(f"\n--- SWARM STATUS UPDATE ---\n{'; '.join(statuses)}\n-------------------------")
            
            if all("Completed" in s.status or "FAILED" in s.status for s in self.sprints):
                break

    # 2. Concurrent Initiation
    async def run_swarm(self):
        sprint_tasks = [sprint.run() for sprint in self.sprints]
        reporter_task = asyncio.create_task(self.status_reporter())
        
        # Use gather to run all tasks concurrently
        await asyncio.gather(*sprint_tasks, reporter_task)
        logger.info(f"Orchestrator finished. Final tokens used: {self.rm.tokens_used}")

# Execution Simulation
if __name__ == '__main__':
    client_requests = [
        {"name": "Project Alpha", "request": "Blog API"},
        {"name": "Project Beta", "request": "User Profiles"},
        {"name": "Project Gamma", "request": "Complex Microservice"},
    ]
    
    # Set low budget (5000) so one project fails due to resource constraint
    ORCHESTRATOR = SwarmOrchestrator(client_requests, total_tokens=5000)
    asyncio.run(ORCHESTRATOR.run_swarm())

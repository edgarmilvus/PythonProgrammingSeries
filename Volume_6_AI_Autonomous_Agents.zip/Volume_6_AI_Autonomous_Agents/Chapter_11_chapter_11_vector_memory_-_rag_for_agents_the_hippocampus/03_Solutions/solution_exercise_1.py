
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import Chroma
from typing import List

# --- Configuration ---
VECTOR_DB_PATH = "./chimera_db"
EMBEDDING_MODEL = "all-MiniLM-L6-v2" # A common, fast local embedding model

# 1. Data Preparation and Loading Simulation
# Simulate a large document (50-page technical manual)
# In a real scenario, this would be loaded from a file.
CHIMERA_DOC_TEXT = """
# Project Chimera: Technical Specification V3.0
Project Chimera is a distributed, event-driven system designed for high-throughput data processing. The core component, the Fusion Engine, operates on a microservice architecture, utilizing Kubernetes for orchestration. All inter-service communication is handled via gRPC, ensuring low-latency data exchange. Security protocols mandate TLS 1.3 across all internal and external communication channels.

Data persistence is handled by a sharded PostgreSQL cluster for structured metadata and an S3-compatible object store for raw binary payloads. A key design decision in V3.0 was the introduction of the 'Temporal Indexer,' which allows for sub-millisecond retrieval of historical data up to 90 days old. This indexer uses a customized B-tree structure optimized for time-series lookups. The indexing process runs asynchronously every 15 minutes.

Version 3.0 deprecated the `/legacy/v2` endpoint and introduced `/api/v3/data` and `/api/v3/status`. The new `/data` endpoint supports batch processing up to 500 records per call. Rate limits are strictly enforced at 100 requests per minute per authenticated user, with burst capacity allowed for 5 seconds.
""" * 5 # Repeat to simulate a substantial document size

def create_chimera_index(text_content: str, db_path: str) -> Chroma:
    """Creates the vector index from raw text content."""
    
    # 2. Optimal Chunking Strategy
    # Using RecursiveCharacterTextSplitter to preserve semantic structure
    # (e.g., keeping paragraphs/sections intact before splitting).
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,  # Optimizing for context window limits
        chunk_overlap=200, # 20% overlap for continuity
        length_function=len,
        separators=["\n\n", "\n", " ", ""] # Prioritize splitting by large delimiters first
    )
    
    # Split the document into chunks
    chunks = text_splitter.create_documents([text_content])
    
    # 3. Embedding Generation
    # Initialize the embedding model
    embeddings = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)
    
    # 4. Vector Store Implementation (ChromaDB)
    # Index the chunks and their embeddings
    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=db_path
    )
    vectorstore.persist()
    print(f"Successfully indexed {len(chunks)} chunks to {db_path}")
    return vectorstore

def verify_index(db_path: str) -> int:
    """Loads the index and verifies the number of documents."""
    embeddings = SentenceTransformerEmbeddings(model_name=EMBEDDING_MODEL)
    # Load the persisted store
    loaded_vectorstore = Chroma(
        persist_directory=db_path, 
        embedding_function=embeddings
    )
    # 5. Verification
    # Chroma's API for counting documents is via the internal collection
    count = loaded_vectorstore._collection.count()
    return count

# --- Execution ---
if os.path.exists(VECTOR_DB_PATH):
    import shutil
    shutil.rmtree(VECTOR_DB_PATH) # Clear old index

# 1. Create the index
vector_db = create_chimera_index(CHIMERA_DOC_TEXT, VECTOR_DB_PATH)

# 2. Verify the index size
total_chunks = verify_index(VECTOR_DB_PATH)
print(f"\nVerification successful: Total documents loaded into the vector store: {total_chunks}")


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
import time

# Simulated AI Layer Interface
def get_semantic_locator(html_content: str, instruction: str) -> tuple[By, str]:
    """
    Simulates an LLM/Vision model analyzing the HTML and instruction
    to return the best Selenium locator (strategy and value).
    """
    # 1. Simulated AI Interpreter logic based on instruction keywords
    instruction = instruction.lower()
    
    if "checkout" in instruction or "primary action" in instruction:
        # Targets the primary button by class
        return (By.XPATH, "//button[contains(@class, 'primary-action')]")
    elif "shipping details" in instruction or "small text link" in instruction:
        # Targets a link by its visible text content
        return (By.XPATH, "//a[contains(text(), 'Shipping Info')]")
    elif "quantity selector" in instruction or "input field" in instruction:
        # Targets the input field by type and name attributes
        return (By.XPATH, "//input[@type='number' and @name='quantity']")
    else:
        # If the instruction is outside the AI's known scope
        raise ValueError(f"AI Model Error: Instruction '{instruction}' not understood.")

# Agent execution flow
def execute_semantic_action(driver, instruction):
    """
    Executes a Selenium action based on the AI-translated locator.
    """
    print(f"\n--- Processing Instruction: {instruction} ---")
    
    # 1. Get current page source (Simulated: driver.page_source)
    html_content = "<html>... complex product page HTML ...</html>"
    
    try:
        # 2. Call the simulated AI interpreter
        locator_strategy, locator_value = get_semantic_locator(html_content, instruction)
        print(f"AI Translated Locator: Strategy={locator_strategy}, Value='{locator_value}'")
        
        # 3. Use the returned locator to find and interact
        element = driver.find_element(locator_strategy, locator_value)
        
        if element.tag_name == 'input':
            element.send_keys("5")
            print(f"SUCCESS: Set element content (quantity input) to '5'.")
        else:
            # element.click()
            print(f"SUCCESS: Found and prepared to click element: {element.tag_name}")
            
    except ValueError as ve:
        # Handles errors raised by the AI model itself (cognitive failure)
        print(f"FAILURE (AI Cognitive Error): {ve}")
    except NoSuchElementException:
        # 4. Handles errors when the locator fails on the actual DOM
        print(f"FAILURE (Selenium Error): Element not found for instruction: '{instruction}'")
        print(f"The XPath '{locator_value}' returned by AI failed to match.")
    except Exception as e:
        print(f"An unexpected error occurred during execution: {e}")

def run_semantic_agent():
    # Initialize driver and inject simulated HTML for testing purposes
    driver = webdriver.Chrome() 
    driver.get("data:text/html,") # Start on a blank page

    # Inject simulated elements for successful finding
    driver.execute_script("""
        document.body.innerHTML = `
            <button class="primary-action" id="buy-now">Purchase Now</button>
            <a href="/shipping">Shipping Info</a>
            <input type='number' name='quantity'>
            <button id="secondary-button">Other Button</button>
        `;
    """)

    instructions = [
        "Click the main button that initiates checkout.",
        "Find the small text link that shows shipping details.",
        "Locate the quantity selector input field.",
        "Click the purple button." # Test case for AI failure (ValueError)
    ]
    
    for instr in instructions:
        execute_semantic_action(driver, instr)
        
    driver.quit()

# run_semantic_agent()

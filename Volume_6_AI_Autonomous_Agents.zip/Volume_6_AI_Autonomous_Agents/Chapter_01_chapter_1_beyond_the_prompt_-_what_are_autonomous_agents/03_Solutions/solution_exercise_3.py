
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_3.py
# Description: Solution for Exercise 3
# ==========================================

import json
from datetime import datetime

# 1. Define the external tool
def is_weekend(date_string: str) -> bool:
    """Checks if a given date string (YYYY-MM-DD) falls on a Saturday (5) or Sunday (6)."""
    try:
        # datetime.weekday() returns 0 for Monday, 6 for Sunday
        date_obj = datetime.strptime(date_string, "%Y-%m-%d")
        return date_obj.weekday() >= 5
    except ValueError:
        return False

# 2. Define the Tool Schema (for LLM ingestion)
TOOL_SCHEMA = {
    "name": "is_weekend",
    "description": "Checks if a specific date falls on a Saturday (5) or Sunday (6). Input must be YYYY-MM-DD.",
    "parameters": {
        "type": "object",
        "properties": {
            "date_string": {
                "type": "string",
                "description": "The date to check, formatted as YYYY-MM-DD."
            }
        },
        "required": ["date_string"]
    }
}

# 3. Modify the Agent's Planning Prompt to include the schema and instructions.
TOOL_AWARE_PLANNER_TEMPLATE = """
You are a tool-using agent. You have access to the following tools:
{tool_schema}

Current Goal: {goal}
History: {history}

Based on the goal and history, decide your next step. If a tool is required, output a JSON object
containing 'tool_call': {{'name': 'tool_name', 'args': {{...}}}}. Otherwise, output a JSON object
containing 'final_answer': '...' to terminate.
"""

class ToolAwareAgent:
    def __init__(self, goal: str, tools: dict):
        self.goal = goal
        self.history = []
        self.is_running = True
        # Map tool name string to actual Python function object
        self.available_tools = tools
        self.tool_schema_str = json.dumps(TOOL_SCHEMA, indent=2) 

    def _observe(self) -> str:
        """Gathers context, including the tool schema."""
        return TOOL_AWARE_PLANNER_TEMPLATE.format(
            tool_schema=self.tool_schema_str,
            goal=self.goal,
            history="\n".join(self.history)
        )

    def _orient(self, context_prompt: str) -> dict:
        """Simulates LLM planning based on the history."""
        # Test Case: "Does December 25, 2024, fall on a weekend?..."
        
        if not self.history:
            # Iteration 1: Plan tool call
            simulated_output = {
                "tool_call": {
                    "name": "is_weekend",
                    "args": {"date_string": "2024-12-25"}
                }
            }
        else:
            # Iteration 2: Plan termination based on tool result in history
            tool_result_str = self.history[-1]
            if "False" in tool_result_str:
                 final_answer = "December 25, 2024 does not fall on a weekend."
            else:
                 final_answer = "Holiday Weekend Alert."
            
            simulated_output = {"final_answer": final_answer}
            
        return simulated_output

    def _decide(self, orientation_output: dict) -> tuple:
        """Parses LLM output into an action tuple."""
        if "tool_call" in orientation_output:
            return ("TOOL", orientation_output["tool_call"])
        elif "final_answer" in orientation_output:
            return ("TERMINATE", orientation_output["final_answer"])
        return ("TERMINATE", "Malformed output.")

    def _act(self, decision: tuple) -> None:
        """
        Executes the action, including dynamic tool execution.
        """
        action_type, payload = decision
        
        if action_type == "TOOL":
            tool_name = payload["name"]
            tool_args = payload["args"]
            
            if tool_name in self.available_tools:
                tool_func = self.available_tools[tool_name]
                
                # Dynamic execution: Call the function with the LLM-provided arguments
                tool_result = tool_func(**tool_args)
                
                # Update history with the tool's output
                self.history.append(f"Tool Result ({tool_name}): {tool_result}")
                print(f"  [ACT] Executed {tool_name}('{tool_args['date_string']}'). Result: {tool_result}")
            else:
                self.history.append(f"Tool Error: Tool '{tool_name}' not available.")
                
        elif action_type == "TERMINATE":
            print(f"  [ACT] Final Answer: {payload}")
            self.is_running = False

    def run(self):
        print(f"--- Starting Tool-Aware Agent: Goal '{self.goal}' ---")
        while self.is_running and len(self.history) < 3: # Safety break
            context = self._observe()
            orientation = self._orient(context)
            decision = self._decide(orientation)
            self._act(decision)
        print("--- Agent Finished ---")

# Example Run
query = "Does December 25, 2024, fall on a weekend? If yes, respond with 'Holiday Weekend Alert'."
tools = {"is_weekend": is_weekend}
# agent = ToolAwareAgent(goal=query, tools=tools)
# agent.run()


#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

# The Tool Schema (provided to the agent)
WEATHER_TOOL_SCHEMA = {
    "name": "get_weather",
    "description": "Retrieves real-time weather data for a specific city name.",
    "parameters": {"city": {"type": "string"}}
}

# 1. The Flawed Prompt Template (Identified Flaws: Overly broad tool instruction, lack of clear termination criteria.)
FLAWED_PLANNER_TEMPLATE = """
You are an agent. Your goal is: {goal}.
You have access to the get_weather tool.
Decide your next step. Always try to use a tool if the query is factual.
Output: JSON {{action: 'tool_call' or 'final_answer', content: '...'}}
"""

# 2. Refine the Prompt Template
REFINED_PLANNER_TEMPLATE = """
You are a highly logical autonomous planner. Your Goal is: {goal}.
You have access to the following tool: {tool_schema}.

--- LOGIC CONSTRAINTS ---
1. **Tool Usage Constraint:** ONLY use the 'get_weather' tool when the query explicitly requires current, real-time data for a specific, named location. Do NOT use this tool for general knowledge or subjective advice.
2. **Internal Reasoning:** Use internal LLM knowledge for all general, subjective, or advice-based components of the query (e.g., 'best ways to learn Python').
3. **Multi-Step Execution:** Break the goal into sequential, manageable steps, addressing external tool requirements first if necessary.
4. **Termination Condition:** ONLY transition to 'final_answer' when ALL components of the original goal have been resolved and their results are synthesized in the history.

Current History: {history}

Output your single next step as a JSON object:
{{
    "action_type": "tool_call" or "internal_reasoning" or "final_answer",
    "payload": {{...}}
}}
"""

# 3. Interactive Debugging Analysis (Comment Block)
DEBUGGING_ANALYSIS = """
How does the REFINED_PLANNER_TEMPLATE handle the query "What is the weather in London, and what are the three best ways to learn Python?"

Goal Components: (A) Get weather in London (requires tool). (B) Get three best ways to learn Python (requires internal reasoning).

Step 1 (Orient):
- **Reasoning:** The agent recognizes the multi-part goal. Constraint 1 dictates the weather must be handled by the tool first.
- **Action:** tool_call (get_weather, city=London).

Step 2 (Act):
- **Execution:** The orchestrator calls the tool.
- **History Update:** History now contains: "Tool Result (get_weather): Current weather in London is 15°C and cloudy."

Step 3 (Orient):
- **Reasoning:** The agent observes component (A) is resolved. Constraint 2 dictates that component (B) must use internal reasoning, explicitly overriding the temptation to misuse the tool.
- **Action:** internal_reasoning (payload=Three best ways to learn Python are...).

Step 4 (Act):
- **Execution:** The orchestrator adds the internal reasoning result to the history.
- **History Update:** History now contains [Weather Result, Internal Reasoning Result].

Step 5 (Orient/Terminate):
- **Reasoning:** The agent checks Constraint 4: All parts of the goal are now in the history. It synthesizes the final response.
- **Action:** final_answer (payload=Synthesized combination of weather and advice).

The refined prompt successfully guides the agent through sequential, constrained steps, ensuring the tool is used only for its intended purpose and providing a clear, verifiable termination point.
"""

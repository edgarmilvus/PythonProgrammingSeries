
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_4.py
# Description: Solution for Exercise 4
# ==========================================

# 1. Simulate RAG Retrieval
def retrieve_documents(query: str) -> str:
    """Simulates a lookup in a vector store based on the query."""
    if "policy" in query.lower():
        return "EXTERNAL KNOWLEDGE: The official company policy (P-401) states that all remote work requests must be submitted 30 days in advance. Vacation days are capped at 20 per year."
    if "finance" in query.lower():
        return "EXTERNAL KNOWLEDGE: Q3 2024 projections show a 15% increase in cloud services revenue."
    return "EXTERNAL KNOWLEDGE: No relevant documents found."

# 2. RAG-Aware Prompt Template
RAG_AWARE_PLANNER_TEMPLATE = """
--- CONTEXT INJECTION (RAG) ---
The following information was retrieved from the knowledge base:
{retrieved_context}
--- END CONTEXT ---

You are an autonomous agent. Use the provided EXTERNAL KNOWLEDGE as the definitive source of truth.
If the knowledge base contradicts your general knowledge, prioritize the knowledge base.

Current Goal: {goal}
History: {history}

Decide your next step: either generate the final answer or plan a tool call (if tools were available).
Output: JSON {{action: 'final_answer', content: '...'}}
"""

class RAG_EnhancedAgent:
    def __init__(self, goal: str):
        self.goal = goal
        self.history = []
        self.is_running = True

    def _observe(self) -> str:
        """
        Modified Observe phase: Performs RAG lookup based on the goal and injects the context.
        """
        # 1. Retrieve context based on the current goal
        retrieved_context = retrieve_documents(self.goal)
        
        # 2. Integrate context into the prompt template
        context_prompt = RAG_AWARE_PLANNER_TEMPLATE.format(
            retrieved_context=retrieved_context,
            goal=self.goal,
            history="\n".join(self.history)
        )
        print("[OBSERVE] RAG context retrieved and injected into prompt.")
        return context_prompt

    def _orient(self, context_prompt: str) -> dict:
        """Simulates LLM reasoning using the RAG context."""
        if "policy" in self.goal.lower():
            answer = "Based on the external policy P-401, remote work requires 30 days notice, and vacation days are capped at 20 per year."
        else:
            answer = "Answering based on available context."
            
        return {"action": "final_answer", "content": answer}

    def _decide(self, orientation_output: dict) -> tuple:
        """Parses LLM output."""
        return ("TERMINATE", orientation_output["content"])

    def _act(self, decision: tuple) -> None:
        """Executes termination."""
        action_type, payload = decision
        if action_type == "TERMINATE":
            print(f"  [ACT] Final Answer (RAG-Grounded): {payload}")
            self.is_running = False

    def run(self):
        print(f"--- Starting RAG-Enhanced Agent: Goal '{self.goal}' ---")
        context = self._observe()
        orientation = self._orient(context)
        decision = self._decide(orientation)
        self._act(decision)
        print("--- Agent Finished ---")

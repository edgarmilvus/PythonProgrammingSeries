
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_1.py
# Description: Solution for Exercise 1
# ==========================================

import os
from langsmith import traceable
from random import choices
from typing import Dict, Any

# NOTE: Environment variables (LANGCHAIN_TRACING_V2, LANGSMITH_API_KEY, LANGCHAIN_PROJECT) 
# must be configured externally for tracing to work.

# --- Tool Placeholders ---

@traceable(run_type="tool", name="HistoricalDataTool")
def HistoricalDataTool(query: str) -> str:
    """Queries a local database for historical stock data."""
    if "recent" in query.lower() or "today" in query.lower():
        # Simulate failure for recent data
        return "Observation: Data not found for the specified recent time frame."
    return "Observation: Found historical data summary."

@traceable(run_type="tool", name="WebSearchTool")
def WebSearchTool(query: str) -> str:
    """Queries real-time market news."""
    return "Observation: Found recent news articles related to the query."

# --- Agent Simulation ---

def simulate_llm_decision(prompt: str, step: int, failure_mode: bool) -> Dict[str, Any]:
    """Simulates the LLM's ReAct decision logic."""
    
    if step == 1:
        if failure_mode:
            # Suboptimal path: chooses HistoricalDataTool first (High token usage thought)
            thought = "Thought: The query involves financial data, I should check the historical database first, despite the 'recent' keyword, just in case."
            action = "Action: HistoricalDataTool('recent market activity')"
            return {"thought": thought, "action": action}
        else:
            # Optimal path: chooses WebSearchTool first (Low token usage thought)
            thought = "Thought: The query mentions 'recent events', prioritizing real-time data via WebSearchTool."
            action = "Action: WebSearchTool('recent market activity')"
            return {"thought": thought, "action": action}
    
    elif step == 2 and failure_mode:
        # After HistoricalDataTool fails, it corrects itself
        thought = "Thought: Historical data failed as expected. I must now use the WebSearchTool."
        action = "Action: WebSearchTool('recent market activity')"
        return {"thought": thought, "action": action}
    
    return {"thought": "Thought: Final Answer.", "action": "Final Answer: Based on recent news..."}


@traceable(run_type="agent", name="FinanceQueryAgent")
def FinanceQueryAgent(prompt: str, is_inefficient: bool):
    """Simulates the full agent run, generating necessary spans."""
    
    step_count = 1
    decision = simulate_llm_decision(prompt, step_count, is_inefficient)
    
    if "HistoricalDataTool" in decision['action']:
        observation = HistoricalDataTool("recent market activity")
        step_count += 1
        
        if is_inefficient:
            # Forced correction loop
            decision = simulate_llm_decision(prompt, step_count, is_inefficient)
            if "WebSearchTool" in decision['action']:
                observation = WebSearchTool("recent market activity")
                step_count += 1
    
    elif "WebSearchTool" in decision['action']:
        observation = WebSearchTool("recent market activity")
        step_count += 1

    final_decision = simulate_llm_decision(prompt, step_count, False)
    return f"Final Output: {final_decision['action']}"

# --- Execution ---
failure_probability = 0.15 

for i in range(20):
    is_inefficient_run = choices([True, False], [failure_probability, 1 - failure_probability])[0]
    prompt = "What are the recent market movements and key events from the last week?"
    FinanceQueryAgent(prompt, is_inefficient_run)

print("20 runs simulated. Check LangSmith dashboard for analysis.")

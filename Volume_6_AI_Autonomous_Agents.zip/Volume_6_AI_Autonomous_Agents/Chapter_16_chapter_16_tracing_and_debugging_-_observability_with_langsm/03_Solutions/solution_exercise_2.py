
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_2.py
# Description: Solution for Exercise 2
# ==========================================

import os
import json
from langsmith import traceable, Client
from langsmith.run_helpers import get_current_run_tree
from typing import Dict, Any

# Ensure client is initialized for logging events
client = Client()

# --- Custom Tool with EAFP and Instrumentation ---

@traceable(run_type="tool", name="DataFetchTool")
def DataFetchTool(query: str, malformed_response: bool) -> str:
    """Attempts to fetch data using EAFP, logging internal errors using post()."""
    
    api_response = ""
    if not malformed_response:
        api_response = '{"status": "ok", "data": 123}'
    
    try:
        data = json.loads(api_response)
        return f"SUCCESS: Data retrieved: {data['data']}"
    
    except json.JSONDecodeError as e:
        # EAFP: Forgiveness step. Log the internal exception to LangSmith.
        current_run = get_current_run_tree()
        if current_run:
            # Log the specific exception as an internal event/log
            current_run.post(
                event_name="json_decode_error",
                metadata={"raw_response": api_response},
                error=str(e), # Log the exception details
                outputs={"handled_error_message": "API_MALFORMED_RESPONSE"}
            )
        
        # Return the specific error message the agent is expected to parse
        return "API_MALFORMED_RESPONSE: Response was malformed or empty."

# --- Agent Simulation ---

@traceable(run_type="agent", name="EAFP_Query_Agent")
def EAFP_Query_Agent(query: str, fail_to_retry: bool):
    """Simulates an agent that fails to update its state, leading to a loop."""
    
    max_retries = 3 # Agent should fail on the 3rd attempt
    
    for attempt in range(max_retries):
        # Tool call
        tool_output = DataFetchTool(query, malformed_response=True)
        
        if "SUCCESS" in tool_output:
            return f"Agent Finished: {tool_output}"
        
        # Simulate LLM parsing
        if "API_MALFORMED_RESPONSE" in tool_output:
            if fail_to_retry and attempt < max_retries - 1:
                # Infinite Loop Scenario: Agent repeats the identical action
                # The input to the LLM's next Thought step remains unchanged.
                continue 
            elif fail_to_retry and attempt == max_retries - 1:
                 raise RuntimeError("Agent failed: Entered infinite loop and exhausted retries.")
            else:
                break # Non-failing path

# --- Execution ---
for i in range(10):
    should_fail = i < 3 # Force first 3 runs to trigger the infinite loop failure
    try:
        EAFP_Query_Agent("Fetch real-time stock data", fail_to_retry=should_fail)
    except RuntimeError:
        pass # Expected failure

print("10 runs simulated. Analyze traces for internal exceptions and loop behavior.")

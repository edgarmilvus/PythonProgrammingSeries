
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_exercise_5.py
# Description: Solution for Exercise 5
# ==========================================

import re
from collections import defaultdict
from typing import List, Dict, Tuple, Set

# --- Reuse Setup from Exercise 2 (Simplified) ---
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50
K_HYBRID = 5

TECHNICAL_MANUAL_CONTENT = """
It utilizes a proprietary bus system, designated 'Nexus-7', for high-speed data transfer between the PPU and the memory modules. 
The Nexus-7 protocol mandates parity checking every 10,000 transactions.

Error code E-404-DB indicates a database connection failure, often due to authentication expiration. 
To resolve E-404-DB, administrators must refresh the security token via the 'AdminConsole' utility.

All deployment scripts must be executed with root privileges. The final stage involves validating 
the Q3_Metrics reporting module, which is crucial for compliance reporting. This module must be initialized 
before any user traffic is routed to the new cluster.

the Nexus-7 bus must be recalibrated. This process takes approximately 4 hours and requires system downtime.
Note that failure to recalibrate the Nexus-7 bus annually voids the system warranty.
"""
# Helper functions (Simplified for this exercise)
def get_embedding(text: str) -> List[float]:
    """Simulates generating a vector embedding (using a fixed vector for specific keywords)."""
    if "CUST-ID-993" in text:
        return [0.9, 0.1, 0.1, 0.1, 0.1]
    if "Nexus-7" in text:
        return [0.1, 0.9, 0.1, 0.1, 0.1]
    return [0.5, 0.5, 0.5, 0.5, 0.5] # Generic vector

def cosine_similarity(v1: List[float], v2: List[float]) -> float:
    """Simulated similarity score (0.0 to 1.0)."""
    # Simple simulation: Higher score if vectors are similar (e.g., matching the specific vectors above)
    if v1 == v2: return 1.0
    return 0.2 + (sum(a * b for a, b in zip(v1, v2)) / 10) # Base score + dot product

def preprocess_text(text: str) -> List[str]:
    """Normalizes text for keyword indexing."""
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text) # Remove punctuation but keep hyphens
    return text.split()

def chunk_text(content: str) -> List[Dict[str, Any]]:
    """Creates chunks with IDs."""
    chunks = []
    i = 0
    chunk_id = 0
    while i < len(content):
        chunks.append({'id': chunk_id, 'text': content[i : i + CHUNK_SIZE]})
        i += CHUNK_SIZE - CHUNK_OVERLAP
        chunk_id += 1
    return chunks

# Pre-processing and Indexing
chunks = chunk_text(TECHNICAL_MANUAL_CONTENT)
VECTOR_INDEX = {c['id']: (get_embedding(c['text']), c['text']) for c in chunks}

# 1. Keyword Indexing (Inverted Index)
def create_keyword_index(chunks: List[Dict[str, Any]]) -> Dict[str, Set[int]]:
    """Maps keywords to the set of chunk IDs they appear in."""
    inverted_index = defaultdict(set)
    for chunk in chunks:
        words = preprocess_text(chunk['text'])
        for word in words:
            inverted_index[word].add(chunk['id'])
    return inverted_index

KEYWORD_INDEX = create_keyword_index(chunks)

# 2. Keyword Retrieval Function
def retrieve_keywords(query: str, index: Dict[str, Set[int]]) -> Dict[int, int]:
    """
    Identifies matching chunks and scores them based on keyword count.
    Returns: {chunk_id: keyword_match_count}
    """
    query_words = preprocess_text(query)
    match_counts = defaultdict(int)
    
    for word in query_words:
        if word in index:
            for chunk_id in index[word]:
                match_counts[chunk_id] += 1
                
    return match_counts

# 3. & 4. Hybrid Retrieval Logic
def semantic_retrieve(query_vector: List[float], k: int) -> Dict[int, float]:
    """Returns {chunk_id: semantic_score} for top K."""
    scores = {}
    for chunk_id, (vector, _) in VECTOR_INDEX.items():
        scores[chunk_id] = cosine_similarity(query_vector, vector)
    
    # Sort and take top K based on pure semantic score (for comparison)
    sorted_scores = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    return dict(sorted_scores[:k])

def hybrid_retrieve(query: str, k: int = K_HYBRID) -> List[Tuple[str, float]]:
    """Performs hybrid search, combining semantic and keyword scores."""
    query_vector = get_embedding(query)

    # 1. Semantic Retrieval (Get scores for all chunks)
    semantic_scores = {chunk_id: cosine_similarity(query_vector, vector) 
                       for chunk_id, (vector, _) in VECTOR_INDEX.items()}
    
    # 2. Keyword Retrieval
    keyword_matches = retrieve_keywords(query, KEYWORD_INDEX)
    
    # 3. Combine and Score
    composite_scores = {}
    all_chunk_ids = set(semantic_scores.keys())
    
    for chunk_id in all_chunk_ids:
        semantic_score = semantic_scores.get(chunk_id, 0.0) # Normalized 0 to 1
        
        # Keyword Score: Normalize keyword count (simple max normalization)
        max_keywords = max(keyword_matches.values()) if keyword_matches else 1
        keyword_count = keyword_matches.get(chunk_id, 0)
        keyword_score = keyword_count / max_keywords # Normalized 0 to 1
        
        # Weighted Composite Score (60% Semantic + 40% Keyword)
        composite_score = (0.6 * semantic_score) + (0.4 * keyword_score)
        
        composite_scores[chunk_id] = composite_score

    # Sort and return top K
    sorted_results = sorted(composite_scores.items(), key=lambda item: item[1], reverse=True)
    
    retrieved_chunks = []
    for chunk_id, score in sorted_results[:k]:
        text = VECTOR_INDEX[chunk_id][1]
        retrieved_chunks.append((text, score))
        
    return retrieved_chunks

# 5. Demonstration
print("--- Hybrid Search Demonstration ---")

# Rare keyword query (CUST-ID-993 is rare, but its surrounding text might be semantically weak)
TEST_QUERY = "I need information regarding the critical identifier CUST-ID-993."

# Simulate pure semantic retrieval (to show potential weakness)
semantic_results = semantic_retrieve(get_embedding(TEST_QUERY), k=3)
print(f"Pure Semantic Retrieval (Top 3 IDs and Scores): {semantic_results}")

# Hybrid Retrieval
hybrid_results = hybrid_retrieve(TEST_QUERY, k=5)

print("\nHybrid Retrieval Results (Top 5 Chunks):")
for text, score in hybrid_results:
    # Identify if the target chunk (containing CUST-ID-993) was retrieved
    target_marker = "<- TARGET CHUNK" if "CUST-ID-993" in text else ""
    print(f"  Score: {score:.4f} | Content: {text[:50]}... {target_marker}")

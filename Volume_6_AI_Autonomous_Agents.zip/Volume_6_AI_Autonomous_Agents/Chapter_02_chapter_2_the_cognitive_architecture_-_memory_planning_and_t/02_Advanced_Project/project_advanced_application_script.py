
#
# These sources are part of the "PyThon Programming Series" by Edgar Milvus, 
# you can find it on Amazon: https://www.amazon.com/dp/B0FTTQNXKG or
# https://tinyurl.com/PythonProgrammingSeries 
# New books info: https://linktr.ee/edgarmilvus 
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import json
from typing import Dict, Any, List
from langchain.agents import AgentExecutor, create_json_agent
from langchain_core.prompts import PromptTemplate
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferWindowMemory
import os

# --- 1. Setup and Configuration ---
# NOTE: Replace 'os.environ["OPENAI_API_KEY"]' with your actual setup.
# We use a powerful model suitable for complex reasoning and JSON output.
try:
    llm = ChatOpenAI(temperature=0.1, model="gpt-4-turbo-preview")
except Exception:
    # Fallback for environments without API key set, though production requires a real LLM.
    print("Warning: Using a mock LLM setup. Real-world execution requires API key.")
    from langchain.llms.fake import FakeListLLM
    llm = FakeListLLM(responses=["The agent completed the analysis successfully."])


# --- 2. Long-Term Memory (RAG Simulation) ---
# In a real system, this would be a VectorStore query. Here, we simulate retrieval.
KNOWLEDGE_BASE: Dict[str, str] = {
    "Project Alpha": "Initial market reports showed high demand for sustainable, subscription-based services in Q4 2023.",
    "Project Beta": "Competitor analysis revealed that pricing above $19.99 significantly reduced conversion rates for niche software tools.",
    "Current Product Idea": "A personalized AI-driven recipe planner targeting busy professionals."
}

def retrieve_rag_context(query: str) -> str:
    """Simulates retrieving relevant long-term knowledge based on the query."""
    if "pricing" in query.lower() or "conversion" in query.lower():
        return KNOWLEDGE_BASE["Project Beta"]
    return KNOWLEDGE_BASE["Project Alpha"]

# --- 3. External Tool Definition (Function Calling) ---

@tool
def external_market_data_search(query: str) -> str:
    """
    Searches an external database for current market saturation and competitor features.
    Returns a JSON string containing key market data points.
    """
    if "recipe planner" in query.lower():
        return json.dumps({
            "market_saturation": "High (7/10)",
            "key_competitors": ["MealPrep AI", "ChefBot Pro"],
            "competitor_pricing_range": "$14.99 - $24.99",
            "unique_feature_gap": "Lack of integrated grocery delivery functionality."
        })
    return json.dumps({"status": "No specific data found."})

tools = [external_market_data_search]

# --- 4. The Cognitive Architecture Prompt (Planning & Reflection) ---

# This prompt forces the agent into a specific, structured thought process.
SYSTEM_PROMPT = """
You are the Strategic Analyst Agent. Your goal is to refine a product idea based on internal knowledge and external data.

Your thought process MUST adhere to the following strict sequence:
1. **RAG Retrieval:** First, retrieve relevant internal knowledge using the current product idea and any known constraints.
2. **Tool Execution:** Next, use the `external_market_data_search` tool to gather current competitor and saturation data.
3. **Reflection:** Analyze the retrieved internal knowledge (RAG) alongside the external market data (Tool Output). Identify conflicts, opportunities, and risks.
4. **Final Plan:** Based on your reflection, provide a refined strategic recommendation for the product idea, including pricing suggestions and feature adjustments.

Use the available tools only when instructed in the planning step.
"""

# --- 5. Agent Initialization and Execution ---

# Initialize short-term memory (stores conversation history)
memory = ConversationBufferWindowMemory(k=5, memory_key="chat_history", return_messages=True)

# Define the input task
product_idea = "A personalized AI-driven recipe planner targeting busy professionals."
initial_task = f"""
Analyze the following product idea: '{product_idea}'.
Use all available resources (RAG and Tools) to generate a refined strategy.
"""

# Step 1: Inject RAG Context into the initial prompt before execution.
# This simulates the RAG step where context is retrieved and prepended to the user query.
rag_context = retrieve_rag_context(product_idea)
full_prompt_with_rag = f"--- INTERNAL KNOWLEDGE (RAG CONTEXT) ---\n{rag_context}\n\n--- USER TASK ---\n{initial_task}"

# Create the agent executor
agent_executor = AgentExecutor.from_agent_and_tools(
    tools=tools,
    llm=llm,
    agent=create_json_agent(llm, tools), # Using JSON agent for structured output/tool interaction
    memory=memory,
    verbose=True,
    handle_parsing_errors=True
)

print(f"Executing Agent with Initial Task:\n{full_prompt_with_rag}\n")

# Step 2: Run the agent
result = agent_executor.invoke({"input": full_prompt_with_rag})

print("\n--- FINAL STRATEGIC RECOMMENDATION ---")
print(result["output"])
